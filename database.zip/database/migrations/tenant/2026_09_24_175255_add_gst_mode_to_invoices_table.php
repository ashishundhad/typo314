<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Per-invoice GST mode: 'include' (prices entered already include GST,
     * tax is shown as a breakdown of the total, not added on top), 'exclude'
     * (GST added on top of the subtotal — this is the historical default
     * behavior, kept as the default here so existing invoices' displayed
     * totals don't change), or 'none' (no GST at all on this invoice,
     * regardless of the tenant's company-wide gst_enabled setting).
     *
     * Nullable so existing invoices (created before this column existed) are
     * distinguishable from ones that explicitly chose a mode — the invoice
     * display templates already infer "no GST" correctly for old rows from
     * their zero/null cgst_amount etc., so nothing needs backfilling here.
     */
    public function up(): void
    {
        Schema::table('invoices', function (Blueprint $table) {
            $table->enum('gst_mode', ['include', 'exclude', 'none'])->nullable()->after('igst_amount');
        });
    }

    public function down(): void
    {
        Schema::table('invoices', function (Blueprint $table) {
            $table->dropColumn('gst_mode');
        });
    }
};
