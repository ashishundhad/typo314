<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('purchases', function (Blueprint $table) {
            $table->enum('tracking_type', ['serialized', 'bulk'])->default('serialized')->after('device_type');
            $table->string('sku')->nullable()->after('brand');
            $table->unsignedInteger('quantity')->default(1)->after('purchase_price');
            $table->unsignedInteger('available_quantity')->default(1)->after('quantity');
            $table->string('imei')->nullable()->change();
        });
    }

    public function down(): void
    {
        Schema::table('purchases', function (Blueprint $table) {
            $table->dropColumn(['tracking_type', 'sku', 'quantity', 'available_quantity']);
            $table->string('imei')->nullable(false)->change();
        });
    }
};
