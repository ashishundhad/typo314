<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('pending_document_uploads', function (Blueprint $table) {
            $table->id();
            $table->uuid('token')->unique();
            $table->string('document_type')->nullable();
            $table->string('document_type_other')->nullable();
            $table->string('document_number')->nullable();
            $table->string('image_path')->nullable();
            $table->unsignedInteger('image_width')->nullable();
            $table->unsignedInteger('image_height')->nullable();
            $table->unsignedInteger('file_size')->nullable();
            // pending: QR generated, nothing submitted yet.
            // uploaded: phone submitted a document, waiting to be pulled into an invoice.
            // claimed: already attached to an invoice via storeCustomerDocuments().
            $table->enum('status', ['pending', 'uploaded', 'claimed'])->default('pending');
            $table->foreignId('created_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamp('expires_at');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('pending_document_uploads');
    }
};
