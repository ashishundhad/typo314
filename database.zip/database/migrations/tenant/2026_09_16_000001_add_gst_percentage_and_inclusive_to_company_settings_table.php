<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('company_settings', function (Blueprint $table) {
            $table->decimal('gst_percentage', 5, 2)->nullable()->after('gst_number');
            $table->boolean('gst_inclusive')->default(false)->after('gst_percentage');
        });
    }

    public function down(): void
    {
        Schema::table('company_settings', function (Blueprint $table) {
            $table->dropColumn(['gst_percentage', 'gst_inclusive']);
        });
    }
};
