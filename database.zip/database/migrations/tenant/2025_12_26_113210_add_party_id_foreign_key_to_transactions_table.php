<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * transactions.party_id's foreign key couldn't live in
     * 2025_06_07_123613_create_transactions_table (it predates parties, created in
     * 2025_12_26_113209_create_parties_table, by six months — the FK would fail on a
     * fresh database with "foreign key constraint is incorrectly formed"). Added here,
     * after parties exists. Guarded so it's a no-op against an already-migrated tenant
     * database that already has this constraint.
     */
    public function up(): void
    {
        if (! $this->hasForeignKey('transactions', 'transactions_party_id_foreign')) {
            Schema::table('transactions', function (Blueprint $table) {
                $table->foreign('party_id')
                    ->references('id')
                    ->on('parties')
                    ->onDelete('set null');
            });
        }
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        if ($this->hasForeignKey('transactions', 'transactions_party_id_foreign')) {
            Schema::table('transactions', function (Blueprint $table) {
                $table->dropForeign('transactions_party_id_foreign');
            });
        }
    }

    protected function hasForeignKey(string $table, string $constraint): bool
    {
        foreach (Schema::getForeignKeys($table) as $foreignKey) {
            if ($foreignKey['name'] === $constraint) {
                return true;
            }
        }

        return false;
    }
};
