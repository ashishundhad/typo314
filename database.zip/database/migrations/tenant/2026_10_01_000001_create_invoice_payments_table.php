<?php

use App\Models\Invoice;
use App\Models\InvoicePayment;
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('invoice_payments', function (Blueprint $table) {
            $table->id();
            $table->foreignId('invoice_id')->constrained('invoices')->cascadeOnDelete();
            $table->string('payment_method');
            $table->decimal('amount', 10, 2);
            $table->timestamps();

            $table->index('invoice_id');
        });

        // Backfill one row per existing invoice from its current single payment_type +
        // net_amount, so Daily Closing / Dashboard reports (which switch to reading this
        // table) don't suddenly show zero for everything billed before this migration.
        Invoice::query()->where('deleted', 0)->chunkById(500, function ($invoices): void {
            foreach ($invoices as $invoice) {
                InvoicePayment::create([
                    'invoice_id' => $invoice->id,
                    'payment_method' => $invoice->payment_type ?: 'Cash',
                    'amount' => $invoice->net_amount,
                ]);
            }
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('invoice_payments');
    }
};
