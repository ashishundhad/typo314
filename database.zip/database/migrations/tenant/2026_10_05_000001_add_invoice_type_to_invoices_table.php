<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('invoices', function (Blueprint $table) {
            // 'simple' keeps today's printed title ("RECEIPT"); 'tax' prints "TAX INVOICE"
            // instead. Defaults to 'simple' so every existing invoice keeps its current look.
            $table->enum('invoice_type', ['simple', 'tax'])->default('simple')->after('gst_mode');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('invoices', function (Blueprint $table) {
            $table->dropColumn('invoice_type');
        });
    }
};
