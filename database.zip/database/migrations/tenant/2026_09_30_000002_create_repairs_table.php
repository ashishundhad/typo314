<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('repairs', function (Blueprint $table) {
            $table->id();
            $table->string('customer_name')->nullable();
            $table->text('issue_description')->nullable();
            $table->date('repair_date')->nullable();
            $table->float('parts_cost', 10, 2)->nullable()->default(0);
            $table->float('repair_fee', 10, 2)->nullable()->default(0);
            $table->enum('status', ['received', 'repairing', 'delivered'])->default('received');
            // Set once billed via the "Generate Invoice" action, reusing the existing
            // Invoice/InvoiceItem pipeline (and therefore the existing profit reports and
            // ledger sync) instead of a parallel repair-revenue system.
            $table->foreignId('invoice_id')->nullable()->constrained('invoices')->nullOnDelete();
            $table->boolean('deleted')->default(0);
            $table->timestamps();

            $table->index(['deleted', 'status']);
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('repairs');
    }
};
