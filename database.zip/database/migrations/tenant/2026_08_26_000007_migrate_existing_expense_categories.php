<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    /**
     * Seeds the default category set and backfills expense_category_id from the old
     * expense_category enum string, mirroring 2026_08_11_090003_migrate_existing_invoice_customers.
     */
    public function up(): void
    {
        $defaults = ['General', 'Petrol', 'Food', 'Entertainment', 'Other'];
        $categoryIdByName = [];

        foreach ($defaults as $name) {
            $categoryIdByName[mb_strtolower($name)] = DB::table('expense_categories')->insertGetId([
                'name' => $name,
                'deleted' => 0,
                'created_at' => now(),
                'updated_at' => now(),
            ]);
        }

        $expenses = DB::table('expenses')->orderBy('id')->get();

        foreach ($expenses as $expense) {
            $name = trim((string) $expense->expense_category);
            $key = mb_strtolower($name !== '' ? $name : 'general');

            if (! isset($categoryIdByName[$key])) {
                $categoryIdByName[$key] = DB::table('expense_categories')->insertGetId([
                    'name' => $name !== '' ? $name : 'General',
                    'deleted' => 0,
                    'created_at' => now(),
                    'updated_at' => now(),
                ]);
            }

            DB::table('expenses')->where('id', $expense->id)->update([
                'expense_category_id' => $categoryIdByName[$key],
            ]);
        }
    }

    public function down(): void
    {
        DB::table('expenses')->update(['expense_category_id' => null]);
        DB::table('expense_categories')->truncate();
    }
};
