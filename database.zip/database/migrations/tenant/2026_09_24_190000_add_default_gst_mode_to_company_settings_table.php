<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Replaces the boolean gst_inclusive with a 3-way default for new
     * invoices — 'include', 'exclude', or 'none' (no GST counted by default,
     * but GSTIN still shows on invoices since that's gated on gst_enabled +
     * gst_number alone, not on this default). gst_inclusive is left in place
     * (unused going forward) rather than dropped, since it's harmless and
     * dropping it isn't necessary for this change.
     */
    public function up(): void
    {
        Schema::table('company_settings', function (Blueprint $table) {
            $table->enum('default_gst_mode', ['include', 'exclude', 'none'])
                ->default('exclude')
                ->after('gst_inclusive');
        });
    }

    public function down(): void
    {
        Schema::table('company_settings', function (Blueprint $table) {
            $table->dropColumn('default_gst_mode');
        });
    }
};
