<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('sale_returns', function (Blueprint $table) {
            $table->id();
            $table->foreignId('invoice_id')->constrained()->cascadeOnDelete();
            $table->foreignId('invoice_item_id')->constrained('invoice_items')->cascadeOnDelete();
            $table->foreignId('purchase_id')->constrained('purchases')->cascadeOnDelete();
            $table->unsignedInteger('quantity');
            $table->decimal('refund_amount', 15, 2);
            $table->enum('condition', ['resellable', 'damaged'])->default('resellable');
            $table->string('reason')->nullable();
            $table->text('notes')->nullable();
            $table->foreignId('processed_by')->constrained('users');
            $table->date('return_date');
            $table->boolean('deleted')->default(0);
            $table->timestamps();

            $table->index(['invoice_id', 'deleted']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('sale_returns');
    }
};
