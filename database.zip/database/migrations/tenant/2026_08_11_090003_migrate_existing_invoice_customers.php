<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        $invoices = DB::table('invoices')->orderBy('id')->get();

        $customerIdByPhone = [];
        $customerIdByName  = [];

        foreach ($invoices as $invoice) {
            $phone = trim((string) $invoice->customer_no);
            $name  = trim((string) $invoice->customer_name);
            $name  = $name !== '' ? $name : 'Walk-in Customer';
            $address = $invoice->customer_address;

            if ($phone !== '') {
                if (! isset($customerIdByPhone[$phone])) {
                    $customerIdByPhone[$phone] = DB::table('customers')->insertGetId([
                        'name'       => $name,
                        'phone'      => $phone,
                        'address'    => $address,
                        'deleted'    => 0,
                        'created_at' => $invoice->created_at ?? now(),
                        'updated_at' => $invoice->updated_at ?? now(),
                    ]);
                } else {
                    // Keep the most recently seen non-empty name/address for this phone.
                    DB::table('customers')
                        ->where('id', $customerIdByPhone[$phone])
                        ->update(array_filter([
                            'name'    => $name !== 'Walk-in Customer' ? $name : null,
                            'address' => $address,
                        ], fn ($value) => $value !== null && $value !== ''));
                }

                $customerId = $customerIdByPhone[$phone];
            } else {
                $nameKey = mb_strtolower($name);

                if (! isset($customerIdByName[$nameKey])) {
                    $customerIdByName[$nameKey] = DB::table('customers')->insertGetId([
                        'name'       => $name,
                        'phone'      => null,
                        'address'    => $address,
                        'deleted'    => 0,
                        'created_at' => $invoice->created_at ?? now(),
                        'updated_at' => $invoice->updated_at ?? now(),
                    ]);
                }

                $customerId = $customerIdByName[$nameKey];
            }

            DB::table('invoices')->where('id', $invoice->id)->update(['customer_id' => $customerId]);
        }
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        DB::table('invoices')->update(['customer_id' => null]);
        DB::table('customers')->truncate();
    }
};
