<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('transactions', function (Blueprint $table) {
            $table->id();
            $table->date('payment_date');
            $table->unsignedBigInteger('payment_method')->nullable();
            $table->text('note')->nullable();
            $table->enum('transaction_type', ['credit', 'debit']);
            $table->decimal('amount', 10, 2);
            $table->decimal('opening_balance', 10, 2)->default(0);
            $table->unsignedBigInteger('created_by');
            $table->unsignedBigInteger('party_id')->nullable();
            $table->timestamps();
            $table->softDeletes();

            $table->foreign('payment_method')
                  ->references('id')
                  ->on('payment_methods')
                  ->onDelete('set null');

            // party_id's foreign key is added in 2025_12_26_113210_add_party_id_foreign_key_to_transactions_table
            // — the parties table it references isn't created until 2025_12_26_113209_create_parties_table.
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('transactions');
    }
};