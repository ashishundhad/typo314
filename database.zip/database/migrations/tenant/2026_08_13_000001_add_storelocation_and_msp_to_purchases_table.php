<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Reconciles schema drift: storelocation and msp were added directly to the
     * live database without a migration. Guarded so it's a no-op where they
     * already exist, and creates them on fresh installs/tenant databases.
     */
    public function up(): void
    {
        Schema::table('purchases', function (Blueprint $table) {
            if (! Schema::hasColumn('purchases', 'storelocation')) {
                $table->string('storelocation', 50)->after('device_type');
            }

            if (! Schema::hasColumn('purchases', 'msp')) {
                $table->double('msp', 10, 2)->default(0)->after('purchase_price');
            }
        });
    }

    public function down(): void
    {
        Schema::table('purchases', function (Blueprint $table) {
            if (Schema::hasColumn('purchases', 'storelocation')) {
                $table->dropColumn('storelocation');
            }

            if (Schema::hasColumn('purchases', 'msp')) {
                $table->dropColumn('msp');
            }
        });
    }
};
