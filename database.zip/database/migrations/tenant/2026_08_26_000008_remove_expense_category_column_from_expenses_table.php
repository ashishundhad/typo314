<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('expenses', function (Blueprint $table) {
            // Replaced by expense_category_id, related to the new expense_categories table.
            $table->dropColumn('expense_category');
        });
    }

    public function down(): void
    {
        Schema::table('expenses', function (Blueprint $table) {
            $table->enum('expense_category', ['General', 'Petrol', 'Food', 'Entertainment', 'Other'])->nullable();
        });
    }
};
