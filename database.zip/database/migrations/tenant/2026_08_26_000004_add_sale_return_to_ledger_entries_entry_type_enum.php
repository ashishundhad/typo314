<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    /**
     * SQLite (used for the test suite) enforces the enum values that were present when the
     * table was created via a CHECK constraint, which can't be altered in place the way
     * MySQL's ENUM column can. This only needs to run for real (MySQL) tenant databases.
     */
    public function up(): void
    {
        if (! in_array(DB::getDriverName(), ['mysql', 'mariadb'], true)) {
            return;
        }

        DB::statement("ALTER TABLE ledger_entries MODIFY entry_type ENUM(
            'SALE', 'PURCHASE', 'EXPENSE', 'PAYMENT',
            'RECEIPT', 'TRANSFER', 'OPENING_BALANCE', 'SALE_RETURN'
        ) NOT NULL");
    }

    public function down(): void
    {
        if (! in_array(DB::getDriverName(), ['mysql', 'mariadb'], true)) {
            return;
        }

        DB::statement("ALTER TABLE ledger_entries MODIFY entry_type ENUM(
            'SALE', 'PURCHASE', 'EXPENSE', 'PAYMENT',
            'RECEIPT', 'TRANSFER', 'OPENING_BALANCE'
        ) NOT NULL");
    }
};
