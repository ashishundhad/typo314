<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * Deliberately separate from the legacy `purchases.document` column (a comma-joined
     * list of raw file paths) rather than migrating it: that column's upload field isn't
     * wired into any live form today (see resources/views/purchase/editpurchase.blade.php,
     * which the edit route never actually renders), so there's no live data flow to
     * preserve. New uploads — both the plain desktop file picker and the QR phone handoff
     * — go through this table instead, mirroring customer_documents so a future unified
     * "Documents" view can query both the same way.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('purchase_documents', function (Blueprint $table) {
            $table->id();
            $table->foreignId('purchase_id')->constrained()->cascadeOnDelete();
            $table->string('document_type')->nullable();
            $table->string('document_type_other')->nullable();
            $table->string('document_number')->nullable();
            $table->string('document_image');
            $table->unsignedInteger('image_width')->nullable();
            $table->unsignedInteger('image_height')->nullable();
            $table->unsignedInteger('file_size')->nullable();
            $table->foreignId('uploaded_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('purchase_documents');
    }
};
