<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        // Nearly every purchases query filters by deleted + is_sold together (stock
        // lists, dashboard totals, reports), and imei/purchase_date are hit on every
        // IMEI-search autocomplete keystroke and every date-ranged report — none of
        // that had index support beyond the primary key.
        Schema::table('purchases', function (Blueprint $table) {
            $table->index(['deleted', 'is_sold'], 'purchases_deleted_is_sold_index');
            $table->index('imei', 'purchases_imei_index');
            $table->index('purchase_date', 'purchases_purchase_date_index');
        });

        // Almost every report method filters invoices by deleted + a whereBetween on
        // invoice_date; only invoice_no had an index before this.
        Schema::table('invoices', function (Blueprint $table) {
            $table->index(['deleted', 'invoice_date'], 'invoices_deleted_invoice_date_index');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('purchases', function (Blueprint $table) {
            $table->dropIndex('purchases_deleted_is_sold_index');
            $table->dropIndex('purchases_imei_index');
            $table->dropIndex('purchases_purchase_date_index');
        });

        Schema::table('invoices', function (Blueprint $table) {
            $table->dropIndex('invoices_deleted_invoice_date_index');
        });
    }
};
