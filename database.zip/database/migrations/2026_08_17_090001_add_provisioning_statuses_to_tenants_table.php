<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        $driver = Schema::getConnection()->getDriverName();

        if (in_array($driver, ['mysql', 'mariadb'], true)) {
            DB::statement("ALTER TABLE tenants MODIFY status ENUM('provisioning', 'provisioning_failed', 'trial', 'active', 'suspended', 'cancelled') NOT NULL DEFAULT 'provisioning'");
        }
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        $driver = Schema::getConnection()->getDriverName();

        if (in_array($driver, ['mysql', 'mariadb'], true)) {
            DB::statement("UPDATE tenants SET status = 'trial' WHERE status IN ('provisioning', 'provisioning_failed')");
            DB::statement("ALTER TABLE tenants MODIFY status ENUM('trial', 'active', 'suspended', 'cancelled') NOT NULL DEFAULT 'trial'");
        }
    }
};
