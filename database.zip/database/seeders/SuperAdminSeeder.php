<?php
namespace Database\Seeders;

use App\Models\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class SuperAdminSeeder extends Seeder
{
    public function run(): void
    {
        // 1. Create Super Admin User
        $admin = User::firstOrCreate(
            ['email' => 'kishanpatel20205@gmail.com'],
            [
                'name'      => 'Kishan Patel',
                'user_name' => 'kishan_patel',
                'password'  => Hash::make('Kishan.20205'), // Make sure to update in prod
            ]
        );

        // 2/3/4. Role + permissions (shared with TenantDatabaseSeeder)
        $role = $this->resolve(RolesAndPermissionsSeeder::class)->run();

        // 5. Assign Role to Super Admin
        $admin->assignRole($role);
    }
}