<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Spatie\Permission\Models\Permission;
use Spatie\Permission\Models\Role;

/**
 * Creates the 'super-admin' role and the full permission set, in whatever database is
 * currently the default connection. Extracted from SuperAdminSeeder (which still seeds
 * the original dev-environment hardcoded admin) so TenantDatabaseSeeder can populate the
 * same role/permission set for a freshly provisioned tenant without duplicating this list.
 */
class RolesAndPermissionsSeeder extends Seeder
{
    public function run(): Role
    {
        $role = Role::firstOrCreate(['name' => 'super-admin', 'guard_name' => 'web']);

        $permissions = [
            // Dashboard
            'dashboard.view',

            // Profile
            'profile.view',
            'profile.update',
            'profile.password.change',

            // Purchases
            'purchases.view',
            'purchases.create',
            'purchases.edit',
            'purchases.delete',
            'purchases.import',
            'purchases.download.stock',

            // Sales
            'sales.view',
            'sales.create',
            'sales.edit',
            'sales.delete',
            'sales.fetch.stock',

            // Invoices
            'invoices.view',
            'invoices.create',
            'invoices.edit',
            'invoices.print',
            'invoices.detail',

            // Sale Returns
            'returns.view',
            'returns.create',
            'returns.delete',

            // Repairs
            'repairs.view',
            'repairs.create',
            'repairs.edit',
            'repairs.delete',

            // Reports
            'reports.sales.view',
            'reports.sales.export',
            'reports.purchases.view',
            'reports.purchases.export',
            'reports.customers.view',
            'reports.customers.export',
            'reports.charts.view',

            // Expenses
            'expenses.view',
            'expenses.create',
            'expenses.edit',
            'expenses.delete',

            // Expense Categories
            'expense-categories.view',
            'expense-categories.create',
            'expense-categories.edit',
            'expense-categories.delete',

            // Transactions
            'transactions.view',
            'transactions.create',
            'transactions.edit',
            'transactions.delete',
            'transactions.resync',

            // Google Sync
            'google.sync',

            // Roles
            'roles.view',
            'roles.create',
            'roles.edit',
            'roles.delete',

            // Users
            'users.view',
            'users.create',
            'users.edit',
            'users.delete',
        ];

        foreach ($permissions as $permissionName) {
            $permission = Permission::firstOrCreate(
                ['name' => $permissionName],
                ['guard_name' => 'web']
            );
            $role->givePermissionTo($permission);
        }

        return $role;
    }
}
