<?php

namespace Database\Seeders;

use App\Models\Plan;
use Illuminate\Database\Seeder;

class PlanSeeder extends Seeder
{
    public function run(): void
    {
        $plan = Plan::firstOrCreate(
            ['slug' => 'fonico-standard'],
            [
                'name' => 'Fonico Standard',
                'description' => 'Full access to all Fonico features.',
                'is_active' => true,
                'default_trial_days' => 2,
            ]
        );

        $plan->prices()->firstOrCreate(
            ['billing_cycle' => 'monthly'],
            ['amount' => 249.00, 'currency' => 'INR', 'is_active' => true]
        );

        $plan->prices()->firstOrCreate(
            ['billing_cycle' => 'yearly'],
            ['amount' => 2399.00, 'currency' => 'INR', 'is_active' => true]
        );
    }
}
