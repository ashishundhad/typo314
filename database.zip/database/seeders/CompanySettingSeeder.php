<?php

namespace Database\Seeders;

use App\Models\CompanySetting;
use Illuminate\Database\Seeder;

class CompanySettingSeeder extends Seeder
{
    public function run(): void
    {
        CompanySetting::firstOrCreate(['id' => 1], [
            'company_name' => 'FONICO Mobile',
            'logo'         => 'assets/images/new_logo/fonico_mobiles.jpg',
            'address'      => 'Bodakdev, Ahmedabad - 380054',
            'phone'        => '+91 99934 76489',
            'email'        => null,
            'gst_enabled'  => false,
            'gst_number'   => null,
        ]);
    }
}
