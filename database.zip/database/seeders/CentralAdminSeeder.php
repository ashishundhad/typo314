<?php

namespace Database\Seeders;

use App\Models\CentralAdmin;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class CentralAdminSeeder extends Seeder
{
    public function run(): void
    {
        CentralAdmin::firstOrCreate(
            ['email' => 'admin@fonico.test'],
            [
                'name' => 'Fonico Admin',
                'password' => Hash::make('password'),
            ]
        );
    }
}
