<?php

namespace Database\Seeders;

use App\Models\CompanySetting;
use App\Models\Tenant;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

/**
 * Seeds a freshly provisioned tenant database (see App\Jobs\InitializeTenantSettings).
 * Runs with the tenant's own DB as the default connection (via Tenant::run()), so every
 * seeder called here writes into that tenant's database, never the central one.
 *
 * Unlike CompanySettingSeeder (which seeds the original single-tenant app's real,
 * hardcoded company details), this seeds a generic default using the new tenant's own
 * name — each tenant is a different business and shouldn't start out branded "FONICO Mobile".
 */
class TenantDatabaseSeeder extends Seeder
{
    public function run(): void
    {
        $this->call(RolesAndPermissionsSeeder::class);

        // PaymentMethodsSeeder does a raw insert (no firstOrCreate) — guard it here so
        // retryProvisioning() can safely re-run this whole seeder without hitting the
        // unique constraint on payment_methods.slug.
        if (DB::table('payment_methods')->doesntExist()) {
            $this->call(PaymentMethodsSeeder::class);
        }

        $tenant = tenant();

        CompanySetting::firstOrCreate(['id' => 1], [
            'company_name' => $tenant instanceof Tenant ? ($tenant->name ?? $tenant->getTenantKey()) : config('app.name'),
            'gst_enabled' => false,
        ]);
    }
}
