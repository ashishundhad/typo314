<?php

declare(strict_types=1);

namespace App\Services;

use App\Models\Plan;
use App\Models\Tenant;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Str;
use RuntimeException;
use Stancl\Tenancy\Events\TenantCreated;

/**
 * Provisions new tenants for the Fonico SaaS migration (Phase 3).
 *
 * Flow: validate -> create central tenant/domain/subscription rows (one DB transaction,
 * central connection) -> the resulting Tenant::create() call fires Stancl's TenantCreated
 * event, which (see TenancyServiceProvider) queues the job pipeline that creates the
 * physical tenant database, migrates it, creates the admin user, and seeds tenant
 * settings. That pipeline runs on the queue (config/queue.php's 'database' connection
 * has after_commit => true, so it only starts once this transaction actually commits) —
 * this method returns as soon as the central rows are written, without waiting for the
 * tenant database to exist.
 *
 * Recovery: if any pipeline step fails, the tenant is left with status
 * 'provisioning_failed' (see App\Jobs\Concerns\HandlesProvisioningFailure) instead of
 * silently stuck — retryProvisioning() re-fires the same, idempotent pipeline.
 */
class TenantService
{
    public function __construct(protected SubscriptionService $subscriptions)
    {
    }

    public function provision(array $data): Tenant
    {
        $validated = Validator::make($data, $this->rules())->validate();

        $tenant = DB::transaction(function () use ($validated) {
            $plan = Plan::findOrFail($validated['plan_id']);
            $planPrice = $plan->prices()->where('billing_cycle', $validated['billing_cycle'])->first();

            $slug = $validated['id'] ?? $this->generateUniqueSlug($validated['name']);

            $tenant = Tenant::create([
                'id' => $slug,
                'status' => 'provisioning',
                'name' => $validated['name'],
                // Stashed transiently on the tenant's data column so the queued
                // provisioning jobs (which may run in a separate worker process) can
                // create the admin user without needing the original request's input.
                // Never the plaintext password — only its hash. Cleared once used,
                // see App\Jobs\CreateTenantAdminUser.
                'admin_name' => $validated['admin_name'],
                'admin_email' => $validated['admin_email'],
                'admin_password_hash' => Hash::make($validated['admin_password']),
            ]);

            $tenant->domains()->create(['domain' => $validated['domain']]);

            $this->subscriptions->startTrial($tenant, $plan, $planPrice);

            return $tenant;
        });

        return $tenant->fresh(['domains', 'subscription']);
    }

    /**
     * Re-run the provisioning pipeline for a tenant stuck in 'provisioning' (e.g. a
     * queue worker died mid-run) or 'provisioning_failed'. Safe to call repeatedly:
     * every job in the pipeline is idempotent (see TenancyServiceProvider).
     */
    public function retryProvisioning(Tenant $tenant): void
    {
        if (! in_array($tenant->status, ['provisioning', 'provisioning_failed'], true)) {
            throw new RuntimeException(
                "Tenant '{$tenant->getTenantKey()}' is not in a provisioning state (current status: {$tenant->status})."
            );
        }

        $tenant->forceFill(['status' => 'provisioning'])->save();

        event(new TenantCreated($tenant));
    }

    /**
     * Public so callers that need to know the slug before calling provision()
     * — e.g. the public signup form, which must build a matching `domain`
     * string from the same slug — can compute it up front instead of letting
     * provision() generate one internally that they'd have no way to see.
     */
    public function generateUniqueSlug(string $name): string
    {
        $base = Str::slug($name) ?: 'tenant';
        $slug = $base;
        $attempt = 1;

        while (Tenant::whereKey($slug)->exists()) {
            $attempt++;
            $slug = "{$base}-{$attempt}";
        }

        return $slug;
    }

    protected function rules(): array
    {
        return [
            'name' => ['required', 'string', 'max:255'],
            'id' => ['nullable', 'alpha_dash', 'max:63', 'unique:tenants,id'],
            'domain' => ['required', 'string', 'max:255', 'unique:domains,domain'],
            'plan_id' => ['required', 'exists:plans,id'],
            'billing_cycle' => ['required', 'in:monthly,yearly'],
            'admin_name' => ['required', 'string', 'max:255'],
            'admin_email' => ['required', 'email', 'max:255'],
            'admin_password' => ['required', 'string', 'min:8'],
        ];
    }
}
