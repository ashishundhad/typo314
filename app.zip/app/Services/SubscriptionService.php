<?php

declare(strict_types=1);

namespace App\Services;

use App\Models\Payment;
use App\Models\Plan;
use App\Models\PlanPrice;
use App\Models\Subscription;
use App\Models\Tenant;
use Illuminate\Support\Facades\DB;

/**
 * The single place that ever writes subscriptions.status and tenants.status
 * together — both fields exist (see the two migrations that added them
 * independently), but the app has exactly one subscription domain, and this
 * service is what keeps them from drifting apart. Nothing else should ever
 * write either column directly.
 *
 * There are no feature-based plans and no per-feature restrictions: every
 * subscription (trial or paid) grants full access to everything. The only
 * question this domain answers is binary — does this tenant currently have
 * access at all — see Subscription::hasAccess() and EnsureSubscriptionActive.
 */
class SubscriptionService
{
    /**
     * Start a new tenant on its trial. Trial length is per-plan and
     * configurable via plans.default_trial_days — not hardcoded here.
     */
    public function startTrial(Tenant $tenant, Plan $plan, ?PlanPrice $planPrice): Subscription
    {
        return Subscription::create([
            'tenant_id' => $tenant->id,
            'plan_id' => $plan->id,
            'plan_price_id' => $planPrice?->id,
            'status' => 'trialing',
            'trial_ends_at' => now()->addDays($plan->default_trial_days),
        ]);
    }

    /**
     * Suspend a tenant: blocks access, but never touches tenant data — the
     * tenant's physical database is completely untouched by this call.
     */
    public function suspend(Tenant $tenant): void
    {
        DB::transaction(function () use ($tenant) {
            $tenant->update(['status' => 'suspended']);
            $tenant->subscription?->update(['status' => 'suspended']);
        });
    }

    /**
     * Admin-triggered reactivation with no payment involved (operator
     * discretion) — restores access immediately and extends the current
     * period by one billing cycle from now.
     */
    public function reactivateManually(Tenant $tenant): void
    {
        DB::transaction(function () use ($tenant) {
            $tenant->update(['status' => 'active']);

            if ($subscription = $tenant->subscription) {
                $this->activateAndExtendPeriod($subscription);
            }
        });
    }

    /**
     * Record a pending payment against a subscription — the seam a future
     * payment gateway integration will call into (e.g. from a webhook
     * controller), once one exists. Does not affect access by itself.
     */
    public function recordPayment(Subscription $subscription, array $attributes): Payment
    {
        return $subscription->payments()->create(array_merge([
            'status' => 'pending',
        ], $attributes));
    }

    /**
     * Confirm a payment succeeded and restore access immediately — this is
     * "renewal", and it's the other seam a future gateway integration calls
     * into (instead of reactivateManually(), which is for admin discretion
     * with no real payment behind it).
     */
    public function confirmPayment(Payment $payment): void
    {
        DB::transaction(function () use ($payment) {
            $payment->markSucceeded();

            $subscription = $payment->subscription;
            $subscription->tenant->update(['status' => 'active']);
            $this->activateAndExtendPeriod($subscription);
        });
    }

    /**
     * The manual-admin equivalent of a gateway webhook: the operator has
     * confirmed money was actually received (bank transfer, cash, etc.) and
     * is logging it after the fact — records the payment as already
     * succeeded and immediately restores access, in one step.
     */
    public function recordAndConfirmPayment(Subscription $subscription, array $attributes): Payment
    {
        return DB::transaction(function () use ($subscription, $attributes) {
            $payment = $this->recordPayment($subscription, $attributes);
            $this->confirmPayment($payment);

            return $payment->fresh();
        });
    }

    /**
     * Find every subscription whose trial or paid period has ended without a
     * renewal, and suspend the owning tenant. Status-only — never touches
     * tenant data. Intended to run on a daily schedule (see
     * App\Console\Commands\ExpireSubscriptions).
     */
    public function expireDueSubscriptions(): int
    {
        $now = now();

        $due = Subscription::with('tenant')
            ->where(function ($query) use ($now) {
                $query->where(function ($q) use ($now) {
                    $q->where('status', 'trialing')->where('trial_ends_at', '<=', $now);
                })->orWhere(function ($q) use ($now) {
                    $q->where('status', 'active')->where('current_period_ends_at', '<=', $now);
                });
            })
            ->get();

        foreach ($due as $subscription) {
            if ($subscription->tenant) {
                $this->suspend($subscription->tenant);
            }
        }

        return $due->count();
    }

    /**
     * Shared by reactivateManually() and confirmPayment(): flips the
     * subscription to active and extends current_period_ends_at by one
     * billing cycle (monthly/yearly) from now, based on the subscription's
     * own plan price — not a hardcoded interval.
     */
    protected function activateAndExtendPeriod(Subscription $subscription): void
    {
        $cycle = $subscription->planPrice?->billing_cycle;

        $periodEnd = match ($cycle) {
            'yearly' => now()->addYear(),
            default => now()->addMonth(),
        };

        $subscription->update([
            'status' => 'active',
            'current_period_starts_at' => now(),
            'current_period_ends_at' => $periodEnd,
        ]);
    }
}
