<?php

namespace App\Services;

use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use RuntimeException;

class DocumentImageService
{
    /**
     * Longest side (px) an optimized document photo is allowed to have.
     */
    private const MAX_DIMENSION = 1600;

    /**
     * WebP encoding quality (0-100). 80 keeps document text legible at a much smaller size.
     */
    private const WEBP_QUALITY = 80;

    /**
     * Convert an uploaded identity document photo to an optimized WebP file
     * and store it on the public disk.
     *
     * @return array{path: string, width: int, height: int, size: int}
     */
    public function optimizeAndStore(UploadedFile $file, string $directory): array
    {
        $source = $this->loadImage($file);

        [$resized, $width, $height] = $this->resizeIfNeeded($source);

        $filename = Str::uuid() . '.webp';
        $relativePath = trim($directory, '/') . '/' . $filename;
        $absoluteDir = Storage::disk('public')->path(trim($directory, '/'));

        if (! is_dir($absoluteDir)) {
            mkdir($absoluteDir, 0755, true);
        }

        $absolutePath = Storage::disk('public')->path($relativePath);

        imagewebp($resized, $absolutePath, self::WEBP_QUALITY);

        imagedestroy($source);
        if ($resized !== $source) {
            imagedestroy($resized);
        }

        return [
            'path'   => $relativePath,
            'width'  => $width,
            'height' => $height,
            'size'   => filesize($absolutePath) ?: 0,
        ];
    }

    /**
     * Delete a previously stored document image from the public disk.
     */
    public function delete(?string $relativePath): void
    {
        if ($relativePath && Storage::disk('public')->exists($relativePath)) {
            Storage::disk('public')->delete($relativePath);
        }
    }

    /**
     * @return \GdImage
     */
    private function loadImage(UploadedFile $file)
    {
        $path = $file->getRealPath();
        $mime = $file->getMimeType();

        $image = match ($mime) {
            'image/jpeg' => imagecreatefromjpeg($path),
            'image/png'  => imagecreatefrompng($path),
            'image/webp' => imagecreatefromwebp($path),
            default      => false,
        };

        if ($image === false) {
            throw new RuntimeException('Unable to read uploaded document image.');
        }

        return $image;
    }

    /**
     * @param  \GdImage  $source
     * @return array{0: \GdImage, 1: int, 2: int}
     */
    private function resizeIfNeeded($source): array
    {
        $originalWidth = imagesx($source);
        $originalHeight = imagesy($source);
        $longestSide = max($originalWidth, $originalHeight);

        if ($longestSide <= self::MAX_DIMENSION) {
            return [$source, $originalWidth, $originalHeight];
        }

        $scale = self::MAX_DIMENSION / $longestSide;
        $newWidth = (int) round($originalWidth * $scale);
        $newHeight = (int) round($originalHeight * $scale);

        $resized = imagecreatetruecolor($newWidth, $newHeight);
        imagecopyresampled($resized, $source, 0, 0, 0, 0, $newWidth, $newHeight, $originalWidth, $originalHeight);

        return [$resized, $newWidth, $newHeight];
    }
}
