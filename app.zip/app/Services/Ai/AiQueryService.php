<?php

namespace App\Services\Ai;

use App\Models\Invoice;
use App\Models\InvoiceItem;
use App\Models\Purchase;
use App\Models\User;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Arr;
use InvalidArgumentException;

class AiQueryService
{
    public function execute(User $user, string $toolName, array $arguments): array
    {
        return match ($toolName) {
            'get_sales_summary' => $this->getSalesSummary($user, $arguments),
            'get_stock_summary' => $this->getStockSummary($user),
            'get_invoice_details' => $this->getInvoiceDetails($user, $arguments),
            'get_purchase_summary' => $this->getPurchaseSummary($user, $arguments),
            default => [
                'status' => 'error',
                'message' => 'Unsupported tool request.',
            ],
        };
    }

    public function toolDefinitions(): array
    {
        return [
            [
                'type' => 'function',
                'name' => 'get_sales_summary',
                'description' => 'Get invoice sales totals for a date range. Use when the user asks about sales, revenue, invoices, profit, or sold items.',
                'parameters' => [
                    'type' => 'object',
                    'properties' => [
                        'from_date' => [
                            'type' => ['string', 'null'],
                            'description' => 'Start date in YYYY-MM-DD format.',
                        ],
                        'to_date' => [
                            'type' => ['string', 'null'],
                            'description' => 'End date in YYYY-MM-DD format.',
                        ],
                    ],
                    'required' => ['from_date', 'to_date'],
                    'additionalProperties' => false,
                ],
                'strict' => true,
            ],
            [
                'type' => 'function',
                'name' => 'get_stock_summary',
                'description' => 'Get current stock counts and values from purchases. Use when the user asks about stock in hand, sold or unsold devices, inventory value, or current inventory.',
                'parameters' => [
                    'type' => 'object',
                    'properties' => new \stdClass(),
                    'required' => [],
                    'additionalProperties' => false,
                ],
                'strict' => true,
            ],
            [
                'type' => 'function',
                'name' => 'get_invoice_details',
                'description' => 'Look up a specific invoice by invoice number or internal invoice id.',
                'parameters' => [
                    'type' => 'object',
                    'properties' => [
                        'invoice_no' => [
                            'type' => ['string', 'null'],
                            'description' => 'Exact invoice number, if the user mentions it.',
                        ],
                        'invoice_id' => [
                            'type' => ['integer', 'null'],
                            'description' => 'Internal invoice id, if the user mentions it.',
                        ],
                    ],
                    'required' => ['invoice_no', 'invoice_id'],
                    'additionalProperties' => false,
                ],
                'strict' => true,
            ],
            [
                'type' => 'function',
                'name' => 'get_purchase_summary',
                'description' => 'Get purchase totals for a date range. Use when the user asks about purchases, buying spend, stock bought, or inventory procurement.',
                'parameters' => [
                    'type' => 'object',
                    'properties' => [
                        'from_date' => [
                            'type' => ['string', 'null'],
                            'description' => 'Start date in YYYY-MM-DD format.',
                        ],
                        'to_date' => [
                            'type' => ['string', 'null'],
                            'description' => 'End date in YYYY-MM-DD format.',
                        ],
                    ],
                    'required' => ['from_date', 'to_date'],
                    'additionalProperties' => false,
                ],
                'strict' => true,
            ],
        ];
    }

    protected function getSalesSummary(User $user, array $arguments): array
    {
        [$fromDate, $toDate] = $this->resolveDateRange($arguments);

        $invoiceQuery = Invoice::query()
            ->where('deleted', 0)
            ->whereBetween('invoice_date', [$fromDate, $toDate]);

        $invoices = (clone $invoiceQuery)
            ->with('customer:id,name')
            ->orderBy('invoice_date', 'desc')
            ->orderBy('created_at', 'desc')
            ->get([
                'id',
                'invoice_no',
                'invoice_date',
                'customer_id',
                'net_amount',
                'payment_type',
            ]);

        $invoiceItemQuery = InvoiceItem::query()
            ->where('deleted', 0)
            ->whereHas('invoice', function (Builder $query) use ($fromDate, $toDate) {
                $query->where('deleted', 0)->whereBetween('invoice_date', [$fromDate, $toDate]);
            });

        return [
            'status' => 'ok',
            'range' => [
                'from_date' => $fromDate,
                'to_date' => $toDate,
            ],
            'summary' => [
                'invoice_count' => $invoices->count(),
                'total_sales' => round((float) $invoices->sum('net_amount'), 2),
                'average_invoice_value' => round((float) $invoices->avg('net_amount'), 2),
                'total_items_sold' => (int) (clone $invoiceItemQuery)->sum('quantity'),
                'gross_profit' => round((float) (clone $invoiceItemQuery)->sum('profit'), 2),
            ],
            'recent_invoices' => $invoices->take(5)->map(fn (Invoice $invoice) => [
                'invoice_id' => $invoice->id,
                'invoice_no' => $invoice->invoice_no,
                'invoice_date' => $invoice->invoice_date,
                'customer_name' => $invoice->customer_name,
                'net_amount' => round((float) $invoice->net_amount, 2),
                'payment_type' => $invoice->payment_type,
            ])->values()->all(),
        ];
    }

    protected function getStockSummary(User $user): array
    {
        $query = Purchase::query()
            ->where('deleted', 0);

        $allPurchases = (clone $query)->get([
            'id',
            'brand',
            'model',
            'purchase_price',
            'purchase_cost',
            'is_sold',
        ]);

        $unsoldPurchases = $allPurchases->where('is_sold', 0);

        $topBrands = $unsoldPurchases
            ->groupBy(fn ($purchase) => trim((string) ($purchase->brand ?: 'Unknown')))
            ->map(fn ($items, $brand) => [
                'brand' => $brand,
                'count' => $items->count(),
            ])
            ->sortByDesc('count')
            ->take(5)
            ->values()
            ->all();

        return [
            'status' => 'ok',
            'summary' => [
                'total_purchases' => $allPurchases->count(),
                'sold_items' => $allPurchases->where('is_sold', 1)->count(),
                'unsold_items' => $unsoldPurchases->count(),
                'purchase_spend' => round((float) $allPurchases->sum('purchase_cost'), 2),
                'stock_value' => round((float) $allPurchases->sum('purchase_price'), 2),
                'unsold_stock_value' => round((float) $unsoldPurchases->sum('purchase_price'), 2),
            ],
            'top_unsold_brands' => $topBrands,
        ];
    }

    protected function getInvoiceDetails(User $user, array $arguments): array
    {
        $invoiceId = Arr::get($arguments, 'invoice_id');
        $invoiceNo = trim((string) Arr::get($arguments, 'invoice_no', ''));

        if (! $invoiceId && $invoiceNo === '') {
            return [
                'status' => 'error',
                'message' => 'An invoice id or invoice number is required.',
            ];
        }

        $invoice = Invoice::with(['items.purchase'])
            ->where('deleted', 0)
            ->when($invoiceId, fn (Builder $query) => $query->where('id', $invoiceId))
            ->when($invoiceNo !== '', fn (Builder $query) => $query->where('invoice_no', $invoiceNo))
            ->orderByDesc('id')
            ->first();

        if (! $invoice) {
            return [
                'status' => 'not_found',
                    'message' => 'No matching invoice was found in the live data for this user scope.',
            ];
        }

        return [
            'status' => 'ok',
            'invoice' => [
                'invoice_id' => $invoice->id,
                'invoice_no' => $invoice->invoice_no,
                'invoice_date' => $invoice->invoice_date,
                'customer_name' => $invoice->customer_name,
                'customer_no' => $invoice->customer_no,
                'payment_type' => $invoice->payment_type,
                'net_amount' => round((float) $invoice->net_amount, 2),
                'tax_amount' => round((float) $invoice->tax_amount, 2),
                'discount' => round((float) $invoice->discount, 2),
                'quantity' => (int) $invoice->quantity,
                'items' => $invoice->items
                    ->where('deleted', 0)
                    ->map(fn (InvoiceItem $item) => [
                        'item_id' => $item->item_id,
                        'description' => $item->item_description,
                        'quantity' => (int) $item->quantity,
                        'unit_price' => round((float) $item->unit_price, 2),
                        'total_amount' => round((float) $item->total_amount, 2),
                        'brand' => $item->purchase?->brand,
                        'model' => $item->purchase?->model,
                        'imei' => $item->purchase?->imei,
                    ])
                    ->values()
                    ->all(),
            ],
        ];
    }

    protected function getPurchaseSummary(User $user, array $arguments): array
    {
        [$fromDate, $toDate] = $this->resolveDateRange($arguments);

        $query = Purchase::query()
            ->where('deleted', 0)
            ->whereBetween('purchase_date', [$fromDate, $toDate]);

        $purchases = (clone $query)
            ->orderBy('purchase_date', 'desc')
            ->orderBy('created_at', 'desc')
            ->get([
                'id',
                'purchase_date',
                'brand',
                'model',
                'purchase_from',
                'purchase_cost',
                'repairing_charge',
                'purchase_price',
                'is_sold',
            ]);

        return [
            'status' => 'ok',
            'range' => [
                'from_date' => $fromDate,
                'to_date' => $toDate,
            ],
            'summary' => [
                'purchase_count' => $purchases->count(),
                'sold_items' => $purchases->where('is_sold', 1)->count(),
                'available_items' => $purchases->where('is_sold', 0)->count(),
                'total_purchase_cost' => round((float) $purchases->sum('purchase_cost'), 2),
                'total_repairing_charge' => round((float) $purchases->sum('repairing_charge'), 2),
                'total_stock_value' => round((float) $purchases->sum('purchase_price'), 2),
            ],
            'recent_purchases' => $purchases->take(5)->map(fn (Purchase $purchase) => [
                'purchase_id' => $purchase->id,
                'purchase_date' => $purchase->purchase_date,
                'brand' => $purchase->brand,
                'model' => $purchase->model,
                'purchase_from' => $purchase->purchase_from,
                'purchase_cost' => round((float) $purchase->purchase_cost, 2),
                'purchase_price' => round((float) $purchase->purchase_price, 2),
                'is_sold' => (bool) $purchase->is_sold,
            ])->values()->all(),
        ];
    }

    protected function resolveDateRange(array $arguments): array
    {
        $fromDate = trim((string) Arr::get($arguments, 'from_date', ''));
        $toDate = trim((string) Arr::get($arguments, 'to_date', ''));

        if ($fromDate === '' && $toDate === '') {
            $today = now()->toDateString();

            return [$today, $today];
        }

        $start = $fromDate !== '' ? Carbon::parse($fromDate)->toDateString() : Carbon::parse($toDate)->toDateString();
        $end = $toDate !== '' ? Carbon::parse($toDate)->toDateString() : $start;

        if ($start > $end) {
            throw new InvalidArgumentException('The from_date cannot be after to_date.');
        }

        return [$start, $end];
    }

}
