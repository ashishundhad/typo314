<?php

namespace App\Services\Ai;

use App\Models\User;
use Illuminate\Http\Client\Factory as HttpFactory;
use Illuminate\Http\Client\RequestException;
use RuntimeException;
use Throwable;

class OpenAiChatService
{
    public function __construct(
        protected HttpFactory $http,
        protected AiQueryService $queryService
    ) {
    }

    public function respond(User $user, string $question, array $history = []): array
    {
        $apiKey = (string) config('services.openai.api_key');

        if ($apiKey === '') {
            throw new RuntimeException('OPENAI_API_KEY is missing. Add it to your environment before using the assistant.');
        }

        $response = $this->createResponse(
            $apiKey,
            $this->buildConversationInput($user, $question, $history),
            $this->queryService->toolDefinitions()
        );

        $toolsUsed = [];

        for ($attempt = 0; $attempt < 4; $attempt++) {
            $functionCalls = collect($response['output'] ?? [])
                ->filter(fn (array $item) => ($item['type'] ?? null) === 'function_call')
                ->values();

            if ($functionCalls->isEmpty()) {
                break;
            }

            $toolOutputs = [];

            foreach ($functionCalls as $functionCall) {
                $arguments = json_decode((string) ($functionCall['arguments'] ?? '{}'), true);

                if (! is_array($arguments)) {
                    $arguments = [];
                }

                try {
                    $toolResult = $this->queryService->execute($user, (string) $functionCall['name'], $arguments);
                } catch (Throwable $exception) {
                    $toolResult = [
                        'status' => 'error',
                        'message' => $exception->getMessage(),
                    ];
                }

                $toolsUsed[] = [
                    'name' => $functionCall['name'] ?? 'unknown',
                    'arguments' => $arguments,
                ];

                $toolOutputs[] = [
                    'type' => 'function_call_output',
                    'call_id' => $functionCall['call_id'],
                    'output' => json_encode($toolResult, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE),
                ];
            }

            $response = $this->createResponse(
                $apiKey,
                $toolOutputs,
                [],
                $response['id'] ?? null
            );
        }

        $answer = trim((string) ($response['output_text'] ?? $this->extractOutputText($response)));

        if ($answer === '') {
            $answer = 'I could not find enough live data to answer that yet.';
        }

        return [
            'answer' => $answer,
            'tools' => $toolsUsed,
            'response_id' => $response['id'] ?? null,
        ];
    }

    protected function buildConversationInput(User $user, string $question, array $history): array
    {
        $messages = [[
            'role' => 'system',
            'content' => $this->systemPrompt($user),
        ]];

        foreach (collect($history)->take(-8) as $message) {
            $role = $message['role'] ?? null;

            if (! in_array($role, ['user', 'assistant'], true)) {
                continue;
            }

            $messages[] = [
                'role' => $role,
                'content' => (string) ($message['content'] ?? ''),
            ];
        }

        $messages[] = [
            'role' => 'user',
            'content' => $question,
        ];

        return $messages;
    }

    protected function systemPrompt(User $user): string
    {
        return implode("\n", [
            'You are a read-only business assistant for the Fonico backend.',
            'Only answer from live tool results returned by the application.',
            'Never invent records, numbers, dates, invoice ids, invoice numbers, customer details, or stock values.',
            'If the user asks for data you cannot retrieve with a tool, say that this MVP cannot answer it yet.',
            'If the request is ambiguous, ask a short clarifying question instead of guessing.',
            'Keep answers concise, clear, and business-focused.',
            'Use absolute dates in YYYY-MM-DD format when referring to a queried range.',
            'When no date is provided for sales or purchases, treat it as today unless the user clearly asks otherwise.',
        ]);
    }

    protected function createResponse(
        string $apiKey,
        array $input,
        array $tools = [],
        ?string $previousResponseId = null
    ): array {
        $payload = [
            'model' => (string) config('services.openai.model', 'gpt-4.1-mini'),
            'input' => $input,
        ];

        if ($previousResponseId !== null) {
            $payload['previous_response_id'] = $previousResponseId;
        } elseif ($tools !== []) {
            $payload['tools'] = $tools;
        }

        try {
            return $this->http
                ->baseUrl((string) config('services.openai.base_url', 'https://api.openai.com/v1'))
                ->timeout((int) config('services.openai.timeout', 30))
                ->withToken($apiKey)
                ->acceptJson()
                ->asJson()
                ->post('/responses', $payload)
                ->throw()
                ->json();
        } catch (RequestException $exception) {
            $message = $exception->response?->json('error.message')
                ?? $exception->response?->body()
                ?? $exception->getMessage();

            throw new RuntimeException('OpenAI request failed: ' . $message, previous: $exception);
        }
    }

    protected function extractOutputText(array $response): string
    {
        $texts = [];

        foreach ($response['output'] ?? [] as $item) {
            if (($item['type'] ?? null) !== 'message') {
                continue;
            }

            foreach ($item['content'] ?? [] as $content) {
                if (($content['type'] ?? null) === 'output_text') {
                    $texts[] = $content['text'] ?? '';
                }
            }
        }

        return trim(implode("\n", $texts));
    }
}
