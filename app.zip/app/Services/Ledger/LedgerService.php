<?php

namespace App\Services\Ledger;

use App\Models\Invoice;
use App\Models\LedgerEntry;
use App\Models\Party;
use App\Models\PartyLedger;
use App\Models\PaymentMethod;
use App\Models\Purchase;
use App\Models\SaleReturn;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

class LedgerService
{
    /**
     * Create a new ledger entry
     */
    public function createEntry(array $data): LedgerEntry
    {
        DB::beginTransaction();
        try {
            // Validate: only one of debit or credit
            if ((($data['debit_amount'] ?? 0) > 0) && 
                (($data['credit_amount'] ?? 0) > 0)) {
                throw new \Exception('Cannot have both debit and credit amounts');
            }

            if ((($data['debit_amount'] ?? 0) <= 0) && 
                (($data['credit_amount'] ?? 0) <= 0)) {
                throw new \Exception('Either debit or credit amount is required');
            }

            $entry = LedgerEntry::create($data);

            // Update party balance
            $this->updatePartyBalance($entry->party_id);

            // Invalidate cache
            \Cache::forget("ledger.balance.{$entry->entry_date}");
            \Cache::forget("party.balance.{$entry->party_id}");

            DB::commit();
            return $entry;
        } catch (\Exception $e) {
            DB::rollBack();
            throw $e;
        }
    }

    /**
     * Update an existing ledger entry
     */
    public function updateEntry(int $id, array $data): LedgerEntry
    {
        DB::beginTransaction();
        try {
            $entry = LedgerEntry::findOrFail($id);

            // Validate
            if ((($data['debit_amount'] ?? 0) > 0) && 
                (($data['credit_amount'] ?? 0) > 0)) {
                throw new \Exception('Cannot have both debit and credit amounts');
            }

            $oldDate = $entry->entry_date;
            $entry->update($data);

            // Recalculate balances for both old and new dates if date changed
            $this->updatePartyBalance($entry->party_id);

            if ($oldDate !== $entry->entry_date) {
                \Cache::forget("ledger.balance.{$oldDate}");
            }

            \Cache::forget("ledger.balance.{$entry->entry_date}");
            \Cache::forget("party.balance.{$entry->party_id}");

            DB::commit();
            return $entry;
        } catch (\Exception $e) {
            DB::rollBack();
            throw $e;
        }
    }

    /**
     * Delete a ledger entry
     */
    public function deleteEntry(int $id): void
    {
        DB::beginTransaction();
        try {
            $entry = LedgerEntry::findOrFail($id);

            $partyId = $entry->party_id;
            $entryDate = $entry->entry_date;

            $entry->delete();

            // Recalculate balances
            $this->updatePartyBalance($partyId);

            // Invalidate cache
            \Cache::forget("ledger.balance.{$entryDate}");
            \Cache::forget("party.balance.{$partyId}");

            DB::commit();
        } catch (\Exception $e) {
            DB::rollBack();
            throw $e;
        }
    }

    /**
     * Get filtered ledger entries
     */
    public function getFilteredEntries(array $filters)
    {
        $query = LedgerEntry::query();

        if (!empty($filters['date_from'])) {
            $query->whereDate('entry_date', '>=', $filters['date_from']);
        }

        if (!empty($filters['date_to'])) {
            $query->whereDate('entry_date', '<=', $filters['date_to']);
        }

        if (!empty($filters['party_id'])) {
            $query->where('party_id', $filters['party_id']);
        }

        if (!empty($filters['entry_type'])) {
            $query->where('entry_type', $filters['entry_type']);
        }

        if (!empty($filters['payment_method_id'])) {
            $query->where('payment_method_id', $filters['payment_method_id']);
        }

        return $query->with(['party', 'createdBy', 'paymentMethod'])
                     ->orderBy('entry_date', 'desc')
                     ->orderBy('created_at', 'desc')
                     ->get();
    }

    /**
     * Update party balance (recalculate)
     */
    public function updatePartyBalance(int $partyId): void
    {
        $totalCredit = LedgerEntry::where('party_id', $partyId)
                                  ->where('credit_amount', '>', 0)
                                  ->sum('credit_amount');
        
        $totalDebit = LedgerEntry::where('party_id', $partyId)
                                 ->where('debit_amount', '>', 0)
                                 ->sum('debit_amount');

        PartyLedger::updateOrCreate(
            ['party_id' => $partyId],
            [
                'total_credit' => $totalCredit,
                'total_debit' => $totalDebit,
                'closing_balance' => $totalCredit - $totalDebit,
                'last_transaction_date' => now()->toDateString(),
            ]
        );

        \Cache::forget("party.balance.{$partyId}");
    }

    /**
     * Validate balance consistency
     */
    public function validateBalance(?string $date = null): bool
    {
        if (!$date) {
            $date = now()->toDateString();
        }

        $totalDebit = LedgerEntry::whereDate('entry_date', '<=', $date)
                                 ->where('debit_amount', '>', 0)
                                 ->sum('debit_amount');

        $totalCredit = LedgerEntry::whereDate('entry_date', '<=', $date)
                                  ->where('credit_amount', '>', 0)
                                  ->sum('credit_amount');

        return true; // Balance validation can be extended
    }

    /**
     * Get daily balance
     */
    public function getDailyBalance(string $date)
    {
        $totalDebit = LedgerEntry::whereDate('entry_date', '<=', $date)
                                 ->where('debit_amount', '>', 0)
                                 ->sum('debit_amount');

        $totalCredit = LedgerEntry::whereDate('entry_date', '<=', $date)
                                  ->where('credit_amount', '>', 0)
                                  ->sum('credit_amount');

        return [
            'date' => $date,
            'total_debit' => $totalDebit,
            'total_credit' => $totalCredit,
            'balance' => $totalCredit - $totalDebit,
        ];
    }

    /**
     * Get entry count for date range
     */
    public function getEntryCount(string $from, string $to): int
    {
        return LedgerEntry::betweenDates($from, $to)->count();
    }

    /**
     * Get total in and out for date range
     */
    public function getTotals(string $from, string $to)
    {
        $entries = LedgerEntry::betweenDates($from, $to)->get();

        return [
            'total_in' => $entries->sum('credit_amount'),
            'total_out' => $entries->sum('debit_amount'),
            'count' => $entries->count(),
            'balance' => $entries->sum('credit_amount') - $entries->sum('debit_amount'),
        ];
    }

    /**
     * Sync purchase and sale rows into the ledger table.
     */
    public function syncTransactionalEntries(): void
    {
        Purchase::query()
            ->where('deleted', 0)
            ->orderBy('id')
            ->chunk(100, function ($purchases) {
                foreach ($purchases as $purchase) {
                    $this->syncPurchase($purchase);
                }
            });

        Invoice::query()
            ->where('deleted', 0)
            ->orderBy('id')
            ->chunk(100, function ($invoices) {
                foreach ($invoices as $invoice) {
                    $this->syncInvoice($invoice);
                }
            });

    }

    public function syncPurchase(Purchase $purchase): ?LedgerEntry
    {
        if ((int) ($purchase->deleted ?? 0) === 1) {
            $this->deleteAutoEntry('PURCHASE', (int) $purchase->id);
            return null;
        }

        $party = $this->findOrCreateParty(
            $purchase->purchase_from ?: 'Unknown Supplier',
            'Supplier',
            $purchase->contactno
        );

        $entry = LedgerEntry::updateOrCreate(
            [
                'entry_type' => 'PURCHASE',
                'transaction_id' => $purchase->id,
            ],
            [
                'entry_date' => $purchase->purchase_date ?: now()->toDateString(),
                'party_id' => $party->id,
                'created_by' => $purchase->user_id ?: 1,
                'debit_amount' => (float) ($purchase->purchase_price ?: $purchase->purchase_cost ?: 0),
                'credit_amount' => 0,
                'payment_method_id' => $this->resolvePaymentMethodId('Other'),
                'reference_number' => 'PUR-' . $purchase->id,
                'description' => trim('Purchase of ' . ($purchase->model ?: 'item')),
                'notes' => $this->buildPurchaseNotes($purchase),
            ]
        );

        $this->updatePartyBalance($party->id);

        return $entry;
    }

    public function syncInvoice(Invoice $invoice): ?LedgerEntry
    {
        if ((int) ($invoice->deleted ?? 0) === 1) {
            $this->deleteAutoEntry('SALE', (int) $invoice->id);
            return null;
        }

        $party = $this->findOrCreateParty(
            $invoice->customer_name ?: 'Walk-in Customer',
            'Customer',
            $invoice->customer_no
        );

        $entry = LedgerEntry::updateOrCreate(
            [
                'entry_type' => 'SALE',
                'transaction_id' => $invoice->id,
            ],
            [
                'entry_date' => $invoice->invoice_date ?: now()->toDateString(),
                'party_id' => $party->id,
                'created_by' => $invoice->invoice_by ?: 1,
                'debit_amount' => 0,
                'credit_amount' => (float) ($invoice->net_amount ?: 0),
                'payment_method_id' => $this->resolvePaymentMethodId($invoice->payment_type),
                'reference_number' => $invoice->invoice_no ?: 'INV-' . $invoice->id,
                'description' => trim('Sale to ' . ($invoice->customer_name ?: 'customer')),
                'notes' => $this->buildInvoiceNotes($invoice),
            ]
        );

        $this->updatePartyBalance($party->id);

        return $entry;
    }

    public function syncSaleReturn(SaleReturn $saleReturn): ?LedgerEntry
    {
        if ((int) ($saleReturn->deleted ?? 0) === 1) {
            $this->deleteAutoEntry('SALE_RETURN', (int) $saleReturn->id);
            return null;
        }

        $invoice = $saleReturn->invoice;

        $party = $this->findOrCreateParty(
            $invoice->customer_name ?: 'Walk-in Customer',
            'Customer',
            $invoice->customer_no
        );

        $entry = LedgerEntry::updateOrCreate(
            [
                'entry_type' => 'SALE_RETURN',
                'transaction_id' => $saleReturn->id,
            ],
            [
                'entry_date' => $saleReturn->return_date ?: now()->toDateString(),
                'party_id' => $party->id,
                'created_by' => $saleReturn->processed_by ?: 1,
                'debit_amount' => (float) ($saleReturn->refund_amount ?: 0),
                'credit_amount' => 0,
                'payment_method_id' => $this->resolvePaymentMethodId($invoice->payment_type),
                'reference_number' => 'RET-' . $saleReturn->id,
                'description' => trim('Return against invoice ' . ($invoice->invoice_no ?: $invoice->id)),
                'notes' => trim($saleReturn->reason ?: ''),
            ]
        );

        $this->updatePartyBalance($party->id);

        return $entry;
    }

    public function deleteAutoEntry(string $entryType, int $transactionId): void
    {
        $entry = LedgerEntry::query()
            ->where('entry_type', $entryType)
            ->where('transaction_id', $transactionId)
            ->first();

        if (! $entry) {
            return;
        }

        $partyId = $entry->party_id;
        $entry->delete();
        $this->updatePartyBalance($partyId);
    }

    protected function findOrCreateParty(string $name, string $type, ?string $phone = null): Party
    {
        $normalizedName = trim($name);

        $party = Party::query()
            ->whereRaw('LOWER(party_name) = ?', [Str::lower($normalizedName)])
            ->where('party_type', $type)
            ->first();

        if ($party) {
            $updates = [];

            if (blank($party->phone) && filled($phone)) {
                $updates['phone'] = $phone;
            }

            if ($updates !== []) {
                $party->update($updates);
            }

            return $party;
        }

        return Party::create([
            'party_name' => $normalizedName,
            'phone' => $phone,
            'party_type' => $type,
            'status' => 1,
            'deleted' => 0,
        ]);
    }

    protected function resolvePaymentMethodId(?string $value): ?int
    {
        if (blank($value)) {
            return null;
        }

        $normalizedValue = Str::lower(trim($value));

        return PaymentMethod::query()
            ->whereRaw('LOWER(method_name) = ?', [$normalizedValue])
            ->orWhereRaw('LOWER(slug) = ?', [$normalizedValue])
            ->value('id');
    }

    protected function buildPurchaseNotes(Purchase $purchase): string
    {
        return collect([
            $purchase->imei ? 'IMEI: ' . $purchase->imei : null,
            $purchase->storage ? 'Storage: ' . $purchase->storage : null,
            $purchase->color ? 'Color: ' . $purchase->color : null,
        ])->filter()->implode(' | ');
    }

    protected function buildInvoiceNotes(Invoice $invoice): string
    {
        return collect([
            $invoice->customer_no ? 'Phone: ' . $invoice->customer_no : null,
            $invoice->payment_type ? 'Payment: ' . $invoice->payment_type : null,
        ])->filter()->implode(' | ');
    }
}
