<?php

declare(strict_types=1);

namespace App\Console\Commands;

use App\Models\Tenant;
use App\Services\TenantService;
use Illuminate\Console\Command;

class RetryTenantProvisioning extends Command
{
    protected $signature = 'tenants:retry-provisioning {tenant : The tenant ID}';

    protected $description = 'Re-run the provisioning pipeline for a tenant stuck in provisioning or provisioning_failed';

    public function handle(TenantService $tenants): int
    {
        $tenant = Tenant::find($this->argument('tenant'));

        if (! $tenant) {
            $this->error("Tenant '{$this->argument('tenant')}' not found.");

            return self::FAILURE;
        }

        $tenants->retryProvisioning($tenant);

        $this->info("Retrying provisioning for tenant '{$tenant->id}'.");

        return self::SUCCESS;
    }
}
