<?php

declare(strict_types=1);

namespace App\Console\Commands;

use App\Services\SubscriptionService;
use Illuminate\Console\Command;

class ExpireSubscriptions extends Command
{
    protected $signature = 'subscriptions:expire';

    protected $description = 'Suspend tenants whose trial or paid subscription period has ended without renewal';

    public function handle(SubscriptionService $subscriptions): int
    {
        $count = $subscriptions->expireDueSubscriptions();

        $this->info("Suspended {$count} tenant(s) with an expired subscription.");

        return self::SUCCESS;
    }
}
