<?php

declare(strict_types=1);

namespace App\Jobs;

use App\Jobs\Concerns\HandlesProvisioningFailure;
use App\Models\Tenant;
use App\Models\User;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Str;
use Spatie\Permission\Models\Role;
use Throwable;

/**
 * Creates the tenant's first (super-admin) user, inside the tenant's own database.
 *
 * TenantService::provision() stashes the admin's name/email/pre-hashed password on the
 * tenant's data column (never plaintext — see TenantService) so this job, which may run
 * on a queue worker in a separate process, has what it needs without re-collecting input.
 * Those transient fields are cleared from the tenant record once the user is created.
 */
class CreateTenantAdminUser implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels, HandlesProvisioningFailure;

    public function __construct(protected Tenant $tenant)
    {
    }

    public function handle(): void
    {
        $name = $this->tenant->admin_name;
        $email = $this->tenant->admin_email;
        $passwordHash = $this->tenant->admin_password_hash;

        if (! $email) {
            // Already created and cleared in a previous attempt (see retryProvisioning()).
            return;
        }

        $this->tenant->run(function () use ($name, $email, $passwordHash) {
            $user = User::firstOrCreate(
                ['email' => $email],
                [
                    'name' => $name,
                    'user_name' => $this->uniqueUserName($name),
                    'password' => $passwordHash,
                ]
            );

            $role = Role::firstOrCreate(['name' => 'super-admin', 'guard_name' => 'web']);
            $user->assignRole($role);
        });

        $this->tenant->forceFill([
            'admin_name' => null,
            'admin_email' => null,
            'admin_password_hash' => null,
        ])->save();
    }

    protected function uniqueUserName(string $name): string
    {
        $base = Str::slug($name) ?: 'admin';
        $candidate = $base;
        $suffix = 1;

        while (User::where('user_name', $candidate)->exists()) {
            $candidate = "{$base}-{$suffix}";
            $suffix++;
        }

        return $candidate;
    }

    public function failed(Throwable $e): void
    {
        $this->markProvisioningFailed($this->tenant, $e);
    }
}
