<?php

declare(strict_types=1);

namespace App\Jobs;

use App\Jobs\Concerns\HandlesProvisioningFailure;
use App\Models\Tenant;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Throwable;

/**
 * Final step of the provisioning pipeline (see TenancyServiceProvider): flips the
 * tenant from 'provisioning' to 'trial' in the central DB. Only reached if every
 * earlier job in the pipeline succeeded, so this is the durable signal that a tenant
 * is fully usable — the central admin panel and the login-blocking middleware (later
 * phase) both key off tenants.status.
 */
class MarkTenantProvisioned implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels, HandlesProvisioningFailure;

    public function __construct(protected Tenant $tenant)
    {
    }

    public function handle(): void
    {
        if ($this->tenant->status === 'provisioning') {
            $this->tenant->forceFill(['status' => 'trial'])->save();
        }
    }

    public function failed(Throwable $e): void
    {
        $this->markProvisioningFailed($this->tenant, $e);
    }
}
