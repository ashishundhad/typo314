<?php

declare(strict_types=1);

namespace App\Jobs;

use App\Jobs\Concerns\HandlesProvisioningFailure;
use App\Models\Tenant;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Stancl\Tenancy\Database\DatabaseManager;
use Stancl\Tenancy\Events\DatabaseCreated;
use Throwable;

/**
 * Thin wrapper around Stancl\Tenancy\Jobs\CreateDatabase: same underlying mechanism
 * (Stancl\Tenancy\TenantDatabaseManagers\MySQLDatabaseManager::createDatabase(), a raw
 * CREATE DATABASE statement), but idempotent (safe to re-run via retryProvisioning())
 * and reports failure via HandlesProvisioningFailure instead of leaving no trace.
 *
 * Stancl's own CreateDatabase job has no failed() method, so JobPipeline would rethrow
 * and swallow the failure without marking the tenant — see HandlesProvisioningFailure.
 */
class CreateTenantDatabase implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels, HandlesProvisioningFailure;

    public function __construct(protected Tenant $tenant)
    {
    }

    public function handle(DatabaseManager $databaseManager): void
    {
        $manager = $this->tenant->database()->manager();
        $name = $this->tenant->database()->getName();

        if ($manager->databaseExists($name)) {
            return;
        }

        $this->tenant->database()->makeCredentials();
        $databaseManager->ensureTenantCanBeCreated($this->tenant);
        $manager->createDatabase($this->tenant);

        event(new DatabaseCreated($this->tenant));
    }

    public function failed(Throwable $e): void
    {
        $this->markProvisioningFailed($this->tenant, $e);
    }
}
