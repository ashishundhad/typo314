<?php

declare(strict_types=1);

namespace App\Jobs;

use App\Jobs\Concerns\HandlesProvisioningFailure;
use App\Models\Tenant;
use Database\Seeders\TenantDatabaseSeeder;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\Artisan;
use Throwable;

/**
 * Seeds the new tenant database with the defaults it needs to be usable on first
 * login: payment methods, a default company-settings row, and the super-admin
 * role/permission set (see database/seeders/TenantDatabaseSeeder). Runs after
 * CreateTenantAdminUser so the 'super-admin' role this seeder populates permissions
 * onto already has the admin user assigned to it.
 */
class InitializeTenantSettings implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels, HandlesProvisioningFailure;

    public function __construct(protected Tenant $tenant)
    {
    }

    public function handle(): void
    {
        $this->tenant->run(function () {
            Artisan::call('db:seed', [
                '--class' => TenantDatabaseSeeder::class,
                '--force' => true,
            ]);
        });
    }

    public function failed(Throwable $e): void
    {
        $this->markProvisioningFailed($this->tenant, $e);
    }
}
