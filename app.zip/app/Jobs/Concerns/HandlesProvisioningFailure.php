<?php

declare(strict_types=1);

namespace App\Jobs\Concerns;

use App\Models\Tenant;
use Illuminate\Support\Facades\Log;
use Throwable;

/**
 * Shared failure handling for every job in the tenant provisioning pipeline
 * (see App\Providers\TenancyServiceProvider::events()'s TenantCreated pipeline).
 *
 * Stancl\JobPipeline\JobPipeline::handle() catches exceptions from each job in the
 * pipeline and, if the job defines a failed() method, calls it and stops the pipeline
 * (it does NOT rethrow). This is the only place a mid-pipeline failure surfaces, so
 * every custom job must define failed() to flag the tenant — otherwise a tenant would
 * be left silently stuck in 'provisioning' status forever with no recovery signal.
 */
trait HandlesProvisioningFailure
{
    protected function markProvisioningFailed(Tenant $tenant, Throwable $e): void
    {
        Log::error('Tenant provisioning failed', [
            'tenant_id' => $tenant->getTenantKey(),
            'job' => static::class,
            'exception' => $e->getMessage(),
        ]);

        // Stancl\Tenancy\Database\Concerns\TenantRun::run() has no try/finally: if the
        // callback throws, tenancy is left initialized on this tenant's database. This
        // job's own failure handling must run against the central connection regardless,
        // or saving $tenant here would hit the tenant DB (which has no `tenants` table).
        if (tenancy()->initialized) {
            tenancy()->end();
        }

        $tenant->forceFill(['status' => 'provisioning_failed'])->save();
    }
}
