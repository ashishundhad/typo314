<?php

declare(strict_types=1);

namespace App\Jobs;

use App\Jobs\Concerns\HandlesProvisioningFailure;
use App\Models\Tenant;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\Artisan;
use Throwable;

/**
 * Thin wrapper around Stancl\Tenancy\Jobs\MigrateDatabase: same underlying mechanism
 * (`tenants:migrate` against database/migrations/tenant), but reports failure via
 * HandlesProvisioningFailure. Laravel's migrator already skips migrations recorded in
 * the tenant DB's own `migrations` table, so re-running this via retryProvisioning()
 * is safe.
 */
class MigrateTenantDatabase implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels, HandlesProvisioningFailure;

    public function __construct(protected Tenant $tenant)
    {
    }

    public function handle(): void
    {
        Artisan::call('tenants:migrate', [
            '--tenants' => [$this->tenant->getTenantKey()],
        ]);
    }

    public function failed(Throwable $e): void
    {
        $this->markProvisioningFailed($this->tenant, $e);
    }
}
