<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Payment extends Model
{
    protected $fillable = [
        'subscription_id',
        'amount',
        'currency',
        'status',
        'provider',
        'provider_reference',
        'paid_at',
    ];

    protected $casts = [
        'amount' => 'decimal:2',
        'paid_at' => 'datetime',
    ];

    public function subscription(): BelongsTo
    {
        return $this->belongsTo(Subscription::class);
    }

    public function markSucceeded(): void
    {
        $this->forceFill(['status' => 'succeeded', 'paid_at' => now()])->save();
    }

    public function markFailed(): void
    {
        $this->forceFill(['status' => 'failed'])->save();
    }
}
