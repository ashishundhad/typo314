<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CustomerDocument extends Model
{
    use HasFactory;

    protected $guarded = [];

    public function invoice()
    {
        return $this->belongsTo(Invoice::class);
    }

    public function customer()
    {
        return $this->belongsTo(Customer::class);
    }

    public function uploader()
    {
        return $this->belongsTo(User::class, 'uploaded_by');
    }

    public function getDocumentTypeLabelAttribute(): string
    {
        return match ($this->document_type) {
            'aadhar' => 'Aadhar Card',
            'pan'    => 'PAN Card',
            default  => $this->document_type_other ?: 'Other',
        };
    }

    public function getMaskedNumberAttribute(): string
    {
        $number = trim((string) $this->document_number);
        $length = strlen($number);

        if ($length <= 4) {
            return str_repeat('X', $length);
        }

        return str_repeat('X', $length - 4) . substr($number, -4);
    }

    /**
     * Routed through the app rather than the public/storage symlink — these files are
     * saved via Storage::disk('public'), but tenancy suffixes that disk's root per-tenant
     * (storage_tenantXXX/app/public/...) while the shared symlink only ever points at the
     * one central storage/app/public, so a direct URL built from Storage::url() 404s for
     * every tenant. See ReportController::viewCustomerDocument() for the serving side.
     */
    public function getImageUrlAttribute(): ?string
    {
        return $this->document_image ? route('customer-document.file', $this->id) : null;
    }
}
