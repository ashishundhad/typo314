<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Repair extends Model
{
    protected $table = 'repairs';

    protected $guarded = [];

    protected $casts = [
        'repair_date' => 'date',
        'parts_cost' => 'float',
        'repair_fee' => 'float',
        'deleted' => 'boolean',
    ];

    public function invoice()
    {
        return $this->belongsTo(Invoice::class);
    }

    /** Hide deleted rows everywhere you use ->notDeleted() */
    public function scopeNotDeleted($q)
    {
        return $q->where('deleted', 0);
    }

    public function getProfitAttribute(): float
    {
        return (float) $this->repair_fee - (float) $this->parts_cost;
    }

    public function isBilled(): bool
    {
        return $this->invoice_id !== null;
    }

    public function getStatusLabelAttribute(): string
    {
        return match ($this->status) {
            'repairing' => 'Repairing',
            'delivered' => 'Delivered',
            default => 'Received',
        };
    }
}
