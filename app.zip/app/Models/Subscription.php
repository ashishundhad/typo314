<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasOne;

class Subscription extends Model
{
    protected $fillable = [
        'tenant_id',
        'plan_id',
        'plan_price_id',
        'status',
        'trial_ends_at',
        'current_period_starts_at',
        'current_period_ends_at',
        'cancelled_at',
    ];

    protected $casts = [
        'trial_ends_at' => 'datetime',
        'current_period_starts_at' => 'datetime',
        'current_period_ends_at' => 'datetime',
        'cancelled_at' => 'datetime',
    ];

    public function tenant(): BelongsTo
    {
        return $this->belongsTo(Tenant::class);
    }

    public function plan(): BelongsTo
    {
        return $this->belongsTo(Plan::class);
    }

    public function planPrice(): BelongsTo
    {
        return $this->belongsTo(PlanPrice::class);
    }

    public function payments(): HasMany
    {
        return $this->hasMany(Payment::class);
    }

    public function latestPayment(): HasOne
    {
        return $this->hasOne(Payment::class)->latestOfMany();
    }

    public function isOnTrial(): bool
    {
        return $this->status === 'trialing';
    }

    public function isActive(): bool
    {
        return $this->status === 'active';
    }

    public function isSuspended(): bool
    {
        return $this->status === 'suspended';
    }

    public function isCancelled(): bool
    {
        return $this->status === 'cancelled';
    }

    /**
     * Whether this subscription currently grants access to the app. There are no
     * feature-based plans — access is binary (trial and active both grant full
     * access to everything; suspended/past_due/cancelled grant none).
     *
     * Checks the actual expiry timestamp, not just the status column — status is
     * only flipped to 'suspended' by the once-daily subscriptions:expire batch
     * job (see SubscriptionService::expireDueSubscriptions()), so trusting status
     * alone would leave an expired trial/period fully accessible for up to 24
     * hours until that job next runs. This makes expiry take effect immediately,
     * on the very next request, regardless of batch timing.
     */
    public function hasAccess(): bool
    {
        if ($this->isOnTrial()) {
            return ! $this->trial_ends_at || $this->trial_ends_at->isFuture();
        }

        if ($this->isActive()) {
            return ! $this->current_period_ends_at || $this->current_period_ends_at->isFuture();
        }

        return false;
    }

    /**
     * A billing-side read of whether this tenant owes money right now, distinct
     * from access status: 'trial' (never billed yet), 'paid' (most recent
     * payment succeeded), or 'due' (no successful payment on record — either
     * none at all, or the last one is pending/failed). Drives the Tenants list
     * "Payment" column and gates manual reactivation — see
     * TenantController::reactivate().
     */
    public function paymentStatus(): string
    {
        if ($this->isOnTrial()) {
            return 'trial';
        }

        return $this->latestPayment?->status === 'succeeded' ? 'paid' : 'due';
    }
}
