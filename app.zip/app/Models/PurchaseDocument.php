<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class PurchaseDocument extends Model
{
    protected $guarded = [];

    public function purchase()
    {
        return $this->belongsTo(Purchase::class);
    }

    public function uploader()
    {
        return $this->belongsTo(User::class, 'uploaded_by');
    }

    public function getDocumentTypeLabelAttribute(): string
    {
        return match ($this->document_type) {
            'aadhar' => 'Aadhar Card',
            'pan'    => 'PAN Card',
            default  => $this->document_type_other ?: 'Other',
        };
    }

    public function getMaskedNumberAttribute(): string
    {
        $number = trim((string) $this->document_number);
        $length = strlen($number);

        if ($length === 0) {
            return '';
        }

        if ($length <= 4) {
            return str_repeat('X', $length);
        }

        return str_repeat('X', $length - 4) . substr($number, -4);
    }

    /**
     * Routed through the app rather than the public/storage symlink — see the identical
     * note on CustomerDocument::getImageUrlAttribute() for why a direct Storage::url()
     * 404s under tenancy, and ReportController::viewCustomerDocument() for the pattern
     * this mirrors (see PurchaseController::viewDocument()).
     */
    public function getImageUrlAttribute(): ?string
    {
        return $this->document_image ? route('purchase-document.file', $this->id) : null;
    }
}
