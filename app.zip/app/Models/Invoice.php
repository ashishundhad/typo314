<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Invoice extends Model
{
    use HasFactory;

    protected $table = 'invoices';

    protected $guarded = [];

    protected $appends = ['customer_name', 'customer_no', 'customer_address'];

    public function user()
    {
        return $this->belongsTo(User::class, 'invoice_by', 'id');
    }

    public function customer()
    {
        return $this->belongsTo(Customer::class);
    }

    public function getCustomerNameAttribute()
    {
        return $this->customer?->name;
    }

    public function getCustomerNoAttribute()
    {
        return $this->customer?->phone;
    }

    public function getCustomerAddressAttribute()
    {
        return $this->customer?->address;
    }

    public function purchase()
    {
        return $this->belongsTo(Purchase::class, 'item_id', 'id');
    }

    /**
     * Get all items for this invoice.
     */
    public function items()
    {
        return $this->hasMany(InvoiceItem::class);
    }

    /**
     * Get all customer identity documents attached to this invoice.
     */
    public function documents()
    {
        return $this->hasMany(CustomerDocument::class);
    }

    /**
     * Payment breakdown rows — one row for a normal single-method invoice, several when
     * the customer split payment across methods (e.g. part cash, part online).
     */
    public function payments()
    {
        return $this->hasMany(InvoicePayment::class);
    }

    /** Hide deleted rows everywhere you use ->notDeleted() */
    public function scopeNotDeleted($q)
    {
        return $q->where('deleted', 0);
    }

    /**
     * Next sequential invoice number in the "INV-YYYY####" format, continuing the
     * current year's sequence (or restarting at 1 when the year has rolled over).
     */
    public static function nextInvoiceNumber(): string
    {
        $lastInvoice = self::orderBy('id', 'desc')->first();
        $currentYear = date('Y');
        $nextInvoiceNo = 1;

        if ($lastInvoice) {
            // Match the trailing year+sequence digits regardless of prefix, so numbering
            // continues correctly across the old "INVOICEYYYY####" and new "INV-YYYY####" formats.
            preg_match('/(\d{4})\d{4}$/', (string) $lastInvoice->invoice_no, $matches);
            $lastYear = $matches[1] ?? null;

            if ($lastYear == $currentYear) {
                $lastId = intval(substr((string) $lastInvoice->invoice_no, -4));
                $nextInvoiceNo = $lastId + 1;
            }
        }

        return 'INV-' . $currentYear . str_pad((string) $nextInvoiceNo, 4, '0', STR_PAD_LEFT);
    }
}
