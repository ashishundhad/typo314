<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Str;

class PendingDocumentUpload extends Model
{
    protected $guarded = [];

    protected $casts = [
        'expires_at' => 'datetime',
    ];

    /**
     * Start a new QR-handoff session: a token a phone can upload a document against,
     * independent of any invoice (the invoice may not exist yet while its form is open).
     */
    public static function startSession(?int $createdBy, int $validMinutes = 30): self
    {
        return static::create([
            'token' => (string) Str::uuid(),
            'status' => 'pending',
            'created_by' => $createdBy,
            'expires_at' => now()->addMinutes($validMinutes),
        ]);
    }

    public function isExpired(): bool
    {
        return $this->expires_at->isPast();
    }

    public function getDocumentTypeLabelAttribute(): string
    {
        return match ($this->document_type) {
            'aadhar' => 'Aadhar Card',
            'pan'    => 'PAN Card',
            default  => $this->document_type_other ?: 'Other',
        };
    }
}
