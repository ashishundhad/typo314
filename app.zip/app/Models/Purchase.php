<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Purchase extends Model
{
    use HasFactory;

    protected $table = 'purchases';

    protected $guarded = [];

    protected $casts = [
        'purchase_cost' => 'float',
        'repairing_charge' => 'float',
        'purchase_price' => 'float',
        'quantity' => 'integer',
        'available_quantity' => 'integer',
        'is_sold' => 'boolean',
        'deleted' => 'boolean',
    ];

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    /**
     * Supplier receipts / supporting paperwork attached to this purchase — separate from
     * the legacy `document` column (a comma-joined list of raw file paths from an upload
     * field that isn't wired into any live form today).
     */
    public function documents()
    {
        return $this->hasMany(PurchaseDocument::class);
    }

    public function isBulkTracked(): bool
    {
        return ($this->tracking_type ?? 'serialized') === 'bulk';
    }

    public function getAvailableUnitsAttribute(): int
    {
        if ($this->isBulkTracked()) {
            return max(0, (int) ($this->available_quantity ?? 0));
        }

        return $this->is_sold ? 0 : 1;
    }

    public function getSoldUnitsAttribute(): int
    {
        if ($this->isBulkTracked()) {
            return max(0, (int) ($this->quantity ?? 0) - (int) ($this->available_quantity ?? 0));
        }

        return $this->is_sold ? 1 : 0;
    }

    public function getTotalUnitsAttribute(): int
    {
        return $this->isBulkTracked() ? max(1, (int) ($this->quantity ?? 1)) : 1;
    }

    public function getAvailableStockValueAttribute(): float
    {
        return (float) $this->purchase_price * $this->available_units;
    }

    public function getTotalStockValueAttribute(): float
    {
        return (float) $this->purchase_price * $this->total_units;
    }

    public function getDisplayCodeAttribute(): string
    {
        if ($this->isBulkTracked()) {
            return (string) ($this->sku ?: ('BULK-' . $this->id));
        }

        return (string) $this->imei;
    }

    public function getStatusLabelAttribute(): string
    {
        if ($this->isBulkTracked()) {
            if ($this->available_units <= 0) {
                return 'Sold';
            }

            if ($this->sold_units > 0) {
                return 'Partial';
            }

            return 'Available';
        }

        return $this->is_sold ? 'Sold' : 'Available';
    }
}
