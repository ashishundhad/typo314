<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class CompanySetting extends Model
{
    protected $fillable = [
        'company_name',
        'logo',
        'address',
        'phone',
        'email',
        'gst_enabled',
        'gst_number',
        'gst_percentage',
        'gst_inclusive',
        'default_gst_mode',
    ];

    protected $casts = [
        'gst_enabled' => 'boolean',
        'gst_inclusive' => 'boolean',
        'gst_percentage' => 'float',
    ];

    // Deliberately not cached (previously Cache::rememberForever('company_setting', ...)):
    // Stancl's CacheTenancyBootstrapper wraps every Cache:: call in Cache::tags([...]) to
    // isolate tenants, and the app's CACHE_STORE=database driver doesn't support tagging —
    // any cache call made while tenant context is bootstrapped throws "This cache store
    // does not support tagging." Confirmed while building tenant provisioning (Phase 3):
    // firstOrCreate() below and its 'saved' hook are exactly this scenario. A single-row
    // lookup by primary key is cheap enough that caching it isn't worth reintroducing that
    // failure mode — if CACHE_STORE moves to a tagging-capable driver (Redis) later, this
    // can be revisited.
    public static function current(): self
    {
        return self::firstOrCreate(['id' => 1], ['company_name' => config('app.name')]);
    }
}
