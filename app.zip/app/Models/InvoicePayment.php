<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class InvoicePayment extends Model
{
    protected $guarded = [];

    protected $casts = [
        'amount' => 'float',
    ];

    public function invoice()
    {
        return $this->belongsTo(Invoice::class);
    }

    /**
     * Replace an invoice's payment rows with the given method/amount pairs (skipping any
     * with a blank method or non-positive amount) and return the label that should be
     * stored on invoices.payment_type — the single method name, or 'Split' when more than
     * one distinct method was used. Kept on the invoice itself too so every existing
     * filter/report/CSV export that reads payment_type directly still gets a sensible
     * value without needing to join this table.
     */
    public static function syncForInvoice(Invoice $invoice, array $rows): string
    {
        $invoice->payments()->delete();

        $methods = [];

        foreach ($rows as $row) {
            $method = trim((string) ($row['method'] ?? ''));
            $amount = (float) ($row['amount'] ?? 0);

            if ($method === '' || $amount <= 0) {
                continue;
            }

            static::create([
                'invoice_id' => $invoice->id,
                'payment_method' => $method,
                'amount' => $amount,
            ]);

            $methods[$method] = true;
        }

        $distinctMethods = array_keys($methods);

        return count($distinctMethods) > 1 ? 'Split' : ($distinctMethods[0] ?? 'Cash');
    }

    /**
     * True when the given method/amount rows sum to the expected total (within a small
     * rounding tolerance), used to reject a split payment that doesn't add up to the
     * invoice's net amount before anything gets written to the database.
     */
    public static function rowsSumTo(array $rows, float $expectedTotal, float $tolerance = 0.01): bool
    {
        $sum = 0.0;

        foreach ($rows as $row) {
            $sum += (float) ($row['amount'] ?? 0);
        }

        return abs($sum - $expectedTotal) <= $tolerance;
    }
}
