<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Customer extends Model
{
    use HasFactory;

    protected $guarded = [];

    public function invoices()
    {
        return $this->hasMany(Invoice::class);
    }

    /**
     * All identity documents this customer has ever submitted, across invoices.
     */
    public function documents()
    {
        return $this->hasMany(CustomerDocument::class);
    }

    /**
     * Find the customer for this phone number, refreshing their name/address
     * if changed, or create a new customer when no match exists.
     */
    public static function firstOrCreateForInvoice(string $name, ?string $phone, ?string $address = null): self
    {
        $name = trim($name) !== '' ? trim($name) : 'Walk-in Customer';
        $phone = $phone !== null && trim($phone) !== '' ? trim($phone) : null;
        $address = $address !== null && trim($address) !== '' ? trim($address) : null;

        if ($phone !== null) {
            $customer = static::where('phone', $phone)->first();

            if ($customer) {
                $updates = [];

                if ($name !== '' && $customer->name !== $name) {
                    $updates['name'] = $name;
                }

                if ($address !== null && $customer->address !== $address) {
                    $updates['address'] = $address;
                }

                if ($updates !== []) {
                    $customer->update($updates);
                }

                return $customer;
            }
        }

        return static::create([
            'name' => $name,
            'phone' => $phone,
            'address' => $address,
        ]);
    }
}
