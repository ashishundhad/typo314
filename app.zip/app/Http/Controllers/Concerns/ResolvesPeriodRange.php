<?php

namespace App\Http\Controllers\Concerns;

use Carbon\Carbon;
use Illuminate\Http\Request;

/**
 * Shared by any controller that offers a "Report Period" filter (All Time, This Month,
 * Last Month, This Year, Last Year, Custom Range) — originally lived only on
 * ReportController, extracted so RepairController's report can reuse the exact same
 * period semantics instead of re-implementing them.
 */
trait ResolvesPeriodRange
{
    /**
     * @param bool $capToToday When true (the default — matches every existing report that
     *   already relied on this), "This Month"/"This Year" stop at today, since those reports
     *   cover transactions that are only ever stamped at creation time (purchases, invoices)
     *   and a future date there would be a data-entry mistake worth excluding. Pass false for
     *   user-picked dates that can legitimately fall later in the current month/year than
     *   today (e.g. a repair's scheduled/received date), so the full month/year is covered
     *   instead of being silently clipped at today.
     */
    protected function resolvePeriodRange(Request $request, string $defaultPeriod = 'thismonth', bool $capToToday = true): array
    {
        $period = $request->input('period', $defaultPeriod);
        $fromDate = $request->input('fromdate');
        $toDate = $request->input('todate');
        $start = null;
        $end = null;
        $timePeriod = 'All Time';

        if ($period === 'today') {
            $start = Carbon::today()->toDateString();
            $end = Carbon::today()->toDateString();
            $timePeriod = 'Today (' . Carbon::today()->format('d M Y') . ')';
        } elseif ($period === 'week') {
            $start = Carbon::now()->startOfWeek()->toDateString();
            $end = $capToToday ? Carbon::now()->toDateString() : Carbon::now()->endOfWeek()->toDateString();
            $timePeriod = Carbon::parse($start)->format('d M Y') . ' - ' . Carbon::parse($end)->format('d M Y');
        } elseif ($period === 'quarter') {
            $start = Carbon::now()->startOfQuarter()->toDateString();
            $end = $capToToday ? Carbon::now()->toDateString() : Carbon::now()->endOfQuarter()->toDateString();
            $timePeriod = 'Q' . Carbon::now()->quarter . ' ' . Carbon::now()->format('Y');
        } elseif ($period === 'month' || $period === 'thismonth') {
            $start = Carbon::now()->startOfMonth()->toDateString();
            $end = $capToToday ? Carbon::now()->toDateString() : Carbon::now()->endOfMonth()->toDateString();
            $timePeriod = Carbon::now()->format('F Y');
        } elseif ($period === 'lastmonth') {
            $start = Carbon::now()->subMonth()->startOfMonth()->toDateString();
            $end = Carbon::now()->subMonth()->endOfMonth()->toDateString();
            $timePeriod = Carbon::now()->subMonth()->format('F Y');
        } elseif ($period === 'year' || $period === 'thisyear') {
            $start = Carbon::now()->startOfYear()->toDateString();
            $end = $capToToday ? Carbon::now()->toDateString() : Carbon::now()->endOfYear()->toDateString();
            $timePeriod = Carbon::now()->format('Y');
        } elseif ($period === 'lastyear') {
            $start = Carbon::now()->subYear()->startOfYear()->toDateString();
            $end = Carbon::now()->subYear()->endOfYear()->toDateString();
            $timePeriod = Carbon::now()->subYear()->format('Y');
        } elseif ($period === 'custom' && $fromDate && $toDate) {
            $start = Carbon::parse($fromDate)->toDateString();
            $end = Carbon::parse($toDate)->toDateString();
            $timePeriod = Carbon::parse($start)->format('d M Y') . ' - ' . Carbon::parse($end)->format('d M Y');
        } elseif ($period === 'alls') {
            $timePeriod = 'All Time';
        } else {
            $period = $defaultPeriod;
            $start = Carbon::now()->startOfMonth()->toDateString();
            $end = $capToToday ? Carbon::now()->toDateString() : Carbon::now()->endOfMonth()->toDateString();
            $timePeriod = Carbon::now()->format('F Y');
        }

        return [
            'period' => $period,
            'fromdate' => $fromDate,
            'todate' => $toDate,
            'start' => $start,
            'end' => $end,
            'timePeriod' => $timePeriod,
        ];
    }
}
