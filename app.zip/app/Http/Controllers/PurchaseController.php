<?php
namespace App\Http\Controllers;

use App\Models\PendingDocumentUpload;
use App\Models\Purchase;
use App\Models\PurchaseDocument;
use App\Services\DocumentImageService;
use App\Services\Ledger\LedgerService;
use Barryvdh\DomPDF\Facade\Pdf;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Response;
use Illuminate\Support\Facades\Storage;
use Illuminate\Validation\Rule;

class PurchaseController extends Controller
{
    public function __construct(private readonly DocumentImageService $documentImageService)
    {
    }

    /**
     * Validation rules shared by save/update for the new purchase_documents upload rows
     * (both a direct file and the QR phone-handoff path) — mirrors
     * InvoiceController::documentValidationRules().
     */
    private function purchaseDocumentValidationRules(): array
    {
        return [
            'documents'                 => 'nullable|array',
            'documents.*.type'          => 'nullable|in:aadhar,pan,other',
            'documents.*.type_other'    => 'nullable|required_if:documents.*.type,other|string|max:100',
            'documents.*.number'        => 'nullable|string|max:100',
            'documents.*.image'         => 'required_without:documents.*.pending_token|image|mimes:jpg,jpeg,png,webp|max:5120',
            'documents.*.pending_token' => 'nullable|string|max:36',
        ];
    }

    /**
     * Optimize and persist any supporting documents submitted with the purchase — either
     * a freshly-chosen file, or one already uploaded via the QR handoff flow and
     * referenced here by its pending_token. Mirrors
     * InvoiceController::storeCustomerDocuments()/claimPendingDocument().
     */
    private function storePurchaseDocuments(Purchase $purchase, Request $request): void
    {
        foreach ($request->input('documents', []) as $index => $data) {
            $type = $data['type'] ?? null;
            $pendingToken = $data['pending_token'] ?? null;

            if ($pendingToken) {
                $this->claimPendingPurchaseDocument($purchase, $pendingToken, $type, $data['type_other'] ?? null, $data['number'] ?? null);
                continue;
            }

            $image = $request->file("documents.{$index}.image");

            if (! $image) {
                continue;
            }

            $optimized = $this->documentImageService->optimizeAndStore(
                $image,
                'purchase-documents/' . $purchase->id
            );

            PurchaseDocument::create([
                'purchase_id'         => $purchase->id,
                'document_type'       => $type,
                'document_type_other' => $type === 'other' ? ($data['type_other'] ?? null) : null,
                'document_number'     => $data['number'] ?? null,
                'document_image'      => $optimized['path'],
                'image_width'         => $optimized['width'],
                'image_height'        => $optimized['height'],
                'file_size'           => $optimized['size'],
                'uploaded_by'         => Auth::id(),
            ]);
        }
    }

    private function claimPendingPurchaseDocument(Purchase $purchase, string $token, ?string $type, ?string $typeOther, ?string $number): void
    {
        $pending = PendingDocumentUpload::where('token', $token)
            ->where('status', 'uploaded')
            ->first();

        if (! $pending || $pending->isExpired() || ! $pending->image_path) {
            return;
        }

        $newPath = 'purchase-documents/' . $purchase->id . '/' . basename($pending->image_path);
        Storage::disk('public')->move($pending->image_path, $newPath);

        PurchaseDocument::create([
            'purchase_id'         => $purchase->id,
            'document_type'       => $type,
            'document_type_other' => $type === 'other' ? $typeOther : null,
            'document_number'     => $number,
            'document_image'      => $newPath,
            'image_width'         => $pending->image_width,
            'image_height'        => $pending->image_height,
            'file_size'           => $pending->file_size,
            'uploaded_by'         => Auth::id(),
        ]);

        $pending->update(['status' => 'claimed']);
    }

    /**
     * Streams a purchase document image through the app instead of the public/storage
     * symlink — see ReportController::viewCustomerDocument() for why.
     */
    public function viewDocument($id)
    {
        $document = PurchaseDocument::query()->findOrFail($id);

        abort_unless($document->document_image && Storage::disk('public')->exists($document->document_image), 404);

        return Storage::disk('public')->response($document->document_image);
    }

    public function index(Request $request)
    {
        $search        = $request->input('search');
        $isSold        = $request->input('is_sold');
        $year          = $request->input('year');
        $storage       = $request->input('storage');
        $color         = $request->input('color');
        $sortDirection = $request->input('direction', 'desc');
        $purchaseQuery = $this->filteredPurchasesQuery($request);
        if ($request->query('download') === 'csv') {
            $fileName = 'stock';
            if ($color) {
                $fileName .= '' . $color;
            }
            if ($storage) {
                $fileName .= '-' . $storage;
            }
            if ($year) {
                $fileName .= '-' . $year;
            }

            $fileName .= '-.csv';
            $headers = [
                'Content-type'        => 'text/csv',
                'Content-Disposition' => "attachment; filename=$fileName",
                'Pragma'              => 'no-cache',
                'Cache-Control'       => 'must-revalidate, post-check=0, pre-check=0',
                'Expires'             => '0',
            ];
            $allPurchases = (clone $purchaseQuery)
                ->orderBy('id', 'asc')
                ->get();

            $callback = function () use ($allPurchases): void {
                $file = fopen('php://output', 'w+');

                                                                                                                                                                                                    // Add the CSV header (modify this based on your model)
                fputcsv($file, ['Sr No', 'Purchase Date', 'IMEI', 'Model', 'Storage', 'Color', 'Sell Date', 'Buy From', 'Mobile No', 'Buy Cost', 'Repairing', 'Buy Price', 'Sold', 'Remark'], ';'); // Specify the custom separator (;)

                // Add the data rows
                $sellDate  = '';
                $totalCost = $repairingCost = $purchasePrice = 0;
                foreach ($allPurchases as $row) {
                    fputcsv($file, [
                        $row->id,
                        Carbon::parse($row->purchase_date)->format('d/m/Y'),
                        (string) $row->imei,
                        $row->model,
                        $row->storage,
                        $row->color,
                        ($row->sell_date) ? Carbon::parse($row->sell_date)->format('d/m/Y') : '',
                        $row->purchase_from,
                        $row->contactno,
                        $row->purchase_cost,
                        $row->repairing_charge ?: 0,
                        $row->purchase_price,
                        ($row->is_sold == 1) ? 'Yes' : 'No',
                        $row->remark,
                    ], ';');
                    $totalCost += $row->purchase_cost;
                    $repairingCost += $row->repairing_charge;
                    $purchasePrice += $row->purchase_price;
                }
                fputcsv($file, ['', '', '', '', '', '', '', '', '', '', '', '', '', ''], ';');
                fputcsv($file, ['', '', '', '', '', '', '', '', '', $totalCost, $repairingCost, $purchasePrice, '', ''], ';');

                fclose($file);
            };

            return Response::stream($callback, 200, $headers);
        }

        if ($request->query('download') === 'pdf') {
            $allPurchases = (clone $purchaseQuery)
                ->orderBy('id', 'asc')
                ->get();

            $pdf = Pdf::loadView('purchase.stock-pdf', [
                'allPurchases' => $allPurchases,
                'totalPurchaseCost' => (float) $allPurchases->sum('purchase_cost'),
                'totalRepairingCost' => (float) $allPurchases->sum('repairing_charge'),
                'totalStockValue' => (float) $allPurchases->sum('purchase_price'),
                'summaryLabel' => $this->buildStockSummaryLabel($request),
            ])->setPaper('a4', 'landscape');

            return $pdf->download('stock-report-' . now()->format('Ymd-His') . '.pdf');
        }

        $allPurchases = (clone $purchaseQuery)
            ->orderBy('id', $sortDirection)
            ->paginate(20);
        $colors = (Purchase::select('color'))
            ->distinct()
            ->whereNotNull('color')
            ->when($search, function ($query, $search): void {
                $query->where(function ($q) use ($search): void {
                    $q->where('id', 'like', "%{$search}%")
                        ->orWhere('imei', 'like', "%{$search}%")
                        ->orWhere('model', 'like', "%{$search}%")
                        ->orWhere('purchase_from', 'like', "%{$search}%");
                });
            })
            ->when(($isSold != ''), function ($query) use ($isSold): void {
                if ($isSold == 2) {
                    $query->where('is_sold', 0);
                } else {
                    $query->where('is_sold', 1);
                }
            })
            ->when($year, function ($query) use ($year): void {
                $query->whereYear('purchase_date', $year);
            })
            ->when($storage, function ($query) use ($storage): void {
                $query->where('storage', 'like', "%{$storage}");
            })
            ->where('deleted', 0)
            ->orderBy('color', 'asc') // Optional: order by color alphabetically
            ->get();
        // Mirrors Purchase::getAvailableStockValueAttribute() (purchase_price * available_units,
        // where bulk-tracked units use available_quantity and serialized units are 1 unless sold)
        // as a single DB-side aggregate instead of loading every non-deleted purchase into PHP.
        $totalAvailableStockAmount = (float) Purchase::query()
            ->where('deleted', 0)
            ->toBase()
            ->selectRaw("SUM(purchase_price * (CASE WHEN tracking_type = 'bulk' THEN GREATEST(available_quantity, 0) ELSE (CASE WHEN is_sold = 1 THEN 0 ELSE 1 END) END)) as total")
            ->value('total');
        return view('purchase.purchases', [
            'allPurchases'  => $allPurchases,
            'issold'        => $isSold,
            'year'          => $year,
            'storage'       => $storage,
            'sortDirection' => $sortDirection,
            'totalItems'    => $allPurchases->total(),
            'colors'        => $colors,
            'selectedcolor' => $color,
            'totalAvailableStockAmount' => $totalAvailableStockAmount,
        ]);
    }

    // New purchase form
    public function newPurchase()
    {
        $purchase = new Purchase();

        return view('purchase.newpurchase', [
            'purchase' => $purchase,
        ]);
    }

    // New multiple purchase form
    public function newMultiplePurchase()
    {
        return view('purchase.newpurchase-multiple');
    }

    public function purchaseDetail($id)
    {
        $purchase = (Purchase::query())->with('documents')->findOrFail($id);

        if (request()->ajax() || request()->boolean('modal')) {
            return view('purchase._detail_content', ['purchase' => $purchase]);
        }

        return view('purchase.purchasedetail', ['purchase' => $purchase]);
    }

    public function savePurchase(Request $request, LedgerService $ledgerService)
    {
        // Check if it's multiple stock entry
        if ($request->entry_type === 'multiple') {
            return $this->saveMultiplePurchases($request, $ledgerService);
        }

        $trackingType = $this->normalizeTrackingType($request->input('tracking_type'), $request->input('device_type'));

        $request->merge(['tracking_type' => $trackingType]);

        $request->validate(array_merge([
            'model'         => 'required',
            'imei'          => $trackingType === 'bulk'
                ? 'nullable|string|max:255'
                : [
                    'required',
                    'string',
                    'max:255',
                    Rule::unique('purchases', 'imei')->where('deleted', 0)->ignore($request->id),
                ],
            'purchase_cost' => 'required|numeric|min:0',
            'quantity'      => $trackingType === 'bulk' ? 'required|integer|min:1' : 'nullable|integer|min:1',
            'sku'           => 'nullable|string|max:255',
        ], $this->purchaseDocumentValidationRules()), [
            'imei.unique' => 'This IMEI already exists in stock.',
        ]);

        // If request has ID → update, else create new
        $purchase = $request->id
            ? Purchase::findOrFail($request->id)
            : new Purchase;

        $isBulk = $trackingType === 'bulk';
        $quantity = $isBulk ? max(1, (int) $request->quantity) : 1;

        // Assign common fields
        $purchase->device_type      = $request->device_type;
        $purchase->tracking_type    = $trackingType;
        $purchase->model            = $request->model;
        $purchase->sku              = $request->sku ?: null;
        $purchase->imei             = $isBulk ? null : $request->imei;
        $purchase->msp              = $request->msp;
        $purchase->purchase_date    = $request->purchase_date ?? Carbon::now()->format('Y-m-d');
        $purchase->color            = $request->color ?: null;
        $purchase->storage          = $request->storage ?: null;
        $purchase->purchase_from    = $request->purchase_from;
        $purchase->contactno        = $request->contactno;
        $purchase->warrentydate     = $request->warrentydate;
        $purchase->purchase_cost    = $request->purchase_cost;
        $purchase->repairing_charge = $request->repairing_charge ?? 0;
        $purchase->remark           = $request->remark;
        $purchase->quantity         = $quantity;
        $purchase->user_id          = Auth::id();

        // Calculate total purchase price
        $purchaseCost             = $purchase->purchase_cost > 0 ? $purchase->purchase_cost : 0;
        $repairingCharge          = $purchase->repairing_charge > 0 ? $purchase->repairing_charge : 0;
        $purchase->purchase_price = floatval($purchaseCost + $repairingCharge);
        $purchase->available_quantity = $purchase->id && $purchase->isBulkTracked()
            ? min($quantity, max(0, (int) $purchase->available_quantity))
            : $quantity;
        $purchase->is_sold = $purchase->available_quantity <= 0;

        // Handle documents
        if ($request->hasFile('document') && count($request->file('document')) > 0) {
            $documents = [];
            foreach ($request->file('document') as $file) {
                $filename = date('YmdHi') . '_' . $file->getClientOriginalName();
                $file->move(public_path('documents/purchases/'), $filename);
                $documents[] = 'documents/purchases/' . $filename;
            }
            $purchase->document = implode(',', $documents);
        }

        // Save or update
        $isNew = ! $request->id;
        $purchase->save();
        $this->storePurchaseDocuments($purchase, $request);
        $ledgerService->syncPurchase($purchase->fresh());

        return redirect()
            ->route('allpurchases')
            ->withStatus($isNew ? 'Stock Added Successfully...' : 'Stock Updated Successfully...');
    }

    private function saveMultiplePurchases(Request $request, LedgerService $ledgerService)
    {
        if ($this->normalizeTrackingType($request->input('tracking_type'), $request->input('device_type')) === 'bulk') {
            return back()->withErrors(['error' => 'Bulk inventory should be added using the single stock form with quantity.'])->withInput();
        }

        $request->validate([
            'purchase_from'               => 'required',
            'stock_items'                 => 'required|array|min:1',
            'stock_items.*.model'         => 'required',
            'stock_items.*.imei'          => [
                'required',
                'distinct',
                Rule::unique('purchases', 'imei')->where('deleted', 0),
            ],
            'stock_items.*.storage'       => 'required',
            'stock_items.*.color'         => 'required',
            'stock_items.*.purchase_cost' => 'required|numeric',
            'stock_items.*.warrentydate'  => 'nullable|date',
            'stock_items.*.purchase_date' => 'required|date'
        ], [
            'stock_items.*.imei.distinct' => 'Duplicate IMEI entered more than once in this form.',
            'stock_items.*.imei.unique'   => 'This IMEI already exists in stock.',
        ]);

        $now          = Carbon::now();
        $userId       = Auth::id();
        $totalCost     = 0;

        $createdCount = 0;

        \DB::transaction(function () use ($request, $ledgerService, $now, $userId, &$totalCost, &$createdCount): void {
            foreach ($request->stock_items as $stockItem) {
                $purchaseCost    = floatval($stockItem['purchase_cost']);
                $repairingCharge = floatval($request->repairing_charge ?? 0);
                $purchasePrice   = $purchaseCost + $repairingCharge;

                $purchase = Purchase::create([
                    'device_type'      => $request->device_type,
                    'tracking_type'    => 'serialized',
                    'model'            => $stockItem['model'],
                    'purchase_date'    => $stockItem['purchase_date'],
                    'msp'              => $stockItem['msp'],
                    'purchase_from'    => $request->purchase_from,
                    'contactno'        => $request->contactno,
                    'warrentydate'     => $stockItem['warrentydate'] ?? null,
                    'repairing_charge' => $repairingCharge,
                    'remark'           => $request->remark ?? null,
                    'user_id'          => $userId,
                    'imei'             => $stockItem['imei'],
                    'color'            => $stockItem['color'],
                    'storage'          => $stockItem['storage'],
                    'purchase_cost'    => $purchaseCost,
                    'purchase_price'   => $purchasePrice,
                    'quantity'         => 1,
                    'available_quantity' => 1,
                    'created_at'       => $now,
                    'updated_at'       => $now,
                ]);

                $totalCost += $purchasePrice;
                $createdCount++;
                $ledgerService->syncPurchase($purchase);
            }
        });

        $message = $createdCount . " stock items added successfully | (Total Cost: ₹" . number_format($totalCost, 2) . ")";

        return redirect()->route('allpurchases')->withStatus($createdCount > 0 ? $message : 'Failed to add stock items');
    }

    public function deleteStock($id, Request $request, LedgerService $ledgerService)
    {
        $purchase = (Purchase::query())->findOrFail($id);
        $purchase->update(['deleted' => 1]);
        $ledgerService->deleteAutoEntry('PURCHASE', (int) $purchase->id);

        return redirect()->route('allpurchases')->withStatus('Stock Deleted Successfully..');
    }

    public function editPurchase($id)
    {
        $purchase = (Purchase::query())->findOrFail($id);

        return view('purchase.newpurchase', [
            'purchase' => $purchase,
        ]);
    }

    public function updatePurchase(Request $request, LedgerService $ledgerService)
    {
        $purchase = (Purchase::query())->findOrFail($request->id);
        $trackingType = $this->normalizeTrackingType($request->input('tracking_type'), $request->input('device_type'));

        $request->merge(['tracking_type' => $trackingType]);

        $request->validate(array_merge([
            'model'         => 'required',
            'imei'          => $trackingType === 'bulk'
                ? 'nullable|string|max:255'
                : [
                    'required',
                    'string',
                    'max:255',
                    Rule::unique('purchases', 'imei')->where('deleted', 0)->ignore($purchase->id),
                ],
            'purchase_date' => 'required',
            'purchase_cost' => 'required|numeric|min:0',
            'quantity'      => $trackingType === 'bulk' ? 'required|integer|min:1' : 'nullable|integer|min:1',
            'sku'           => 'nullable|string|max:255',
        ], $this->purchaseDocumentValidationRules()), [
            'imei.unique' => 'This IMEI already exists in stock.',
        ]);

        $isBulk = $trackingType === 'bulk';
        $quantity = $isBulk ? max(1, (int) $request->quantity) : 1;
        $alreadySoldUnits = $purchase->sold_units;

        $purchase->model            = $request->model;
        $purchase->device_type      = $request->device_type;
        $purchase->tracking_type    = $trackingType;
        $purchase->sku              = $request->sku ?: null;
        $purchase->imei             = $isBulk ? null : $request->imei;
        $purchase->purchase_date    = $request->purchase_date;
        $purchase->color            = $request->color ?: null;
        $purchase->storage          = $request->storage ?: null;
        $purchase->purchase_from    = $request->purchase_from;
        $purchase->contactno        = $request->contactno;
        $purchase->purchase_cost    = $request->purchase_cost;
        $purchase->repairing_charge = $request->repairing_charge;
        $purchase->warrentydate     = $request->warrentydate;
        $purchase->quantity         = $quantity;

        $repairingCharge = $purchase->purchase_price = 0;
        $purchaseCost = 0;
        if ($purchase->repairing_charge > 0) {
            $repairingCharge = $purchase->repairing_charge;
        }
        if ($purchase->purchase_cost > 0) {
            $purchaseCost = $purchase->purchase_cost;
        }
        $purchase->purchase_price = floatval($purchaseCost + $repairingCharge);
        $purchase->available_quantity = max(0, $quantity - ($isBulk ? $alreadySoldUnits : ($purchase->is_sold ? 1 : 0)));
        $purchase->is_sold = $purchase->available_quantity <= 0;
        $purchase->remark         = $request->remark;
        $purchase->user_id        = Auth::user()->id;

        if ($request->file('document') != null && count($request->file('document')) > 0) {
            $purchase->document = $this->uploadFiles($request->file('document'));
        }
        $purchase->update();
        $this->storePurchaseDocuments($purchase, $request);
        $ledgerService->syncPurchase($purchase->fresh());

        return redirect()->route('allpurchases')->withStatus("Stock Updated Successfully.. :: '" . $purchase->model . "'");
    }

    // Function for uploading documents
    public function uploadFiles($documents): string
    {
        foreach ($documents as $file) {
            $filename = time() . $file->getClientOriginalName();
            $file->move(public_path('documents/purchases/'), $filename);
            $docs[] = $filename;
        }

        return implode(',', $docs);
    }

    public function importStocks()
    {
        return view('purchase.import');
    }

    private function filteredPurchasesQuery(Request $request)
    {
        $search = $request->input('search');
        $isSold = $request->input('is_sold');
        $year = $request->input('year');
        $storage = $request->input('storage');
        $color = $request->input('color');

        return (Purchase::query())
            ->when($search, function ($query, $search): void {
                $query->where(function ($q) use ($search): void {
                    $q->where('id', 'like', "%{$search}%")
                        ->orWhere('imei', 'like', "%{$search}%")
                        ->orWhere('sku', 'like', "%{$search}%")
                        ->orWhere('model', 'like', "%{$search}%")
                        ->orWhere('purchase_from', 'like', "%{$search}%");
                });
            })
            ->when(($isSold != ''), function ($query) use ($isSold): void {
                if ($isSold == 2) {
                    $query->where('is_sold', 0);
                } else {
                    $query->where('is_sold', 1);
                }
            })
            ->when($year, function ($query) use ($year): void {
                $query->whereYear('purchase_date', $year);
            })
            ->when($storage, function ($query) use ($storage): void {
                $query->where('storage', 'like', "%{$storage}");
            })
            ->when($color, function ($query) use ($color): void {
                $query->where('color', $color);
            })
            ->where('deleted', 0);
    }

    private function buildStockSummaryLabel(Request $request): string
    {
        $parts = [];

        if ($request->filled('year')) {
            $parts[] = 'Year ' . $request->input('year');
        }

        if ($request->filled('storage')) {
            $parts[] = 'Storage ' . $request->input('storage');
        }

        if ($request->filled('color')) {
            $parts[] = 'Color ' . $request->input('color');
        }

        if ($request->input('is_sold') !== null && $request->input('is_sold') !== '') {
            $parts[] = $request->input('is_sold') == 2 ? 'Available Only' : 'Sold Only';
        }

        if ($request->filled('search')) {
            $parts[] = 'Search "' . $request->input('search') . '"';
        }

        return empty($parts) ? 'All Stock Records' : implode(' | ', $parts);
    }

    public function downloadStock(Request $request): void
    {
        echo 'Download Stocks';
        exit;
    }

    public function importStocksData(Request $request)
    {
        $request->validate([
            'stockdata' => 'required|mimes:csv,txt',
        ]);
        $file = $request->file('stockdata');

        if (($handle = fopen($file, 'r')) !== false) {
            fgetcsv($handle, 1000, ';');
            while (($data = fgetcsv($handle, 1000, ';')) !== false) {
                $is_sold = $data[8] !== null && $data[8] !== '' && $data[8] !== '0' ? 1 : 0;
                Purchase::create([
                    'purchase_date'    => \DateTime::createFromFormat('d.m.Y', $data[1])->format('Y-m-d'),
                    'imei'             => $data[2],
                    'model'            => $data[3],
                    'storage'          => $data[4],
                    'color'            => $data[5],
                    'purchase_from'    => $data[6],
                    'contactno'        => ($data[7] !== null && $data[7] !== '' && $data[7] !== '0') ? $data[7] : null,
                    'purchase_cost'    => trim(($data[9] !== null && $data[9] !== '' && $data[9] !== '0') ? $data[9] : 0),
                    'repairing_charge' => trim($data[10] !== null && $data[10] !== '' && $data[10] !== '0' ? $data[10] : 0),
                    'remark'           => $data[11],
                    'purchase_price'   => trim((string) $data[12]),
                    'user_id'          => Auth::user()->id,
                    'device_type'      => 'Phone',
                    'tracking_type'    => 'serialized',
                    'quantity'         => 1,
                    'available_quantity' => $is_sold ? 0 : 1,
                    'is_sold'          => $is_sold,
                ]);
            }
            fclose($handle);
        }

        return redirect()->route('allpurchases')->withStatus('Stocks imported successfully.');
    }

    /* Get parties on add stock form */
    public function getParties(Request $request)
    {
        $search = $request->get('partname');

        $parties = (Purchase::select('purchase_from', 'contactno'))
            ->where('purchase_from', 'LIKE', '%' . $search . '%')
            ->where('deleted', 0)
            ->groupBy('purchase_from', 'contactno')
            ->limit(10)
            ->get();

        return response()->json($parties);
    }

    public function getColors(Request $request)
    {
        $search = trim((string) $request->get('color', ''));

        $colors = (Purchase::query())
            ->select('color')
            ->where('deleted', 0)
            ->whereNotNull('color')
            ->where('color', '!=', '')
            ->where('color', 'LIKE', '%' . $search . '%')
            ->distinct()
            ->orderBy('color')
            ->limit(10)
            ->get();

        return response()->json($colors);
    }

    /* Check whether an IMEI is already in stock (used for on-blur validation) */
    public function checkImei(Request $request)
    {
        $imei = trim((string) $request->get('imei', ''));

        if ($imei === '') {
            return response()->json(['exists' => false]);
        }

        $query = Purchase::query()
            ->where('imei', $imei)
            ->where('deleted', 0);

        if ($request->filled('exclude_id')) {
            $query->where('id', '!=', $request->get('exclude_id'));
        }

        return response()->json(['exists' => $query->exists()]);
    }

    private function normalizeTrackingType(?string $trackingType, ?string $deviceType): string
    {
        if ($trackingType === 'bulk') {
            return 'bulk';
        }

        if ($trackingType === 'serialized') {
            return 'serialized';
        }

        return $deviceType === 'Accessories' ? 'bulk' : 'serialized';
    }

    public function getStorages(Request $request)
    {
        $search = trim((string) $request->get('storage', ''));

        $storages = (Purchase::query())
            ->select('storage')
            ->where('deleted', 0)
            ->whereNotNull('storage')
            ->where('storage', '!=', '')
            ->where('storage', 'LIKE', '%' . $search . '%')
            ->distinct()
            ->orderBy('storage')
            ->limit(10)
            ->get();

        return response()->json($storages);
    }
}
