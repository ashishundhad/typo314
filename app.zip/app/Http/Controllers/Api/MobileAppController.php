<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\CompanySetting;
use App\Models\Customer;
use App\Models\Expense;
use App\Models\Invoice;
use App\Models\InvoiceItem;
use App\Models\Party;
use App\Models\PaymentMethod;
use App\Models\Purchase;
use App\Models\Transaction;
use App\Services\Ledger\LedgerService;
use App\Services\OpeningBalanceService;
use Barryvdh\DomPDF\Facade\Pdf;
use Carbon\Carbon;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use Illuminate\Validation\Rule;

class MobileAppController extends Controller
{
    public function dashboard(Request $request): JsonResponse
    {
        $today = Carbon::today();
        $startOfMonth = Carbon::now()->startOfMonth();
        $endOfMonth = Carbon::now()->endOfDay();
        $sevenDaysAgo = Carbon::now()->subDays(7)->startOfDay();

        $recentInvoices = Invoice::query()
            ->where('deleted', 0)
            ->orderByDesc('invoice_date')
            ->limit(5)
            ->get([
                'id',
                'invoice_no',
                'customer_name',
                'invoice_date',
                'net_amount',
                'payment_type',
            ]);

        return response()->json([
            'summary' => [
                'stocks_in_hand' => Purchase::query()->where('is_sold', 0)->where('deleted', 0)->count(),
                'today_sales' => (float) Invoice::query()->whereDate('invoice_date', $today)->where('deleted', 0)->sum('net_amount'),
                'month_sales' => (float) Invoice::query()->whereBetween('invoice_date', [$startOfMonth, $endOfMonth])->where('deleted', 0)->sum('net_amount'),
                'month_expenses' => (float) Expense::query()->whereBetween('entrydate', [$startOfMonth, $endOfMonth])->where('deleted', 0)->sum('amount'),
                'recent_sales_count' => Invoice::query()->whereBetween('invoice_date', [$sevenDaysAgo, $endOfMonth])->where('deleted', 0)->count(),
            ],
            'recent_invoices' => $recentInvoices,
        ]);
    }

    public function paymentMethods(): JsonResponse
    {
        return response()->json([
            'data' => PaymentMethod::query()->orderBy('id')->get(),
        ]);
    }

    public function parties(Request $request): JsonResponse
    {
        $perPage = min((int) $request->integer('per_page', 15), 100);
        $search = trim((string) $request->input('search'));

        $parties = Party::query()
            ->where('deleted', 0)
            ->when($search !== '', function ($query) use ($search) {
                $query->where(function ($q) use ($search) {
                    $q->where('party_name', 'like', '%' . $search . '%')
                        ->orWhere('phone', 'like', '%' . $search . '%')
                        ->orWhere('email', 'like', '%' . $search . '%');
                });
            })
            ->withSum([
                'transactions as credit_total' => fn ($query) => $query->where('transaction_type', 'credit'),
            ], 'amount')
            ->withSum([
                'transactions as debit_total' => fn ($query) => $query->where('transaction_type', 'debit'),
            ], 'amount')
            ->latest()
            ->paginate($perPage);

        $parties->getCollection()->transform(function (Party $party) {
            return [
                'id' => $party->id,
                'party_name' => $party->party_name,
                'phone' => $party->phone,
                'email' => $party->email,
                'address' => $party->address,
                'party_type' => $party->party_type,
                'credit_total' => (float) ($party->credit_total ?? 0),
                'debit_total' => (float) ($party->debit_total ?? 0),
                'balance' => (float) $party->balance,
            ];
        });

        return response()->json($parties);
    }

    public function partyDetail(int $id): JsonResponse
    {
        $party = Party::query()
            ->where('deleted', 0)
            ->whereKey($id)
            ->with(['transactions' => function ($query) {
                $query->orderBy('payment_date')->orderBy('id');
            }])
            ->firstOrFail();

        $runningBalance = 0;
        $transactions = $party->transactions->map(function ($transaction) use (&$runningBalance) {
            $runningBalance += $transaction->transaction_type === 'credit'
                ? $transaction->amount
                : -$transaction->amount;

            return [
                'id' => $transaction->id,
                'payment_date' => $transaction->payment_date,
                'transaction_type' => $transaction->transaction_type,
                'payment_method' => $transaction->payment_method,
                'amount' => (float) $transaction->amount,
                'note' => $transaction->note,
                'running_balance' => (float) $runningBalance,
            ];
        })->values();

        return response()->json([
            'data' => [
                'id' => $party->id,
                'party_name' => $party->party_name,
                'phone' => $party->phone,
                'email' => $party->email,
                'address' => $party->address,
                'party_type' => $party->party_type,
                'transactions' => $transactions,
            ],
        ]);
    }

    public function invoices(Request $request): JsonResponse
    {
        $perPage = min((int) $request->integer('per_page', 15), 100);
        $search = trim((string) $request->input('search'));

        $invoices = Invoice::query()
            ->where('deleted', 0)
            ->when($search !== '', function ($query) use ($search) {
                $query->where(function ($q) use ($search) {
                    $q->where('invoice_no', 'like', '%' . $search . '%')
                        ->orWhereHas('customer', function ($customerQuery) use ($search) {
                            $customerQuery->where('name', 'like', '%' . $search . '%')
                                ->orWhere('phone', 'like', '%' . $search . '%');
                        });
                });
            })
            ->orderByDesc('invoice_date')
            ->paginate($perPage);

        return response()->json($invoices);
    }

    public function invoiceDetail(int $id): JsonResponse
    {
        $invoice = Invoice::query()
            ->with(['items.purchase'])
            ->where('deleted', 0)
            ->findOrFail($id);

        return response()->json([
            'data' => $invoice,
        ]);
    }

    public function companySettings(): JsonResponse
    {
        $setting = CompanySetting::current();

        return response()->json([
            'data' => [
                'company_name' => $setting->company_name,
                'gst_enabled'  => $setting->gst_enabled,
                'gst_number'   => $setting->gst_enabled ? $setting->gst_number : null,
            ],
        ]);
    }

    public function searchImeiStock(string $imei): JsonResponse
    {
        $items = (Purchase::query())
            ->where('imei', 'LIKE', $imei . '%')
            ->where(function ($query): void {
                $query->where('tracking_type', 'serialized')
                    ->orWhereNull('tracking_type');
            })
            ->where('is_sold', 0)
            ->where('deleted', 0)
            ->take(10)
            ->get();

        return response()->json(['data' => $items]);
    }

    public function searchBulkStock(string $term): JsonResponse
    {
        $items = (Purchase::query())
            ->where('tracking_type', 'bulk')
            ->where('deleted', 0)
            ->where('available_quantity', '>', 0)
            ->where(function ($query) use ($term): void {
                $query->where('model', 'LIKE', $term . '%')
                    ->orWhere('sku', 'LIKE', $term . '%');
            })
            ->orderBy('model')
            ->take(10)
            ->get();

        return response()->json(['data' => $items]);
    }

    public function storeInvoice(Request $request, LedgerService $ledgerService): JsonResponse
    {
        $validated = $request->validate([
            'customer_name'                 => 'required|string|max:255',
            'customer_no'                   => 'nullable|string|max:20',
            'customer_address'              => 'nullable|string',
            'invoice_date'                  => 'required|date',
            'payment_type'                  => 'required|string|max:50',
            'discount_amount'               => 'nullable|numeric|min:0',
            'discount_rate'                 => 'nullable|numeric|min:0',
            'cgst_rate'                     => 'nullable|numeric|min:0',
            'sgst_rate'                     => 'nullable|numeric|min:0',
            'igst_rate'                     => 'nullable|numeric|min:0',
            'cgst_amount'                   => 'nullable|numeric|min:0',
            'sgst_amount'                   => 'nullable|numeric|min:0',
            'igst_amount'                   => 'nullable|numeric|min:0',
            'declaration'                   => 'nullable|string',
            'items'                         => 'required|array|min:1',
            'items.*.item_id'               => 'required|integer|exists:purchases,id',
            'items.*.item_description'      => 'nullable|string',
            'items.*.unit_price'            => 'required|numeric|min:0',
            'items.*.quantity'              => 'required|integer|min:1',
            'items.*.warranty_expiry_date'  => 'nullable|date',
        ]);

        $invoice = DB::transaction(function () use ($validated, $request, $ledgerService) {
            $totalAmount = 0;
            foreach ($validated['items'] as $item) {
                $totalAmount += $item['unit_price'] * $item['quantity'];
            }

            $taxAmount = ($validated['cgst_amount'] ?? 0) + ($validated['sgst_amount'] ?? 0) + ($validated['igst_amount'] ?? 0);
            $discount = $validated['discount_amount'] ?? 0;
            $netAmount = $totalAmount + $taxAmount - $discount;

            $customer = Customer::firstOrCreateForInvoice(
                $validated['customer_name'],
                $validated['customer_no'] ?? null,
                $validated['customer_address'] ?? null
            );

            $invoice = Invoice::create([
                'customer_id'      => $customer->id,
                'invoice_date'     => $validated['invoice_date'],
                'invoice_no'       => $this->nextInvoiceNumber(),
                'total_amount'     => $totalAmount,
                'net_amount'       => $netAmount,
                'cgst_rate'        => $validated['cgst_rate'] ?? 0,
                'sgst_rate'        => $validated['sgst_rate'] ?? 0,
                'igst_rate'        => $validated['igst_rate'] ?? 0,
                'cgst_amount'      => $validated['cgst_amount'] ?? 0,
                'sgst_amount'      => $validated['sgst_amount'] ?? 0,
                'igst_amount'      => $validated['igst_amount'] ?? 0,
                'tax_amount'       => $taxAmount,
                'discount'         => $discount,
                'discount_rate'    => $validated['discount_rate'] ?? 0,
                'declaration'      => $validated['declaration'] ?? null,
                'payment_type'     => $validated['payment_type'],
                'is_paid'          => 1,
                'invoice_by'       => $request->user()->id,
            ]);

            foreach ($validated['items'] as $item) {
                $purchase = (Purchase::query())->findOrFail($item['item_id']);
                $quantity = (int) $item['quantity'];
                $unitPrice = (float) $item['unit_price'];

                $validationError = $this->validateInvoiceItemQuantity($purchase, $quantity);
                if ($validationError !== null) {
                    abort(422, $validationError);
                }

                InvoiceItem::create([
                    'invoice_id'           => $invoice->id,
                    'item_id'              => $item['item_id'],
                    'item_description'     => $item['item_description'] ?? $purchase->model,
                    'quantity'             => $quantity,
                    'unit_price'           => $unitPrice,
                    'total_amount'         => $unitPrice * $quantity,
                    'warranty_expiry_date' => $item['warranty_expiry_date'] ?? null,
                    'profit'               => ($unitPrice - $purchase->purchase_price) * $quantity,
                ]);

                $this->applyInvoiceSaleToPurchase($purchase, $quantity, $validated['invoice_date']);
            }

            $ledgerService->syncInvoice($invoice->fresh());

            return $invoice->fresh('items');
        });

        return response()->json(['data' => $invoice], 201);
    }

    public function invoicePdf(int $id)
    {
        $invoice = (Invoice::with('items.purchase'))->findOrFail($id);
        $amountInWords = $this->amoutInWords((float) $invoice->net_amount);

        $pdf = Pdf::loadView('invoice.pdf', [
            'invoice' => $invoice,
            'amountInWords' => $amountInWords,
        ]);

        return response($pdf->output(), 200, [
            'Content-Type' => 'application/pdf',
            'Content-Disposition' => 'inline; filename="invoice-' . $invoice->invoice_no . '.pdf"',
        ]);
    }

    public function invoiceWhatsappLink(int $id): JsonResponse
    {
        $invoice = (Invoice::with('items.purchase'))->findOrFail($id);

        if (! $invoice->customer_no) {
            return response()->json([
                'message' => 'This invoice has no customer phone number on file.',
            ], 422);
        }

        $amountInWords = $this->amoutInWords((float) $invoice->net_amount);
        $fileName = $invoice->invoice_no . '-' . Str::random(10) . '.pdf';

        $pdf = Pdf::loadView('invoice.pdf', [
            'invoice' => $invoice,
            'amountInWords' => $amountInWords,
        ]);
        // 'invoice_pdfs', not 'public': the 'public' disk's root gets suffixed
        // per-tenant by tenancy while this request runs, so a file saved there
        // would never be reachable through the app's one shared public/storage
        // symlink — see the disk's own comment in config/filesystems.php.
        Storage::disk('invoice_pdfs')->put('pdfs/' . $fileName, $pdf->output());
        $url = asset('storage/pdfs/' . $fileName);

        $companyName = CompanySetting::current()->company_name;
        $message = "Hello " . ucfirst($invoice->customer_name) . ",\n\nThank you for your purchase at {$companyName}!\n\n"
            . "Your invoice total is ₹" . number_format((float) $invoice->net_amount, 2) . ".\n\n"
            . "You can view and download your digital invoice here:\n" . $url;

        $formattedNo = $invoice->customer_no;
        if (! str_starts_with($formattedNo, '+')) {
            $formattedNo = strlen($formattedNo) == 10 ? '91' . $formattedNo : $formattedNo;
        } else {
            $formattedNo = str_replace('+', '', $formattedNo);
        }

        return response()->json([
            'data' => [
                'url' => 'https://wa.me/' . $formattedNo . '?text=' . urlencode($message),
                'message' => $message,
            ],
        ]);
    }

    private function nextInvoiceNumber(): string
    {
        $lastInvoice = Invoice::orderBy('id', 'desc')->first();
        $currentYear = date('Y');
        $nextInvoiceNo = 1;

        if ($lastInvoice) {
            // Match the trailing year+sequence digits regardless of prefix, so numbering
            // continues correctly across the old "INVOICEYYYY####" and new "INV-YYYY####" formats.
            preg_match('/(\d{4})\d{4}$/', (string) $lastInvoice->invoice_no, $matches);
            $lastYear = $matches[1] ?? null;

            if ($lastYear == $currentYear) {
                $lastId = intval(substr((string) $lastInvoice->invoice_no, -4));
                $nextInvoiceNo = $lastId + 1;
            }
        }

        return 'INV-' . $currentYear . str_pad((string) $nextInvoiceNo, 4, '0', STR_PAD_LEFT);
    }

    public function purchases(Request $request): JsonResponse
    {
        $perPage = min((int) $request->integer('per_page', 15), 100);

        $purchases = Purchase::query()
            ->where('deleted', 0)
            ->orderByDesc('purchase_date')
            ->paginate($perPage);

        return response()->json($purchases);
    }

    public function storePurchase(Request $request, LedgerService $ledgerService): JsonResponse
    {
        $isBulk = $request->input('tracking_type') === 'bulk';

        $validated = $request->validate([
            'device_type'   => ['required', Rule::in(['Phone', 'Tablet', 'Laptop', 'Accessories'])],
            'tracking_type' => ['nullable', Rule::in(['serialized', 'bulk'])],
            'model'         => 'required|string|max:255',
            'imei'          => $isBulk ? 'nullable|string|max:255' : 'required|string|max:255',
            'sku'           => 'nullable|string|max:255',
            'quantity'      => $isBulk ? 'required|integer|min:1' : 'nullable|integer|min:1',
            'color'         => 'nullable|string|max:255',
            'storage'       => 'nullable|string|max:255',
            'warrentydate'  => 'nullable|date',
            'purchase_from' => 'nullable|string|max:255',
            'contactno'     => 'nullable|string|max:20',
            'purchase_date' => 'nullable|date',
            'purchase_cost' => 'required|numeric|min:0',
            'msp'           => 'nullable|numeric|min:0',
            'remark'        => 'nullable|string',
        ]);

        $quantity = $isBulk ? max(1, (int) $validated['quantity']) : 1;

        $purchase = new Purchase();
        $purchase->device_type      = $validated['device_type'];
        $purchase->tracking_type    = $isBulk ? 'bulk' : 'serialized';
        $purchase->model            = $validated['model'];
        $purchase->sku              = $validated['sku'] ?? null;
        $purchase->imei             = $isBulk ? null : $validated['imei'];
        $purchase->color            = $validated['color'] ?? null;
        $purchase->storage          = $validated['storage'] ?? null;
        $purchase->warrentydate     = $validated['warrentydate'] ?? null;
        $purchase->purchase_from    = $validated['purchase_from'] ?? null;
        $purchase->contactno        = $validated['contactno'] ?? null;
        $purchase->purchase_date    = $validated['purchase_date'] ?? Carbon::now()->format('Y-m-d');
        $purchase->purchase_cost    = $validated['purchase_cost'];
        $purchase->msp              = $validated['msp'] ?? 0;
        $purchase->remark           = $validated['remark'] ?? null;
        $purchase->repairing_charge = 0;
        $purchase->purchase_price   = $purchase->purchase_cost;
        $purchase->quantity         = $quantity;
        $purchase->available_quantity = $quantity;
        $purchase->is_sold          = false;
        $purchase->user_id          = $request->user()->id;
        $purchase->save();

        $ledgerService->syncPurchase($purchase->fresh());

        return response()->json(['data' => $purchase], 201);
    }

    public function expenses(Request $request): JsonResponse
    {
        $perPage = min((int) $request->integer('per_page', 15), 100);

        $expenses = Expense::query()
            ->where('deleted', 0)
            ->orderByDesc('entrydate')
            ->paginate($perPage);

        return response()->json($expenses);
    }

    public function transactions(Request $request): JsonResponse
    {
        $filters = [
            'date_from' => $request->input('date_from'),
            'date_to' => $request->input('date_to'),
            'transaction_type' => $request->input('transaction_type'),
            'payment_method' => $request->input('payment_method'),
            'source' => $request->input('source'),
        ];

        $entries = (new Transaction())->getLedgerEntries($filters)->values();
        $openingBalance = (new Transaction())->getOpeningBalance($filters);
        $perPage = min((int) $request->integer('per_page', 20), 100);
        $page = max((int) $request->integer('page', 1), 1);

        $paginatedItems = $entries->forPage($page, $perPage)->values();

        return response()->json([
            'data' => $paginatedItems,
            'meta' => [
                'current_page' => $page,
                'per_page' => $perPage,
                'total' => $entries->count(),
                'last_page' => (int) ceil(max($entries->count(), 1) / $perPage),
            ],
            'summary' => [
                'opening_balance' => (float) ($openingBalance['balance'] ?? 0),
                'cash_balance' => (float) ($openingBalance['cash_balance'] ?? 0),
                'bank_balance' => (float) ($openingBalance['bank_balance'] ?? 0),
                'total_in' => (float) $entries->where('transaction_type', 'credit')->sum('amount'),
                'total_out' => (float) $entries->where('transaction_type', 'debit')->sum('amount'),
            ],
        ]);
    }

    public function storeTransaction(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'party_id' => ['required', 'exists:parties,id'],
            'payment_date' => ['required', 'date'],
            'transaction_type' => ['required', 'in:credit,debit'],
            'payment_method' => ['required'],
            'amount' => ['required', 'numeric', 'min:0.01'],
            'note' => ['nullable', 'string'],
        ]);

        $validated['created_by'] = $request->user()->id;

        $transaction = Transaction::create($validated);

        app(OpeningBalanceService::class)->recalculateFrom($validated['payment_date']);

        return response()->json([
            'message' => 'Transaction created successfully.',
            'data' => $transaction,
        ], 201);
    }

    public function deleteTransaction(Request $request, int $id): JsonResponse
    {
        $transaction = Transaction::query()->findOrFail($id);

        $recalculateFrom = $transaction->payment_date;
        $transaction->delete();

        app(OpeningBalanceService::class)->recalculateFrom($recalculateFrom);

        return response()->json([
            'message' => 'Transaction deleted successfully.',
        ]);
    }
}
