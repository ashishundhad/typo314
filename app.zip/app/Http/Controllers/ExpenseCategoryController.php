<?php

namespace App\Http\Controllers;

use App\Models\ExpenseCategory;
use Illuminate\Http\Request;

class ExpenseCategoryController extends Controller
{
    public function index(Request $request)
    {
        if ($request->ajax()) {
            $search = trim((string) $request->input('search.value', ''));

            $query = ExpenseCategory::query()->notDeleted()->withCount('expenses');

            if ($search !== '') {
                $query->where('name', 'like', "%{$search}%");
            }

            $recordsTotal = ExpenseCategory::notDeleted()->count();
            $recordsFiltered = (clone $query)->count();

            $start = max((int) $request->input('start', 0), 0);
            $length = (int) $request->input('length', 10);
            if ($length < 0) {
                $length = 10;
            }

            $categories = $query->orderBy('name')->skip($start)->take($length)->get();

            $data = $categories->values()->map(function (ExpenseCategory $category, $index) use ($start) {
                return [
                    'id' => $category->id,
                    'DT_RowIndex' => $start + $index + 1,
                    'name' => $category->name,
                    'expenses_count' => $category->expenses_count,
                ];
            });

            return response()->json([
                'draw' => (int) $request->input('draw', 1),
                'recordsTotal' => $recordsTotal,
                'recordsFiltered' => $recordsFiltered,
                'data' => $data,
            ]);
        }

        return view('expense-categories.index');
    }

    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:255|unique:expense_categories,name,' . $request->id,
        ]);

        if ($request->id) {
            $category = ExpenseCategory::findOrFail($request->id);
            $category->update(['name' => $request->name]);

            return response()->json(['status' => true, 'message' => 'Category updated successfully!']);
        }

        ExpenseCategory::create(['name' => $request->name, 'deleted' => 0]);

        return response()->json(['status' => true, 'message' => 'Category created successfully!']);
    }

    public function destroy($id)
    {
        $category = ExpenseCategory::findOrFail($id);

        if ($category->expenses()->exists()) {
            return response()->json([
                'status' => false,
                'message' => 'This category is used by existing expenses and cannot be deleted.',
            ], 422);
        }

        $category->update(['deleted' => 1]);

        return response()->json(['status' => true, 'message' => 'Category deleted successfully!']);
    }
}
