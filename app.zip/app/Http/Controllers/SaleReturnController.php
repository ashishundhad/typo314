<?php

namespace App\Http\Controllers;

use App\Models\Invoice;
use App\Models\InvoiceItem;
use App\Models\Purchase;
use App\Models\SaleReturn;
use App\Services\Ledger\LedgerService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class SaleReturnController extends Controller
{
    public function index(Request $request)
    {
        if ($request->ajax()) {
            $search = trim((string) $request->input('search.value', ''));

            $query = SaleReturn::query()
                ->notDeleted()
                ->with(['invoice', 'invoiceItem', 'purchase', 'processedBy']);

            if ($search !== '') {
                $query->where(function ($builder) use ($search) {
                    $builder->whereHas('invoice', function ($invoiceQuery) use ($search) {
                        $invoiceQuery->where('invoice_no', 'like', "%{$search}%");
                    })->orWhereHas('purchase', function ($purchaseQuery) use ($search) {
                        $purchaseQuery->where('model', 'like', "%{$search}%")
                            ->orWhere('imei', 'like', "%{$search}%");
                    });
                });
            }

            $recordsTotal = SaleReturn::notDeleted()->count();
            $recordsFiltered = (clone $query)->count();

            $start = max((int) $request->input('start', 0), 0);
            $length = (int) $request->input('length', 10);
            if ($length < 0) {
                $length = 10;
            }

            $returns = $query->orderBy('id', 'desc')->skip($start)->take($length)->get();

            $data = $returns->values()->map(function (SaleReturn $saleReturn, $index) use ($start) {
                return [
                    'id' => $saleReturn->id,
                    'DT_RowIndex' => $start + $index + 1,
                    'invoice_no' => $saleReturn->invoice?->invoice_no,
                    'item' => $saleReturn->purchase?->display_code . ' - ' . $saleReturn->purchase?->model,
                    'quantity' => $saleReturn->quantity,
                    'refund_amount' => number_format((float) $saleReturn->refund_amount, 2),
                    'condition' => $saleReturn->condition,
                    'reason' => $saleReturn->reason,
                    'return_date' => optional($saleReturn->return_date)->format('Y-m-d'),
                    'processed_by' => $saleReturn->processedBy?->name,
                ];
            });

            return response()->json([
                'draw' => (int) $request->input('draw', 1),
                'recordsTotal' => $recordsTotal,
                'recordsFiltered' => $recordsFiltered,
                'data' => $data,
            ]);
        }

        return view('sale-returns.index');
    }

    public function store(Request $request, LedgerService $ledgerService)
    {
        $request->validate([
            'invoice_item_id' => 'required|exists:invoice_items,id',
            'quantity' => 'required|integer|min:1',
            'condition' => 'required|in:resellable,damaged',
            'reason' => 'nullable|string|max:255',
            'notes' => 'nullable|string',
        ]);

        $invoiceItem = InvoiceItem::with(['invoice', 'purchase'])->findOrFail($request->invoice_item_id);
        $purchase = $invoiceItem->purchase;

        if (! $purchase) {
            return back()->withErrors(['error' => 'This item is no longer linked to a stock record and cannot be returned.']);
        }

        $alreadyReturned = SaleReturn::notDeleted()
            ->where('invoice_item_id', $invoiceItem->id)
            ->sum('quantity');

        $returnableQuantity = (int) $invoiceItem->quantity - (int) $alreadyReturned;

        if ($request->quantity > $returnableQuantity) {
            return back()->withErrors(['error' => "Only {$returnableQuantity} unit(s) of this item can still be returned."]);
        }

        $unitPrice = (float) $invoiceItem->unit_price;
        $refundAmount = $unitPrice * (int) $request->quantity;

        DB::beginTransaction();
        try {
            $saleReturn = SaleReturn::create([
                'invoice_id' => $invoiceItem->invoice_id,
                'invoice_item_id' => $invoiceItem->id,
                'purchase_id' => $purchase->id,
                'quantity' => $request->quantity,
                'refund_amount' => $refundAmount,
                'condition' => $request->condition,
                'reason' => $request->reason,
                'notes' => $request->notes,
                'processed_by' => Auth::id(),
                'return_date' => now()->toDateString(),
                'deleted' => 0,
            ]);

            if ($request->condition === 'resellable') {
                $this->restoreInvoiceSaleToPurchase($purchase, (int) $request->quantity);
            } else {
                $purchase->update(['condition' => 'Damaged (returned ' . now()->toDateString() . ')']);
            }

            DB::commit();
        } catch (\Exception $e) {
            DB::rollBack();

            return back()->withErrors(['error' => 'An error occurred while processing the return: ' . $e->getMessage()]);
        }

        $ledgerService->syncSaleReturn($saleReturn->fresh('invoice'));

        return back()->withStatus('Return processed successfully.');
    }

    public function destroy($id, LedgerService $ledgerService)
    {
        DB::beginTransaction();
        try {
            $saleReturn = SaleReturn::with('purchase')->findOrFail($id);
            $purchase = $saleReturn->purchase;

            if ($purchase && $saleReturn->condition === 'resellable') {
                // Undo the restock: put the returned quantity back on the sold side.
                $this->applyInvoiceSaleToPurchase(
                    $purchase,
                    (int) $saleReturn->quantity,
                    optional($saleReturn->invoice)->invoice_date ?? now()->toDateString()
                );
            }

            $saleReturn->update(['deleted' => 1]);

            DB::commit();
        } catch (\Exception $e) {
            DB::rollBack();

            return back()->withErrors(['error' => 'An error occurred while voiding the return.']);
        }

        $ledgerService->deleteAutoEntry('SALE_RETURN', (int) $saleReturn->id);

        return redirect()->route('sale-returns.index')->withStatus('Return voided successfully.');
    }
}
