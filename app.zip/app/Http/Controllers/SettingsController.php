<?php

namespace App\Http\Controllers;

use App\Models\CompanySetting;
use Illuminate\Http\Request;

class SettingsController extends Controller
{
    public function edit()
    {
        $setting = CompanySetting::current();

        return view('admin.settings', ['setting' => $setting]);
    }

    public function update(Request $request)
    {
        $request->validate([
            'company_name'   => 'required|string|max:255',
            'logo'           => 'nullable|image|max:2048',
            'address'        => 'nullable|string',
            'phone'          => 'nullable|string|max:20',
            'email'          => 'nullable|email|max:255',
            'gst_enabled'    => 'nullable|boolean',
            'gst_number'     => 'required_if:gst_enabled,1|nullable|string|max:20',
            'gst_percentage' => 'nullable|numeric|min:0|max:100',
            'default_gst_mode' => 'nullable|in:include,exclude,none',
        ], [
            'gst_number.required_if' => 'The GST number is required when GST is enabled.',
        ]);

        $setting = CompanySetting::current();

        $data = [
            'company_name'   => $request->company_name,
            'address'        => $request->address,
            'phone'          => $request->phone,
            'email'          => $request->email,
            'gst_enabled'    => $request->boolean('gst_enabled'),
            'gst_number'     => $request->boolean('gst_enabled') ? $request->gst_number : null,
            'gst_percentage' => $request->boolean('gst_enabled') ? $request->gst_percentage : null,
            'default_gst_mode' => $request->input('default_gst_mode', 'exclude'),
        ];

        if ($request->hasFile('logo')) {
            $file     = $request->file('logo');
            $filename = 'logo-' . time() . '.' . $file->getClientOriginalExtension();
            $file->move(public_path('assets/images/new_logo'), $filename);
            $data['logo'] = 'assets/images/new_logo/' . $filename;
        }

        $setting->update($data);

        return redirect()->back()->with('message', 'Settings updated successfully');
    }
}
