<?php
namespace App\Http\Controllers;

use App\Models\PendingDocumentUpload;
use App\Services\DocumentImageService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

/**
 * QR-code handoff for identity-document uploads: a staff member creating an invoice on
 * desktop (with no webcam / no existing photo on that machine) generates a one-time QR
 * code; a customer's or staff's phone scans it, lands on a plain unauthenticated mobile
 * page, and uploads/photographs the document there. The desktop page then pulls the
 * result in via "Check for upload" and attaches it to the invoice like any other
 * identity document (see InvoiceController::storeCustomerDocuments()).
 */
class DocumentUploadController extends Controller
{
    public function __construct(private readonly DocumentImageService $documentImageService)
    {
    }

    /**
     * Start a new upload session and return its token + the public URL to QR-encode.
     */
    public function create(Request $request)
    {
        $session = PendingDocumentUpload::startSession(Auth::id());

        return response()->json([
            'token' => $session->token,
            'url' => route('doc-upload.show', $session->token),
        ]);
    }

    /**
     * Authenticated poll from the desktop page: has the phone uploaded anything yet?
     */
    public function status($token)
    {
        $session = PendingDocumentUpload::where('token', $token)->first();

        if (! $session || $session->isExpired() || $session->status === 'claimed') {
            return response()->json(['status' => 'unavailable']);
        }

        if ($session->status !== 'uploaded') {
            return response()->json(['status' => 'pending']);
        }

        return response()->json([
            'status' => 'uploaded',
            'token' => $session->token,
            'document_type' => $session->document_type,
            'document_type_other' => $session->document_type_other,
            'document_type_label' => $session->document_type_label,
            'document_number' => $session->document_number,
        ]);
    }

    /**
     * Public mobile page — no auth, reachable only by whoever has the QR/link.
     */
    public function showUploadForm($token)
    {
        $session = PendingDocumentUpload::where('token', $token)->first();

        if (! $session || $session->isExpired()) {
            return view('document-uploads.expired');
        }

        if ($session->status !== 'pending') {
            return view('document-uploads.done');
        }

        return view('document-uploads.show', ['token' => $token]);
    }

    /**
     * Public mobile submit — no auth. Optimizes/stores the photo exactly like the
     * desktop upload path (DocumentImageService), just under a token-scoped temp
     * directory instead of an invoice's, since no invoice exists yet at this point.
     */
    public function submitUpload(Request $request, $token)
    {
        $session = PendingDocumentUpload::where('token', $token)->first();

        if (! $session || $session->isExpired() || $session->status !== 'pending') {
            return back()->withErrors(['error' => 'This upload link is no longer valid. Ask for a fresh QR code.']);
        }

        $request->validate([
            'document_type' => 'required|in:aadhar,pan,other',
            'document_type_other' => 'nullable|required_if:document_type,other|string|max:100',
            'document_number' => 'required|string|max:100',
            'image' => 'required|image|mimes:jpg,jpeg,png,webp|max:5120',
        ]);

        $optimized = $this->documentImageService->optimizeAndStore(
            $request->file('image'),
            'pending-document-uploads/' . $token
        );

        $session->update([
            'document_type' => $request->document_type,
            'document_type_other' => $request->document_type === 'other' ? $request->document_type_other : null,
            'document_number' => $request->document_number,
            'image_path' => $optimized['path'],
            'image_width' => $optimized['width'],
            'image_height' => $optimized['height'],
            'file_size' => $optimized['size'],
            'status' => 'uploaded',
        ]);

        return view('document-uploads.done');
    }
}
