<?php
namespace App\Http\Controllers;

use App\Models\{Customer, CustomerDocument, Invoice, InvoiceItem, InvoicePayment, PendingDocumentUpload, Purchase, SaleReturn};
use App\Services\DocumentImageService;
use App\Services\Ledger\LedgerService;
use Carbon\Carbon;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\{DB, Auth, Storage, URL};
use Illuminate\Support\Str;

class InvoiceController extends Controller
{
    // protected $googleContactService;

    public function __construct(private readonly DocumentImageService $documentImageService)
    {
        // $this->googleContactService = app('GoogleContact');
    }

    /**
     * Validation rules shared by create/update for optional customer ID documents.
     */
    private function documentValidationRules(): array
    {
        return [
            'documents'                 => 'nullable|array',
            'documents.*.type'          => 'required_with:documents|in:aadhar,pan,other',
            'documents.*.type_other'    => 'nullable|required_if:documents.*.type,other|string|max:100',
            'documents.*.number'        => 'required_with:documents|string|max:100',
            // A row either carries its own freshly-chosen file, or a pending_token
            // referencing a photo already uploaded via the QR handoff flow (see
            // DocumentUploadController) — never neither.
            'documents.*.image'         => 'required_without:documents.*.pending_token|image|mimes:jpg,jpeg,png,webp|max:5120',
            'documents.*.pending_token' => 'nullable|string|max:36',
        ];
    }

    /**
     * Optimize and persist any customer identity documents submitted with the invoice —
     * either a freshly-chosen file, or one already uploaded via the QR handoff flow and
     * referenced here by its pending_token.
     */
    private function storeCustomerDocuments(Invoice $invoice, Customer $customer, Request $request): void
    {
        foreach ($request->input('documents', []) as $index => $data) {
            $type = $data['type'] ?? null;
            $pendingToken = $data['pending_token'] ?? null;

            if (! $type) {
                continue;
            }

            if ($pendingToken) {
                $this->claimPendingDocument($invoice, $customer, $pendingToken, $type, $data['type_other'] ?? null, $data['number'] ?? '');
                continue;
            }

            $image = $request->file("documents.{$index}.image");

            if (! $image) {
                continue;
            }

            $optimized = $this->documentImageService->optimizeAndStore(
                $image,
                'customer-documents/' . $invoice->id
            );

            CustomerDocument::create([
                'invoice_id'          => $invoice->id,
                'customer_id'         => $customer->id,
                'document_type'       => $type,
                'document_type_other' => $type === 'other' ? ($data['type_other'] ?? null) : null,
                'document_number'     => $data['number'] ?? '',
                'document_image'      => $optimized['path'],
                'image_width'         => $optimized['width'],
                'image_height'        => $optimized['height'],
                'file_size'           => $optimized['size'],
                'uploaded_by'         => Auth::id(),
            ]);
        }
    }

    /**
     * Pull in a document that was uploaded via the QR handoff flow (DocumentUploadController)
     * instead of a direct file upload — move its already-optimized image into this
     * invoice's own documents directory and mark the pending session as claimed so it
     * can't be reused on a second invoice.
     */
    private function claimPendingDocument(Invoice $invoice, Customer $customer, string $token, string $type, ?string $typeOther, string $number): void
    {
        $pending = PendingDocumentUpload::where('token', $token)
            ->where('status', 'uploaded')
            ->first();

        if (! $pending || $pending->isExpired() || ! $pending->image_path) {
            return;
        }

        $newPath = 'customer-documents/' . $invoice->id . '/' . basename($pending->image_path);
        Storage::disk('public')->move($pending->image_path, $newPath);

        CustomerDocument::create([
            'invoice_id'          => $invoice->id,
            'customer_id'         => $customer->id,
            'document_type'       => $type,
            'document_type_other' => $type === 'other' ? $typeOther : null,
            'document_number'     => $number,
            'document_image'      => $newPath,
            'image_width'         => $pending->image_width,
            'image_height'        => $pending->image_height,
            'file_size'           => $pending->file_size,
            'uploaded_by'         => Auth::id(),
        ]);

        $pending->update(['status' => 'claimed']);
    }

    public function index(Request $request)
    {
        $search = trim((string) $request->input('search'));
        $paymentType = trim((string) $request->input('payment_type'));

        // Sidebar list only needs enough to render each row (and 'customer' to avoid an
        // N+1 on customer_name/customer_no), not the full items/purchases/documents
        // graph — that's loaded separately, only for whichever invoice is selected.
        $baseQuery = (Invoice::query())
            ->with('customer')
            ->where('deleted', 0)
            ->when($search !== '', function ($query) use ($search) {
                $query->where(function ($q) use ($search) {
                    $q->where('invoice_no', 'like', '%' . $search . '%')
                        ->orWhereHas('customer', function ($customerQuery) use ($search) {
                            $customerQuery->where('name', 'like', '%' . $search . '%')
                                ->orWhere('phone', 'like', '%' . $search . '%');
                        })
                        ->orWhereHas('items', function ($itemQuery) use ($search) {
                            $itemQuery->where('item_description', 'like', '%' . $search . '%')
                                ->orWhereHas('purchase', function ($purchaseQuery) use ($search) {
                                    $purchaseQuery->where('imei', 'like', '%' . $search . '%')
                                        ->orWhere('sku', 'like', '%' . $search . '%')
                                        ->orWhere('model', 'like', '%' . $search . '%');
                                });
                        });
                });
            })
            ->when($paymentType !== '', function ($query) use ($paymentType) {
                $query->where('payment_type', $paymentType);
            })
            ->orderBy('invoice_date', 'desc')
            ->orderBy('id', 'desc');

        $perPage = 20;
        $invoices = (clone $baseQuery)->paginate($perPage)->appends($request->query());

        $selectedInvoice = null;
        $amountInWords = null;
        $selectedInvoiceId = $request->integer('invoice');

        if ($selectedInvoiceId > 0) {
            // Looked up independently of the paginated list — the selected invoice may
            // live on a page other than the one currently shown.
            $selectedInvoice = (Invoice::query())
                ->with('items.purchase', 'documents')
                ->where('deleted', 0)
                ->find($selectedInvoiceId);
        }

        if (! $selectedInvoice) {
            $selectedInvoice = (clone $baseQuery)->with('items.purchase', 'documents')->first();
        }

        $returnedQuantities = collect();

        if ($selectedInvoice) {
            $amountInWords = $this->amoutInWords((float) $selectedInvoice->net_amount);

            $returnedQuantities = SaleReturn::notDeleted()
                ->whereIn('invoice_item_id', $selectedInvoice->items->pluck('id'))
                ->selectRaw('invoice_item_id, sum(quantity) as qty')
                ->groupBy('invoice_item_id')
                ->pluck('qty', 'invoice_item_id');
        }

        return view('invoice.index', [
            'invoices' => $invoices,
            'selectedInvoice' => $selectedInvoice,
            'amountInWords' => $amountInWords,
            'returnedQuantities' => $returnedQuantities,
            'paymentTypes' => (Invoice::query())
                ->where('deleted', 0)
                ->whereNotNull('payment_type')
                ->where('payment_type', '!=', '')
                ->distinct()
                ->orderBy('payment_type')
                ->pluck('payment_type'),
        ]);
    }

    public function newInvoice()
    {
        $stocksModel = (Purchase::query())
            ->where('deleted', 0)
            ->where(function ($query): void {
                $query->where(function ($serializedQuery): void {
                    $serializedQuery->where(function ($trackingQuery): void {
                        $trackingQuery->where('tracking_type', 'serialized')
                            ->orWhereNull('tracking_type');
                    })->where('is_sold', 0);
                })->orWhere(function ($bulkQuery): void {
                    $bulkQuery->where('tracking_type', 'bulk')
                        ->where('available_quantity', '>', 0);
                });
            })
            ->orderBy('purchase_date', 'desc')
            ->get();

        return view('invoice.add', [
            'stocksModel' => $stocksModel,
            'lastId'      => Invoice::nextInvoiceNumber(),
        ]);
    }

    public function createInvoice(Request $request, LedgerService $ledgerService)
    {
        // Validate request first, against the raw dd/mm/yyyy strings. Doing this before any
        // conversion means a failure (e.g. an invalid document photo) redisplays the form via
        // withInput() with the original dd/mm/yyyy value intact, instead of a converted Y-m-d
        // value that would fail re-parsing on resubmit.
        $isSplitPayment = $request->boolean('split_payment');

        $request->validate(array_merge([
            'items'                        => 'required|array|min:1',
            'items.*.item_id'              => 'required|integer|exists:purchases,id',
            'items.*.unit_price'           => 'required|numeric|min:0',
            'items.*.quantity'             => 'required|integer|min:1',
            'items.*.warranty_expiry_date' => 'nullable|date_format:d/m/Y',
            'customer_name'                => 'required|string|max:255',
            'invoice_date'                 => 'required|date_format:d/m/Y',
            'warranty_expiry_date'         => 'nullable|date_format:d/m/Y',
            'invoice_no'                   => 'required|string',
            'total_amount'                 => 'required|numeric|min:0',
            'net_amount'                   => 'required|numeric|min:0',
            'payment_type'                 => $isSplitPayment ? 'nullable|string' : 'required|string',
            'payments'                     => $isSplitPayment ? 'required|array|min:2' : 'nullable|array',
            'payments.*.method'            => 'required_with:payments|string|max:100',
            'payments.*.amount'            => 'required_with:payments|numeric|min:0.01',
            'gst_mode'                     => 'nullable|in:include,exclude,none',
            'invoice_type'                 => 'nullable|in:simple,tax',
        ], $this->documentValidationRules()));

        $paymentRows = $isSplitPayment
            ? $request->input('payments', [])
            : [['method' => $request->payment_type, 'amount' => $request->net_amount]];

        if ($isSplitPayment && ! InvoicePayment::rowsSumTo($paymentRows, (float) $request->net_amount)) {
            return back()->withErrors(['error' => 'Split payment amounts must add up to the net amount.'])->withInput();
        }

        $invoiceDate = Carbon::createFromFormat('d/m/Y', $request->invoice_date)->format('Y-m-d');

        // Use database transaction
        DB::beginTransaction();
        try {
            // Create invoice
            $customer = Customer::firstOrCreateForInvoice($request->customer_name, $request->customer_no, $request->customer_address);

            $invoice = Invoice::create([
                'customer_id'      => $customer->id,
                'invoice_date'     => $invoiceDate,
                'invoice_no'       => $request->invoice_no,
                'total_amount'     => $request->total_amount,
                'net_amount'       => $request->net_amount,
                'cgst_rate'        => $request->cgst_rate ?? 0,
                'sgst_rate'        => $request->sgst_rate ?? 0,
                'igst_rate'        => $request->igst_rate ?? 0,
                'cgst_amount'      => $request->cgst_amount ?? 0,
                'sgst_amount'      => $request->sgst_amount ?? 0,
                'igst_amount'      => $request->igst_amount ?? 0,
                'tax_amount'       => $request->tax_amount ?? 0,
                'gst_mode'         => $request->gst_mode ?? 'none',
                'invoice_type'     => $request->invoice_type ?? 'simple',
                'discount'         => $request->discount_amount ?? 0,
                'discount_rate'    => $request->discount_rate ?? 0,
                'declaration'      => $request->declaration ?? null,
                'payment_type'     => $paymentRows[0]['method'] ?? 'Cash',
                'is_paid'          => 1,
                'invoice_by'       => Auth::id(),
            ]);

            $invoice->payment_type = InvoicePayment::syncForInvoice($invoice, $paymentRows);
            $invoice->save();

            // Create invoice items and mark purchases as sold
            $totalProfit = 0;
            foreach ($request->items as $item) {
                $purchase = (Purchase::query())->findOrFail($item['item_id']);
                $quantity = (int) $item['quantity'];
                $unitPrice = $item['unit_price'];
                $validationError = $this->validateInvoiceItemQuantity($purchase, $quantity);

                if ($validationError !== null) {
                    DB::rollBack();

                    return back()->withErrors(['error' => $validationError])->withInput();
                }

                $totalAmount = $unitPrice * $quantity;
                $profit = ($unitPrice - $purchase->purchase_price) * $quantity;

                // Convert warranty date if provided
                $warrantyDate = null;
                if (! empty($item['warranty_expiry_date'])) {
                    $warrantyDate = Carbon::createFromFormat('d/m/Y', $item['warranty_expiry_date'])->format('Y-m-d');
                }

                // Create invoice item
                InvoiceItem::create([
                    'invoice_id'           => $invoice->id,
                    'item_id'              => $item['item_id'],
                    'item_description'     => $item['item_description'],
                    'quantity'             => $quantity,
                    'unit_price'           => $unitPrice,
                    'total_amount'         => $totalAmount,
                    'warranty_expiry_date' => $warrantyDate,
                    'profit'               => $profit,
                ]);

                $totalProfit += $profit;

                $this->applyInvoiceSaleToPurchase($purchase, $quantity, $invoiceDate);
            }

            $this->storeCustomerDocuments($invoice, $customer, $request);

            DB::commit();
            $ledgerService->syncInvoice($invoice->fresh());

            // Handle Google contact sync
            if ($request->customer_no_sync === 'on') {
                $request->merge(['invoice_id' => $invoice->id]);
                // $result = $this->googleContactService->syncContact($request);

                if (! $result['success']) {
                    if (isset($result['redirect'])) {
                        return redirect()->to($result['redirect']);
                    }

                    return response()->json(['error' => $result['error'] ?? 'Contact sync failed'], 500);
                }
            }

            return redirect()->route('print-invoice', $invoice->id);

        } catch (Exception $e) {
            DB::rollBack();

            return back()->withErrors(['error' => 'An error occurred: ' . $e->getMessage()])->withInput();
        }
    }

    public function invoiceDetail($id)
    {
        $invoice = (Invoice::with(['documents', 'items.purchase']))->findOrFail($id);

        $returnedQuantities = SaleReturn::notDeleted()
            ->whereIn('invoice_item_id', $invoice->items->pluck('id'))
            ->selectRaw('invoice_item_id, sum(quantity) as qty')
            ->groupBy('invoice_item_id')
            ->pluck('qty', 'invoice_item_id');

        return view('invoice.detail', [
            'invoice' => $invoice,
            'returnedQuantities' => $returnedQuantities,
        ]);
    }

    public function printInvoice($id)
    {
        $invoice = (Invoice::with('items.purchase'))->findOrFail($id);
        $amountInWords = $this->amoutInWords(floatval($invoice->net_amount));

        return view('invoice.print', ['invoice' => $invoice, 'amountInWords' => $amountInWords]);
    }

    public function downloadPdf($id)
    {
        $invoice = (Invoice::with('items.purchase'))->findOrFail($id);
        $amountInWords = $this->amoutInWords(floatval($invoice->net_amount));

        $pdf = \Barryvdh\DomPDF\Facade\Pdf::loadView('invoice.pdf', ['invoice' => $invoice, 'amountInWords' => $amountInWords]);
        return $pdf->download('invoice-' . $invoice->invoice_no . '.pdf');
    }

    public function publicPdf($id)
    {
        $invoice = (Invoice::with('items.purchase'))->findOrFail($id);
        $amountInWords = $this->amoutInWords(floatval($invoice->net_amount));

        $pdf = \Barryvdh\DomPDF\Facade\Pdf::loadView('invoice.pdf', ['invoice' => $invoice, 'amountInWords' => $amountInWords]);
        return $pdf->stream('invoice-' . $invoice->invoice_no . '.pdf');
    }

    public function sendWhatsapp($id)
    {
        $invoice = (Invoice::with('items.purchase'))->findOrFail($id);
        $amountInWords  = $this->amoutInWords(floatval($invoice->net_amount));
        $fileName       = $invoice->invoice_no.'-'.Str::random(10).'.pdf';

        $pdf = \Barryvdh\DomPDF\Facade\Pdf::loadView(
            'invoice.pdf', 
            [
                'invoice' => $invoice, 
                'amountInWords' => $amountInWords
            ]
        );
        // 'invoice_pdfs', not 'public': the 'public' disk's root gets suffixed
        // per-tenant by tenancy while this request runs, so a file saved there
        // would never be reachable through the app's one shared public/storage
        // symlink — see the disk's own comment in config/filesystems.php.
        Storage::disk('invoice_pdfs')->put('pdfs/'.$fileName, $pdf->output());
        $url = asset('storage/pdfs/'.$fileName);

        // $url = URL::temporarySignedRoute(
        //     'public-invoice-pdf', 
        //     Carbon::now()->addMinutes(5), 
        //     ['id' => $id]
        // );
      
        $companyName = \App\Models\CompanySetting::current()->company_name;
        $msg = "Hello " . ucfirst($invoice->customer_name) . ",\n\nThank you for your purchase at {$companyName}!\n
        Your invoice total is ₹" . number_format($invoice->net_amount, 2) . ".\n\nYou can view and download your digital invoice here:\n" . $url;
        
        // Format number for WhatsApp
        $formattedNo = $invoice->customer_no;
        if (!str_starts_with($formattedNo, '+')) {
            $formattedNo = (strlen($formattedNo) == 10) ? '91' . $formattedNo : $formattedNo;
        } else {
            $formattedNo = str_replace('+', '', $formattedNo);
        }
        $waUrl = "https://wa.me/" . $formattedNo . "?text=" . urlencode($msg);
        return redirect()->away($waUrl);
    }


    public function fetchModelData($imei)
    {
        // $purchase = Purchase::where('imei', 'LIKE', "%{$imei}%")
        //     ->where('is_sold', 0)
        //     ->first();
        // if (! $purchase) {
        //     return response()->json([
        //         'error' => 'IMEI Not in stock',
        //     ]);
        // }

        // return response()->json([
        //     'purchase' => $purchase,
        // ]);
        $query = (Purchase::query())
            ->where('imei', 'LIKE', $imei . '%')
            ->where(function ($query): void {
                $query->where('tracking_type', 'serialized')
                    ->orWhereNull('tracking_type');
            })
            ->where('is_sold', 0)
            ->where('deleted', 0)
            ->take(10)
            ->get();

        return response()->json($query);
    }

    public function fetchBulkStock(string $term)
    {
        $query = (Purchase::query())
            ->where('tracking_type', 'bulk')
            ->where('deleted', 0)
            ->where('available_quantity', '>', 0)
            ->where(function ($builder) use ($term): void {
                $builder->where('model', 'LIKE', $term . '%')
                    ->orWhere('sku', 'LIKE', $term . '%');
            })
            ->orderBy('model')
            ->take(10)
            ->get();

        return response()->json($query);
    }

    public function fetchCustomerByContact($contactNo)
    {
        $customer = Customer::where('phone', $contactNo)->first();

        if (! $customer) {
            return response()->json([
                'error' => 'No customer found with this contact number',
            ]);
        }

        return response()->json([
            'customer' => [
                'customer_name'    => $customer->name,
                'customer_no'      => $customer->phone,
                'customer_address' => $customer->address,
            ],
        ]);
    }

    public function editInvoice($id)
    {
        $invoice = (Invoice::with('items.purchase', 'documents', 'payments'))->findOrFail($id);
        $stocksModel = (Purchase::query())
            ->where('deleted', 0)
            ->where(function ($query): void {
                $query->where(function ($serializedQuery): void {
                    $serializedQuery->where(function ($trackingQuery): void {
                        $trackingQuery->where('tracking_type', 'serialized')
                            ->orWhereNull('tracking_type');
                    })->where('is_sold', 0);
                })->orWhere(function ($bulkQuery): void {
                    $bulkQuery->where('tracking_type', 'bulk')
                        ->where('available_quantity', '>', 0);
                });
            })
            ->orderBy('purchase_date', 'desc')
            ->get();

        return view('invoice.edit', ['invoice' => $invoice, 'stocksModel' => $stocksModel]);
    }

    public function updateInvoice(Request $request, $id, LedgerService $ledgerService)
    {
        $invoice = (Invoice::with('items.purchase'))->findOrFail($id);

        // Validate against the raw dd/mm/yyyy strings before any conversion, so that a failure
        // (e.g. an invalid document photo) redisplays the form via withInput() with the original
        // dd/mm/yyyy value intact, instead of a converted Y-m-d value that would fail re-parsing
        // on resubmit.
        $isSplitPayment = $request->boolean('split_payment');

        $request->validate(array_merge([
            'items'                        => 'required|array|min:1',
            'items.*.item_id'              => 'required|integer|exists:purchases,id',
            'items.*.unit_price'           => 'required|numeric|min:0',
            'items.*.quantity'             => 'required|integer|min:1',
            'items.*.warranty_expiry_date' => 'nullable|date_format:d/m/Y',
            'customer_name'                => 'required|string|max:255',
            'invoice_date'                 => 'required|date_format:d/m/Y',
            'warranty_expiry_date'         => 'nullable|date_format:d/m/Y',
            'invoice_no'                   => 'required|string',
            'total_amount'                 => 'required|numeric|min:0',
            'net_amount'                   => 'required|numeric|min:0',
            'payment_type'                 => $isSplitPayment ? 'nullable|string' : 'required|string',
            'payments'                     => $isSplitPayment ? 'required|array|min:2' : 'nullable|array',
            'payments.*.method'            => 'required_with:payments|string|max:100',
            'payments.*.amount'            => 'required_with:payments|numeric|min:0.01',
            'gst_mode'                     => 'nullable|in:include,exclude,none',
            'invoice_type'                 => 'nullable|in:simple,tax',
        ], $this->documentValidationRules()));

        $paymentRows = $isSplitPayment
            ? $request->input('payments', [])
            : [['method' => $request->payment_type, 'amount' => $request->net_amount]];

        if ($isSplitPayment && ! InvoicePayment::rowsSumTo($paymentRows, (float) $request->net_amount)) {
            return back()->withErrors(['error' => 'Split payment amounts must add up to the net amount.'])->withInput();
        }

        $invoiceDate = Carbon::createFromFormat('d/m/Y', $request->invoice_date)->format('Y-m-d');

        // Use database transaction
        DB::beginTransaction();
        try {
            // Mark all old purchases as unsold
            foreach ($invoice->items as $item) {
                if ($item->purchase) {
                    $this->restoreInvoiceSaleToPurchase($item->purchase, (int) $item->quantity);
                }
            }

            // Delete old invoice items
            $invoice->items()->delete();

            // Update invoice details
            $customer = Customer::firstOrCreateForInvoice($request->customer_name, $request->customer_no, $request->customer_address);

            $invoice->update([
                'customer_id'      => $customer->id,
                'invoice_date'     => $invoiceDate,
                'total_amount'     => $request->total_amount,
                'net_amount'       => $request->net_amount,
                'cgst_rate'        => $request->cgst_rate ?? 0,
                'sgst_rate'        => $request->sgst_rate ?? 0,
                'igst_rate'        => $request->igst_rate ?? 0,
                'cgst_amount'      => $request->cgst_amount ?? 0,
                'sgst_amount'      => $request->sgst_amount ?? 0,
                'igst_amount'      => $request->igst_amount ?? 0,
                'tax_amount'       => $request->tax_amount ?? 0,
                'gst_mode'         => $request->gst_mode ?? 'none',
                'invoice_type'     => $request->invoice_type ?? 'simple',
                'discount'         => $request->discount_amount ?? 0,
                'discount_rate'    => $request->discount_rate ?? 0,
                'declaration'      => $request->declaration ?? null,
                'payment_type'     => InvoicePayment::syncForInvoice($invoice, $paymentRows),
                'invoice_by'       => Auth::id(),
            ]);

            // Create new invoice items and mark purchases as sold
            $totalProfit = 0;
            foreach ($request->items as $item) {
                $purchase = (Purchase::query())->findOrFail($item['item_id']);
                $quantity = (int) $item['quantity'];
                $unitPrice = $item['unit_price'];
                $validationError = $this->validateInvoiceItemQuantity($purchase, $quantity);

                if ($validationError !== null) {
                    DB::rollBack();

                    return back()->withErrors(['error' => $validationError])->withInput();
                }

                $totalAmount = $unitPrice * $quantity;
                $profit = ($unitPrice - $purchase->purchase_price) * $quantity;

                // Convert warranty date if provided
                $warrantyDate = null;
                if (! empty($item['warranty_expiry_date'])) {
                    $warrantyDate = Carbon::createFromFormat('d/m/Y', $item['warranty_expiry_date'])->format('Y-m-d');
                }

                // Create invoice item
                InvoiceItem::create([
                    'invoice_id'           => $invoice->id,
                    'item_id'              => $item['item_id'],
                    'item_description'     => $item['item_description'],
                    'quantity'             => $quantity,
                    'unit_price'           => $unitPrice,
                    'total_amount'         => $totalAmount,
                    'warranty_expiry_date' => $warrantyDate,
                    'profit'               => $profit,
                ]);

                $totalProfit += $profit;

                $this->applyInvoiceSaleToPurchase($purchase, $quantity, $invoiceDate);
            }

            $this->storeCustomerDocuments($invoice, $customer, $request);

            DB::commit();
            $ledgerService->syncInvoice($invoice->fresh('items'));

            return redirect()->route('allinvoices')->withStatus('Invoice Updated Successfully..');

        } catch (Exception $e) {
            DB::rollBack();

            return back()->withErrors(['error' => 'An error occurred: ' . $e->getMessage()])->withInput();
        }
    }

    public function deleteDocument($invoiceId, $documentId)
    {
        $invoice = (Invoice::query())->findOrFail($invoiceId);
        $document = $invoice->documents()->findOrFail($documentId);

        $this->documentImageService->delete($document->document_image);
        $document->delete();

        return back()->withStatus('Document removed successfully.');
    }

    public function deleteInvoice($id, LedgerService $ledgerService)
    {
        DB::beginTransaction();
        try {
            $invoice = (Invoice::with('items.purchase'))->findOrFail($id);

            // Mark the purchases as unsold so they can be sold again
            foreach ($invoice->items as $item) {
                if ($item->purchase) {
                    $this->restoreInvoiceSaleToPurchase($item->purchase, (int) $item->quantity);
                }
            }

            // Soft delete invoice items
            $invoice->items()->update(['deleted' => 1]);

            // Soft delete the invoice
            $invoice->update(['deleted' => 1]);

            DB::commit();
            $ledgerService->deleteAutoEntry('SALE', (int) $invoice->id);

            return redirect()->route('allinvoices')->withStatus('Invoice Deleted Successfully.');
        } catch (Exception $e) {
            DB::rollBack();

            return back()->withErrors(['error' => 'An error occurred while deleting the invoice.']);
        }
    }

}
