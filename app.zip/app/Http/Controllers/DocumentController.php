<?php

namespace App\Http\Controllers;

use App\Models\CustomerDocument;
use App\Models\PurchaseDocument;
use Illuminate\Http\Request;

/**
 * Unified "Documents" view — brings together identity/KYC documents uploaded against
 * Invoices (CustomerDocument) and receipts/other documents uploaded against Purchases
 * (PurchaseDocument) into one tabbed screen, so staff don't need to open every invoice
 * or purchase individually to find a document.
 */
class DocumentController extends Controller
{
    public function index(Request $request)
    {
        $invoiceDocuments = $this->invoiceDocumentsQuery($request->get('invoice_search', ''))
            ->paginate(12, ['*'], 'invoice_page')
            ->withQueryString();

        $purchaseDocuments = $this->purchaseDocumentsQuery($request->get('purchase_search', ''))
            ->paginate(12, ['*'], 'purchase_page')
            ->withQueryString();

        return view('documents.index', [
            'invoiceDocuments' => $invoiceDocuments,
            'purchaseDocuments' => $purchaseDocuments,
            'invoiceSearch' => $request->get('invoice_search', ''),
            'purchaseSearch' => $request->get('purchase_search', ''),
            'invoiceDocumentCount' => (clone $this->invoiceDocumentsQuery(''))->count(),
            'purchaseDocumentCount' => (clone $this->purchaseDocumentsQuery(''))->count(),
            'activeTab' => $request->get('tab', 'invoice') === 'purchase' ? 'purchase' : 'invoice',
        ]);
    }

    public function invoiceDocuments(Request $request)
    {
        $documents = $this->invoiceDocumentsQuery($request->get('invoice_search', ''))
            ->paginate(12, ['*'], 'invoice_page')
            ->withQueryString();

        return view('documents._invoice-documents-list', [
            'invoiceDocuments' => $documents,
        ]);
    }

    public function purchaseDocuments(Request $request)
    {
        $documents = $this->purchaseDocumentsQuery($request->get('purchase_search', ''))
            ->paginate(12, ['*'], 'purchase_page')
            ->withQueryString();

        return view('documents._purchase-documents-list', [
            'purchaseDocuments' => $documents,
        ]);
    }

    private function invoiceDocumentsQuery(string $search)
    {
        $query = CustomerDocument::query()->with(['invoice', 'customer'])->latest();

        if ($search !== '') {
            $query->where(function ($inner) use ($search) {
                $inner->where('document_number', 'like', "%{$search}%")
                    ->orWhere('document_type_other', 'like', "%{$search}%")
                    ->orWhereHas('customer', function ($q) use ($search) {
                        $q->where('name', 'like', "%{$search}%");
                    })
                    ->orWhereHas('invoice', function ($q) use ($search) {
                        $q->where('invoice_no', 'like', "%{$search}%");
                    });
            });
        }

        return $query;
    }

    private function purchaseDocumentsQuery(string $search)
    {
        $query = PurchaseDocument::query()->with('purchase')->latest();

        if ($search !== '') {
            $query->where(function ($inner) use ($search) {
                $inner->where('document_number', 'like', "%{$search}%")
                    ->orWhere('document_type_other', 'like', "%{$search}%")
                    ->orWhereHas('purchase', function ($q) use ($search) {
                        $q->where('model', 'like', "%{$search}%")
                            ->orWhere('imei', 'like', "%{$search}%")
                            ->orWhere('purchase_from', 'like', "%{$search}%");
                    });
            });
        }

        return $query;
    }
}
