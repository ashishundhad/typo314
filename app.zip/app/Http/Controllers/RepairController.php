<?php
namespace App\Http\Controllers;

use App\Http\Controllers\Concerns\ResolvesPeriodRange;
use App\Models\Customer;
use App\Models\Invoice;
use App\Models\InvoiceItem;
use App\Models\InvoicePayment;
use App\Models\Repair;
use App\Services\Ledger\LedgerService;
use Barryvdh\DomPDF\Facade\Pdf;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Response;

class RepairController extends Controller
{
    use ResolvesPeriodRange;

    public function index(Request $request)
    {
        $search = trim((string) $request->input('search', ''));
        $status = (string) $request->input('status', '');
        // capToToday=false: a repair's date is user-picked and can reasonably fall later in
        // the current month/year than today (e.g. the server's clock lagging the browser's,
        // or just scheduling ahead), unlike purchases/invoices which are stamped at creation.
        $range = $this->resolvePeriodRange($request, 'alls', false);

        $query = Repair::query()
            ->notDeleted()
            ->when($search !== '', function ($q) use ($search) {
                $q->where(function ($inner) use ($search) {
                    $inner->where('customer_name', 'like', "%{$search}%")
                        ->orWhere('issue_description', 'like', "%{$search}%");
                });
            })
            ->when($status !== '', function ($q) use ($status) {
                $q->where('status', $status);
            })
            ->when($range['start'] && $range['end'], function ($q) use ($range) {
                $q->whereBetween('repair_date', [$range['start'], $range['end']]);
            })
            ->orderBy('created_at', 'desc');

        if ($request->query('download') === 'csv') {
            return $this->downloadCsv((clone $query)->orderBy('repair_date', 'asc')->get());
        }

        if ($request->query('download') === 'pdf') {
            return $this->downloadPdf((clone $query)->orderBy('repair_date', 'asc')->get(), $range);
        }

        $repairs = (clone $query)->paginate(15)->appends($request->query());

        $summary = (clone $query)->toBase()->reorder()->selectRaw('
            COUNT(*) as total_repairs,
            SUM(CASE WHEN status = "received" THEN 1 ELSE 0 END) as received_count,
            SUM(CASE WHEN status = "repairing" THEN 1 ELSE 0 END) as repairing_count,
            SUM(CASE WHEN status = "delivered" THEN 1 ELSE 0 END) as delivered_count,
            SUM(repair_fee - parts_cost) as total_profit
        ')->first();

        return view('repairs.index', [
            'repairs' => $repairs,
            'search' => $search,
            'status' => $status,
            'period' => $range['period'],
            'fromdate' => $range['fromdate'],
            'todate' => $range['todate'],
            'timePeriod' => $range['timePeriod'],
            'totalRepairs' => (int) $summary->total_repairs,
            'receivedCount' => (int) $summary->received_count,
            'repairingCount' => (int) $summary->repairing_count,
            'deliveredCount' => (int) $summary->delivered_count,
            'totalProfit' => (float) $summary->total_profit,
        ]);
    }

    private function downloadCsv($repairs)
    {
        $fileName = 'repair-report-' . now()->format('Ymd-His') . '.csv';
        $headers = [
            'Content-type' => 'text/csv',
            'Content-Disposition' => "attachment; filename=$fileName",
            'Pragma' => 'no-cache',
            'Cache-Control' => 'must-revalidate, post-check=0, pre-check=0',
            'Expires' => '0',
        ];

        $callback = function () use ($repairs): void {
            $file = fopen('php://output', 'w+');

            fputcsv($file, ['Sr No', 'Customer', 'Issue', 'Repair Date', 'Parts Cost', 'Repair Fee', 'Profit', 'Status']);

            foreach ($repairs as $index => $repair) {
                fputcsv($file, [
                    $index + 1,
                    $repair->customer_name ?: 'Walk-in Customer',
                    $repair->issue_description,
                    $repair->repair_date ? $repair->repair_date->format('d/m/Y') : '',
                    $repair->parts_cost,
                    $repair->repair_fee,
                    $repair->profit,
                    $repair->status_label,
                ]);
            }

            fclose($file);
        };

        return Response::stream($callback, 200, $headers);
    }

    private function downloadPdf($repairs, array $range)
    {
        $pdf = Pdf::loadView('repairs.repair-pdf', [
            'repairs' => $repairs,
            'timePeriod' => $range['timePeriod'],
            'totalPartsCost' => (float) $repairs->sum('parts_cost'),
            'totalRepairFee' => (float) $repairs->sum('repair_fee'),
            'totalProfit' => (float) $repairs->sum(fn (Repair $repair) => $repair->profit),
        ])->setPaper('a4', 'landscape');

        return $pdf->download('repair-report-' . now()->format('Ymd-His') . '.pdf');
    }

    public function store(Request $request)
    {
        $validated = $this->validateRepair($request);

        Repair::create($validated);

        return redirect()->route('repairs.index')->withStatus('Repair added successfully.');
    }

    public function edit($id)
    {
        $repair = Repair::query()->notDeleted()->findOrFail($id);

        return response()->json(['data' => $repair]);
    }

    public function update(Request $request, $id)
    {
        $repair = Repair::query()->notDeleted()->findOrFail($id);
        $validated = $this->validateRepair($request);

        $repair->update($validated);

        return redirect()->route('repairs.index')->withStatus('Repair updated successfully.');
    }

    public function destroy($id)
    {
        $repair = Repair::query()->notDeleted()->findOrFail($id);
        $repair->update(['deleted' => 1]);

        return redirect()->route('repairs.index')->withStatus('Repair deleted successfully.');
    }

    private function validateRepair(Request $request): array
    {
        return $request->validate([
            'customer_name' => 'nullable|string|max:255',
            'issue_description' => 'nullable|string',
            'repair_date' => 'nullable|date',
            'parts_cost' => 'nullable|numeric|min:0',
            'repair_fee' => 'nullable|numeric|min:0',
            'status' => 'nullable|in:received,repairing,delivered',
        ]);
    }

    /**
     * Bill a repair job: create a normal Invoice with a single InvoiceItem carrying the
     * repair fee/profit, so it flows into the existing profit reports and ledger the exact
     * same way a sale does — no separate repair-revenue tracking needed anywhere else.
     */
    public function bill(Request $request, $id, LedgerService $ledgerService)
    {
        $repair = Repair::query()->notDeleted()->findOrFail($id);

        if ($repair->isBilled()) {
            return back()->withErrors(['error' => 'This repair has already been billed.']);
        }

        $request->validate([
            'payment_type' => 'required|string',
        ]);

        $invoiceDate = $repair->repair_date ?? now()->toDateString();

        DB::beginTransaction();
        try {
            $customer = Customer::firstOrCreateForInvoice($repair->customer_name ?? '', null, null);

            $unitPrice = (float) $repair->repair_fee;
            $profit = $unitPrice - (float) $repair->parts_cost;

            $invoice = Invoice::create([
                'customer_id' => $customer->id,
                'invoice_date' => $invoiceDate,
                'invoice_no' => Invoice::nextInvoiceNumber(),
                'total_amount' => $unitPrice,
                'net_amount' => $unitPrice,
                'cgst_rate' => 0,
                'sgst_rate' => 0,
                'igst_rate' => 0,
                'cgst_amount' => 0,
                'sgst_amount' => 0,
                'igst_amount' => 0,
                'tax_amount' => 0,
                'gst_mode' => 'none',
                'discount' => 0,
                'discount_rate' => 0,
                'payment_type' => $request->payment_type,
                'is_paid' => 1,
                'invoice_by' => Auth::id(),
            ]);

            InvoiceItem::create([
                'invoice_id' => $invoice->id,
                'item_id' => null,
                'item_description' => 'Repair: ' . ($repair->issue_description ?: 'Service charge'),
                'quantity' => 1,
                'unit_price' => $unitPrice,
                'total_amount' => $unitPrice,
                'profit' => $profit,
            ]);

            // Daily Closing / Dashboard now read cash-vs-online-vs-card totals from
            // invoice_payments rather than invoices.payment_type directly, so every
            // invoice-creating flow needs at least one row here to show up there.
            InvoicePayment::create([
                'invoice_id' => $invoice->id,
                'payment_method' => $request->payment_type,
                'amount' => $unitPrice,
            ]);

            $repair->update(['invoice_id' => $invoice->id, 'status' => 'delivered']);

            DB::commit();
            $ledgerService->syncInvoice($invoice->fresh());

            return redirect()->route('print-invoice', $invoice->id);
        } catch (Exception $e) {
            DB::rollBack();

            return back()->withErrors(['error' => 'An error occurred: ' . $e->getMessage()]);
        }
    }
}
