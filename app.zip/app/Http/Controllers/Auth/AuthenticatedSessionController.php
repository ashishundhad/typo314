<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Http\Requests\Auth\LoginRequest;
use App\Providers\RouteServiceProvider;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Validation\ValidationException;
use Illuminate\View\View;

class AuthenticatedSessionController extends Controller
{
    /**
     * True when the current request is inside an initialized tenant whose
     * subscription doesn't grant access (suspended, cancelled, expired
     * trial/period, or stuck in provisioning_failed) — mirrors
     * EnsureSubscriptionActive's check via Subscription::hasAccess(). A no-op
     * outside tenant context (central/legacy domains).
     */
    private function tenantIsBlocked(): bool
    {
        return tenancy()->initialized && ! (tenant()->subscription?->hasAccess() ?? false);
    }

    /**
     * Display the login view.
     */
    public function create(): View|RedirectResponse
    {
        if (Auth::check()) {
            return redirect()->route('dashboard');
        }

        $tenantSuspended = $this->tenantIsBlocked();

        return view('auth.login', [
            'tenantSuspended' => $tenantSuspended,
            'subscription' => $tenantSuspended && tenancy()->initialized ? tenant()->subscription : null,
        ]);
    }

    /**
     * Handle an incoming authentication request.
     */
    public function store(LoginRequest $request): RedirectResponse
    {
        if ($this->tenantIsBlocked()) {
            throw ValidationException::withMessages([
                'email' => 'This account is suspended. Please contact support to restore access.',
            ]);
        }

        $request->authenticate();

        $request->session()->regenerate();

        return redirect()->intended(RouteServiceProvider::HOME);
    }

    /**
     * Destroy an authenticated session.
     */
    public function destroy(Request $request): RedirectResponse
    {
        Auth::guard('web')->logout();

        $request->session()->invalidate();

        $request->session()->regenerateToken();

        return redirect('/login');
    }
}
