<?php

namespace App\Http\Controllers;

use App\Models\Purchase;

abstract class Controller
{
    protected function validateInvoiceItemQuantity(Purchase $purchase, int $quantity): ?string
    {
        if ($purchase->isBulkTracked()) {
            if ($purchase->available_units < $quantity) {
                return 'Only ' . $purchase->available_units . ' unit(s) available for ' . $purchase->model . '.';
            }

            return null;
        }

        if ($quantity !== 1) {
            return 'Serialized items must be billed with quantity 1.';
        }

        if ($purchase->is_sold) {
            return 'Item ' . $purchase->display_code . ' is already sold.';
        }

        return null;
    }

    protected function applyInvoiceSaleToPurchase(Purchase $purchase, int $quantity, string $invoiceDate): void
    {
        if ($purchase->isBulkTracked()) {
            $remainingQuantity = max(0, $purchase->available_units - $quantity);

            $purchase->update([
                'available_quantity' => $remainingQuantity,
                'is_sold' => $remainingQuantity <= 0,
                'sell_date' => $invoiceDate,
            ]);

            return;
        }

        $purchase->update([
            'available_quantity' => 0,
            'is_sold' => 1,
            'sell_date' => $invoiceDate,
        ]);
    }

    protected function restoreInvoiceSaleToPurchase(Purchase $purchase, int $quantity): void
    {
        if ($purchase->isBulkTracked()) {
            $restoredQuantity = min($purchase->total_units, $purchase->available_units + $quantity);

            $purchase->update([
                'available_quantity' => $restoredQuantity,
                'is_sold' => $restoredQuantity <= 0,
                'sell_date' => $restoredQuantity < $purchase->total_units ? $purchase->sell_date : null,
            ]);

            return;
        }

        $purchase->update([
            'available_quantity' => 1,
            'is_sold' => 0,
            'sell_date' => null,
        ]);
    }

    public function amoutInWords(float $amount): string
    {
        $amount_after_decimal = round($amount - ($num = floor($amount)), 2) * 100;
        // Check if there is any number after decimal
        $amt_hundred  = null;
        $count_length = strlen($num);
        $x            = 0;
        $string       = [];
        $change_words = [0 => '', 1 => 'One', 2 => 'Two', 3 => 'Three', 4 => 'Four', 5 => 'Five', 6 => 'Six', 7 => 'Seven', 8 => 'Eight', 9 => 'Nine', 10 => 'Ten', 11 => 'Eleven', 12 => 'Twelve', 13 => 'Thirteen', 14 => 'Fourteen', 15 => 'Fifteen', 16 => 'Sixteen', 17 => 'Seventeen', 18 => 'Eighteen', 19 => 'Nineteen', 20 => 'Twenty', 30 => 'Thirty', 40 => 'Forty', 50 => 'Fifty', 60 => 'Sixty', 70 => 'Seventy', 80 => 'Eighty', 90 => 'Ninety'];
        $here_digits  = ['', 'Hundred', 'Thousand', 'Lakh', 'Crore'];

        while ($x < $count_length) {
            $get_divider = ($x == 2) ? 10 : 100;
            $amount      = floor($num % $get_divider);
            $num         = floor($num / $get_divider);
            $x += $get_divider == 10 ? 1 : 2;
            if ($amount !== 0.0) {
                $add_plural  = (($counter = count($string)) && $amount > 9) ? 's' : null;
                $amt_hundred = ($counter == 1 && $string[0]) ? ' and ' : null;
                $string[]    = ($amount < 21) ? $change_words[$amount] . ' ' . $here_digits[$counter] . $add_plural . ' ' . $amt_hundred : $change_words[floor($amount / 10) * 10] . ' ' . $change_words[$amount % 10] . ' ' . $here_digits[$counter] . $add_plural . ' ' . $amt_hundred;
            } else {
                $string[] = null;
            }
        }
        $implode_to_Rupees = implode('', array_reverse($string));
        $get_paise         = ($amount_after_decimal > 0) ? 'And ' . ($change_words[$amount_after_decimal / 10] . '
        ' . $change_words[$amount_after_decimal % 10]) . ' Paise' : '';

        return ($implode_to_Rupees !== '' && $implode_to_Rupees !== '0' ? $implode_to_Rupees . 'Only ' : '') . $get_paise;
    }
}
