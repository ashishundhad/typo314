<?php

namespace App\Http\Controllers\Ai;

use App\Http\Controllers\Controller;
use App\Models\ChatMessage;
use App\Services\Ai\OpenAiChatService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Throwable;

class AiAssistantController extends Controller
{
    public function __construct(
        protected OpenAiChatService $chatService
    ) {
    }

    public function index(Request $request)
    {
        $user = $request->user();

        $sessionId = trim((string) $request->query('session', ''));

        if ($sessionId === '') {
            $sessionId = (string) ChatMessage::query()
                ->where('user_id', $user->id)
                ->latest('id')
                ->value('session_id');
        }

        if ($sessionId === '') {
            $sessionId = (string) Str::uuid();
        }

        $messages = ChatMessage::query()
            ->where('user_id', $user->id)
            ->where('session_id', $sessionId)
            ->orderBy('id')
            ->get();

        return view('ai.assistant', [
            'sessionId' => $sessionId,
            'messages' => $messages,
        ]);
    }

    public function store(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'session_id' => ['nullable', 'string', 'max:64'],
            'question' => ['required', 'string', 'max:5000'],
        ]);

        $user = $request->user();
        $sessionId = trim((string) ($validated['session_id'] ?? '')) ?: (string) Str::uuid();

        $history = ChatMessage::query()
            ->where('user_id', $user->id)
            ->where('session_id', $sessionId)
            ->orderByDesc('id')
            ->limit(8)
            ->get(['role', 'content'])
            ->reverse()
            ->values()
            ->all();

        ChatMessage::create([
            'session_id' => $sessionId,
            'user_id' => $user->id,
            'role' => 'user',
            'content' => $validated['question'],
        ]);

        try {
            $assistantReply = $this->chatService->respond($user, $validated['question'], $history);
        } catch (Throwable $exception) {
            report($exception);

            return response()->json([
                'message' => $exception->getMessage(),
            ], 422);
        }

        $assistantMessage = ChatMessage::create([
            'session_id' => $sessionId,
            'user_id' => $user->id,
            'role' => 'assistant',
            'content' => $assistantReply['answer'],
            'metadata' => [
                'tools' => $assistantReply['tools'],
                'response_id' => $assistantReply['response_id'],
            ],
        ]);

        return response()->json([
            'session_id' => $sessionId,
            'message' => [
                'id' => $assistantMessage->id,
                'role' => $assistantMessage->role,
                'content' => $assistantMessage->content,
                'created_at' => $assistantMessage->created_at?->toDateTimeString(),
            ],
        ]);
    }
}
