<?php
namespace App\Http\Controllers;

use App\Models\CompanySetting;
use App\Models\Invoice;

class PosController extends Controller
{
    // Quick-checkout screen: item cart posts straight to InvoiceController::createInvoice,
    // reusing the same validation, stock/ledger sync, and print/PDF pipeline as the full
    // invoice form — this controller only renders the leaner POS UI.
    public function index()
    {
        return view('pos.index', [
            'invoiceNo' => Invoice::nextInvoiceNumber(),
            'companySetting' => CompanySetting::current(),
        ]);
    }
}
