<?php

namespace App\Http\Controllers\Central;

use App\Http\Controllers\Controller;
use App\Models\Plan;
use Illuminate\Http\Request;

class PlanController extends Controller
{
    public function edit()
    {
        $plan = Plan::with('prices')->firstOrFail();

        return view('central.plans.edit', ['plan' => $plan]);
    }

    // $central_domain is unused but must stay second (right after Request): routes/central.php
    // matches on a Route::domain('{central_domain}') parameter, and Laravel binds scalar route
    // parameters to controller arguments POSITIONALLY — the domain parameter is always first in
    // the route, landing right after any container-resolved dependency like Request.
    public function update(Request $request, string $central_domain, Plan $plan)
    {
        $validated = $request->validate([
            'name' => ['required', 'string', 'max:255'],
            'description' => ['nullable', 'string'],
            'default_trial_days' => ['required', 'integer', 'min:0'],
            'prices' => ['required', 'array'],
            'prices.*.id' => ['required', 'exists:plan_prices,id'],
            'prices.*.amount' => ['required', 'numeric', 'min:0'],
        ]);

        $plan->update([
            'name' => $validated['name'],
            'description' => $validated['description'] ?? null,
            'default_trial_days' => $validated['default_trial_days'],
        ]);

        foreach ($validated['prices'] as $priceInput) {
            $plan->prices()->whereKey($priceInput['id'])->update(['amount' => $priceInput['amount']]);
        }

        return back()->with('status', 'Plan updated.');
    }
}
