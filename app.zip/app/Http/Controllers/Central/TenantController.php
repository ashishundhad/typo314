<?php

namespace App\Http\Controllers\Central;

use App\Http\Controllers\Controller;
use App\Models\{Plan, Tenant};
use App\Services\{SubscriptionService, TenantService};
use Illuminate\Http\Request;

class TenantController extends Controller
{
    public function __construct(protected TenantService $tenants, protected SubscriptionService $subscriptions)
    {
    }

    public function index()
    {
        $tenants = Tenant::with(['domains', 'subscription.plan', 'subscription.latestPayment'])->latest()->get();

        $stats = [
            'total' => $tenants->count(),
            'active' => $tenants->where('status', 'active')->count(),
            'provisioning' => $tenants->whereIn('status', ['provisioning', 'provisioning_failed'])->count(),
            'suspended' => $tenants->where('status', 'suspended')->count(),
        ];

        return view('central.tenants.index', ['tenants' => $tenants, 'stats' => $stats]);
    }

    public function create()
    {
        $plans = Plan::where('is_active', true)->get();

        return view('central.tenants.create', ['plans' => $plans]);
    }

    public function store(Request $request)
    {
        $tenant = $this->tenants->provision($request->all());

        return redirect()->route('central.tenants.index')
            ->with('status', "Tenant '{$tenant->id}' is being provisioned.");
    }

    public function retryProvisioning(string $central_domain, string $tenant)
    {
        $tenant = Tenant::findOrFail($tenant);
        $this->tenants->retryProvisioning($tenant);

        return back()->with('status', "Tenant '{$tenant->id}' provisioning retried.");
    }

    // $central_domain is unused but must stay first: routes/central.php matches on a
    // Route::domain('{central_domain}') parameter, and Laravel binds scalar (non-model)
    // controller parameters to route parameters POSITIONALLY, not by name — the domain
    // parameter is always first in the route's parameter list.
    public function show(string $central_domain, string $tenant)
    {
        $tenant = Tenant::with(['domains', 'subscription.plan', 'subscription.planPrice', 'subscription.payments'])
            ->findOrFail($tenant);

        return view('central.tenants.show', ['tenant' => $tenant]);
    }

    public function suspend(string $central_domain, string $tenant)
    {
        $tenant = Tenant::findOrFail($tenant);
        $this->subscriptions->suspend($tenant);

        return back()->with('status', "Tenant '{$tenant->id}' suspended.");
    }

    public function reactivate(string $central_domain, string $tenant)
    {
        $tenant = Tenant::with('subscription')->findOrFail($tenant);

        if ($tenant->subscription?->paymentStatus() === 'due') {
            return back()->withErrors([
                'payment' => "Tenant '{$tenant->id}' has an outstanding payment due — record the payment before reactivating.",
            ]);
        }

        $this->subscriptions->reactivateManually($tenant);

        return back()->with('status', "Tenant '{$tenant->id}' reactivated.");
    }

    public function recordPayment(Request $request, string $central_domain, string $tenant)
    {
        $tenant = Tenant::with('subscription')->findOrFail($tenant);

        $validated = $request->validate([
            'amount' => ['required', 'numeric', 'min:0'],
            'currency' => ['required', 'string', 'size:3'],
            'provider' => ['nullable', 'string', 'max:255'],
            'provider_reference' => ['nullable', 'string', 'max:255'],
        ]);

        if (! $tenant->subscription) {
            return back()->withErrors(['payment' => "Tenant '{$tenant->id}' has no subscription to bill."]);
        }

        $this->subscriptions->recordAndConfirmPayment($tenant->subscription, $validated);

        return back()->with('status', "Payment recorded and tenant '{$tenant->id}' reactivated.");
    }
}
