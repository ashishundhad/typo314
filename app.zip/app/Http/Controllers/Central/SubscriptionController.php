<?php

namespace App\Http\Controllers\Central;

use App\Http\Controllers\Controller;
use App\Models\Subscription;
use Illuminate\Http\Request;

class SubscriptionController extends Controller
{
    public function index()
    {
        $subscriptions = Subscription::with(['tenant.domains', 'plan', 'planPrice'])->latest()->get();

        $stats = [
            'active' => $subscriptions->where('status', 'active')->count(),
            'trialing' => $subscriptions->where('status', 'trialing')->count(),
            'past_due' => $subscriptions->where('status', 'past_due')->count(),
            'suspended' => $subscriptions->whereIn('status', ['suspended', 'cancelled'])->count(),
        ];

        return view('central.subscriptions.index', ['subscriptions' => $subscriptions, 'stats' => $stats]);
    }

    // $central_domain is unused but must stay second (right after Request) — see the note
    // on PlanController::update for why (Laravel's positional route-parameter binding).
    public function update(Request $request, string $central_domain, Subscription $subscription)
    {
        $validated = $request->validate([
            'status' => ['required', 'in:trialing,active,past_due,suspended,cancelled'],
            'current_period_ends_at' => ['nullable', 'date'],
        ]);

        $subscription->update($validated);

        if (in_array($validated['status'], ['suspended', 'cancelled'], true)) {
            $subscription->tenant?->update(['status' => 'suspended']);
        } elseif ($validated['status'] === 'active') {
            $subscription->tenant?->update(['status' => 'active']);
        }

        return back()->with('status', 'Subscription updated.');
    }
}
