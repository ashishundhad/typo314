<?php

namespace App\Http\Controllers\Central;

use App\Http\Controllers\Controller;
use App\Models\Plan;
use App\Services\TenantService;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;

/**
 * Public, unauthenticated self-service signup — a prospective shop owner
 * picks a plan and gets a brand new tenant provisioned immediately, on the
 * plan's free trial (see TenantService::provision(), which this reuses
 * as-is). No central-admin approval step; no payment is collected here —
 * that still happens out of band (see Central\PaymentController) once the
 * trial converts.
 */
class PublicSignupController extends Controller
{
    public function __construct(protected TenantService $tenants)
    {
    }

    public function create(): View
    {
        $plans = Plan::with(['prices' => fn ($query) => $query->where('is_active', true)])
            ->where('is_active', true)
            ->get();

        return view('central.signup', [
            'plans' => $plans,
            'success' => session('signup_success'),
        ]);
    }

    public function store(Request $request): RedirectResponse
    {
        $validated = $request->validate([
            'shop_name' => ['required', 'string', 'max:255'],
            'admin_name' => ['required', 'string', 'max:255'],
            'admin_email' => ['required', 'email', 'max:255'],
            'admin_password' => ['required', 'string', 'min:8', 'confirmed'],
            'plan_id' => ['required', 'exists:plans,id'],
            'billing_cycle' => ['required', 'in:monthly,yearly'],
        ]);

        $plan = Plan::where('is_active', true)->findOrFail($validated['plan_id']);

        if (! $plan->prices()->where('billing_cycle', $validated['billing_cycle'])->where('is_active', true)->exists()) {
            return back()->withErrors(['billing_cycle' => 'That billing cycle is not available for the selected plan.'])->withInput();
        }

        $slug = $this->tenants->generateUniqueSlug($validated['shop_name']);
        $baseDomain = config('tenancy.central_domains')[0];

        $tenant = $this->tenants->provision([
            'name' => $validated['shop_name'],
            'id' => $slug,
            'domain' => "{$slug}.{$baseDomain}",
            'plan_id' => $plan->id,
            'billing_cycle' => $validated['billing_cycle'],
            'admin_name' => $validated['admin_name'],
            'admin_email' => $validated['admin_email'],
            'admin_password' => $validated['admin_password'],
        ]);

        return redirect()->route('central.signup')->with('signup_success', [
            'shop_name' => $validated['shop_name'],
            'url' => 'https://' . $tenant->domains->first()->domain,
            'admin_email' => $validated['admin_email'],
            'trial_ends_at' => optional($tenant->subscription?->trial_ends_at)->toDateString(),
        ]);
    }
}
