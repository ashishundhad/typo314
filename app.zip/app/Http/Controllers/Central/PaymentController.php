<?php

namespace App\Http\Controllers\Central;

use App\Http\Controllers\Controller;
use App\Models\Payment;

class PaymentController extends Controller
{
    public function index()
    {
        $payments = Payment::with(['subscription.tenant'])->latest()->get();

        $stats = [
            'total_succeeded' => $payments->where('status', 'succeeded')->sum('amount'),
            'succeeded_count' => $payments->where('status', 'succeeded')->count(),
            'pending' => $payments->where('status', 'pending')->count(),
            'failed' => $payments->where('status', 'failed')->count(),
        ];

        return view('central.payments.index', ['payments' => $payments, 'stats' => $stats]);
    }
}
