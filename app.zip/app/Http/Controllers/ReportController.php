<?php

namespace App\Http\Controllers;

use Carbon\Carbon;
use App\Http\Controllers\Concerns\ResolvesPeriodRange;
use App\Models\Customer;
use App\Models\CustomerDocument;
use App\Models\DayOpeningBalance;
use App\Models\Expense;
use App\Models\Invoice;
use App\Models\InvoicePayment;
use App\Models\Purchase;
use App\Models\InvoiceItem;
use Illuminate\Http\Request;
use Illuminate\Pagination\LengthAwarePaginator;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Response;
use Illuminate\Support\Facades\Storage;
use Barryvdh\DomPDF\Facade\Pdf;

class ReportController extends Controller
{
    use ResolvesPeriodRange;

    protected function purchaseReportDataset(Request $request, bool $paginate = true): array
    {
        $range = $this->resolvePeriodRange($request, 'thismonth');
        $search = trim((string) $request->input('search', ''));
        $status = (string) $request->input('status', '');
        $perPage = max((int) $request->input('per_page', 15), 1);

        $query = (Purchase::query())
            ->where('deleted', 0)
            ->when($range['start'] && $range['end'], function ($query) use ($range) {
                $query->whereBetween('purchase_date', [$range['start'], $range['end']]);
            })
            ->when($search !== '', function ($query) use ($search) {
                $query->where(function ($innerQuery) use ($search) {
                    $innerQuery->where('imei', 'like', "%{$search}%")
                        ->orWhere('model', 'like', "%{$search}%")
                        ->orWhere('purchase_from', 'like', "%{$search}%")
                        ->orWhere('contactno', 'like', "%{$search}%")
                        ->orWhere('remark', 'like', "%{$search}%");
                });
            })
            ->when($status === 'sold', function ($query) {
                $query->where('is_sold', 1);
            })
            ->when($status === 'available', function ($query) {
                $query->where('is_sold', 0);
            })
            ->orderBy('purchase_date', 'desc')
            ->orderBy('created_at', 'desc');

        // ->toBase() is required here: without it, Eloquent hydrates a Purchase model from
        // this row, and aliases like total_stock_value collide with the model's own
        // getTotalStockValueAttribute() accessor, which silently overrides the raw
        // aggregated value with a bogus computed one instead of returning what SUM() found.
        $summary = (clone $query)->toBase()->reorder()->selectRaw('
            COUNT(*) as total_items,
            SUM(purchase_cost) as total_purchase_amount,
            SUM(repairing_charge) as total_repairing_amount,
            SUM(purchase_price) as total_stock_value,
            SUM(CASE WHEN is_sold = 1 THEN 1 ELSE 0 END) as sold_items,
            SUM(CASE WHEN is_sold = 0 THEN 1 ELSE 0 END) as available_items
        ')->first();

        return [
            'purchases' => $paginate ? $query->paginate($perPage)->appends($request->query()) : $query->get(),
            'period' => $range['period'],
            'fromdate' => $range['fromdate'],
            'todate' => $range['todate'],
            'timePeriod' => $range['timePeriod'],
            'search' => $search,
            'status' => $status,
            'totalItems' => (int) $summary->total_items,
            'totalPurchaseAmount' => (float) $summary->total_purchase_amount,
            'totalRepairingAmount' => (float) $summary->total_repairing_amount,
            'totalStockValue' => (float) $summary->total_stock_value,
            'soldItems' => (int) $summary->sold_items,
            'availableItems' => (int) $summary->available_items,
        ];
    }

    protected function purchaseReportFilename(string $extension): string
    {
        return 'purchase-report-' . now()->format('Ymd-His') . '.' . $extension;
    }

    protected function supplierLedgerBaseQuery(Request $request): array
    {
        $range = $this->resolvePeriodRange($request, 'alls');
        $search = trim((string) $request->input('search', ''));
        $status = (string) $request->input('status', '');

        $query = (Purchase::query())
            ->where('deleted', 0)
            ->when($range['start'] && $range['end'], function ($query) use ($range) {
                $query->whereBetween('purchase_date', [$range['start'], $range['end']]);
            })
            ->when($search !== '', function ($query) use ($search) {
                $query->where(function ($innerQuery) use ($search) {
                    $innerQuery->where('purchase_from', 'like', "%{$search}%")
                        ->orWhere('contactno', 'like', "%{$search}%")
                        ->orWhere('model', 'like', "%{$search}%")
                        ->orWhere('imei', 'like', "%{$search}%")
                        ->orWhere('color', 'like', "%{$search}%")
                        ->orWhere('storage', 'like', "%{$search}%")
                        ->orWhere('remark', 'like', "%{$search}%");
                });
            })
            ->when($status === 'sold', function ($query) {
                $query->where('is_sold', 1);
            })
            ->when($status === 'available', function ($query) {
                $query->where('is_sold', 0);
            });

        return [
            'query' => $query,
            'period' => $range['period'],
            'fromdate' => $range['fromdate'],
            'todate' => $range['todate'],
            'timePeriod' => $range['timePeriod'],
            'search' => $search,
            'status' => $status,
        ];
    }

    public function buildFinanceReportSummary($invoices, ?string $fromDate = null, ?string $toDate = null): array
    {
        $records = collect($invoices);
        $lineItems = $records->flatMap(function ($invoice) {
            $items = $invoice->items ?? $invoice['items'] ?? [];

            return collect($items)->map(function ($item) {
                return [
                    'profit' => (float) ($item->profit ?? $item['profit'] ?? 0),
                    'quantity' => (int) ($item->quantity ?? $item['quantity'] ?? 0),
                    'purchaseCost' => (float) (
                        $item->purchase->purchase_cost ??
                        $item->purchase->purchase_price ??
                        $item->purchase_cost ??
                        $item['purchase_cost'] ??
                        $item['purchasePrice'] ??
                        0
                    ),
                ];
            });
        });

        $paymentTypeBreakdown = [];

        foreach ($records as $invoice) {
            $paymentType = trim((string) ($invoice->payment_type ?? $invoice['payment_type'] ?? 'Unknown')) ?: 'Unknown';
            $items = collect($invoice->items ?? $invoice['items'] ?? []);
            $invoiceProfit = (float) $items->sum('profit');
            $invoiceItemsSold = (int) $items->sum('quantity');
            $invoicePurchaseCost = (float) $items->sum(function ($item) {
                return (float) (
                    $item->purchase->purchase_cost ??
                    $item->purchase->purchase_price ??
                    $item->purchase_cost ??
                    $item['purchase_cost'] ??
                    $item['purchasePrice'] ??
                    0
                );
            });

            if (! isset($paymentTypeBreakdown[$paymentType])) {
                $paymentTypeBreakdown[$paymentType] = [
                    'label' => $paymentType,
                    'count' => 0,
                    'sales' => 0.0,
                    'profit' => 0.0,
                    'purchaseCost' => 0.0,
                    'itemsSold' => 0,
                ];
            }

            $paymentTypeBreakdown[$paymentType]['count'] += 1;
            $paymentTypeBreakdown[$paymentType]['sales'] += (float) ($invoice->net_amount ?? $invoice['net_amount'] ?? 0);
            $paymentTypeBreakdown[$paymentType]['profit'] += $invoiceProfit;
            $paymentTypeBreakdown[$paymentType]['purchaseCost'] += $invoicePurchaseCost;
            $paymentTypeBreakdown[$paymentType]['itemsSold'] += $invoiceItemsSold;
        }

        $paymentTypeBreakdown = collect($paymentTypeBreakdown)
            ->values()
            ->sortByDesc('count')
            ->values()
            ->all();

        return [
            'fromDate' => $fromDate,
            'toDate' => $toDate,
            'invoiceCount' => $records->count(),
            'totalSales' => round((float) $records->sum(fn ($invoice) => (float) ($invoice->net_amount ?? $invoice['net_amount'] ?? 0)), 2),
            'totalProfit' => round((float) $lineItems->sum('profit'), 2),
            'totalPurchaseCost' => round((float) $lineItems->sum('purchaseCost'), 2),
            'itemsSold' => (int) $lineItems->sum('quantity'),
            'paymentTypeBreakdown' => $paymentTypeBreakdown,
        ];
    }

    public function financeReport(Request $request)
    {
        $range = $this->resolvePeriodRange($request, 'thismonth');
        $fromDate = $request->filled('fromdate') ? $request->input('fromdate') : $range['start'];
        $toDate = $request->filled('todate') ? $request->input('todate') : $range['end'];

        $query = (
            Invoice::with(['customer', 'items' => function ($query) {
                $query->where('deleted', 0);
            }])
        )->where('deleted', 0);

        if ($fromDate && $toDate) {
            $query->whereBetween('invoice_date', [$fromDate, $toDate]);
        }

        $invoices = $query->orderBy('invoice_date', 'asc')->orderBy('created_at', 'asc')->get();
        $summary = $this->buildFinanceReportSummary($invoices, $fromDate, $toDate);

        return view('reports.finance-report', [
            'invoices' => $invoices,
            'summary' => $summary,
            'period' => $request->input('period', $range['period']),
            'fromdate' => $fromDate,
            'todate' => $toDate,
            'timePeriod' => $range['timePeriod'],
        ]);
    }

    public function exportFinanceReportCsv(Request $request)
    {
        $range = $this->resolvePeriodRange($request, 'thismonth');
        $fromDate = $request->filled('fromdate') ? $request->input('fromdate') : $range['start'];
        $toDate = $request->filled('todate') ? $request->input('todate') : $range['end'];

        $query = (
            Invoice::with(['customer', 'items' => function ($query) {
                $query->where('deleted', 0);
            }])
        )->where('deleted', 0);

        if ($fromDate && $toDate) {
            $query->whereBetween('invoice_date', [$fromDate, $toDate]);
        }

        $invoices = $query->orderBy('invoice_date', 'asc')->orderBy('created_at', 'asc')->get();

        $headers = [
            'Content-Type' => 'text/csv',
            'Content-Disposition' => 'attachment; filename=finance-report-' . now()->format('Ymd-His') . '.csv',
            'Pragma' => 'no-cache',
            'Cache-Control' => 'must-revalidate, post-check=0, pre-check=0',
            'Expires' => '0',
        ];

        $callback = function () use ($invoices): void {
            $file = fopen('php://output', 'w+');
            fputcsv($file, ['Date', 'Invoice No', 'Customer Name', 'Sales Amount', 'Purchase Cost', 'Profit', 'Items Sold', 'Payment Method'], ';');

            foreach ($invoices as $invoice) {
                $items = $invoice->items ?? collect();
                $purchaseCost = (float) $items->sum(function ($item) {
                    return (float) (
                        $item->purchase->purchase_cost ??
                        $item->purchase->purchase_price ??
                        $item->purchase_cost ??
                        0
                    );
                });

                fputcsv($file, [
                    $invoice->invoice_date,
                    $invoice->invoice_no,
                    $invoice->customer_name,
                    $invoice->net_amount,
                    $purchaseCost,
                    (float) $items->sum('profit'),
                    (int) $items->sum('quantity'),
                    $invoice->payment_type,
                ], ';');
            }

            fclose($file);
        };

        return Response::stream($callback, 200, $headers);
    }

    public function exportFinanceReportPdf(Request $request)
    {
        $range = $this->resolvePeriodRange($request, 'thismonth');
        $fromDate = $request->filled('fromdate') ? $request->input('fromdate') : $range['start'];
        $toDate = $request->filled('todate') ? $request->input('todate') : $range['end'];

        $query = (
            Invoice::with(['customer', 'items' => function ($query) {
                $query->where('deleted', 0);
            }])
        )->where('deleted', 0);

        if ($fromDate && $toDate) {
            $query->whereBetween('invoice_date', [$fromDate, $toDate]);
        }

        $invoices = $query->orderBy('invoice_date', 'asc')->orderBy('created_at', 'asc')->get();
        $summary = $this->buildFinanceReportSummary($invoices, $fromDate, $toDate);

        $pdf = Pdf::loadView('reports.finance-report-pdf', [
            'invoices' => $invoices,
            'summary' => $summary,
            'fromdate' => $fromDate,
            'todate' => $toDate,
            'timePeriod' => $range['timePeriod'],
        ])->setPaper('a4', 'landscape');

        return $pdf->download('finance-report-' . now()->format('Ymd-His') . '.pdf');
    }

    public function dailyClosing(Request $request)
    {
        $selectedDate = $request->filled('date')
            ? Carbon::parse($request->input('date'))->toDateString()
            : Carbon::today()->toDateString();

        $trendStart = Carbon::today()->startOfMonth()->subMonths(11);
        $trendEnd = Carbon::today()->endOfMonth();

        $openingBalance = DayOpeningBalance::whereDate('date', $selectedDate)->first()
            ?? DayOpeningBalance::whereDate('date', '<', $selectedDate)->latest('date')->first();

        $openingCash = (float) ($openingBalance->cash_balance ?? $openingBalance->balance ?? 0);
        $openingBank = (float) ($openingBalance->bank_balance ?? 0);

        $invoices = (Invoice::with(['items', 'customer']))
            ->where('deleted', 0)
            ->whereDate('invoice_date', $selectedDate)
            ->orderBy('invoice_date', 'desc')
            ->orderBy('created_at', 'desc')
            ->get();

        // Summed from invoice_payments rather than invoices.payment_type directly, so a
        // split-payment invoice (part cash, part online) contributes its actual amount to
        // each method's bucket instead of being counted entirely under whichever single
        // label happened to be stored.
        $paymentTotals = InvoicePayment::query()
            ->join('invoices', 'invoices.id', '=', 'invoice_payments.invoice_id')
            ->where('invoices.deleted', 0)
            ->whereDate('invoices.invoice_date', $selectedDate)
            ->selectRaw('invoice_payments.payment_method, SUM(invoice_payments.amount) as total')
            ->groupBy('invoice_payments.payment_method')
            ->pluck('total', 'payment_method');

        $cashSales = (float) ($paymentTotals['Cash'] ?? 0);
        $onlineSales = (float) ($paymentTotals['Online'] ?? 0);
        $cardSales = (float) ($paymentTotals['Credit Card'] ?? 0);
        $totalSales = (float) $invoices->sum('net_amount');
        $grossProfit = (float) $invoices->sum(function ($invoice) {
            return $invoice->items->where('deleted', 0)->sum('profit');
        });
        $itemsSold = (int) $invoices->sum(function ($invoice) {
            return $invoice->items->where('deleted', 0)->sum('quantity');
        });

        $expenses = Expense::where('deleted', 0)
            ->whereDate('entrydate', $selectedDate)
            ->orderBy('created_at', 'desc')
            ->get();

        $monthlyPurchaseTotals = (Purchase::query())
            ->where('deleted', 0)
            ->whereBetween('purchase_date', [$trendStart->toDateString(), $trendEnd->toDateString()])
            ->selectRaw("DATE_FORMAT(purchase_date, '%Y-%m') as month_key, SUM(purchase_cost) as total_amount")
            ->groupBy('month_key')
            ->pluck('total_amount', 'month_key');

        $monthlySalesTotals = (Invoice::query())
            ->where('deleted', 0)
            ->whereBetween('invoice_date', [$trendStart->toDateString(), $trendEnd->toDateString()])
            ->selectRaw("DATE_FORMAT(invoice_date, '%Y-%m') as month_key, SUM(net_amount) as total_amount")
            ->groupBy('month_key')
            ->pluck('total_amount', 'month_key');

        $monthlyComparison = collect(range(0, 11))->map(function ($offset) use ($trendStart, $monthlyPurchaseTotals, $monthlySalesTotals) {
            $month = $trendStart->copy()->addMonths($offset);
            $monthKey = $month->format('Y-m');

            return [
                'label' => $month->format('M Y'),
                'purchase' => round((float) ($monthlyPurchaseTotals[$monthKey] ?? 0), 2),
                'sales' => round((float) ($monthlySalesTotals[$monthKey] ?? 0), 2),
            ];
        });

        $totalExpense = (float) $expenses->sum('amount');
        $netProfit = $grossProfit - $totalExpense;
        $closingCash = $openingCash + $cashSales - $totalExpense;
        $closingBank = $openingBank + $onlineSales + $cardSales;
        $closingBalance = $closingCash + $closingBank;

        return view('reports.daily-closing', [
            'selectedDate' => $selectedDate,
            'invoiceCount' => $invoices->count(),
            'itemsSold' => $itemsSold,
            'cashSales' => $cashSales,
            'onlineSales' => $onlineSales,
            'cardSales' => $cardSales,
            'totalSales' => $totalSales,
            'grossProfit' => $grossProfit,
            'totalExpense' => $totalExpense,
            'netProfit' => $netProfit,
            'openingCash' => $openingCash,
            'openingBank' => $openingBank,
            'openingBalance' => $openingCash + $openingBank,
            'closingCash' => $closingCash,
            'closingBank' => $closingBank,
            'closingBalance' => $closingBalance,
            'expenses' => $expenses,
            'invoices' => $invoices,
            'monthlyComparisonLabels' => $monthlyComparison->pluck('label'),
            'monthlyPurchaseSeries' => $monthlyComparison->pluck('purchase'),
            'monthlySalesSeries' => $monthlyComparison->pluck('sales'),
            'lastTwelveMonthPurchaseTotal' => (float) $monthlyComparison->sum('purchase'),
            'lastTwelveMonthSalesTotal' => (float) $monthlyComparison->sum('sales'),
        ]);
    }

    public function profitLoss(Request $request)
    {
        $range = $this->resolvePeriodRange($request);

        $invoiceQuery = (Invoice::with(['customer', 'items' => function ($query) {
            $query->where('deleted', 0);
        }]))->where('deleted', 0);
        $expenseQuery = Expense::with('category')->where('deleted', 0);
        $purchaseQuery = (Purchase::query())->where('deleted', 0);

        if ($range['start'] && $range['end']) {
            $invoiceQuery->whereBetween('invoice_date', [$range['start'], $range['end']]);
            $expenseQuery->whereBetween('entrydate', [$range['start'], $range['end']]);
            $purchaseQuery->whereBetween('purchase_date', [$range['start'], $range['end']]);
        }

        $invoices = $invoiceQuery
            ->orderBy('invoice_date', 'desc')
            ->orderBy('created_at', 'desc')
            ->get();

        $expenses = $expenseQuery
            ->orderBy('entrydate', 'desc')
            ->orderBy('created_at', 'desc')
            ->get();

        $purchases = $purchaseQuery
            ->orderBy('purchase_date', 'desc')
            ->orderBy('created_at', 'desc')
            ->get();

        $totalRevenue = (float) $invoices->sum('net_amount');
        $grossProfit = (float) $invoices->sum(function ($invoice) {
            return $invoice->items->sum('profit');
        });
        $totalExpenses = (float) $expenses->sum('amount');
        $purchaseSpend = (float) $purchases->sum('purchase_cost');
        $netProfit = $grossProfit - $totalExpenses;
        $grossMargin = $totalRevenue > 0 ? ($grossProfit / $totalRevenue) * 100 : 0;
        $netMargin = $totalRevenue > 0 ? ($netProfit / $totalRevenue) * 100 : 0;

        $expenseBreakdown = $expenses
            ->groupBy(function ($expense) {
                return $expense->category?->name ?: 'Uncategorized';
            })
            ->map(function ($group, $label) {
                return [
                    'label' => $label,
                    'count' => $group->count(),
                    'amount' => (float) $group->sum('amount'),
                ];
            })
            ->sortByDesc('amount')
            ->values()
            ->take(8);

        $bucketFormat = 'Y-m-d';
        if ($range['start'] && $range['end']) {
            $diffInDays = Carbon::parse($range['start'])->diffInDays(Carbon::parse($range['end']));
            if ($diffInDays > 62) {
                $bucketFormat = 'Y-m';
            }
        } elseif ($range['period'] === 'alls') {
            $bucketFormat = 'Y-m';
        }

        $statementMap = [];

        foreach ($invoices as $invoice) {
            $key = Carbon::parse($invoice->invoice_date)->format($bucketFormat);
            $statementMap[$key] = $statementMap[$key] ?? ['revenue' => 0, 'gross_profit' => 0, 'expenses' => 0, 'purchase_spend' => 0];
            $statementMap[$key]['revenue'] += (float) $invoice->net_amount;
            $statementMap[$key]['gross_profit'] += (float) $invoice->items->sum('profit');
        }

        foreach ($expenses as $expense) {
            $key = Carbon::parse($expense->entrydate)->format($bucketFormat);
            $statementMap[$key] = $statementMap[$key] ?? ['revenue' => 0, 'gross_profit' => 0, 'expenses' => 0, 'purchase_spend' => 0];
            $statementMap[$key]['expenses'] += (float) $expense->amount;
        }

        foreach ($purchases as $purchase) {
            $key = Carbon::parse($purchase->purchase_date)->format($bucketFormat);
            $statementMap[$key] = $statementMap[$key] ?? ['revenue' => 0, 'gross_profit' => 0, 'expenses' => 0, 'purchase_spend' => 0];
            $statementMap[$key]['purchase_spend'] += (float) $purchase->purchase_cost;
        }

        $statementRows = collect($statementMap)
            ->map(function ($row, $key) use ($bucketFormat) {
                $label = $bucketFormat === 'Y-m'
                    ? Carbon::createFromFormat('Y-m', $key)->format('M Y')
                    : Carbon::createFromFormat('Y-m-d', $key)->format('d M Y');

                $row['label'] = $label;
                $row['net_profit'] = $row['gross_profit'] - $row['expenses'];

                return $row;
            })
            ->sortBy(function ($row, $key) {
                return $key;
            })
            ->values();

        return view('reports.profit-loss', [
            'period' => $range['period'],
            'fromdate' => $range['fromdate'],
            'todate' => $range['todate'],
            'timePeriod' => $range['timePeriod'],
            'totalRevenue' => $totalRevenue,
            'grossProfit' => $grossProfit,
            'totalExpenses' => $totalExpenses,
            'purchaseSpend' => $purchaseSpend,
            'netProfit' => $netProfit,
            'grossMargin' => $grossMargin,
            'netMargin' => $netMargin,
            'invoiceCount' => $invoices->count(),
            'expenseCount' => $expenses->count(),
            'purchaseCount' => $purchases->count(),
            'expenseBreakdown' => $expenseBreakdown,
            'statementRows' => $statementRows,
        ]);
    }

    public function sale(Request $request)
    {
        $allSales = (Invoice::query())->where('deleted', 0)->orderBy('invoice_date', 'desc')->get();
        $period = $request->input('period');
        $totalSalesAmount = $totalProfitAmount = 0;
        $fromDate = $toDate = '';
        if ($period === 'thismonth') {
            $startOfMonth = Carbon::now()->startOfMonth();
            $endOfMonth = Carbon::now();  // today's date)
            $allSales = (Invoice::query())
                ->whereBetween('invoice_date', [$startOfMonth, $endOfMonth])
                ->where('deleted', 0)
                ->orderBy('created_at', 'desc')->paginate(10);
            $totalSalesAmount = (Invoice::query())->whereBetween('invoice_date', [$startOfMonth, $endOfMonth])->where('deleted', 0)->sum('net_amount');
            $totalProfitAmount = (InvoiceItem::query())->whereHas('invoice', function ($query) use ($startOfMonth, $endOfMonth) {
                $query->whereBetween('invoice_date', [$startOfMonth, $endOfMonth])->where('deleted', 0);
            })->where('deleted', 0)->sum('profit');
            $totalExpenseAmount = Expense::whereBetween('entrydate', [$startOfMonth, $endOfMonth])->where('deleted', 0)->sum('amount');
            $timePeriod = Carbon::now()->format('F');
        } elseif ($period === 'lastmonth') {
            $lastMonthStart = Carbon::now()->subMonth()->startOfMonth();
            $lastMonthEnd = Carbon::now()->subMonth()->endOfMonth();  // today's date)
            $allSales = (Invoice::query())
                ->whereBetween('invoice_date', [$lastMonthStart, $lastMonthEnd])
                ->where('deleted', 0)
                ->orderBy('created_at', 'desc')->paginate(10);
            $totalSalesAmount = (Invoice::query())->whereBetween('invoice_date', [$lastMonthStart, $lastMonthEnd])->where('deleted', 0)->sum('net_amount');
            $totalProfitAmount = (InvoiceItem::query())->whereHas('invoice', function ($query) use ($lastMonthStart, $lastMonthEnd) {
                $query->whereBetween('invoice_date', [$lastMonthStart, $lastMonthEnd]);
            })->where('deleted', 0)->sum('profit');
            $totalExpenseAmount = Expense::whereBetween('entrydate', [$lastMonthStart, $lastMonthEnd])->where('deleted', 0)->sum('amount');
            $timePeriod = Carbon::now()->subMonth()->format('F');
        } elseif ($period === 'thisyear') {
            $startOfYear = Carbon::now()->startOfYear();
            $endOfYear = Carbon::now();  // today's date)
            $allSales = (Invoice::query())
                ->whereBetween('invoice_date', [$startOfYear, $endOfYear])
                ->where('deleted', 0)
                ->orderBy('created_at', 'desc')->paginate(10);
            $totalSalesAmount = (Invoice::query())->whereBetween('invoice_date', [$startOfYear, $endOfYear])->where('deleted', 0)->sum('net_amount');
            $totalProfitAmount = (InvoiceItem::query())->whereHas('invoice', function ($query) use ($startOfYear, $endOfYear) {
                $query->whereBetween('invoice_date', [$startOfYear, $endOfYear]);
            })->where('deleted', 0)->sum('profit');
            $totalExpenseAmount = Expense::whereBetween('entrydate', [$startOfYear, $endOfYear])->where('deleted', 0)->sum('amount');
            $timePeriod = Carbon::now()->format('Y');
        } elseif ($period === 'lastyear') {
            $startOfLastYear = Carbon::now()->subYear()->startOfYear();
            $endOfLastYear = Carbon::now()->subYear()->endOfYear();
            $allSales = (Invoice::query())
                ->whereBetween('invoice_date', [$startOfLastYear, $endOfLastYear])
                ->where('deleted', 0)
                ->orderBy('created_at', 'asc')->paginate(15);
            $totalSalesAmount = (Invoice::query())->whereBetween('invoice_date', [$startOfLastYear, $endOfLastYear])->where('deleted', 0)->sum('net_amount');
            $totalProfitAmount = (InvoiceItem::query())->whereHas('invoice', function ($query) use ($startOfLastYear, $endOfLastYear) {
                $query->whereBetween('invoice_date', [$startOfLastYear, $endOfLastYear]);
            })->where('deleted', 0)->sum('profit');
            $totalExpenseAmount = Expense::whereBetween('entrydate', [$startOfLastYear, $endOfLastYear])->where('deleted', 0)->sum('amount');
            $timePeriod = Carbon::now()->subYear()->format('Y');
        } elseif ($period === 'custom') {
            $fromDate = $request->input('fromdate');
            $toDate = $request->input('todate');
            $allSales = (Invoice::query())->whereBetween('invoice_date', [$fromDate, $toDate])->where('deleted', 0)->orderBy('created_at', 'desc')->paginate(15);
            $totalSalesAmount = (Invoice::query())->whereBetween('invoice_date', [$fromDate, $toDate])->where('deleted', 0)->sum('net_amount');
            $totalProfitAmount = (InvoiceItem::query())->whereHas('invoice', function ($query) use ($fromDate, $toDate) {
                $query->whereBetween('invoice_date', [$fromDate, $toDate]);
            })->where('deleted', 0)->sum('profit');
            $totalExpenseAmount = Expense::whereBetween('entrydate', [$fromDate, $toDate])->where('deleted', 0)->sum('amount');
            $timePeriod = Carbon::now()->format('F');
        } elseif ($period === 'alls') {
            $allSales = (Invoice::query())->where('deleted', 0)
                ->orderBy('created_at', 'desc')->paginate(10);
            $totalSalesAmount = (Invoice::query())->whereBetween('invoice_date', [Carbon::now()->startOfMonth(), Carbon::now()])
                ->where('deleted', 0)->sum('net_amount');
            $totalProfitAmount = (InvoiceItem::query())->whereHas('invoice', function ($query) {
                $query->whereBetween('invoice_date', [Carbon::now()->startOfMonth(), Carbon::now()]);
            })->where('deleted', 0)->sum('profit');
            $totalExpenseAmount = Expense::whereBetween('entrydate', [Carbon::now()->startOfMonth(), Carbon::now()])->where('deleted', 0)->sum('amount');
            $timePeriod = Carbon::now()->format('F');
        } else {
            $allSales = (Invoice::query())->where('deleted', 0)
                ->orderBy('created_at', 'desc')->paginate(10);
            $totalSalesAmount = (Invoice::query())->whereBetween('invoice_date', [Carbon::now()->startOfMonth(), Carbon::now()])
                ->where('deleted', 0)->sum('net_amount');
            $totalProfitAmount = (InvoiceItem::query())->whereHas('invoice', function ($query) {
                $query->whereBetween('invoice_date', [Carbon::now()->startOfMonth(), Carbon::now()]);
            })->where('deleted', 0)->sum('profit');
            $totalExpenseAmount = Expense::whereBetween('entrydate', [Carbon::now()->startOfMonth(), Carbon::now()])->where('deleted', 0)->sum('amount');
            $timePeriod = Carbon::now()->format('F');
        }

        return view('reports.sales', [
            'allSales' => $allSales,
            'period' => $period,
            'totalSalesAmount' => number_format((float) $totalSalesAmount, 2, '.', ''),
            'totalProfitAmount' => number_format((float) $totalProfitAmount, 2, '.', ''),
            'fromdate' => $fromDate,
            'todate' => $toDate,
            'totalItems' => $allSales->total(),
            'currentMonth' => Carbon::now()->format('F'),
            'timePeriod' => $timePeriod,
            'totalExpenseAmount' => number_format((float) $totalExpenseAmount, 2, '.', ''),
        ]);
    }

    /**
     * Download sales records using route(sale-export)
     */
    public function downloadExcel(Request $request)
    {
        $period = $request->input('period');
        $monthName = Carbon::now()->format('F');

        // Get sales data based on the selected period
        if ($period === 'thismonth') {
            $monthName = Carbon::now()->format('F');
            $start = Carbon::now()->startOfMonth();
            $end = Carbon::now();
        } elseif ($period === 'lastmonth') {
            $monthName = Carbon::now()->subMonth()->format('F');
            $start = Carbon::now()->subMonth()->startOfMonth();
            $end = Carbon::now()->subMonth()->endOfMonth();
        } elseif ($period === 'thisyear') {
            $monthName = Carbon::now()->format('Y');
            $start = Carbon::now()->startOfYear();
            $end = Carbon::now();
        } elseif ($period === 'custom') {
            $from = $request->input('fromdate');
            $to = $request->input('todate');
            $monthName = Carbon::parse($from)->format('d-M') . '_to_' . Carbon::parse($to)->format('d-M');
            $start = $from;
            $end = $to;
        } else {
            $start = null;
            $end = null;
        }

        // Query invoices with relationships eager loaded
        $query = (Invoice::with(['customer', 'items.purchase']))->where('deleted', 0);

        if ($start && $end) {
            $query->whereBetween('invoice_date', [$start, $end]);
        }

        $salesReport = $query->orderBy('created_at', 'asc')->get();

        // Prepare CSV headers
        $fileName = $monthName . '-sales.csv';
        $headers = [
            'Content-Type' => 'text/csv',
            'Content-Disposition' => "attachment; filename=$fileName",
            'Pragma' => 'no-cache',
            'Cache-Control' => 'must-revalidate, post-check=0, pre-check=0',
            'Expires' => '0',
        ];

        // CSV callback generator
        $callback = function () use ($salesReport) {
            $file = fopen('php://output', 'w+');

            // CSV header
            fputcsv($file, [
                'Sr No',
                'Invoice No.',
                'Invoice Date',
                'IMEI',
                'Model',
                'Storage (GB)',
                'Color',
                'Customer Name',
                'Mobile No.',
                'Sell Price',
                'Profit',
                'Payment Mode',
            ], ';');

            $count = 1;

            foreach ($salesReport as $invoice) {
                foreach ($invoice->items as $item) {
                    $purchase = $item->purchase; // Purchase related to this item

                    fputcsv($file, [
                        $count++,
                        $invoice->invoice_no,
                        $invoice->invoice_date ? Carbon::parse($invoice->invoice_date)->format('d-m-Y') : '',
                        $purchase->imei ?? '',
                        $purchase->model ?? '',
                        $purchase->storage ?? '',
                        $purchase->color ?? '',
                        $invoice->customer_name ?? '',
                        $invoice->customer_no ?? '',
                        $item->unit_price ?? 0, // prefer per-item price if available
                        $item->profit ?? 0,
                        $invoice->payment_type ?? '',
                    ], ';');
                }
            }

            fclose($file);
        };

        return Response::stream($callback, 200, $headers);
    }

    public function downloadSalesPdf(Request $request)
    {
        $period = $request->input('period');
        $fromDate = $request->input('fromdate');
        $toDate = $request->input('todate');

        $query = (Invoice::with(['customer', 'items.purchase']))->where('deleted', 0)->orderBy('invoice_date', 'asc');
        $timePeriod = 'All Sales';

        if ($period === 'thismonth') {
            $start = Carbon::now()->startOfMonth();
            $end = Carbon::now();
            $query->whereBetween('invoice_date', [$start, $end]);
            $timePeriod = Carbon::now()->format('F');
        } elseif ($period === 'lastmonth') {
            $start = Carbon::now()->subMonth()->startOfMonth();
            $end = Carbon::now()->subMonth()->endOfMonth();
            $query->whereBetween('invoice_date', [$start, $end]);
            $timePeriod = Carbon::now()->subMonth()->format('F');
        } elseif ($period === 'thisyear') {
            $start = Carbon::now()->startOfYear();
            $end = Carbon::now();
            $query->whereBetween('invoice_date', [$start, $end]);
            $timePeriod = Carbon::now()->format('Y');
        } elseif ($period === 'lastyear') {
            $start = Carbon::now()->subYear()->startOfYear();
            $end = Carbon::now()->subYear()->endOfYear();
            $query->whereBetween('invoice_date', [$start, $end]);
            $timePeriod = Carbon::now()->subYear()->format('Y');
        } elseif ($period === 'custom' && $fromDate && $toDate) {
            $query->whereBetween('invoice_date', [$fromDate, $toDate]);
            $timePeriod = Carbon::parse($fromDate)->format('d M Y') . ' - ' . Carbon::parse($toDate)->format('d M Y');
        }

        $allSales = $query->get();

        $totalSalesAmount = (float) $allSales->sum('net_amount');
        $invoiceIds = $allSales->pluck('id');
        $totalProfitAmount = (float) (InvoiceItem::query())->whereIn('invoice_id', $invoiceIds)->where('deleted', 0)->sum('profit');

        if ($period === 'custom' && $fromDate && $toDate) {
            $totalExpenseAmount = (float) Expense::whereBetween('entrydate', [$fromDate, $toDate])->where('deleted', 0)->sum('amount');
        } elseif ($period === 'lastmonth') {
            $totalExpenseAmount = (float) Expense::whereBetween('entrydate', [Carbon::now()->subMonth()->startOfMonth(), Carbon::now()->subMonth()->endOfMonth()])->where('deleted', 0)->sum('amount');
        } elseif ($period === 'thisyear') {
            $totalExpenseAmount = (float) Expense::whereBetween('entrydate', [Carbon::now()->startOfYear(), Carbon::now()])->where('deleted', 0)->sum('amount');
        } elseif ($period === 'lastyear') {
            $totalExpenseAmount = (float) Expense::whereBetween('entrydate', [Carbon::now()->subYear()->startOfYear(), Carbon::now()->subYear()->endOfYear()])->where('deleted', 0)->sum('amount');
        } else {
            $totalExpenseAmount = (float) Expense::whereBetween('entrydate', [Carbon::now()->startOfMonth(), Carbon::now()])->where('deleted', 0)->sum('amount');
        }

        $pdf = Pdf::loadView('reports.sales-pdf', [
            'allSales' => $allSales,
            'timePeriod' => $timePeriod,
            'totalSalesAmount' => $totalSalesAmount,
            'totalProfitAmount' => $totalProfitAmount,
            'totalExpenseAmount' => $totalExpenseAmount,
        ])->setPaper('a4', 'landscape');

        return $pdf->download('sales-report-' . now()->format('Ymd-His') . '.pdf');
    }

    public function downloadPurchaseExcel(Request $request)
    {
        $report = $this->purchaseReportDataset($request, false);
        $allPurchases = $report['purchases'];
        $fileName = $this->purchaseReportFilename('csv');
        $headers = [
            'Content-type' => 'text/csv',
            'Content-Disposition' => "attachment; filename=$fileName",
            'Pragma' => 'no-cache',
            'Cache-Control' => 'must-revalidate, post-check=0, pre-check=0',
            'Expires' => '0',
        ];
        $callback = function () use ($allPurchases): void {
            $file = fopen('php://output', 'w+');

            fputcsv($file, ['Sr No', 'Purchase Date', 'IMEI', 'Model', 'Storage', 'Color', 'Supplier', 'Mobile No', 'Buy Cost', 'Repairing', 'Stock Value', 'Sell Date', 'Status', 'Remark']);

            foreach ($allPurchases as $index => $row) {
                fputcsv($file, [
                    $index + 1,
                    Carbon::parse($row->purchase_date)->format('d/m/Y'),
                    (string) $row->imei,
                    $row->model,
                    $row->storage,
                    $row->color,
                    $row->purchase_from,
                    $row->contactno,
                    $row->purchase_cost,
                    $row->repairing_charge ?: '',
                    $row->purchase_price,
                    ($row->sell_date) ? Carbon::parse($row->sell_date)->format('d/m/Y') : '',
                    ($row->is_sold == 1) ? 'Yes' : 'No',
                    $row->remark,
                ]);
            }

            fclose($file);
        };

        return Response::stream($callback, 200, $headers);
    }

    public function downloadPurchaseReport(Request $request)
    {
        $report = $this->purchaseReportDataset($request);

        return view('reports.purchase', [
            'allPurchased' => $report['purchases'],
            'period' => $report['period'],
            'fromdate' => $report['fromdate'],
            'todate' => $report['todate'],
            'timePeriod' => $report['timePeriod'],
            'search' => $report['search'],
            'status' => $report['status'],
            'totalItems' => $report['totalItems'],
            'totalPurchaseAmount' => $report['totalPurchaseAmount'],
            'totalRepairingAmount' => $report['totalRepairingAmount'],
            'totalStockValue' => $report['totalStockValue'],
            'soldItems' => $report['soldItems'],
            'availableItems' => $report['availableItems'],
        ]);
    }

    public function downloadPurchasePdf(Request $request)
    {
        $report = $this->purchaseReportDataset($request, false);

        $pdf = Pdf::loadView('reports.purchase-pdf', [
            'allPurchased' => $report['purchases'],
            'timePeriod' => $report['timePeriod'],
            'search' => $report['search'],
            'status' => $report['status'],
            'totalItems' => $report['totalItems'],
            'totalPurchaseAmount' => $report['totalPurchaseAmount'],
            'totalRepairingAmount' => $report['totalRepairingAmount'],
            'totalStockValue' => $report['totalStockValue'],
            'soldItems' => $report['soldItems'],
            'availableItems' => $report['availableItems'],
        ])->setPaper('a4', 'landscape');

        return $pdf->download($this->purchaseReportFilename('pdf'));
    }

    public function supplierLedger(Request $request)
    {
        $dataset = $this->supplierLedgerBaseQuery($request);
        $perPage = max((int) $request->input('per_page', 12), 1);
        $baseQuery = $dataset['query'];
        // ->toBase(): see the identical note in purchaseReportDataset() above — avoids
        // Eloquent's getTotalStockValueAttribute() accessor shadowing this alias.
        $summary = (clone $baseQuery)->toBase()->reorder()->selectRaw('
            COUNT(*) as total_items,
            SUM(purchase_cost) as total_purchase_amount,
            SUM(repairing_charge) as total_repairing_amount,
            SUM(purchase_price) as total_stock_value
        ')->first();

        $supplierBase = (clone $baseQuery)
            ->selectRaw("COALESCE(NULLIF(TRIM(purchase_from), ''), 'Unknown Supplier') as supplier_name")
            ->selectRaw("COALESCE(NULLIF(TRIM(purchase_from), ''), '__unknown__') as supplier_filter")
            ->addSelect('contactno', 'purchase_cost', 'repairing_charge', 'purchase_price', 'is_sold', 'purchase_date');

        $supplierCollection = DB::query()
            ->fromSub($supplierBase, 'supplier_rows')
            ->select('supplier_name', 'supplier_filter')
            ->selectRaw('MAX(contactno) as contactno')
            ->selectRaw('COUNT(*) as purchase_count')
            ->selectRaw('SUM(purchase_cost) as total_purchase_cost')
            ->selectRaw('SUM(COALESCE(repairing_charge, 0)) as total_repairing_charge')
            ->selectRaw('SUM(purchase_price) as total_stock_value')
            ->selectRaw('SUM(CASE WHEN is_sold = 1 THEN 1 ELSE 0 END) as sold_count')
            ->selectRaw('SUM(CASE WHEN is_sold = 0 THEN 1 ELSE 0 END) as available_count')
            ->selectRaw('MAX(purchase_date) as latest_purchase_date')
            ->groupBy('supplier_name', 'supplier_filter')
            ->orderByDesc('latest_purchase_date')
            ->orderByDesc('total_purchase_cost')
            ->get();

        $currentPage = LengthAwarePaginator::resolveCurrentPage();
        $suppliers = new LengthAwarePaginator(
            $supplierCollection->forPage($currentPage, $perPage)->values(),
            $supplierCollection->count(),
            $perPage,
            $currentPage,
            [
                'path' => $request->url(),
                'query' => $request->query(),
            ]
        );

        $viewData = [
            'suppliers' => $suppliers,
            'period' => $dataset['period'],
            'fromdate' => $dataset['fromdate'],
            'todate' => $dataset['todate'],
            'timePeriod' => $dataset['timePeriod'],
            'search' => $dataset['search'],
            'status' => $dataset['status'],
            'supplierCount' => $suppliers->total(),
            'totalItems' => (int) $summary->total_items,
            'totalPurchaseAmount' => (float) $summary->total_purchase_amount,
            'totalRepairingAmount' => (float) $summary->total_repairing_amount,
            'totalStockValue' => (float) $summary->total_stock_value,
        ];

        if ($request->ajax()) {
            return response()->json([
                'metrics' => view('reports._supplier-ledger-metrics', $viewData)->render(),
                'table' => view('reports._supplier-ledger-table', $viewData)->render(),
            ]);
        }

        return view('reports.supplier-ledger', $viewData);
    }

    public function supplierLedgerDetail(Request $request)
    {
        $dataset = $this->supplierLedgerBaseQuery($request);
        $supplierFilter = trim((string) $request->input('supplier', ''));
        abort_if($supplierFilter === '', 404);

        $purchaseQuery = $dataset['query'];

        if ($supplierFilter === '__unknown__') {
            $purchaseQuery->where(function ($query) {
                $query->whereNull('purchase_from')
                    ->orWhereRaw("TRIM(purchase_from) = ''");
            });
            $supplierName = 'Unknown Supplier';
        } else {
            $purchaseQuery->whereRaw('TRIM(purchase_from) = ?', [$supplierFilter]);
            $supplierName = $supplierFilter;
        }

        $perPage = max((int) $request->input('per_page', 15), 1);
        $supplierRows = (clone $purchaseQuery)->orderBy('purchase_date', 'desc')->orderBy('created_at', 'desc')->get();
        $purchases = (clone $purchaseQuery)
            ->orderBy('purchase_date', 'desc')
            ->orderBy('created_at', 'desc')
            ->paginate($perPage)
            ->appends($request->query());
        $viewData = [
            'purchases' => $purchases,
            'supplierName' => $supplierName,
            'supplierFilter' => $supplierFilter,
            'period' => $dataset['period'],
            'fromdate' => $dataset['fromdate'],
            'todate' => $dataset['todate'],
            'timePeriod' => $dataset['timePeriod'],
            'search' => $dataset['search'],
            'status' => $dataset['status'],
            'totalItems' => $supplierRows->count(),
            'totalPurchaseAmount' => (float) $supplierRows->sum('purchase_cost'),
            'totalRepairingAmount' => (float) $supplierRows->sum('repairing_charge'),
            'totalStockValue' => (float) $supplierRows->sum('purchase_price'),
            'soldItems' => (int) $supplierRows->where('is_sold', 1)->count(),
            'availableItems' => (int) $supplierRows->where('is_sold', 0)->count(),
            'latestPurchaseDate' => optional($supplierRows->sortByDesc('purchase_date')->first())->purchase_date,
            'contactno' => $supplierRows->pluck('contactno')->filter()->unique()->implode(', '),
        ];

        if ($request->ajax() || $request->boolean('modal')) {
            return view('reports._supplier-ledger-detail-content', $viewData);
        }

        return view('reports.supplier-ledger-detail', $viewData);
    }

    /**
     * display Sales & profit Charts
     */
    public function displayCharts()
    {
        $startOfMonth = Carbon::now()->startOfMonth();
        $endOfMonth = Carbon::now();
        $allSales = (Invoice::with(['items', 'customer']))
            ->whereBetween('invoice_date', [$startOfMonth, $endOfMonth])
            ->where('deleted', 0)
            ->orderBy('invoice_date', 'asc')
            ->get();

        $dailySales = $allSales
            ->groupBy(fn ($invoice) => Carbon::parse($invoice->invoice_date)->format('Y-m-d'))
            ->map(fn ($group) => round((float) $group->sum('net_amount'), 2));

        $dailyProfit = $allSales
            ->groupBy(fn ($invoice) => Carbon::parse($invoice->invoice_date)->format('Y-m-d'))
            ->map(function ($group) {
                return round((float) $group->sum(function ($invoice) {
                    return $invoice->items->sum('profit');
                }), 2);
            });

        $paymentModeData = $allSales
            ->groupBy(fn ($invoice) => $invoice->payment_type ?: 'Unknown')
            ->map(fn ($group) => $group->count());

        $dailyInvoiceCounts = $allSales
            ->groupBy(fn ($invoice) => Carbon::parse($invoice->invoice_date)->format('Y-m-d'))
            ->map(fn ($group) => $group->count());

        $topCustomers = $allSales
            ->groupBy(fn ($invoice) => $invoice->customer_name ?: 'Walk-in Customer')
            ->map(fn ($group) => round((float) $group->sum('net_amount'), 2))
            ->sortDesc()
            ->take(5);

        $totalSalesAmount = (float) $allSales->sum('net_amount');
        $totalProfitAmount = (float) $allSales->sum(function ($invoice) {
            return $invoice->items->sum('profit');
        });
        $timePeriod = Carbon::now()->format('F');
        $invoiceCount = $allSales->count();

        return view('reports.saleschart', [
            'timePeriod' => $timePeriod,
            'invoiceCount' => $invoiceCount,
            'totalSalesAmount' => $totalSalesAmount,
            'totalProfitAmount' => $totalProfitAmount,
            'dailySalesLabels' => $dailySales->keys()->values(),
            'dailySalesValues' => $dailySales->values(),
            'dailyProfitLabels' => $dailyProfit->keys()->values(),
            'dailyProfitValues' => $dailyProfit->values(),
            'paymentModeLabels' => $paymentModeData->keys()->values(),
            'paymentModeValues' => $paymentModeData->values(),
            'dailyInvoiceCountLabels' => $dailyInvoiceCounts->keys()->values(),
            'dailyInvoiceCountValues' => $dailyInvoiceCounts->values(),
            'topCustomerLabels' => $topCustomers->keys()->values(),
            'topCustomerValues' => $topCustomers->values(),
        ]);
    }

    public function customers(Request $request)
    {
        $search = trim((string) $request->input('search', ''));

        $customers = Customer::query()
            ->whereHas('invoices', function ($query) {
                ($query)->where('deleted', 0);
            })
            ->withCount(['invoices' => function ($query) {
                $query->where('deleted', 0);
            }])
            ->withCount('documents')
            ->when($search, function ($query) use ($search) {
                $query->where(function ($q) use ($search) {
                    $q->where('name', 'like', "%{$search}%")
                        ->orWhere('phone', 'like', "%{$search}%");
                });
            })
            ->orderBy('created_at', 'desc')
            ->paginate(15)
            ->appends($request->query());

        $totalCustomers = Customer::query()
            ->whereHas('invoices', fn ($query) => $query->where('deleted', 0))
            ->count();

        return view('reports.customers', [
            'customers' => $customers,
            'totalcustomers' => $totalCustomers,
            'search' => $search,
        ]);
    }

    /**
     * Identity documents a customer submitted across any of their invoices — rendered
     * into a modal on the Customers list via AJAX, reusing the same document-card/
     * reveal-number markup as the Invoice preview pane.
     */
    public function customerDocuments($id)
    {
        $customer = Customer::query()->findOrFail($id);
        $documents = $customer->documents()->with('invoice')->latest()->get();

        return view('reports._customer-documents-content', [
            'customer' => $customer,
            'documents' => $documents,
        ]);
    }

    /**
     * Streams an identity-document image through the app instead of the public/storage
     * symlink. These files are saved via Storage::disk('public'), but tenancy suffixes
     * that disk's root per-tenant (storage_tenantXXX/app/public/...) while the shared
     * symlink only ever points at the one central storage/app/public — so a direct
     * /storage/... URL 404s for every tenant. Routing the request through the app instead
     * resolves the disk correctly for whichever tenant is active, and as a side effect
     * keeps these KYC documents behind the same permission as the rest of this page
     * instead of sitting on a guessable public URL.
     */
    public function viewCustomerDocument($id)
    {
        $document = CustomerDocument::query()->findOrFail($id);

        abort_unless($document->document_image && Storage::disk('public')->exists($document->document_image), 404);

        return Storage::disk('public')->response($document->document_image);
    }

    public function exportcustomers()
    {
        $customers = Customer::query()->orderBy('created_at', 'desc')->get();
        $fileName = 'vision-customers.csv';
        $headers = [
            'Content-type' => 'text/csv',
            'Content-Disposition' => "attachment; filename=$fileName",
            'Pragma' => 'no-cache',
            'Cache-Control' => 'must-revalidate, post-check=0, pre-check=0',
            'Expires' => '0',
        ];
        $callback = function () use ($customers): void {
            $file = fopen('php://output', 'w+');

            fputcsv($file,
                [
                    'ID',
                    'Customer Name',
                    'Contact Number',
                ],
                ';'
            );

            foreach ($customers as $key => $row) {
                fputcsv($file, [
                    $key + 1,
                    $row->name,
                    $row->phone,
                ], ';');
            }
            fclose($file);
        };

        return Response::stream($callback, 200, $headers);
    }
}
