<?php

namespace App\Http\Middleware;

use Closure;
use Stancl\Tenancy\Middleware\InitializeTenancyByDomain;

/**
 * Same as InitializeTenancyByDomain, except it's a no-op for central domains.
 * Central-domain requests share routes/app-web.php's single (domain-less)
 * registration with real tenants — see bootstrap/app.php for why there's
 * only one registration rather than a per-domain copy — so this middleware
 * is what keeps the central admin app off the tenant database connection.
 */
class InitializeTenancyUnlessLegacy extends InitializeTenancyByDomain
{
    public function handle($request, Closure $next)
    {
        $host = $request->getHost();

        if (in_array($host, config('tenancy.central_domains', []), true)) {
            return $next($request);
        }

        return parent::handle($request, $next);
    }
}
