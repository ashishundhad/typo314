<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

/**
 * Blocks access when the current tenant's subscription doesn't grant it —
 * suspended, cancelled, expired trial/period, or stuck in provisioning_failed.
 * Trial and active both grant full access while genuinely still within their
 * window (no feature-based plans, no per-feature checks — see
 * App\Services\SubscriptionService and Subscription::hasAccess()).
 *
 * A no-op for central domains (tenancy() isn't initialized there —
 * InitializeTenancyUnlessLegacy already skips them) and for guests (an
 * unauthenticated request should hit the 'auth' middleware's
 * redirect-to-login, not this check).
 */
class EnsureSubscriptionActive
{
    public function handle(Request $request, Closure $next)
    {
        // Logging out must always work — otherwise a blocked user has no way
        // off the renewal page at all, since this middleware guards every
        // route in the tenant app (see bootstrap/app.php).
        if (! tenancy()->initialized || ! Auth::check() || $request->routeIs('logout')) {
            return $next($request);
        }

        $tenant = tenant();

        if ($tenant->subscription?->hasAccess()) {
            return $next($request);
        }

        return response()->view('errors.subscription-inactive', [
            'tenant' => $tenant,
            'subscription' => $tenant->subscription,
        ], 402);
    }
}
