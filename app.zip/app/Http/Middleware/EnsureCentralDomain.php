<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Cookie;
use Illuminate\Support\Facades\URL;
use Symfony\Component\HttpFoundation\Response;

class EnsureCentralDomain
{
    public function handle(Request $request, Closure $next): Response
    {
        if (! in_array($request->getHost(), config('tenancy.central_domains', []), true)) {
            abort(404);
        }

        // The central app never authenticates on the default 'web' guard (it's
        // central_admin-only), but Laravel's DatabaseSessionHandler unconditionally
        // resolves Auth::guard()->id() — the default guard — to populate
        // sessions.user_id on every save, for every request. A browser still
        // holding a 'web' remember-me cookie from before the legacy app's `users`
        // table was removed makes that resolution query a table that no longer
        // exists on the central connection, fataling requests that have nothing
        // to do with that guard. Strip it here, before anything touches the guard.
        $this->forgetStaleWebGuardCookies($request);

        // routes/central.php matches a parameterized {central_domain} segment so it can
        // support multiple central domains (prod domain + local testing hosts) without
        // colliding with routes/web.php's identical paths. Supply it as a URL default so
        // route()/action() calls in controllers and views don't need to pass it explicitly.
        URL::defaults(['central_domain' => $request->getHost()]);

        return $next($request);
    }

    private function forgetStaleWebGuardCookies(Request $request): void
    {
        $guard = Auth::guard('web');

        foreach ([$guard->getName(), $guard->getRecallerName()] as $cookieName) {
            if ($request->cookies->has($cookieName)) {
                $request->cookies->remove($cookieName);
                Cookie::queue(Cookie::forget($cookieName));
            }
        }
    }
}
