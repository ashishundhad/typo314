<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>@yield('title', 'Central Admin') &middot; Fonico</title>

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/datatables.net-bs5@1.13.11/css/dataTables.bootstrap5.min.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">

    <style>
        :root {
            --erp-navy: #112939;
            --erp-navy-deep: #0c1e2a;
            --erp-teal: #1abc9c;
            --erp-teal-deep: #128a73;
            --erp-bg: #f3f6f8;
            --erp-surface: #ffffff;
            --erp-border: #e3e9ef;
            --erp-ink: #17324d;
            --erp-ink-soft: #64748b;
            --erp-ink-faint: #94a3b8;
            --erp-shadow: 0 10px 26px rgba(17, 41, 57, 0.06);
        }

        * { box-sizing: border-box; }

        body {
            font-family: "Inter", -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
            margin: 0;
            background: var(--erp-bg);
            color: var(--erp-ink);
        }

        /* Legacy shell styles — still relied on by the plain create/edit forms
           (tenants/create, plans/edit) that haven't been given the ERP treatment. */
        nav { background: #1f2328; color: #fff; padding: 0.75rem 1.5rem; display: flex; align-items: center; justify-content: space-between; }
        nav a { color: #d1d5db; text-decoration: none; margin-right: 1.25rem; font-size: 0.9rem; }
        nav a.brand { color: #fff; font-weight: 600; font-size: 1.05rem; }
        nav a:hover { color: #fff; }
        .card { background: #fff; border: 1px solid #e5e7eb; border-radius: 8px; padding: 1.5rem; margin-bottom: 1.5rem; }
        table { width: 100%; border-collapse: collapse; }
        th, td { text-align: left; padding: 0.6rem 0.75rem; border-bottom: 1px solid #e5e7eb; font-size: 0.9rem; }
        th { color: #6b7280; font-weight: 600; font-size: 0.8rem; text-transform: uppercase; }
        .btn { display: inline-block; background: #6d28d9; color: #fff; border: none; padding: 0.5rem 1rem; border-radius: 6px; font-size: 0.85rem; cursor: pointer; text-decoration: none; }
        .btn:hover { background: #5b21b6; color: #fff; }
        .btn.secondary { background: #6b7280; }
        .btn.danger { background: #dc2626; }
        .btn-primary { background-color: #6d28d9 !important; border-color: #6d28d9 !important; }
        .btn-primary:hover, .btn-primary:focus, .btn-primary:active { background-color: #5b21b6 !important; border-color: #5b21b6 !important; }
        .status { font-size: 0.75rem; padding: 0.2rem 0.6rem; border-radius: 999px; font-weight: 700; text-transform: capitalize; display: inline-block; }
        .status.trial, .status.trialing { background: #fef3c7; color: #92400e; }
        .status.active { background: #d1fae5; color: #065f46; }
        .status.suspended, .status.past_due { background: #fee2e2; color: #991b1b; }
        .status.cancelled { background: #e5e7eb; color: #374151; }
        .alert { background: #d1fae5; color: #065f46; padding: 0.75rem 1rem; border-radius: 6px; margin-bottom: 1.5rem; }
        .errors { background: #fee2e2; color: #991b1b; padding: 0.75rem 1rem; border-radius: 6px; margin-bottom: 1.5rem; }
        label { display: block; font-size: 0.85rem; font-weight: 600; margin-bottom: 0.25rem; }
        input, select { width: 100%; padding: 0.5rem; border: 1px solid #d1d5db; border-radius: 6px; margin-bottom: 1rem; font-size: 0.9rem; }
        h1 { font-size: 1.4rem; margin: 0 0 1.25rem; }

        /* ---------- ERP shell (Tenants / Subscriptions / Payments) ---------- */
        .erp-topbar {
            background: linear-gradient(135deg, var(--erp-navy) 0%, var(--erp-navy-deep) 100%);
            padding: 0 24px;
            box-shadow: 0 6px 20px rgba(12, 30, 42, 0.18);
        }

        .erp-topbar__inner {
            max-width: 1360px;
            margin: 0 auto;
            display: flex;
            align-items: center;
            justify-content: space-between;
            height: 62px;
        }

        .erp-brand {
            display: inline-flex;
            align-items: center;
            gap: 9px;
            color: #fff;
            font-weight: 800;
            font-size: 1.05rem;
            text-decoration: none !important;
            letter-spacing: -0.01em;
        }

        .erp-brand__dot {
            width: 9px;
            height: 9px;
            border-radius: 50%;
            background: var(--erp-teal);
            box-shadow: 0 0 0 4px rgba(26, 188, 156, 0.22);
        }

        .erp-nav {
            display: flex;
            align-items: center;
            gap: 4px;
            list-style: none;
            margin: 0;
            padding: 0;
        }

        .erp-nav a {
            display: inline-flex;
            align-items: center;
            gap: 7px;
            color: rgba(255, 255, 255, 0.62);
            text-decoration: none !important;
            font-size: 0.86rem;
            font-weight: 600;
            padding: 9px 14px;
            border-radius: 9px;
            transition: background-color 0.15s ease, color 0.15s ease;
        }

        .erp-nav a:hover {
            color: #fff;
            background: rgba(255, 255, 255, 0.06);
        }

        .erp-nav a.is-active {
            color: #fff;
            background: rgba(26, 188, 156, 0.16);
        }

        .erp-user {
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .erp-user__badge {
            width: 34px;
            height: 34px;
            border-radius: 50%;
            background: rgba(255, 255, 255, 0.1);
            border: 1px solid rgba(255, 255, 255, 0.14);
            color: #fff;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            font-weight: 700;
            font-size: 0.8rem;
        }

        .erp-logout-btn {
            border: 1px solid rgba(255, 255, 255, 0.18);
            background: transparent;
            color: rgba(255, 255, 255, 0.78);
            border-radius: 9px;
            padding: 7px 12px;
            font-size: 0.82rem;
            font-weight: 600;
            display: inline-flex;
            align-items: center;
            gap: 6px;
        }

        .erp-logout-btn:hover {
            color: #fff;
            border-color: rgba(255, 255, 255, 0.32);
        }

        .erp-main {
            max-width: 1360px;
            margin: 0 auto;
            padding: 28px 24px 56px;
        }

        .erp-flash.alert-success {
            background: #e7f8f1;
            border: 1px solid #bfe9d6;
            color: #0e6b4f;
            border-radius: 12px;
        }

        .erp-flash.alert-danger {
            background: #fdecec;
            border: 1px solid #f6c6c6;
            color: #96271f;
            border-radius: 12px;
        }

        .erp-page-header {
            display: flex;
            align-items: flex-start;
            justify-content: space-between;
            gap: 16px;
            flex-wrap: wrap;
            margin-bottom: 22px;
        }

        .erp-page-header__eyebrow {
            color: var(--erp-teal-deep);
            font-size: 12px;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.08em;
            margin-bottom: 6px;
        }

        .erp-page-header h1 {
            font-size: 1.65rem;
            font-weight: 800;
            color: var(--erp-ink);
            margin: 0 0 4px;
            letter-spacing: -0.01em;
        }

        .erp-page-header p {
            color: var(--erp-ink-soft);
            font-size: 0.92rem;
            margin: 0;
        }

        .erp-btn-primary {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            background: #6d28d9;
            color: #fff;
            border: 0;
            border-radius: 10px;
            padding: 10px 18px;
            font-weight: 700;
            font-size: 0.88rem;
            text-decoration: none !important;
            box-shadow: 0 10px 22px rgba(109, 40, 217, 0.22);
        }

        .erp-btn-primary:hover {
            color: #fff;
            filter: brightness(1.04);
        }

        .erp-stat-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 14px;
            margin-bottom: 22px;
        }

        .erp-stat-card {
            background: var(--erp-surface);
            border: 1px solid var(--erp-border);
            border-radius: 16px;
            padding: 16px 18px;
            box-shadow: var(--erp-shadow);
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .erp-stat-card__icon {
            width: 42px;
            height: 42px;
            border-radius: 11px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            font-size: 18px;
            flex-shrink: 0;
        }

        .erp-stat-card__value {
            font-size: 1.35rem;
            font-weight: 800;
            color: var(--erp-ink);
            line-height: 1.1;
        }

        .erp-stat-card__label {
            font-size: 0.76rem;
            color: var(--erp-ink-soft);
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.03em;
            margin-top: 2px;
        }

        .erp-stat-card--teal .erp-stat-card__icon { background: rgba(26, 188, 156, 0.12); color: var(--erp-teal-deep); }
        .erp-stat-card--indigo .erp-stat-card__icon { background: rgba(99, 91, 255, 0.12); color: #5849d6; }
        .erp-stat-card--amber .erp-stat-card__icon { background: rgba(255, 176, 32, 0.16); color: #b1740b; }
        .erp-stat-card--red .erp-stat-card__icon { background: rgba(239, 68, 68, 0.12); color: #c0362d; }
        .erp-stat-card--slate .erp-stat-card__icon { background: rgba(100, 116, 139, 0.12); color: #475569; }

        .erp-panel {
            background: var(--erp-surface);
            border: 1px solid var(--erp-border);
            border-radius: 18px;
            box-shadow: var(--erp-shadow);
            padding: 22px;
        }

        .erp-panel table.dataTable {
            font-size: 0.87rem;
        }

        .erp-panel table.dataTable thead th {
            color: var(--erp-ink-soft);
            font-size: 0.72rem;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.04em;
            border-bottom-width: 1px;
        }

        .erp-panel table.dataTable tbody td {
            vertical-align: middle;
            color: var(--erp-ink);
        }

        .erp-badge {
            display: inline-flex;
            align-items: center;
            gap: 5px;
            font-size: 0.72rem;
            font-weight: 700;
            text-transform: capitalize;
            padding: 4px 10px;
            border-radius: 999px;
        }

        .erp-badge.active, .erp-badge.succeeded, .erp-badge.paid { background: #e0f7ee; color: #0e7a55; }
        .erp-badge.trial, .erp-badge.trialing, .erp-badge.pending { background: #fef3c7; color: #92400e; }
        .erp-badge.provisioning { background: #e0edff; color: #1d4ed8; }
        .erp-badge.suspended, .erp-badge.past_due, .erp-badge.failed, .erp-badge.provisioning_failed, .erp-badge.due { background: #fde2e2; color: #b3261e; }
        .erp-badge.cancelled, .erp-badge.refunded { background: #e5e9ef; color: #475569; }

        .erp-action-btn {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            border: 1px solid var(--erp-border);
            background: #fff;
            color: var(--erp-ink);
            border-radius: 8px;
            padding: 6px 12px;
            font-size: 0.78rem;
            font-weight: 700;
            text-decoration: none !important;
        }

        .erp-action-btn:hover {
            color: var(--erp-ink);
            border-color: #c9d4de;
        }

        .erp-action-btn.is-danger { color: #b3261e; border-color: #f3c9c6; background: #fef4f4; }
        .erp-action-btn.is-teal { color: var(--erp-teal-deep); border-color: rgba(26, 188, 156, 0.3); background: rgba(26, 188, 156, 0.08); }

        .erp-empty {
            text-align: center;
            color: var(--erp-ink-faint);
            padding: 8px 0;
        }

        @media (max-width: 900px) {
            .erp-stat-grid { grid-template-columns: repeat(2, 1fr); }
            .erp-nav { display: none; }
        }
    </style>

    @stack('styles')
</head>
<body>
    @auth('central_admin')
        <div class="erp-topbar">
            <div class="erp-topbar__inner">
                <a href="{{ route('central.tenants.index') }}" class="erp-brand">
                    <span class="erp-brand__dot"></span> Fonico Central
                </a>

                <ul class="erp-nav">
                    <li><a href="{{ route('central.tenants.index') }}" class="{{ request()->routeIs('central.tenants.*') ? 'is-active' : '' }}"><i class="bi bi-buildings"></i> Tenants</a></li>
                    <li><a href="{{ route('central.subscriptions.index') }}" class="{{ request()->routeIs('central.subscriptions.*') ? 'is-active' : '' }}"><i class="bi bi-arrow-repeat"></i> Subscriptions</a></li>
                    <li><a href="{{ route('central.payments.index') }}" class="{{ request()->routeIs('central.payments.*') ? 'is-active' : '' }}"><i class="bi bi-credit-card"></i> Payments</a></li>
                    <li><a href="{{ route('central.plan.edit') }}" class="{{ request()->routeIs('central.plan.*') ? 'is-active' : '' }}"><i class="bi bi-box-seam"></i> Plan</a></li>
                </ul>

                <div class="erp-user">
                    <span class="erp-user__badge">
                        {{ strtoupper(substr(auth('central_admin')->user()->name ?? 'A', 0, 1)) }}
                    </span>
                    <form method="POST" action="{{ route('central.logout') }}">
                        @csrf
                        <button type="submit" class="erp-logout-btn"><i class="bi bi-box-arrow-right"></i> Logout</button>
                    </form>
                </div>
            </div>
        </div>
    @endauth

    <main @auth('central_admin') class="erp-main" @else style="max-width:1080px;margin:2rem auto;padding:0 1.5rem;" @endauth>
        @if (session('status'))
            <div class="alert erp-flash alert-success">{{ session('status') }}</div>
        @endif
        @if ($errors->any())
            <div class="errors erp-flash alert-danger">
                <ul style="margin:0;padding-left:1.1rem;">
                    @foreach ($errors->all() as $error)
                        <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
        @endif
        @yield('content')
    </main>

    <script src="https://cdn.jsdelivr.net/npm/jquery@3.7.1/dist/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/datatables.net@1.13.11/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/datatables.net-bs5@1.13.11/js/dataTables.bootstrap5.min.js"></script>
    @stack('scripts')
</body>
</html>
