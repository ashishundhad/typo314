@extends('central.layout')

@section('title', 'Plan')

@section('content')
    <div class="erp-page-header">
        <div>
            <div class="erp-page-header__eyebrow">Billing</div>
            <h1>Plan</h1>
            <p>The single plan every tenant subscribes to — name, trial length, and billing prices.</p>
        </div>
    </div>

    <div class="erp-panel" style="max-width:640px;">
        <form method="POST" action="{{ route('central.plan.update', $plan) }}">
            @csrf
            @method('PUT')

            <div class="mb-3">
                <label class="form-label fw-semibold" for="name">Name</label>
                <input type="text" class="form-control" id="name" name="name"
                    value="{{ old('name', $plan->name) }}" required>
            </div>

            <div class="mb-3">
                <label class="form-label fw-semibold" for="description">Description</label>
                <textarea class="form-control" id="description" name="description" rows="2">{{ old('description', $plan->description) }}</textarea>
            </div>

            <div class="mb-3">
                <label class="form-label fw-semibold" for="default_trial_days">Default Trial Days</label>
                <input type="number" class="form-control" id="default_trial_days" name="default_trial_days"
                    min="0" value="{{ old('default_trial_days', $plan->default_trial_days) }}" required>
            </div>

            <hr class="my-4">

            <div class="row">
                @foreach ($plan->prices as $price)
                    <div class="col-md-6 mb-3">
                        <input type="hidden" name="prices[{{ $loop->index }}][id]" value="{{ $price->id }}">
                        <label class="form-label fw-semibold" for="price_{{ $price->id }}">
                            {{ ucfirst($price->billing_cycle) }} Price ({{ $price->currency }})
                        </label>
                        <input type="number" step="0.01" min="0" class="form-control"
                            id="price_{{ $price->id }}" name="prices[{{ $loop->index }}][amount]"
                            value="{{ old('prices.'.$loop->index.'.amount', $price->amount) }}" required>
                    </div>
                @endforeach
            </div>

            <div class="d-flex justify-content-end mt-3">
                <button type="submit" class="erp-btn-primary border-0">
                    <i class="bi bi-check2-circle"></i> Save Plan
                </button>
            </div>
        </form>
    </div>
@endsection
