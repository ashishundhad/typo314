@extends('central.layout')

@section('title', 'New Tenant')

@section('content')
    <div class="erp-page-header">
        <div>
            <div class="erp-page-header__eyebrow">Workspace</div>
            <h1>New Tenant</h1>
            <p>Provision a new shop's workspace, database, and first admin user.</p>
        </div>
        <a href="{{ route('central.tenants.index') }}" class="erp-action-btn">
            <i class="bi bi-arrow-left"></i> Back to Tenants
        </a>
    </div>

    <div class="erp-panel" style="max-width:640px;">
        <form method="POST" action="{{ route('central.tenants.store') }}">
            @csrf

            <div class="mb-3">
                <div class="erp-page-header__eyebrow" style="margin-bottom:2px;">Company</div>
            </div>

            <div class="mb-3">
                <label class="form-label fw-semibold" for="name">Company Name</label>
                <input type="text" class="form-control" id="name" name="name"
                    value="{{ old('name') }}" placeholder="e.g. Fonico Mobiles" required>
            </div>

            <div class="mb-3">
                <label class="form-label fw-semibold" for="id">Tenant ID</label>
                <input type="text" class="form-control" id="id" name="id"
                    value="{{ old('id') }}" placeholder="e.g. fonico1">
                <div class="form-text">Optional — generated from the company name if left blank.</div>
            </div>

            <div class="mb-3">
                <label class="form-label fw-semibold" for="domain">Domain</label>
                <input type="text" class="form-control" id="domain" name="domain"
                    value="{{ old('domain') }}" placeholder="e.g. fonico1.fonico.ddev.site" required>
            </div>

            <div class="row">
                <div class="col-md-6 mb-3">
                    <label class="form-label fw-semibold" for="plan_id">Plan</label>
                    <select class="form-select" id="plan_id" name="plan_id" required>
                        @foreach ($plans as $plan)
                            <option value="{{ $plan->id }}" @selected(old('plan_id') == $plan->id)>{{ $plan->name }}</option>
                        @endforeach
                    </select>
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label fw-semibold" for="billing_cycle">Billing Cycle</label>
                    <select class="form-select" id="billing_cycle" name="billing_cycle" required>
                        <option value="monthly" @selected(old('billing_cycle', 'monthly') === 'monthly')>Monthly</option>
                        <option value="yearly" @selected(old('billing_cycle') === 'yearly')>Yearly</option>
                    </select>
                </div>
            </div>

            <hr class="my-4">

            <div class="erp-page-header__eyebrow" style="margin-bottom:14px;">First Admin User</div>

            <div class="mb-3">
                <label class="form-label fw-semibold" for="admin_name">Admin Name</label>
                <input type="text" class="form-control" id="admin_name" name="admin_name"
                    value="{{ old('admin_name') }}" required>
            </div>

            <div class="mb-3">
                <label class="form-label fw-semibold" for="admin_email">Admin Email</label>
                <input type="email" class="form-control" id="admin_email" name="admin_email"
                    value="{{ old('admin_email') }}" required>
            </div>

            <div class="mb-3">
                <label class="form-label fw-semibold" for="admin_password">Admin Password</label>
                <input type="password" class="form-control" id="admin_password" name="admin_password"
                    minlength="8" required>
            </div>

            <div class="d-flex justify-content-end mt-4">
                <button type="submit" class="erp-btn-primary border-0">
                    <i class="bi bi-plus-circle"></i> Create Tenant
                </button>
            </div>
        </form>
    </div>
@endsection
