@extends('central.layout')

@section('title', $tenant->id)

@section('content')
    <div class="card">
        <h1>{{ $tenant->id }}</h1>
        <p><strong>Status:</strong> <span class="status {{ $tenant->status }}">{{ $tenant->status }}</span></p>
        <p><strong>Domain:</strong> {{ $tenant->domains->first()?->domain ?? '—' }}</p>
        <p><strong>Created:</strong> {{ $tenant->created_at->format('Y-m-d H:i') }}</p>
    </div>

    <div class="card">
        <h1>Subscription</h1>
        @if ($tenant->subscription)
            <p><strong>Plan:</strong> {{ $tenant->subscription->plan?->name }} ({{ $tenant->subscription->planPrice?->billing_cycle }})</p>
            <p><strong>Status:</strong> <span class="status {{ $tenant->subscription->status }}">{{ $tenant->subscription->status }}</span></p>
            <p><strong>Trial ends:</strong> {{ optional($tenant->subscription->trial_ends_at)->format('Y-m-d H:i') ?? '—' }}</p>
            <p><strong>Current period ends:</strong> {{ optional($tenant->subscription->current_period_ends_at)->format('Y-m-d H:i') ?? '—' }}</p>
        @else
            <p>No subscription on record.</p>
        @endif
    </div>

    <div class="card">
        <h1>Payments</h1>
        <table>
            <thead><tr><th>Amount</th><th>Status</th><th>Provider</th><th>Paid At</th></tr></thead>
            <tbody>
                @forelse ($tenant->subscription?->payments ?? [] as $payment)
                    <tr>
                        <td>{{ $payment->currency }} {{ $payment->amount }}</td>
                        <td>{{ $payment->status }}</td>
                        <td>{{ $payment->provider ?? '—' }}</td>
                        <td>{{ optional($payment->paid_at)->format('Y-m-d H:i') ?? '—' }}</td>
                    </tr>
                @empty
                    <tr><td colspan="4">No payments yet.</td></tr>
                @endforelse
            </tbody>
        </table>
    </div>

    <a href="{{ route('central.tenants.index') }}" class="btn secondary">Back to tenants</a>
@endsection
