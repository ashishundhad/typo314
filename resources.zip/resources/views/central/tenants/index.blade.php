@extends('central.layout')

@section('title', 'Tenants')

@section('content')
    <div class="erp-page-header">
        <div>
            <div class="erp-page-header__eyebrow">Workspace</div>
            <h1>Tenants</h1>
            <p>Every shop running on Fonico, its domain, plan, and current access status.</p>
        </div>
        <a href="{{ route('central.tenants.create') }}" class="erp-btn-primary">
            <i class="bi bi-plus-circle"></i> New Tenant
        </a>
    </div>

    <div class="erp-stat-grid">
        <div class="erp-stat-card erp-stat-card--slate">
            <span class="erp-stat-card__icon"><i class="bi bi-buildings"></i></span>
            <div>
                <div class="erp-stat-card__value">{{ $stats['total'] }}</div>
                <div class="erp-stat-card__label">Total Tenants</div>
            </div>
        </div>
        <div class="erp-stat-card erp-stat-card--teal">
            <span class="erp-stat-card__icon"><i class="bi bi-check-circle"></i></span>
            <div>
                <div class="erp-stat-card__value">{{ $stats['active'] }}</div>
                <div class="erp-stat-card__label">Active</div>
            </div>
        </div>
        <div class="erp-stat-card erp-stat-card--indigo">
            <span class="erp-stat-card__icon"><i class="bi bi-hourglass-split"></i></span>
            <div>
                <div class="erp-stat-card__value">{{ $stats['provisioning'] }}</div>
                <div class="erp-stat-card__label">Provisioning</div>
            </div>
        </div>
        <div class="erp-stat-card erp-stat-card--red">
            <span class="erp-stat-card__icon"><i class="bi bi-pause-circle"></i></span>
            <div>
                <div class="erp-stat-card__value">{{ $stats['suspended'] }}</div>
                <div class="erp-stat-card__label">Suspended</div>
            </div>
        </div>
    </div>

    <div class="erp-panel">
        <div class="table-responsive">
            <table id="tenantsTable" class="table table-hover align-middle">
                <thead>
                    <tr>
                        <th>Tenant</th>
                        <th>Domain</th>
                        <th>Status</th>
                        <th>Plan</th>
                        <th>Subscription</th>
                        <th>Payment</th>
                        <th class="text-end">Action</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach ($tenants as $tenant)
                        @php
                            $subscription = $tenant->subscription;
                            $paymentStatus = $subscription?->paymentStatus();

                            $trialLabel = null;
                            if ($subscription?->status === 'trialing' && $subscription->trial_ends_at) {
                                $secondsLeft = \Carbon\Carbon::parse($subscription->trial_ends_at)->getTimestamp() - now()->getTimestamp();
                                $daysLeft = (int) ceil($secondsLeft / 86400);
                                $trialLabel = $daysLeft > 0
                                    ? 'Trial, ' . $daysLeft . ' day' . ($daysLeft === 1 ? '' : 's') . ' left'
                                    : 'Trial ended';
                            }
                        @endphp
                        <tr>
                            <td><a href="{{ route('central.tenants.show', $tenant->id) }}">{{ $tenant->id }}</a></td>
                            <td>{{ $tenant->domains->first()?->domain ?? '—' }}</td>
                            <td><span class="erp-badge {{ $tenant->status }}">{{ $tenant->status }}</span></td>
                            <td>{{ $tenant->subscription?->plan?->name ?? '—' }}</td>
                            <td><span class="erp-badge {{ $subscription?->status }}">{{ $trialLabel ?? $subscription?->status ?? '—' }}</span></td>
                            <td>
                                @if ($paymentStatus)
                                    <span class="erp-badge {{ $paymentStatus }}">{{ $paymentStatus }}</span>
                                @else
                                    —
                                @endif
                            </td>
                            <td class="text-end">
                                @if (in_array($tenant->status, ['provisioning', 'provisioning_failed'], true))
                                    <form method="POST" action="{{ route('central.tenants.retry-provisioning', $tenant->id) }}" class="d-inline">
                                        @csrf
                                        <button type="submit" class="erp-action-btn is-teal">Retry Provisioning</button>
                                    </form>
                                @elseif ($tenant->status === 'suspended')
                                    @if ($paymentStatus === 'due')
                                        <button type="button" class="erp-action-btn is-teal" data-bs-toggle="modal" data-bs-target="#recordPayment{{ $tenant->id }}">
                                            Record Payment
                                        </button>
                                    @else
                                        <form method="POST" action="{{ route('central.tenants.reactivate', $tenant->id) }}" class="d-inline">
                                            @csrf
                                            <button type="submit" class="erp-action-btn is-teal">Reactivate</button>
                                        </form>
                                    @endif
                                @else
                                    <form method="POST" action="{{ route('central.tenants.suspend', $tenant->id) }}" class="d-inline">
                                        @csrf
                                        <button type="submit" class="erp-action-btn is-danger">Suspend</button>
                                    </form>
                                @endif
                            </td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>

    @foreach ($tenants as $tenant)
        @if ($tenant->status === 'suspended' && $tenant->subscription?->paymentStatus() === 'due')
            <div class="modal fade" id="recordPayment{{ $tenant->id }}" tabindex="-1" aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <form method="POST" action="{{ route('central.tenants.record-payment', $tenant->id) }}">
                            @csrf
                            <div class="modal-header">
                                <h5 class="modal-title">Record Payment — {{ $tenant->id }}</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <div class="modal-body">
                                <p class="text-muted small">Confirms money already received (bank transfer, cash, etc.) and reactivates this tenant immediately.</p>
                                <div class="row">
                                    <div class="col-8 mb-3">
                                        <label class="form-label" for="amount{{ $tenant->id }}">Amount</label>
                                        <input type="number" step="0.01" min="0" class="form-control" id="amount{{ $tenant->id }}"
                                            name="amount" value="{{ $tenant->subscription?->planPrice?->amount }}" required>
                                    </div>
                                    <div class="col-4 mb-3">
                                        <label class="form-label" for="currency{{ $tenant->id }}">Currency</label>
                                        <input type="text" class="form-control" id="currency{{ $tenant->id }}"
                                            name="currency" maxlength="3" value="{{ $tenant->subscription?->planPrice?->currency ?? 'USD' }}" required>
                                    </div>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label" for="provider{{ $tenant->id }}">Provider (optional)</label>
                                    <input type="text" class="form-control" id="provider{{ $tenant->id }}"
                                        name="provider" placeholder="e.g. Bank Transfer, Cash, UPI">
                                </div>
                                <div class="mb-3">
                                    <label class="form-label" for="reference{{ $tenant->id }}">Reference (optional)</label>
                                    <input type="text" class="form-control" id="reference{{ $tenant->id }}"
                                        name="provider_reference" placeholder="e.g. transaction / receipt no.">
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                                <button type="submit" class="btn btn-primary">Record &amp; Reactivate</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        @endif
    @endforeach
@endsection

@push('scripts')
    <script>
        $(function () {
            $('#tenantsTable').DataTable({
                order: [],
                columnDefs: [{ orderable: false, targets: -1 }],
                language: { emptyTable: 'No tenants yet.' }
            });
        });
    </script>
@endpush
