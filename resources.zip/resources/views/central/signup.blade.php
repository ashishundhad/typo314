<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Start your free trial — Invoxa</title>
<meta name="robots" content="noindex">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,300..900&family=IBM+Plex+Sans:ital,wght@0,400;0,500;0,600;0,700;1,400&display=swap" rel="stylesheet">

<style>
    :root {
        --ink: #211f1b;
        --ink-soft: rgba(33, 31, 27, 0.64);
        --ink-faint: rgba(33, 31, 27, 0.4);
        --paper: #eef0e8;
        --paper-deep: #dfe2d3;
        --paper-card: #f6f7f1;
        --rule: rgba(33, 31, 27, 0.16);
        --stamp: #a23a2e;
        --stamp-soft: rgba(162, 58, 46, 0.12);
        --shadow: 0 18px 40px rgba(33, 31, 27, 0.14);
    }

    * { box-sizing: border-box; }

    body {
        margin: 0;
        min-height: 100vh;
        background: var(--paper);
        color: var(--ink);
        font-family: "IBM Plex Sans", sans-serif;
        padding: 40px 20px;
    }

    .wrap {
        max-width: 880px;
        margin: 0 auto;
    }

    .back-link {
        display: inline-flex;
        align-items: center;
        gap: 6px;
        color: var(--ink-soft);
        text-decoration: none;
        font-size: 0.9rem;
        font-weight: 600;
        margin-bottom: 28px;
    }

    .back-link:hover { color: var(--ink); }

    .signup-header {
        text-align: center;
        margin-bottom: 32px;
    }

    .signup-header h1 {
        font-family: "Fraunces", serif;
        font-weight: 600;
        font-size: clamp(1.8rem, 4vw, 2.6rem);
        margin: 0 0 10px;
    }

    .signup-header p {
        color: var(--ink-soft);
        margin: 0;
        font-size: 1rem;
    }

    .signup-card {
        background: var(--paper-card);
        border: 1px solid var(--rule);
        border-radius: 6px;
        box-shadow: var(--shadow);
        padding: 40px;
    }

    @media (max-width: 600px) {
        .signup-card { padding: 26px; }
    }

    .form-section-label {
        font-size: 0.78rem;
        font-weight: 700;
        letter-spacing: 0.08em;
        text-transform: uppercase;
        color: var(--stamp);
        margin: 0 0 16px;
    }

    .form-section + .form-section {
        margin-top: 30px;
        padding-top: 30px;
        border-top: 1px solid var(--rule);
    }

    .form-row {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 18px;
    }

    @media (max-width: 600px) {
        .form-row { grid-template-columns: 1fr; }
    }

    .form-group {
        margin-bottom: 18px;
    }

    .form-group label {
        display: block;
        font-size: 0.85rem;
        font-weight: 600;
        margin-bottom: 7px;
        color: var(--ink);
    }

    .form-group input {
        width: 100%;
        height: 46px;
        padding: 0 14px;
        border-radius: 4px;
        border: 1px solid var(--rule);
        background: #fff;
        color: var(--ink);
        font-size: 0.95rem;
        font-family: inherit;
    }

    .form-group input:focus {
        outline: none;
        border-color: var(--stamp);
        box-shadow: 0 0 0 3px var(--stamp-soft);
    }

    .field-error {
        color: var(--stamp);
        font-size: 0.8rem;
        margin-top: 6px;
    }

    .plan-options {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 14px;
    }

    @media (max-width: 600px) {
        .plan-options { grid-template-columns: 1fr; }
    }

    .plan-option {
        position: relative;
        border: 1.5px solid var(--rule);
        border-radius: 6px;
        padding: 16px 18px;
        cursor: pointer;
        background: #fff;
        transition: border-color 0.15s ease, background 0.15s ease;
    }

    .plan-option:has(input:checked) {
        border-color: var(--stamp);
        background: var(--stamp-soft);
    }

    .plan-option input {
        position: absolute;
        top: 16px;
        right: 16px;
    }

    .plan-option__cycle {
        font-weight: 700;
        text-transform: capitalize;
        margin-bottom: 4px;
    }

    .plan-option__price {
        font-size: 1.3rem;
        font-weight: 700;
    }

    .plan-option__price span {
        font-size: 0.8rem;
        font-weight: 500;
        color: var(--ink-soft);
    }

    .plan-option__note {
        font-size: 0.78rem;
        color: var(--ink-soft);
        margin-top: 4px;
    }

    .trial-note {
        text-align: center;
        font-size: 0.85rem;
        color: var(--ink-soft);
        margin: 18px 0 0;
    }

    .submit-btn {
        display: block;
        width: 100%;
        margin-top: 26px;
        height: 52px;
        border: 0;
        border-radius: 4px;
        background: var(--stamp);
        color: #fdf7f1;
        font-size: 1rem;
        font-weight: 700;
        font-family: inherit;
        cursor: pointer;
        transition: transform 0.15s ease, box-shadow 0.15s ease;
    }

    .submit-btn:hover {
        transform: translateY(-2px);
        box-shadow: var(--shadow);
    }

    .alert-errors {
        background: var(--stamp-soft);
        border: 1px solid var(--stamp);
        color: var(--stamp);
        border-radius: 6px;
        padding: 14px 16px;
        margin-bottom: 24px;
        font-size: 0.88rem;
    }

    .alert-errors ul {
        margin: 6px 0 0;
        padding-left: 18px;
    }

    .success-icon {
        width: 56px;
        height: 56px;
        border-radius: 50%;
        background: var(--stamp-soft);
        color: var(--stamp);
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 1.6rem;
        margin: 0 auto 18px;
    }

    .success-card {
        text-align: center;
    }

    .success-card h2 {
        font-family: "Fraunces", serif;
        font-size: 1.6rem;
        margin: 0 0 12px;
    }

    .success-card p {
        color: var(--ink-soft);
        margin: 0 0 6px;
    }

    .success-card .shop-url {
        display: inline-block;
        margin: 18px 0;
        padding: 12px 20px;
        background: var(--paper-deep);
        border-radius: 4px;
        font-family: "IBM Plex Mono", monospace;
        font-size: 0.9rem;
        word-break: break-all;
    }

    .success-card .btn-primary {
        display: inline-block;
        margin-top: 10px;
        padding: 14px 28px;
        background: var(--stamp);
        color: #fdf7f1;
        text-decoration: none;
        border-radius: 4px;
        font-weight: 700;
    }
</style>
</head>

<body>
<div class="wrap">
    <a href="/" class="back-link">← Back to Invoxa</a>

    @if($success)
        <div class="signup-card success-card">
            <div class="success-icon">✓</div>
            <h2>Your shop is being set up</h2>
            <p>"{{ $success['shop_name'] }}" is provisioning now — this usually takes under a minute.</p>
            <div class="shop-url">{{ $success['url'] }}</div>
            <p>Sign in there with <strong>{{ $success['admin_email'] }}</strong> and the password you just chose.</p>
            @if($success['trial_ends_at'])
                <p>Your free trial runs until <strong>{{ \Carbon\Carbon::parse($success['trial_ends_at'])->format('d M Y') }}</strong>.</p>
            @endif
            <a href="{{ $success['url'] }}" class="btn-primary">Go to your shop →</a>
        </div>
    @else
        <div class="signup-header">
            <h1>Start your free trial</h1>
            <p>Pick a plan, set up your counter, and start selling — full access, no card required.</p>
        </div>

        <div class="signup-card">
            @if ($errors->any())
                <div class="alert-errors">
                    <strong>Please fix the following:</strong>
                    <ul>
                        @foreach ($errors->all() as $error)
                            <li>{{ $error }}</li>
                        @endforeach
                    </ul>
                </div>
            @endif

            <form method="POST" action="{{ route('central.signup.store') }}">
                @csrf

                <div class="form-section">
                    <p class="form-section-label">Your Shop</p>
                    <div class="form-group">
                        <label for="shop_name">Shop Name</label>
                        <input type="text" id="shop_name" name="shop_name" value="{{ old('shop_name') }}" placeholder="e.g. Ravi Mobiles" required autofocus>
                    </div>
                </div>

                <div class="form-section">
                    <p class="form-section-label">Your Account</p>
                    <div class="form-row">
                        <div class="form-group">
                            <label for="admin_name">Your Name</label>
                            <input type="text" id="admin_name" name="admin_name" value="{{ old('admin_name') }}" required>
                        </div>
                        <div class="form-group">
                            <label for="admin_email">Email</label>
                            <input type="email" id="admin_email" name="admin_email" value="{{ old('admin_email') }}" required>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group">
                            <label for="admin_password">Password</label>
                            <input type="password" id="admin_password" name="admin_password" minlength="8" required>
                        </div>
                        <div class="form-group">
                            <label for="admin_password_confirmation">Confirm Password</label>
                            <input type="password" id="admin_password_confirmation" name="admin_password_confirmation" minlength="8" required>
                        </div>
                    </div>
                </div>

                <div class="form-section">
                    <p class="form-section-label">Choose Your Plan</p>
                    <input type="hidden" name="plan_id" value="{{ $plans->first()?->id }}">
                    <div class="plan-options">
                        @foreach ($plans->first()?->prices ?? [] as $price)
                            <label class="plan-option">
                                <input type="radio" name="billing_cycle" value="{{ $price->billing_cycle }}" @checked($loop->first || old('billing_cycle') === $price->billing_cycle) required>
                                <div class="plan-option__cycle">{{ $price->billing_cycle }}</div>
                                <div class="plan-option__price">{{ $price->currency }} {{ number_format((float) $price->amount, 0) }} <span>/ {{ $price->billing_cycle === 'yearly' ? 'year' : 'month' }}</span></div>
                                @if($price->billing_cycle === 'yearly')
                                    <div class="plan-option__note">Two months free against the monthly rate</div>
                                @endif
                            </label>
                        @endforeach
                    </div>
                    <p class="trial-note">Every new account starts on a free trial — you won't be charged today.</p>
                </div>

                <button type="submit" class="submit-btn">Start my free trial →</button>
            </form>
        </div>
    @endif
</div>
</body>
</html>
