@extends('central.layout')

@section('title', 'Subscriptions')

@section('content')
    <div class="erp-page-header">
        <div>
            <div class="erp-page-header__eyebrow">Billing</div>
            <h1>Subscriptions</h1>
            <p>Every tenant's plan, billing cycle, and access status in one place.</p>
        </div>
    </div>

    <div class="erp-stat-grid">
        <div class="erp-stat-card erp-stat-card--teal">
            <span class="erp-stat-card__icon"><i class="bi bi-check-circle"></i></span>
            <div>
                <div class="erp-stat-card__value">{{ $stats['active'] }}</div>
                <div class="erp-stat-card__label">Active</div>
            </div>
        </div>
        <div class="erp-stat-card erp-stat-card--amber">
            <span class="erp-stat-card__icon"><i class="bi bi-hourglass-split"></i></span>
            <div>
                <div class="erp-stat-card__value">{{ $stats['trialing'] }}</div>
                <div class="erp-stat-card__label">Trialing</div>
            </div>
        </div>
        <div class="erp-stat-card erp-stat-card--red">
            <span class="erp-stat-card__icon"><i class="bi bi-exclamation-triangle"></i></span>
            <div>
                <div class="erp-stat-card__value">{{ $stats['past_due'] }}</div>
                <div class="erp-stat-card__label">Past Due</div>
            </div>
        </div>
        <div class="erp-stat-card erp-stat-card--slate">
            <span class="erp-stat-card__icon"><i class="bi bi-pause-circle"></i></span>
            <div>
                <div class="erp-stat-card__value">{{ $stats['suspended'] }}</div>
                <div class="erp-stat-card__label">Suspended / Cancelled</div>
            </div>
        </div>
    </div>

    <div class="erp-panel">
        <div class="table-responsive">
            <table id="subscriptionsTable" class="table table-hover align-middle">
                <thead>
                    <tr>
                        <th>Tenant</th>
                        <th>Domain</th>
                        <th>Plan</th>
                        <th>Status</th>
                        <th>Trial Ends</th>
                        <th>Period Ends</th>
                        <th class="text-end">Action</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach ($subscriptions as $subscription)
                        <tr>
                            <td>
                                @if ($subscription->tenant)
                                    <a href="{{ route('central.tenants.show', $subscription->tenant->id) }}">
                                        {{ $subscription->tenant->id }}
                                    </a>
                                @else
                                    —
                                @endif
                            </td>
                            <td>{{ $subscription->tenant?->domains->first()?->domain ?? '—' }}</td>
                            <td>{{ $subscription->plan?->name ?? '—' }} ({{ $subscription->planPrice?->billing_cycle ?? '—' }})</td>
                            <td><span class="erp-badge {{ $subscription->status }}">{{ $subscription->status }}</span></td>
                            <td>{{ optional($subscription->trial_ends_at)->format('Y-m-d H:i') ?? '—' }}</td>
                            <td>{{ optional($subscription->current_period_ends_at)->format('Y-m-d H:i') ?? '—' }}</td>
                            <td class="text-end">
                                <button type="button" class="erp-action-btn is-teal" data-bs-toggle="modal" data-bs-target="#editSubscription{{ $subscription->id }}">
                                    Edit
                                </button>
                            </td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>

    @foreach ($subscriptions as $subscription)
        <div class="modal fade" id="editSubscription{{ $subscription->id }}" tabindex="-1" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <form method="POST" action="{{ route('central.subscriptions.update', $subscription) }}">
                        @csrf
                        @method('PUT')
                        <div class="modal-header">
                            <h5 class="modal-title">Edit Subscription — {{ $subscription->tenant?->id }}</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <div class="mb-3">
                                <label class="form-label" for="status{{ $subscription->id }}">Status</label>
                                <select class="form-select" id="status{{ $subscription->id }}" name="status" required>
                                    @foreach (['trialing', 'active', 'past_due', 'suspended', 'cancelled'] as $statusOption)
                                        <option value="{{ $statusOption }}" @selected($subscription->status === $statusOption)>
                                            {{ ucfirst(str_replace('_', ' ', $statusOption)) }}
                                        </option>
                                    @endforeach
                                </select>
                            </div>
                            <div class="mb-3">
                                <label class="form-label" for="period{{ $subscription->id }}">Current Period Ends</label>
                                <input type="date" class="form-control" id="period{{ $subscription->id }}"
                                    name="current_period_ends_at"
                                    value="{{ optional($subscription->current_period_ends_at)->format('Y-m-d') }}">
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                            <button type="submit" class="btn btn-primary">Save</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    @endforeach
@endsection

@push('scripts')
    <script>
        $(function () {
            $('#subscriptionsTable').DataTable({
                order: [],
                columnDefs: [{ orderable: false, targets: -1 }],
                language: { emptyTable: 'No subscriptions yet.' }
            });
        });
    </script>
@endpush
