<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <title>Log In · Fonico Central</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">

    <style>
        :root {
            --invoxa-purple: #6d28d9;
            --invoxa-purple-deep: #5b21b6;
            --invoxa-ink: #1c1f2b;
            --invoxa-copy: #6b7280;
            --invoxa-field-bg: #eef2ff;
            --invoxa-field-border: #e0e5fb;
        }

        * {
            box-sizing: border-box;
        }

        html, body {
            height: 100%;
        }

        body {
            min-height: 100vh;
            margin: 0;
            font-family: "Plus Jakarta Sans", sans-serif;
            color: var(--invoxa-ink);
        }

        .login-shell {
            position: relative;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 24px;
            background: #0b0f14 url('{{ asset('assets/images/bg-auth.jpg') }}') center center / cover no-repeat;
        }

        .login-shell::before {
            content: "";
            position: absolute;
            inset: 0;
            background: rgba(8, 10, 16, 0.55);
        }

        .login-card {
            position: relative;
            z-index: 1;
            width: 100%;
            max-width: 416px;
            background: rgba(247, 247, 249, 0.98);
            border-radius: 22px;
            padding: 40px 36px 32px;
            box-shadow: 0 40px 90px rgba(0, 0, 0, 0.35);
            text-align: center;
        }

        .login-logo {
            display: inline-flex;
            align-items: flex-end;
            gap: 3px;
            margin-bottom: 14px;
        }

        .login-logo span {
            display: block;
            width: 6px;
            border-radius: 2px;
            background: var(--invoxa-ink);
        }

        .login-logo span:nth-child(1) { height: 12px; }
        .login-logo span:nth-child(2) { height: 20px; }
        .login-logo span:nth-child(3) { height: 28px; }

        .login-brandname {
            margin: 0 0 10px;
            font-size: 1.7rem;
            font-weight: 800;
            color: var(--invoxa-purple);
            letter-spacing: -0.02em;
        }

        .login-tagline {
            margin: 0 0 26px;
            color: var(--invoxa-copy);
            font-size: 13.5px;
            line-height: 1.6;
        }

        .login-heading {
            margin: 0 0 6px;
            font-size: 1.5rem;
            font-weight: 800;
            color: var(--invoxa-ink);
            letter-spacing: -0.02em;
        }

        .login-subheading {
            margin: 0 0 26px;
            color: var(--invoxa-copy);
            font-size: 14px;
        }

        .alert {
            border-radius: 14px;
            padding: 12px 14px;
            border: 0;
            margin-bottom: 18px;
            text-align: left;
        }

        .alert ul {
            padding-left: 18px;
            margin-bottom: 0;
        }

        .login-form {
            text-align: left;
        }

        .form-group {
            margin-bottom: 16px;
        }

        .form-label {
            display: block;
            margin-bottom: 7px;
            font-size: 13px;
            font-weight: 700;
            color: var(--invoxa-ink);
        }

        .field-shell {
            position: relative;
        }

        .form-control {
            width: 100%;
            height: 50px;
            border-radius: 12px;
            border: 1px solid var(--invoxa-field-border);
            background: var(--invoxa-field-bg);
            color: var(--invoxa-ink);
            padding: 0 16px;
            font-size: 14.5px;
            transition: border-color 0.2s ease, box-shadow 0.2s ease;
        }

        .field-shell .form-control {
            padding-right: 44px;
        }

        .form-control:focus {
            outline: none;
            border-color: var(--invoxa-purple);
            box-shadow: 0 0 0 3px rgba(109, 40, 217, 0.14);
        }

        .password-toggle {
            position: absolute;
            top: 50%;
            right: 12px;
            transform: translateY(-50%);
            border: 0;
            background: transparent;
            color: #8b93a7;
            padding: 6px;
            line-height: 1;
            cursor: pointer;
        }

        .password-toggle:focus {
            outline: none;
            color: var(--invoxa-purple);
        }

        .signin-btn {
            width: 100%;
            height: 52px;
            border: 0;
            border-radius: 12px;
            background: var(--invoxa-purple);
            color: #fff;
            font-size: 15px;
            font-weight: 700;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            margin-top: 6px;
            box-shadow: 0 14px 28px rgba(109, 40, 217, 0.28);
            transition: transform 0.2s ease, box-shadow 0.2s ease, background 0.2s ease;
        }

        .signin-btn:hover,
        .signin-btn:focus {
            color: #fff;
            background: var(--invoxa-purple-deep);
            transform: translateY(-1px);
        }

        .parsley-errors-list {
            list-style: none;
            padding-left: 0;
            margin: 6px 0 0;
        }

        .parsley-required {
            color: #d64b5c;
            font-size: 12.5px;
            font-weight: 600;
        }

        .page-footer {
            position: relative;
            z-index: 1;
            margin-top: 18px;
            text-align: center;
            color: rgba(255, 255, 255, 0.65);
            font-size: 12.5px;
        }

        @media (max-width: 575.98px) {
            .login-card {
                padding: 32px 22px 26px;
            }
        }
    </style>
</head>

<body>
    <main class="login-shell">
        <div class="w-100" style="max-width: 416px;">
            <div class="login-card">
                <div class="login-logo"><span></span><span></span><span></span></div>
                <h1 class="login-brandname">Invoxa</h1>
                <p class="login-tagline">Simple GST Billing, Inventory &amp; POS for Retail, Restaurant &amp; Salon</p>

                <h2 class="login-heading">Welcome Back</h2>
                <p class="login-subheading">Sign in to the central admin console</p>

                @if ($errors->any())
                    <div class="alert alert-danger">
                        <ul>
                            @foreach ($errors->all() as $error)
                                <li>{{ $error }}</li>
                            @endforeach
                        </ul>
                    </div>
                @endif

                <form class="login-form" method="POST" action="{{ route('central.login.store') }}">
                    @csrf
                    <input type="hidden" name="remember" value="1">

                    <div class="form-group">
                        <label class="form-label" for="email">Email</label>
                        <div class="field-shell">
                            <input
                                class="form-control"
                                type="email"
                                id="email"
                                name="email"
                                value="{{ old('email') }}"
                                placeholder="you@fonico.com"
                                required
                                autofocus
                                autocomplete="username">
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="form-label" for="password">Password</label>
                        <div class="field-shell">
                            <input
                                type="password"
                                id="password"
                                name="password"
                                required
                                autocomplete="current-password"
                                class="form-control"
                                placeholder="Enter your password">
                            <button type="button" class="password-toggle" id="passwordToggle" aria-label="Show password">
                                <i class="bi bi-eye"></i>
                            </button>
                        </div>
                    </div>

                    <button class="signin-btn" type="submit">
                        <i class="bi bi-box-arrow-in-right"></i> Login to Dashboard
                    </button>
                </form>
            </div>

            <div class="page-footer">
                <script>document.write(new Date().getFullYear())</script> &copy; Fonico Central.
            </div>
        </div>
    </main>

    <script>
        const passwordInput = document.getElementById('password');
        const passwordToggle = document.getElementById('passwordToggle');

        if (passwordInput && passwordToggle) {
            passwordToggle.addEventListener('click', function () {
                const nextType = passwordInput.type === 'password' ? 'text' : 'password';
                passwordInput.type = nextType;
                this.setAttribute('aria-label', nextType === 'password' ? 'Show password' : 'Hide password');
                this.innerHTML = nextType === 'password' ? '<i class="bi bi-eye"></i>' : '<i class="bi bi-eye-slash"></i>';
            });
        }
    </script>
</body>
</html>
