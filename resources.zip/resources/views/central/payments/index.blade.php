@extends('central.layout')

@section('title', 'Payments')

@section('content')
    <div class="erp-page-header">
        <div>
            <div class="erp-page-header__eyebrow">Billing</div>
            <h1>Payments</h1>
            <p>Every payment recorded against a tenant's subscription.</p>
        </div>
    </div>

    <div class="erp-stat-grid">
        <div class="erp-stat-card erp-stat-card--teal">
            <span class="erp-stat-card__icon"><i class="bi bi-cash-stack"></i></span>
            <div>
                <div class="erp-stat-card__value">{{ number_format($stats['total_succeeded'], 2) }}</div>
                <div class="erp-stat-card__label">Collected</div>
            </div>
        </div>
        <div class="erp-stat-card erp-stat-card--indigo">
            <span class="erp-stat-card__icon"><i class="bi bi-check2-circle"></i></span>
            <div>
                <div class="erp-stat-card__value">{{ $stats['succeeded_count'] }}</div>
                <div class="erp-stat-card__label">Succeeded</div>
            </div>
        </div>
        <div class="erp-stat-card erp-stat-card--amber">
            <span class="erp-stat-card__icon"><i class="bi bi-hourglass-split"></i></span>
            <div>
                <div class="erp-stat-card__value">{{ $stats['pending'] }}</div>
                <div class="erp-stat-card__label">Pending</div>
            </div>
        </div>
        <div class="erp-stat-card erp-stat-card--red">
            <span class="erp-stat-card__icon"><i class="bi bi-x-circle"></i></span>
            <div>
                <div class="erp-stat-card__value">{{ $stats['failed'] }}</div>
                <div class="erp-stat-card__label">Failed</div>
            </div>
        </div>
    </div>

    <div class="erp-panel">
        <div class="table-responsive">
            <table id="paymentsTable" class="table table-hover align-middle">
                <thead>
                    <tr>
                        <th>Tenant</th>
                        <th>Amount</th>
                        <th>Status</th>
                        <th>Provider</th>
                        <th>Paid At</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach ($payments as $payment)
                        <tr>
                            <td>
                                @if ($payment->subscription?->tenant)
                                    <a href="{{ route('central.tenants.show', $payment->subscription->tenant->id) }}">
                                        {{ $payment->subscription->tenant->id }}
                                    </a>
                                @else
                                    —
                                @endif
                            </td>
                            <td>{{ $payment->currency }} {{ number_format($payment->amount, 2) }}</td>
                            <td><span class="erp-badge {{ $payment->status }}">{{ $payment->status }}</span></td>
                            <td>{{ $payment->provider ?? '—' }}</td>
                            <td>{{ optional($payment->paid_at)->format('Y-m-d H:i') ?? '—' }}</td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>
@endsection

@push('scripts')
    <script>
        $(function () {
            $('#paymentsTable').DataTable({
                order: [[4, 'desc']],
                language: { emptyTable: 'No payments yet.' }
            });
        });
    </script>
@endpush
