@extends('layout.app')

@section('title', 'AI Assistant')

@section('content')
    <div class="container-fluid">
        <div class="row justify-content-center">
            <div class="col-12">
                <div class="page-title-box">
                    <h4 class="page-title">AI Assistant</h4>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-xl-4">
                <div class="card border-0 shadow-sm h-100">
                    <div class="card-body">
                        <div class="d-flex align-items-start justify-content-between mb-3">
                            <div>
                                <h4 class="mb-1">Read-only chatbot</h4>
                                <p class="text-muted mb-0">Answers only from your live app data for the logged-in backend user.</p>
                            </div>
                            <span class="badge badge-soft-primary px-3 py-2">MVP</span>
                        </div>

                        <div class="alert alert-info mb-4">
                            It can currently answer sales summaries, stock summaries, purchase summaries, and invoice lookups.
                        </div>

                        <h5 class="mb-3">Try questions like</h5>
                        <div class="ai-suggestions">
                            <button type="button" class="btn btn-light btn-block text-left ai-suggestion">What are today's sales?</button>
                            <button type="button" class="btn btn-light btn-block text-left ai-suggestion">How much unsold stock do we have?</button>
                            <button type="button" class="btn btn-light btn-block text-left ai-suggestion">Show invoice details for invoice number INV-1001</button>
                            <button type="button" class="btn btn-light btn-block text-left ai-suggestion">What were purchases from 2026-04-01 to 2026-04-10?</button>
                        </div>

                        <hr>

                        <p class="text-muted mb-0 small">
                            Answers are limited by the logged-in user's store scope and permissions already enforced in the app.
                        </p>
                    </div>
                </div>
            </div>

            <div class="col-xl-8 mt-3 mt-xl-0">
                <div class="card border-0 shadow-sm">
                    <div class="card-body p-0">
                        <div class="ai-chat-header px-4 py-3 border-bottom">
                            <div>
                                <h4 class="mb-1">Chat</h4>
                                <p class="text-muted mb-0">Session: <span class="font-weight-medium">{{ $sessionId }}</span></p>
                            </div>
                        </div>

                        <div class="ai-chat-messages p-4" id="ai-chat-messages">
                            @forelse($messages as $message)
                                <div class="ai-message ai-message--{{ $message->role }}">
                                    <div class="ai-message__label">{{ $message->role === 'assistant' ? 'Assistant' : 'You' }}</div>
                                    <div class="ai-message__bubble">{{ $message->content }}</div>
                                </div>
                            @empty
                                <div class="text-muted" id="ai-chat-empty">
                                    Ask a business question to start. This assistant only uses live application data.
                                </div>
                            @endforelse
                        </div>

                        <div class="border-top p-4">
                            <form id="ai-chat-form">
                                @csrf
                                <input type="hidden" name="session_id" id="session_id" value="{{ $sessionId }}">
                                <div class="form-group mb-3">
                                    <label for="question" class="font-weight-semibold">Your question</label>
                                    <textarea class="form-control" id="question" name="question" rows="4" maxlength="5000" placeholder="Example: What are today's sales?"></textarea>
                                </div>
                                <div class="d-flex flex-column flex-md-row align-items-md-center justify-content-between">
                                    <small class="text-muted mb-3 mb-md-0">Read-only. No records are created or changed.</small>
                                    <button type="submit" class="btn btn-primary px-4" id="ai-submit-btn">Ask assistant</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection

@section('scripts')
    <script>
        (function () {
            const form = document.getElementById('ai-chat-form');
            const questionInput = document.getElementById('question');
            const sessionInput = document.getElementById('session_id');
            const submitButton = document.getElementById('ai-submit-btn');
            const chatMessages = document.getElementById('ai-chat-messages');
            const emptyState = document.getElementById('ai-chat-empty');

            function appendMessage(role, content) {
                if (emptyState) {
                    emptyState.remove();
                }

                const wrapper = document.createElement('div');
                wrapper.className = 'ai-message ai-message--' + role;

                const label = document.createElement('div');
                label.className = 'ai-message__label';
                label.textContent = role === 'assistant' ? 'Assistant' : 'You';

                const bubble = document.createElement('div');
                bubble.className = 'ai-message__bubble';
                bubble.textContent = content;

                wrapper.appendChild(label);
                wrapper.appendChild(bubble);
                chatMessages.appendChild(wrapper);
                chatMessages.scrollTop = chatMessages.scrollHeight;
            }

            async function sendQuestion(question) {
                appendMessage('user', question);

                submitButton.disabled = true;
                submitButton.textContent = 'Thinking...';

                try {
                    const response = await fetch(@json(route('ai.store')), {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                            'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content'),
                            'Accept': 'application/json'
                        },
                        body: JSON.stringify({
                            session_id: sessionInput.value,
                            question: question
                        })
                    });

                    const payload = await response.json();

                    if (!response.ok) {
                        throw new Error(payload.message || 'The assistant could not answer right now.');
                    }

                    sessionInput.value = payload.session_id;
                    appendMessage(payload.message.role, payload.message.content);
                    questionInput.value = '';
                } catch (error) {
                    appendMessage('assistant', error.message);
                } finally {
                    submitButton.disabled = false;
                    submitButton.textContent = 'Ask assistant';
                }
            }

            form.addEventListener('submit', function (event) {
                event.preventDefault();

                const question = questionInput.value.trim();

                if (question === '') {
                    return;
                }

                sendQuestion(question);
            });

            document.querySelectorAll('.ai-suggestion').forEach(function (button) {
                button.addEventListener('click', function () {
                    questionInput.value = this.textContent.trim();
                    questionInput.focus();
                });
            });
        })();
    </script>
@endsection
