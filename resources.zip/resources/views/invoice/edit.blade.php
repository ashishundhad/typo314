@extends('layout.app')

@section('title')
    Edit Invoice
@endsection

@section('css')
    <link rel="stylesheet" href="https://code.jquery.com/ui/1.13.2/themes/ui-lightness/jquery-ui.css">
@endsection

@section('content')

    <div class="container-fluid">
        <!-- start page title -->
        <div class="row">
            <div class="col-6">
                <div class="page-title-box">
                    <h4 class="page-title font-weight-bold"> EDIT INVOICE : #{{ $invoice->invoice_no }}</h4>
                </div>
            </div>
            <div class="col-6 d-flex justify-content-end align-items-center">
                <a href="{{ route('allinvoices') }}" class="btn btn-sm btn-success"><i class="mdi mdi-keyboard-backspace"></i> Back</a>
            </div>
        </div>
        <!-- end page title -->

        <div class="row">
            <div class="col-12">
                <div class="card shadow-sm border-0">
                    <div class="card-body">
                        @include('include.alert')

                        <h4 class="text-uppercase fw-semibold mb-3 border-bottom pb-2 text-primary">
                            <i class="mdi mdi-file-document-edit-outline me-1"></i> Edit Invoice
                        </h4>

                        <form action="{{ route('invoice-update', $invoice->id) }}" method="POST" enctype="multipart/form-data"
                            class="@if(count($errors)) was-validated @endif">
                            @csrf
                            <input type="hidden" name="invoice_no" value="{{ $invoice->invoice_no }}" />

                            <!-- Customer Info -->
                            <div class="row g-3">
                                <div class="col-md-4">
                                    <label class="form-label fw-semibold">Customer Name <span
                                            class="text-danger">*</span></label>
                                    <input type="text" required placeholder="Customer Name" name="customer_name"
                                        class="form-control form-control-sm @error('customer_name') parsley-error @enderror"
                                        id="customer_name" value="{{ $invoice->customer_name }}">
                                    @error('customer_name')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>

                                <div class="col-md-3">
                                    <label class="form-label fw-semibold">Contact No <span
                                            class="text-danger">*</span></label>
                                    <input type="text" name="customer_no" class="form-control form-control-sm"
                                        id="customer_no" maxlength="10" placeholder="Customer mobile"
                                        value="{{ $invoice->customer_no }}">
                                </div>

                                <div class="col-md-3">
                                    <label class="form-label fw-semibold">Invoice Date</label>
                                    <input type="text" name="invoice_date" class="form-control form-control-sm"
                                        id="invoicedate" placeholder="dd/mm/yyyy"
                                        value="{{ date('d/m/Y', strtotime($invoice->invoice_date)) }}">
                                </div>

                                <div class="col-md-2" id="paymentModeWrap" style="{{ $invoice->payments->count() > 1 ? 'display:none;' : '' }}">
                                    <label class="form-label fw-semibold">Payment Mode <span
                                            class="text-danger">*</span></label>
                                    <select name="payment_type"
                                        class="form-control form-control-sm @error('payment_type') parsley-error @enderror"
                                        id="payment_type" {{ $invoice->payments->count() > 1 ? '' : 'required' }}>
                                        <option value="">Select</option>
                                        <option value="Cash" @selected($invoice->payment_type == 'Cash')>Cash</option>
                                        <option value="Online" @selected($invoice->payment_type == 'Online')>Online/UPI
                                        </option>
                                        <option value="Credit Card" @selected($invoice->payment_type == 'Credit Card')>Credit
                                            Card</option>
                                    </select>
                                </div>

                                <div class="col-md-12 mt-2">
                                    <div class="custom-control custom-checkbox">
                                        <input type="checkbox" class="custom-control-input" id="splitPaymentToggle" {{ $invoice->payments->count() > 1 ? 'checked' : '' }}>
                                        <label class="custom-control-label" for="splitPaymentToggle">Split payment across multiple methods</label>
                                    </div>
                                </div>

                                <div class="col-md-12 mt-2" id="splitPaymentSection" style="{{ $invoice->payments->count() > 1 ? '' : 'display:none;' }}">
                                    <input type="hidden" name="split_payment" id="splitPaymentFlag" value="{{ $invoice->payments->count() > 1 ? '1' : '0' }}">
                                    <div id="splitPaymentRows">
                                        @if($invoice->payments->count() > 1)
                                            @foreach($invoice->payments as $index => $payment)
                                                <div class="row g-2 align-items-end split-payment-row mb-2" data-index="{{ $index + 1 }}">
                                                    <div class="col-5">
                                                        <select class="form-control form-control-sm split-payment-method" name="payments[{{ $index + 1 }}][method]">
                                                            <option value="Cash" @selected($payment->payment_method == 'Cash')>Cash</option>
                                                            <option value="Online" @selected($payment->payment_method == 'Online')>Online/UPI</option>
                                                            <option value="Credit Card" @selected($payment->payment_method == 'Credit Card')>Credit Card</option>
                                                        </select>
                                                    </div>
                                                    <div class="col-5">
                                                        <input type="number" class="form-control form-control-sm split-payment-amount"
                                                            name="payments[{{ $index + 1 }}][amount]" step="0.01" min="0" value="{{ $payment->amount }}">
                                                    </div>
                                                    <div class="col-2">
                                                        <button type="button" class="btn btn-outline-danger btn-block remove-split-payment-row"><i class="mdi mdi-delete"></i></button>
                                                    </div>
                                                </div>
                                            @endforeach
                                        @endif
                                    </div>
                                    <button type="button" class="btn btn-sm btn-outline-success mt-1" id="addSplitPaymentRow">
                                        <i class="mdi mdi-plus-circle-outline mr-1"></i>Add Payment Method
                                    </button>
                                    <div class="small mt-2">
                                        Remaining to allocate: <strong>₹ <span id="splitPaymentRemaining">0.00</span></strong>
                                    </div>
                                </div>

                                <div class="col-md-12 mt-2">
                                    <label class="form-label fw-semibold">Address</label>
                                    <input type="text" name="customer_address" class="form-control form-control-sm"
                                        id="customer_address" placeholder="Customer Address"
                                        value="{{ $invoice->customer_address }}">
                                </div>
                            </div>

                            <!-- Item Details -->
                            <div class="mt-4">
                                <h5 class="text-uppercase fw-semibold mb-2 border-bottom pb-1 text-secondary">
                                    <i class="mdi mdi-package-variant-closed me-1"></i> Item Details
                                </h5>

                                <div id="itemsContainer" class="mb-3"></div>

                                <div class="d-flex justify-content-end">
                                    <button type="button" class="btn btn-sm btn-outline-success" id="addItemBtn">
                                        <i class="mdi mdi-plus-circle-outline me-1"></i> Add Item
                                    </button>
                                </div>
                            </div>

                            <!-- Customer Identity Documents -->
                            <div class="mt-4">
                                <h5 class="text-uppercase fw-semibold mb-2 border-bottom pb-1 text-secondary">
                                    <i class="mdi mdi-card-account-details-outline me-1"></i> Customer Identity Document (Optional)
                                </h5>

                                @if($invoice->documents->isNotEmpty())
                                    <div class="row g-2 mb-3">
                                        @foreach($invoice->documents as $document)
                                            <div class="col-md-3">
                                                <div class="border rounded p-2 text-center bg-light">
                                                    <img src="{{ $document->image_url }}" alt="{{ $document->document_type_label }}"
                                                        style="max-height:90px;max-width:100%;border-radius:6px;">
                                                    <div class="small fw-semibold mt-1">{{ $document->document_type_label }}</div>
                                                    <div class="small text-muted">{{ $document->masked_number }}</div>
                                                    <button type="button"
                                                        class="btn btn-sm btn-outline-danger mt-1 delete-document-btn"
                                                        data-url="{{ route('invoice-document-delete', [$invoice->id, $document->id]) }}">
                                                        <i class="mdi mdi-delete"></i> Remove
                                                    </button>
                                                </div>
                                            </div>
                                        @endforeach
                                    </div>
                                @endif

                                <div id="documentsContainer" class="mb-2"></div>

                                <div class="d-flex justify-content-end">
                                    <button type="button" class="btn btn-sm btn-outline-success" id="addDocumentBtn">
                                        <i class="mdi mdi-plus-circle-outline me-1"></i> Add Document
                                    </button>
                                </div>
                            </div>

                            <!-- Taxes and Summary -->
                            <?php
                                $companySetting = \App\Models\CompanySetting::current();
                                $currentGstMode = old('gst_mode', $invoice->gst_mode ?? 'exclude');
                            ?>
                            <div class="row mt-2 align-items-end">
                                <div class="col-md-2">
                                    <label class="form-label fw-semibold">Invoice Type</label>
                                    <select class="form-control form-control-sm" name="invoice_type" id="invoiceType">
                                        <option value="simple" @selected(old('invoice_type', $invoice->invoice_type ?? 'simple') === 'simple')>Simple Invoice</option>
                                        <option value="tax" @selected(old('invoice_type', $invoice->invoice_type ?? 'simple') === 'tax')>Tax Invoice</option>
                                    </select>
                                </div>
                                @if($companySetting->gst_enabled)
                                    <div class="col-md-2">
                                        <label class="form-label fw-semibold">GST</label>
                                        <select class="form-control form-control-sm" name="gst_mode" id="gstMode">
                                            <option value="exclude" @selected($currentGstMode === 'exclude')>Exclude GST</option>
                                            <option value="include" @selected($currentGstMode === 'include')>Include GST</option>
                                            <option value="none" @selected($currentGstMode === 'none')>None</option>
                                        </select>
                                    </div>
                                @else
                                    <input type="hidden" name="gst_mode" value="none">
                                @endif

                                <div class="col-md-2">
                                    <label class="form-label fw-semibold">Discount Amount</label>
                                    <input type="number" class="form-control form-control-sm" placeholder="Discount"
                                        name="discount_amount" id="discAmount" min="0"
                                        value="{{ $invoice->discount ?? 0 }}">
                                </div>
                            </div>

                            @if($companySetting->gst_enabled)
                                <div class="row mt-2" id="gstRateFields">
                                    <div class="col-md-3">
                                        <label class="form-label fw-semibold">CGST (%)</label>
                                        <input type="text" class="form-control form-control-sm" placeholder="CGST Rate"
                                            name="cgst_rate" id="cgst" value="{{ $invoice->cgst_rate ?? 0 }}">
                                        <input type="hidden" id="cgstAmount" name="cgst_amount"
                                            value="{{ $invoice->cgst_amount ?? 0 }}">
                                    </div>

                                    <div class="col-md-3">
                                        <label class="form-label fw-semibold">SGST (%)</label>
                                        <input type="text" class="form-control form-control-sm" placeholder="SGST Rate"
                                            name="sgst_rate" id="sgst" value="{{ $invoice->sgst_rate ?? 0 }}">
                                        <input type="hidden" id="sgstAmount" name="sgst_amount"
                                            value="{{ $invoice->sgst_amount ?? 0 }}">
                                    </div>

                                    <div class="col-md-3">
                                        <label class="form-label fw-semibold">IGST (%)</label>
                                        <input type="text" class="form-control form-control-sm" placeholder="IGST Rate"
                                            name="igst_rate" id="igst" value="{{ $invoice->igst_rate ?? 0 }}">
                                        <input type="hidden" id="igstAmount" name="igst_amount"
                                            value="{{ $invoice->igst_amount ?? 0 }}">
                                    </div>
                                </div>
                            @else
                                <input type="hidden" id="cgst" name="cgst_rate" value="{{ $invoice->cgst_rate ?? 0 }}">
                                <input type="hidden" id="cgstAmount" name="cgst_amount" value="{{ $invoice->cgst_amount ?? 0 }}">
                                <input type="hidden" id="sgst" name="sgst_rate" value="{{ $invoice->sgst_rate ?? 0 }}">
                                <input type="hidden" id="sgstAmount" name="sgst_amount" value="{{ $invoice->sgst_amount ?? 0 }}">
                                <input type="hidden" id="igst" name="igst_rate" value="{{ $invoice->igst_rate ?? 0 }}">
                                <input type="hidden" id="igstAmount" name="igst_amount" value="{{ $invoice->igst_amount ?? 0 }}">
                            @endif

                            <div class="row mt-2">
                                <div class="col-md-4">
                                    <div class="bg-light p-3 rounded shadow-sm">
                                        <ul class="mb-0 list-unstyled small">
                                            <li><b>Subtotal:</b> ₹ <span
                                                    id="totalAmountDisplay">{{ $invoice->total_amount ?? 0 }}</span></li>
                                            <li><b>Discount:</b> ₹ <span
                                                    id="discountAmount">{{ $invoice->discount ?? 0 }}</span></li>
                                            <li><b>GST (<span id="gstRateDisplay">{{ ($invoice->cgst_rate ?? 0) + ($invoice->sgst_rate ?? 0) + ($invoice->igst_rate ?? 0) }}</span>%):</b> ₹ <span
                                                    id="taxDisplay">{{ ($invoice->cgst_amount ?? 0) + ($invoice->sgst_amount ?? 0) + ($invoice->igst_amount ?? 0) }}</span>
                                            </li>
                                            <li class="mt-1 border-top pt-1">
                                                <b>Net Amount:</b> ₹
                                                <span id="netAmountDisplay"
                                                    class="fw-bold text-success">{{ $invoice->net_amount ?? 0 }}</span>
                                            </li>
                                        </ul>
                                        <input type="hidden" name="total_amount" id="totalAmountInput"
                                            value="{{ $invoice->total_amount ?? 0 }}">
                                        <input type="hidden" name="tax_amount" id="taxAmount"
                                            value="{{ ($invoice->cgst_amount ?? 0) + ($invoice->sgst_amount ?? 0) + ($invoice->igst_amount ?? 0) }}">
                                        <input type="hidden" name="net_amount" id="netAmount"
                                            value="{{ $invoice->net_amount ?? 0 }}">
                                    </div>
                                </div>
                            </div>

                            <!-- Declaration -->
                            <div class="mt-4">
                                <label class="form-label fw-semibold">Declaration</label>
                                <input type="text" name="declaration" class="form-control form-control-sm"
                                    placeholder="Add any declaration or note" value="{{ $invoice->declaration ?? '' }}">
                            </div>

                            <!-- Actions -->
                            <div class="d-flex justify-content-end mt-4">
                                <a href="{{ route('allinvoices') }}" class="btn btn-outline-danger btn-sm me-2">
                                    <i class="mdi mdi-keyboard-backspace"></i> Back
                                </a>
                                <button type="submit" class="btn btn-primary btn-sm ml-2">
                                    <i class="mdi mdi-check-circle-outline me-1"></i> Update Invoice
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

@endsection

@section('scripts')
    <script src="https://code.jquery.com/ui/1.13.2/jquery-ui.min.js"></script>
    <script>
        let itemCounter = 0;
        let documentCounter = 0;
        const existingItems = @json($invoice->items);

        $(document).ready(function () {
            $("#invoicedate").datepicker({ dateFormat: 'dd/mm/yy' });

            $(document).on('click', '#addDocumentBtn', addDocumentRow);
            $(document).on('click', '.remove-document', function () {
                $(this).closest('.item-row').remove();
            });
            $(document).on('change', '.document-type', function () {
                $(this).closest('.item-row').find('.document-type-other-wrap').toggle($(this).val() === 'other');
            });
            $(document).on('change', '.document-image', function () {
                const $row = $(this).closest('.item-row');
                const file = this.files && this.files[0];
                if (file) {
                    $row.find('.document-preview').attr('src', URL.createObjectURL(file)).show();
                }
            });
            $(document).on('click', '.delete-document-btn', function () {
                const url = $(this).data('url');

                Swal.fire({
                    title: 'Remove this document?',
                    text: "You won't be able to revert this!",
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: 'Yes, remove it!'
                }).then((result) => {
                    if (result.isConfirmed) {
                        const $form = $(`<form action="${url}" method="POST"></form>`);
                        $form.append('@csrf');
                        $('body').append($form);
                        $form.submit();
                    }
                });
            });

            // Load existing items
            existingItems.forEach(function (item) {
                addItemRow(item);
            });

            // If no items exist, add one empty row
            if (existingItems.length === 0) {
                addItemRow();
            }

            $(document).on('click', '#addItemBtn', function () {
                addItemRow();
            });

            $(document).on('click', '.remove-item', function () {
                if ($('.item-row').length <= 1) {
                    alert('At least one item is required in the invoice');
                    return;
                }
                $(this).closest('.item-row').remove();
                calculateTotals();
            });

            $('form').on('submit', function (e) {
                if ($('.item-row').length === 0) {
                    e.preventDefault();
                    alert('Please add at least one item to the invoice');
                    return false;
                }

                if ($('#splitPaymentToggle').is(':checked')) {
                    const remaining = parseFloat($('#netAmount').val() || 0) - splitPaymentTotal();
                    if ($('.split-payment-row').length < 2) {
                        e.preventDefault();
                        alert('Add at least two payment methods, or turn off split payment.');
                        return false;
                    }
                    if (Math.abs(remaining) > 0.01) {
                        e.preventDefault();
                        alert('Split payment amounts must add up to the net amount (₹' + parseFloat($('#netAmount').val() || 0).toFixed(2) + ').');
                        return false;
                    }
                }
            });

            let splitPaymentRowIndex = {{ $invoice->payments->count() > 1 ? $invoice->payments->count() : 0 }};

            function splitPaymentTotal() {
                let total = 0;
                $('.split-payment-row .split-payment-amount').each(function () {
                    total += parseFloat($(this).val()) || 0;
                });
                return total;
            }

            function updateSplitPaymentRemaining() {
                const net = parseFloat($('#netAmount').val()) || 0;
                const remaining = net - splitPaymentTotal();
                $('#splitPaymentRemaining').text(remaining.toFixed(2)).toggleClass('text-danger', Math.abs(remaining) > 0.01);
            }

            function addSplitPaymentRow() {
                splitPaymentRowIndex++;
                const rowHtml = `
                    <div class="row g-2 align-items-end split-payment-row mb-2" data-index="${splitPaymentRowIndex}">
                        <div class="col-5">
                            <select class="form-control form-control-sm split-payment-method" name="payments[${splitPaymentRowIndex}][method]">
                                <option value="Cash">Cash</option>
                                <option value="Online">Online/UPI</option>
                                <option value="Credit Card">Credit Card</option>
                            </select>
                        </div>
                        <div class="col-5">
                            <input type="number" class="form-control form-control-sm split-payment-amount"
                                name="payments[${splitPaymentRowIndex}][amount]" step="0.01" min="0" placeholder="Amount">
                        </div>
                        <div class="col-2">
                            <button type="button" class="btn btn-outline-danger btn-block remove-split-payment-row"><i class="mdi mdi-delete"></i></button>
                        </div>
                    </div>`;
                $('#splitPaymentRows').append(rowHtml);
            }

            $('#splitPaymentToggle').on('change', function () {
                const isSplit = $(this).is(':checked');
                $('#splitPaymentSection').toggle(isSplit);
                $('#splitPaymentFlag').val(isSplit ? '1' : '0');
                $('#paymentModeWrap').toggle(!isSplit);
                $('#payment_type').prop('required', !isSplit);

                if (isSplit && $('.split-payment-row').length === 0) {
                    addSplitPaymentRow();
                    addSplitPaymentRow();
                    updateSplitPaymentRemaining();
                }
            });

            $('#addSplitPaymentRow').on('click', function () {
                addSplitPaymentRow();
                updateSplitPaymentRemaining();
            });

            $(document).on('click', '.remove-split-payment-row', function () {
                $(this).closest('.split-payment-row').remove();
                updateSplitPaymentRemaining();
            });

            $(document).on('input', '.split-payment-amount', updateSplitPaymentRemaining);

            updateSplitPaymentRemaining();

            $(document).on('change', '.item-type', function () {
                syncItemTypeState($(this).closest('.item-row'));
            });

            $(document).on('input', '.item-search', function () {
                const $row = $(this).closest('.item-row');
                $row.find('.item-search-error').hide();

                if (!$(this).val().trim()) {
                    clearSelectedInventory($row, false);
                }
            });

            $(document).on('blur', '.item-search', function () {
                searchInventory($(this).closest('.item-row'));
            });

            $(document).on('keydown', '.item-search', function (e) {
                if (e.which === 13) {
                    e.preventDefault();
                    searchInventory($(this).closest('.item-row'));
                }
            });

            $(document).on('input keyup change', '.item-price, .item-quantity', function () {
                calculateItemTotal($(this).closest('.item-row'));
            });

            $(document).on('input keyup change', '#cgst, #sgst, #igst, #discAmount', function () {
                calculateNetAmount();
            });

            // Initialize calculations
            calculateTotals();
        });

        function addItemRow(item = null) {
            itemCounter++;
            const itemType = item && item.purchase && item.purchase.tracking_type === 'bulk' ? 'bulk' : 'serialized';
            const searchValue = item && item.purchase
                ? (itemType === 'bulk' ? (item.purchase.sku || item.purchase.model) : (item.purchase.imei || ''))
                : '';
            const itemId = item ? item.item_id : '';
            let warrantyDate = '';
            if (item && item.warranty_expiry_date) {
                const date = new Date(item.warranty_expiry_date);
                warrantyDate = String(date.getDate()).padStart(2, '0') + '/' + String(date.getMonth() + 1).padStart(2, '0') + '/' + date.getFullYear();
            }
            const quantity = item ? item.quantity : 1;
            const unitPrice = item ? item.unit_price : '';
            const total = item ? item.total_amount : 0;
            const description = item ? item.item_description : '';

            const rowHtml = `
                <div class="item-row border rounded p-2 mb-2 shadow-sm bg-light" data-index="${itemCounter}" style="font-size: 14px;">
                    <div class="row g-2 align-items-end">
                        <div class="col-md-2">
                            <label class="form-label mb-1 fw-semibold">Item Type</label>
                            <select class="form-control form-control-sm item-type" name="items[${itemCounter}][item_type]">
                                <option value="serialized" ${itemType === 'serialized' ? 'selected' : ''}>Serialized</option>
                                <option value="bulk" ${itemType === 'bulk' ? 'selected' : ''}>Bulk Accessory</option>
                            </select>
                        </div>
                        <div class="col-md-3">
                            <label class="form-label mb-1 fw-semibold item-search-label">IMEI <span class="text-danger">*</span> <small class="text-danger item-search-error" style="display:none;"></small></label>
                            <input type="text" class="form-control form-control-sm item-search" placeholder="Search IMEI.." value="${searchValue}">
                            <input type="hidden" class="item-id" name="items[${itemCounter}][item_id]" value="${itemId}">
                        </div>
                        <div class="col-md-2">
                            <label class="form-label mb-1 fw-semibold item-warranty-label">Warranty Expiry</label>
                            <input type="text" class="form-control form-control-sm item-warranty"
                                name="items[${itemCounter}][warranty_expiry_date]" placeholder="dd/mm/yyyy" value="${warrantyDate}">
                        </div>
                        <div class="col-md-2">
                            <label class="form-label mb-1 fw-semibold">Qty <span class="text-danger">*</span></label>
                            <input type="number" class="form-control form-control-sm item-quantity"
                                name="items[${itemCounter}][quantity]" min="1" value="${quantity}">
                        </div>
                        <div class="col-md-2">
                            <label class="form-label mb-1 fw-semibold">Unit Price <span class="text-danger">*</span></label>
                            <input type="number" class="form-control form-control-sm item-price"
                                name="items[${itemCounter}][unit_price]" step="0.01" min="0" value="${unitPrice}">
                        </div>
                        <div class="col-md-1">
                            <label class="form-label mb-1 fw-semibold">Total</label>
                            <input type="text" class="form-control form-control-sm item-total" readonly value="${total}">
                        </div>
                    </div>
                    <div class="row g-2 mt-2">
                        <div class="col-md-10">
                            <label class="form-label mb-1 fw-semibold">Description</label>
                            <textarea class="form-control form-control-sm item-description"
                                    name="items[${itemCounter}][item_description]" rows="4"
                                    placeholder="Enter item description...">${description}</textarea>
                        </div>
                        <div class="col-md-2 d-flex align-items-end justify-content-end mt-2">
                            <button type="button" class="btn btn-sm btn-outline-danger remove-item">
                                <i class="mdi mdi-delete"></i> Remove
                            </button>
                        </div>
                    </div>
                </div>`;

            $('#itemsContainer').append(rowHtml);
            $('.item-warranty').last().datepicker({ dateFormat: 'dd/mm/yy' });
            syncItemTypeState($('#itemsContainer .item-row').last(), true);
        }

        function addDocumentRow() {
            documentCounter++;
            const rowHtml = `
                <div class="item-row border rounded p-2 mb-2 shadow-sm bg-light" data-index="${documentCounter}" style="font-size: 14px;">
                    <div class="row g-2 align-items-end">
                        <div class="col-md-3">
                            <label class="form-label mb-1 fw-semibold">Document Type <span class="text-danger">*</span></label>
                            <select class="form-control form-control-sm document-type" name="documents[${documentCounter}][type]">
                                <option value="aadhar">Aadhar Card</option>
                                <option value="pan">PAN Card</option>
                                <option value="other">Other</option>
                            </select>
                        </div>
                        <div class="col-md-3 document-type-other-wrap" style="display:none;">
                            <label class="form-label mb-1 fw-semibold">Document Name</label>
                            <input type="text" class="form-control form-control-sm" name="documents[${documentCounter}][type_other]" placeholder="e.g. Voter ID">
                        </div>
                        <div class="col-md-3">
                            <label class="form-label mb-1 fw-semibold">Document Number <span class="text-danger">*</span></label>
                            <input type="text" class="form-control form-control-sm" name="documents[${documentCounter}][number]" placeholder="Document number">
                        </div>
                        <div class="col-md-2">
                            <label class="form-label mb-1 fw-semibold">Photo <span class="text-danger">*</span></label>
                            <input type="file" class="form-control form-control-sm document-image" name="documents[${documentCounter}][image]" accept="image/png,image/jpeg,image/webp">
                        </div>
                        <div class="col-md-1">
                            <img class="document-preview" style="display:none;max-height:38px;border-radius:6px;" />
                        </div>
                        <div class="col-md-12 d-flex justify-content-end mt-2">
                            <button type="button" class="btn btn-sm btn-outline-danger remove-document">
                                <i class="mdi mdi-delete"></i> Remove
                            </button>
                        </div>
                    </div>
                </div>`;
            $('#documentsContainer').append(rowHtml);
        }

        function syncItemTypeState($row, preserveValues = false) {
            const isBulk = $row.find('.item-type').val() === 'bulk';

            $row.find('.item-search-label').html((isBulk ? 'Accessory / SKU' : 'IMEI') + ' <span class="text-danger">*</span> <small class="text-danger item-search-error" style="display:none;"></small>');
            $row.find('.item-search').attr('placeholder', isBulk ? 'Search accessory or SKU..' : 'Search IMEI..');
            $row.find('.item-quantity').prop('readonly', !isBulk).val(isBulk ? ($row.find('.item-quantity').val() || 1) : 1);
            $row.find('.item-warranty').prop('disabled', isBulk).val(isBulk && !preserveValues ? '' : $row.find('.item-warranty').val());
            $row.find('.item-warranty-label').toggle(!isBulk);
            $row.find('.item-warranty').closest('.col-md-2').toggle(!isBulk);

            if (!preserveValues) {
                clearSelectedInventory($row, true);
            }

            calculateItemTotal($row);
        }

        function clearSelectedInventory($row, clearSearch = true) {
            if (clearSearch) {
                $row.find('.item-search').val('');
            }

            $row.find('.item-id').val('');
            $row.find('.item-description').val('');
            $row.find('.item-price').val('0.00');
            $row.find('.item-total').val('0.00');
            $row.find('.item-search-error').hide();
        }

        function getSelectedItemIds($currentRow) {
            const selectedIds = [];

            $('.item-row').each(function () {
                const $row = $(this);
                if ($row[0] === $currentRow[0]) {
                    return;
                }

                const selectedId = $row.find('.item-id').val();
                if (selectedId) {
                    selectedIds.push(String(selectedId));
                }
            });

            return selectedIds;
        }

        function buildItemDescription(item) {
            let desc = `Model: ${item['model'] || ''}\n`;

            if (item['sku']) desc += `SKU: ${item['sku']}\n`;
            if (item['color']) desc += `Color: ${item['color']}\n`;
            if (item['storage']) desc += `Storage: ${item['storage']}\n`;
            if (item['imei']) {
                desc += `IMEI: ${item['imei']}`;
            } else if (typeof item['available_quantity'] !== 'undefined') {
                desc += `Available Qty: ${item['available_quantity']}`;
            }

            return desc.trim();
        }

        function searchInventory($row) {
            const query = ($row.find('.item-search').val() || '').trim();
            const itemType = $row.find('.item-type').val();
            if (!query) return;

            const endpoint = itemType === 'bulk' ? `/admin/fetchbulkstock/${encodeURIComponent(query)}` : `/admin/fetchstockonimei/${encodeURIComponent(query)}`;
            const selectedIds = getSelectedItemIds($row);

            $.ajax({
                url: endpoint,
                type: 'GET',
                success: function (data) {
                    const filteredData = (data || []).filter(item => !selectedIds.includes(String(item['id'] || '')));

                    if (filteredData.length === 0) {
                        $row.find('.item-search-error').text(itemType === 'bulk' ? 'No bulk stock found for this search' : 'No available IMEI found for this search').show();
                        return;
                    }

                    const item = filteredData[0];
                    $row.find('.item-search-error').hide();
                    $row.find('.item-id').val(item.id);
                    $row.find('.item-search').val(itemType === 'bulk' ? (item.sku || item.model) : item.imei);
                    $row.find('.item-description').val(buildItemDescription(item));
                    $row.find('.item-price').val(item.purchase_price).trigger('input');

                    if (itemType !== 'bulk') {
                        $row.find('.item-quantity').val(1);
                    }
                },
                error: function () {
                    $row.find('.item-search-error').text(itemType === 'bulk' ? 'Bulk item not found' : 'IMEI not found').show();
                }
            });
        }

        function calculateItemTotal($row) {
            const qty = parseFloat($row.find('.item-quantity').val()) || 1;
            const price = parseFloat($row.find('.item-price').val()) || 0;
            const total = qty * price;
            $row.find('.item-total').val(total.toFixed(2));
            calculateTotals();
        }

        function calculateTotals() {
            let total = 0;
            $('.item-total').each(function () {
                total += parseFloat($(this).val()) || 0;
            });
            $('#totalAmountInput').val(total.toFixed(2));
            $('#totalAmountDisplay').text(total.toFixed(2));
            calculateNetAmount();
        }

        function calculateNetAmount() {
            const total = parseFloat($('#totalAmountInput').val()) || 0;
            const discount = parseFloat($('#discAmount').val()) || 0;
            const gstMode = $('#gstMode').length ? $('#gstMode').val() : 'none';

            let cgst = 0, sgst = 0, igst = 0;
            if (gstMode !== 'none') {
                cgst = parseFloat($('#cgst').val()) || 0;
                sgst = parseFloat($('#sgst').val()) || 0;
                igst = parseFloat($('#igst').val()) || 0;
            }

            let cgstAmt = 0, sgstAmt = 0, igstAmt = 0, tax = 0, net = 0, subtotal = total;

            if (gstMode === 'include') {
                // Item prices already include GST — the displayed total is the
                // tax-exclusive taxable value, so Total + GST - Discount reads as
                // Net Amount on screen instead of double-counting the tax.
                const combinedRate = cgst + sgst + igst;
                const taxable = combinedRate > 0 ? total / (1 + combinedRate / 100) : total;
                tax = total - taxable;
                subtotal = taxable;
                cgstAmt = combinedRate > 0 ? tax * (cgst / combinedRate) : 0;
                sgstAmt = combinedRate > 0 ? tax * (sgst / combinedRate) : 0;
                igstAmt = combinedRate > 0 ? tax * (igst / combinedRate) : 0;
                net = total - discount;
            } else if (gstMode === 'exclude') {
                cgstAmt = (cgst / 100) * total;
                sgstAmt = (sgst / 100) * total;
                igstAmt = (igst / 100) * total;
                tax = cgstAmt + sgstAmt + igstAmt;
                net = total + tax - discount;
            } else {
                net = total - discount;
            }

            $('#cgstDisplay').text(cgstAmt.toFixed(2));
            $('#sgstDisplay').text(sgstAmt.toFixed(2));
            $('#igstDisplay').text(igstAmt.toFixed(2));
            $('#cgstAmount').val(cgstAmt.toFixed(2));
            $('#sgstAmount').val(sgstAmt.toFixed(2));
            $('#igstAmount').val(igstAmt.toFixed(2));
            $('#taxDisplay').text(tax.toFixed(2));
            $('#taxAmount').val(tax.toFixed(2));
            $('#discountAmount').text(discount.toFixed(2));
            $('#totalAmountDisplay').text(subtotal.toFixed(2));
            $('#netAmountDisplay').text(net.toFixed(2));
            $('#netAmount').val(net.toFixed(2));

            const combinedRate = cgst + sgst + igst;
            $('#gstRateDisplay').text(combinedRate % 1 === 0 ? combinedRate : combinedRate.toFixed(2));

            if (typeof updateSplitPaymentRemaining === 'function') {
                updateSplitPaymentRemaining();
            }
        }

        function toggleGstRateFields() {
            const $fields = $('#gstRateFields');
            if (!$fields.length) {
                return;
            }
            $fields.toggle($('#gstMode').val() !== 'none');
        }

        $(document).on('change', '#gstMode', function () {
            toggleGstRateFields();
            calculateNetAmount();
        });
        toggleGstRateFields();

        // A Tax Invoice needs an actual GST breakdown to make sense — if GST is
        // configured for this company but the mode is still "None", nudge it to
        // "Exclude GST" instead of silently printing a tax invoice with no tax on it.
        $(document).on('change', '#invoiceType', function () {
            const $gstMode = $('#gstMode');
            if ($(this).val() === 'tax' && $gstMode.length && $gstMode.val() === 'none') {
                $gstMode.val('exclude').trigger('change');
            }
        });
    </script>
@endsection
