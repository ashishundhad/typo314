@extends('layout.app')

@section('title')
    Invoice #{{ $invoice->invoice_no }}
@endsection

@section('content')
    <div class="page-container">
        <div class="invoice-print-wrap">
            <div class="invoice-admin-actions no-print">
                <div class="invoice-admin-actions__group">
                    <button type="button" class="invoice-admin-actions__btn invoice-admin-actions__btn--back" onclick="window.history.back()">
                        <i class="mdi mdi-arrow-left"></i>
                        <span>Back</span>
                    </button>
                </div>

                <div class="invoice-admin-actions__group">
                    <button type="button" class="invoice-admin-actions__btn invoice-admin-actions__btn--print" onclick="window.print()">
                        <i class="mdi mdi-printer"></i>
                        <span>Print</span>
                    </button>

                    <a href="{{ route('download-pdf', $invoice->id) }}" class="invoice-admin-actions__btn invoice-admin-actions__btn--pdf">
                        <i class="mdi mdi-file-pdf-box"></i>
                        <span>Download</span>
                    </a>

                    @if($invoice->customer_no)
                        <a href="{{ route('send-whatsapp', ['id' => $invoice->id]) }}" target="_blank" class="invoice-admin-actions__btn invoice-admin-actions__btn--wa">
                            <i class="mdi mdi-whatsapp"></i>
                            <span>WhatsApp</span>
                        </a>
                    @endif
                </div>
            </div>

            @include('invoice._document', ['invoice' => $invoice, 'amountInWords' => $amountInWords])
        </div>
    </div>
@endsection
