@extends('layout.app')

@section('title')
    Create Invoice
@endsection

@section('css')
    <link rel="stylesheet" href="https://code.jquery.com/ui/1.13.2/themes/ui-lightness/jquery-ui.css">
@endsection

@section('content')
    <div class="container-fluid invoice-create-shell">
        <div class="invoice-create-hero">
            <div class="row align-items-center">
                <div class="col-lg-8">
                    <!-- <div class="invoice-create-hero__eyebrow">Billing Workspace</div> -->
                    <h1 class="invoice-create-hero__title">Create Invoice</h1>
                    <p class="invoice-create-hero__subtitle"></p>
                </div>
                <div class="col-lg-4 text-lg-right">
                    <div class="invoice-create-hero__badge">Invoice #{{ $lastId }}</div>
                </div>
            </div>
        </div>

        <div class="card invoice-create-card">
            <div class="card-body">
                @include('include.alert')

                <form action="{{ route('create-invoice') }}" method="post" enctype="multipart/form-data"
                    class="@if(count($errors)) was-validated @endif">
                    @csrf
                    <input type="hidden" name="invoice_no" value="{{ $lastId }}" />

                    <div class="invoice-create-section">
                        <!-- <div class="invoice-create-section__eyebrow">Customer Details</div> -->
                        <h2 class="invoice-create-section__title">Invoice Information</h2>
                        <p class="invoice-create-section__subtitle"></p>

                        <div class="invoice-create-panel">
                            <div class="row">
                                <div class="col-md-4 mb-3">
                                    <label class="invoice-create-label">Customer Name <span class="text-danger">*</span></label>
                                    <input type="text" required placeholder="Customer Name" name="customer_name"
                                        class="form-control invoice-create-input @error('customer_name') parsley-error @enderror"
                                        id="customer_name" value="{{ old('customer_name') }}">
                                    @error('customer_name')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>

                                <div class="col-md-3 mb-3">
                                    <label class="invoice-create-label" for="customer_no">Contact No <span class="text-danger">*</span></label>
                                    <input type="text" name="customer_no" class="form-control invoice-create-input"
                                        id="customer_no" maxlength="10" placeholder="Customer mobile"
                                        value="{{ old('customer_no') }}">
                                </div>

                                <div class="col-md-3 mb-3">
                                    <label class="invoice-create-label">Invoice Date</label>
                                    <input type="text" name="invoice_date" class="form-control invoice-create-input"
                                        id="invoicedate" placeholder="dd/mm/yyyy"
                                        value="{{ old('invoice_date', date('d/m/Y')) }}">
                                </div>

                                <div class="col-md-2 mb-3" id="paymentModeWrap">
                                    <label class="invoice-create-label">Payment Mode <span class="text-danger">*</span></label>
                                    <select name="payment_type"
                                        class="form-control invoice-create-input @error('payment_type') parsley-error @enderror"
                                        id="payment_type" required>
                                        <option value="">Select</option>
                                        <option value="Cash" {{ old('payment_type') === 'Cash' ? 'selected' : '' }}>Cash</option>
                                        <option value="Online" {{ old('payment_type') === 'Online' ? 'selected' : '' }}>Online/UPI</option>
                                        <option value="Credit Card" {{ old('payment_type') === 'Credit Card' ? 'selected' : '' }}>Credit Card</option>
                                    </select>
                                </div>

                                <div class="col-md-12">
                                    <div class="custom-control custom-checkbox">
                                        <input type="checkbox" class="custom-control-input" id="splitPaymentToggle">
                                        <label class="custom-control-label" for="splitPaymentToggle">Split payment across multiple methods</label>
                                    </div>
                                </div>

                                <div class="col-md-12 mb-3" id="splitPaymentSection" style="display:none;">
                                    <input type="hidden" name="split_payment" id="splitPaymentFlag" value="0">
                                    <div id="splitPaymentRows"></div>
                                    <button type="button" class="btn btn-sm btn-outline-success mt-1" id="addSplitPaymentRow">
                                        <i class="mdi mdi-plus-circle-outline mr-1"></i>Add Payment Method
                                    </button>
                                    <div class="small mt-2">
                                        Remaining to allocate: <strong>₹ <span id="splitPaymentRemaining">0.00</span></strong>
                                    </div>
                                </div>

                                <div class="col-md-12">
                                    <label class="invoice-create-label">Address</label>
                                    <input type="text" name="customer_address" class="form-control invoice-create-input"
                                        id="customer_address" placeholder="Customer Address"
                                        value="{{ old('customer_address') }}">
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="invoice-create-section">
                        <div class="d-flex justify-content-between align-items-center flex-wrap mb-3">
                            <div>
                                <!-- <div class="invoice-create-section__eyebrow">KYC (Optional)</div> -->
                                <h2 class="invoice-create-section__title mb-1">Customer Identity Document</h2>
                                <p class="invoice-create-section__subtitle mb-0">Attach Aadhar, PAN, or other ID proof for this customer. Photos are optimized automatically.</p>
                            </div>
                            <div class="mt-3 mt-md-0">
                                <button type="button" class="btn btn-outline-success invoice-create-add" id="addDocumentBtn">
                                    <i class="mdi mdi-plus-circle-outline mr-1"></i>Add Document
                                </button>
                                <button type="button" class="btn btn-primary invoice-create-add" id="qrUploadBtn" data-toggle="modal" data-target="#qrUploadModal">
                                    <i class="mdi mdi-qrcode mr-1"></i>Via Phone (QR)
                                </button>
                            </div>
                        </div>

                        <div id="documentsContainer" class="mb-2"></div>
                    </div>

                    <div class="invoice-create-section">
                        <div class="d-flex justify-content-between align-items-center flex-wrap mb-3">
                            <div>
                                <!-- <div class="invoice-create-section__eyebrow">Items</div> -->
                                <h2 class="invoice-create-section__title mb-1">Invoice Items</h2>
                                <!-- <p class="invoice-create-section__subtitle mb-0">Search by IMEI, fill prices, and let the totals update automatically.</p> -->
                            </div>
                            <button type="button" class="btn btn-outline-success invoice-create-add mt-3 mt-md-0" id="addItemBtn">
                                <i class="mdi mdi-plus-circle-outline mr-1"></i>Add Item
                            </button>
                        </div>

                        <div id="itemsContainer" class="mb-2"></div>
                    </div>

                    <div class="invoice-create-section">
                        <!-- <div class="invoice-create-section__eyebrow">Totals</div> -->
                        <h2 class="invoice-create-section__title">Tax & Summary</h2>
                        <!-- <p class="invoice-create-section__subtitle">Apply taxes and discounts to compute the final net amount.</p> -->

                        <?php
                            $companySetting = \App\Models\CompanySetting::current();
                            $defaultGstMode = old('gst_mode', $companySetting->default_gst_mode ?? 'exclude');
                            $defaultGstRate = $companySetting->gst_percentage ? number_format($companySetting->gst_percentage / 2, 2, '.', '') : '';
                        ?>
                        <div class="row">
                            <div class="col-lg-8">
                                <div class="invoice-create-panel">
                                    <div class="row">
                                        <div class="col-md-3 mb-3 mb-md-0">
                                            <label class="invoice-create-label">Invoice Type</label>
                                            <select class="form-control invoice-create-input" name="invoice_type" id="invoiceType">
                                                <option value="simple" @selected(old('invoice_type', 'simple') === 'simple')>Simple Invoice</option>
                                                <option value="tax" @selected(old('invoice_type') === 'tax')>Tax Invoice</option>
                                            </select>
                                        </div>
                                        @if($companySetting->gst_enabled)
                                            <div class="col-md-3 mb-3 mb-md-0">
                                                <label class="invoice-create-label">GST</label>
                                                <select class="form-control invoice-create-input" name="gst_mode" id="gstMode">
                                                    <option value="exclude" @selected($defaultGstMode === 'exclude')>Exclude GST</option>
                                                    <option value="include" @selected($defaultGstMode === 'include')>Include GST</option>
                                                    <option value="none" @selected($defaultGstMode === 'none')>None</option>
                                                </select>
                                            </div>
                                        @else
                                            <input type="hidden" name="gst_mode" value="none">
                                        @endif
                                        <div class="col-md-3">
                                            <label class="invoice-create-label">Discount Amount</label>
                                            <input type="number" class="form-control invoice-create-input" placeholder="Discount"
                                                name="discount_amount" id="discAmount" min="0" value="{{ old('discount_amount') }}">
                                        </div>
                                    </div>

                                    @if($companySetting->gst_enabled)
                                        <div class="row mt-3" id="gstRateFields">
                                            <div class="col-md-4 mb-3 mb-md-0">
                                                <label class="invoice-create-label">CGST (%)</label>
                                                <input type="text" class="form-control invoice-create-input" placeholder="CGST Rate"
                                                    name="cgst_rate" id="cgst" value="{{ old('cgst_rate', $defaultGstRate) }}">
                                                <input type="hidden" id="cgstAmount" name="cgst_amount" value="{{ old('cgst_amount', 0) }}">
                                            </div>
                                            <div class="col-md-4 mb-3 mb-md-0">
                                                <label class="invoice-create-label">SGST (%)</label>
                                                <input type="text" class="form-control invoice-create-input" placeholder="SGST Rate"
                                                    name="sgst_rate" id="sgst" value="{{ old('sgst_rate', $defaultGstRate) }}">
                                                <input type="hidden" id="sgstAmount" name="sgst_amount" value="{{ old('sgst_amount', 0) }}">
                                            </div>
                                            <div class="col-md-4 mb-3 mb-md-0">
                                                <label class="invoice-create-label">IGST (%)</label>
                                                <input type="text" class="form-control invoice-create-input" placeholder="IGST Rate"
                                                    name="igst_rate" id="igst" value="{{ old('igst_rate') }}">
                                                <input type="hidden" id="igstAmount" name="igst_amount" value="{{ old('igst_amount', 0) }}">
                                            </div>
                                        </div>
                                    @else
                                        <input type="hidden" id="cgst" name="cgst_rate" value="0">
                                        <input type="hidden" id="cgstAmount" name="cgst_amount" value="0">
                                        <input type="hidden" id="sgst" name="sgst_rate" value="0">
                                        <input type="hidden" id="sgstAmount" name="sgst_amount" value="0">
                                        <input type="hidden" id="igst" name="igst_rate" value="0">
                                        <input type="hidden" id="igstAmount" name="igst_amount" value="0">
                                    @endif
                                </div>
                            </div>

                            <div class="col-lg-4 mt-3 mt-lg-0">
                                <div class="invoice-create-summary">
                                    <div class="invoice-create-summary__row">
                                        <span>Subtotal</span>
                                        <strong>₹ <span id="totalAmountDisplay">{{ old('total_amount', 0) }}</span></strong>
                                    </div>
                                    <div class="invoice-create-summary__row">
                                        <span>Discount</span>
                                        <strong>₹ <span id="discountAmount">{{ old('discount_amount', 0) }}</span></strong>
                                    </div>
                                    <div class="invoice-create-summary__row" id="taxSummaryRow" style="display:none;">
                                        <span>GST (<span id="gstRateDisplay">0</span>%)</span>
                                        <strong>₹ <span id="taxDisplay">{{ old('tax_amount', 0) }}</span></strong>
                                    </div>
                                    <div class="invoice-create-summary__row invoice-create-summary__row--total">
                                        <span>Net Amount</span>
                                        <span>₹ <span id="netAmountDisplay">{{ old('net_amount', 0) }}</span></span>
                                    </div>

                                    <input type="hidden" name="total_amount" id="totalAmountInput" value="{{ old('total_amount', 0) }}">
                                    <input type="hidden" name="tax_amount" id="taxAmount" value="{{ old('tax_amount', 0) }}">
                                    <input type="hidden" name="net_amount" id="netAmount" value="{{ old('net_amount', 0) }}">
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="invoice-create-section">
                        <!-- <div class="invoice-create-section__eyebrow">Notes</div> -->
                        <h2 class="invoice-create-section__title">Declaration</h2>
                        <p class="invoice-create-section__subtitle">Add any optional note or declaration to appear with this invoice.</p>
                        <input type="text" name="declaration" class="form-control invoice-create-input"
                            placeholder="Add any declaration or note" value="{{ old('declaration') }}">
                    </div>

                    <div class="invoice-create-actions">
                        <a href="{{ route('allinvoices') }}" class="btn btn-danger ">
                            <i class="mdi mdi-keyboard-backspace mr-1"></i>Back
                        </a>
                        <button type="submit" class="btn btn-primary invoice-create-btn">
                            <i class="mdi mdi-check-circle-outline mr-1"></i>Submit Invoice
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <div class="modal fade" id="qrUploadModal" tabindex="-1" role="dialog" aria-labelledby="qrUploadModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="qrUploadModalLabel">Upload Document via Phone</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body text-center">
                    <p class="text-muted mb-3">Scan this with a phone — no webcam needed. It'll appear here once uploaded.</p>
                    <div id="qrUploadCode" class="mb-3 d-flex justify-content-center"></div>
                    <div id="qrUploadStatus" class="small text-muted mb-3">Generating code...</div>
                    <button type="button" class="btn btn-outline-primary" id="qrUploadCheckBtn" disabled>
                        <i class="mdi mdi-refresh mr-1"></i>Check for Upload
                    </button>
                </div>
            </div>
        </div>
    </div>
@endsection

@section('scripts')
    <script src="https://code.jquery.com/ui/1.13.2/jquery-ui.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/qrcodejs@1.0.0/qrcode.min.js"></script>
    <script>
        let itemCounter = 0;
        let documentCounter = 0;
        let qrUploadToken = null;
        $(document).ready(function () {
            $(document).on('click', '#addDocumentBtn', addDocumentRow);
            $(document).on('click', '.remove-document', function () {
                $(this).closest('.item-row').remove();
            });
            $(document).on('change', '.document-type', function () {
                $(this).closest('.item-row').find('.document-type-other-wrap').toggle($(this).val() === 'other');
            });
            $(document).on('change', '.document-image', function () {
                const $row = $(this).closest('.item-row');
                const file = this.files && this.files[0];
                if (file) {
                    $row.find('.document-preview').attr('src', URL.createObjectURL(file)).show();
                }
            });

            $("#invoicedate").datepicker({ dateFormat: 'dd/mm/yy' });

            $('#customer_no').on('blur', function() {
                let contactNo = $(this).val().trim();
                contactNo = contactNo.replace(/\D/g, '');
                if (contactNo.length >= 10) {
                    fetchCustomerByContact(contactNo);
                }
            });

            const oldItems = @json(old('items', []));
            if (oldItems && Object.keys(oldItems).length > 0) {
                Object.keys(oldItems).forEach(function (key) {
                    const item = oldItems[key] || {};
                    addItemRow();
                    const $row = $('#itemsContainer .item-row').last();
                    const itemType = item.item_type || ((parseInt(item.quantity || 1, 10) > 1) ? 'bulk' : 'serialized');
                    $row.find('.item-type').val(itemType);
                    syncItemTypeState($row);
                    if (item.item_id) $row.find('.item-id').val(item.item_id);
                    if (item.item_description) $row.find('.item-description').val(item.item_description);
                    if (item.quantity) $row.find('.item-quantity').val(item.quantity);
                    if (item.unit_price) $row.find('.item-price').val(item.unit_price);
                    if (item.warranty_expiry_date) $row.find('.item-warranty').val(item.warranty_expiry_date);
                    if (item.item_description) {
                        $row.find('.item-search').val(item.item_description.split('\n')[0].replace('Model: ', ''));
                    }
                    calculateItemTotal($row);
                });
            } else {
                addItemRow();
            }

            $(document).on('click', '#addItemBtn', addItemRow);
            $(document).on('click', '.remove-item', function () {
                if ($('.item-row').length <= 1) {
                    alert('At least one item is required in the invoice');
                    return;
                }
                $(this).closest('.item-row').remove();
                calculateTotals();
            });

            $('form').on('submit', function (e) {
                if ($('.item-row').length === 0) {
                    e.preventDefault();
                    alert('Please add at least one item to the invoice');
                    return false;
                }

                if ($('#splitPaymentToggle').is(':checked')) {
                    const remaining = parseFloat($('#netAmount').val() || 0) - splitPaymentTotal();
                    if ($('.split-payment-row').length < 2) {
                        e.preventDefault();
                        alert('Add at least two payment methods, or turn off split payment.');
                        return false;
                    }
                    if (Math.abs(remaining) > 0.01) {
                        e.preventDefault();
                        alert('Split payment amounts must add up to the net amount (₹' + parseFloat($('#netAmount').val() || 0).toFixed(2) + ').');
                        return false;
                    }
                }
            });

            let splitPaymentRowIndex = 0;

            function splitPaymentTotal() {
                let total = 0;
                $('.split-payment-row .split-payment-amount').each(function () {
                    total += parseFloat($(this).val()) || 0;
                });
                return total;
            }

            function updateSplitPaymentRemaining() {
                const net = parseFloat($('#netAmount').val()) || 0;
                const remaining = net - splitPaymentTotal();
                $('#splitPaymentRemaining').text(remaining.toFixed(2)).toggleClass('text-danger', Math.abs(remaining) > 0.01);
            }

            function addSplitPaymentRow() {
                splitPaymentRowIndex++;
                const rowHtml = `
                    <div class="row g-2 align-items-end split-payment-row mb-2" data-index="${splitPaymentRowIndex}">
                        <div class="col-5">
                            <select class="form-control invoice-create-input split-payment-method" name="payments[${splitPaymentRowIndex}][method]">
                                <option value="Cash">Cash</option>
                                <option value="Online">Online/UPI</option>
                                <option value="Credit Card">Credit Card</option>
                            </select>
                        </div>
                        <div class="col-5">
                            <input type="number" class="form-control invoice-create-input split-payment-amount"
                                name="payments[${splitPaymentRowIndex}][amount]" step="0.01" min="0" placeholder="Amount">
                        </div>
                        <div class="col-2">
                            <button type="button" class="btn btn-outline-danger btn-block remove-split-payment-row"><i class="mdi mdi-delete"></i></button>
                        </div>
                    </div>`;
                $('#splitPaymentRows').append(rowHtml);
            }

            $('#splitPaymentToggle').on('change', function () {
                const isSplit = $(this).is(':checked');
                $('#splitPaymentSection').toggle(isSplit);
                $('#splitPaymentFlag').val(isSplit ? '1' : '0');
                $('#paymentModeWrap').toggle(!isSplit);
                $('#payment_type').prop('required', !isSplit);

                if (isSplit && $('.split-payment-row').length === 0) {
                    addSplitPaymentRow();
                    addSplitPaymentRow();
                    updateSplitPaymentRemaining();
                }
            });

            $('#addSplitPaymentRow').on('click', function () {
                addSplitPaymentRow();
                updateSplitPaymentRemaining();
            });

            $(document).on('click', '.remove-split-payment-row', function () {
                $(this).closest('.split-payment-row').remove();
                updateSplitPaymentRemaining();
            });

            $(document).on('input', '.split-payment-amount', updateSplitPaymentRemaining);

            $(document).on('change', '.item-type', function () {
                syncItemTypeState($(this).closest('.item-row'));
            });

            $(document).on('input', '.item-search', function () {
                const $row = $(this).closest('.item-row');
                const $input = $(this);
                const query = $input.val().trim();
                $row.find('.item-search-error').hide();

                if (!query) {
                    clearSelectedInventory($row, false);
                }

                clearTimeout($input.data('searchTimer'));

                if (query.length >= 2) {
                    $input.data('searchTimer', setTimeout(function () {
                        searchInventory($row);
                    }, 300));
                } else {
                    const suggestions = $row.find('.item-suggestions')[0];
                    if (suggestions) {
                        suggestions.classList.remove('show');
                        suggestions.innerHTML = '';
                    }
                }
            });

            // A plain blur re-search here would race the mousedown-based selection
            // above (see the note by addEventListener("mousedown", ...)) and also
            // reopen the dropdown any time focus simply moves elsewhere (e.g. to the
            // date field). So blur only ever closes the list, after a short delay to
            // let a suggestion's mousedown/click still land first.
            $(document).on('blur', '.item-search', function () {
                const $row = $(this).closest('.item-row');
                setTimeout(function () {
                    const suggestions = $row.find('.item-suggestions')[0];
                    if (suggestions) {
                        suggestions.classList.remove('show');
                        suggestions.innerHTML = '';
                    }
                }, 150);
            });

            $(document).on('keydown', '.item-search', function (e) {
                if (e.which === 13) {
                    e.preventDefault();
                    clearTimeout($(this).data('searchTimer'));
                    searchInventory($(this).closest('.item-row'));
                }
            });

            $(document).on('input keyup change', '.item-price, .item-quantity', function () {
                calculateItemTotal($(this).closest('.item-row'));
            });

            $(document).on('input keyup change', '#cgst, #sgst, #igst, #discAmount', function () {
                calculateNetAmount();
            });

            calculateTotals();
        });

        function fetchCustomerByContact(contactNo) {
            if (!contactNo || contactNo.length < 10) {
                return;
            }

            $.ajax({
                url: `/admin/fetchcustomer/${contactNo}`,
                type: 'GET',
                beforeSend: function() {
                    $('#customer_no').css('border-color', '#1abc9c');
                },
                success: function (data) {
                    if (data.customer) {
                        $('#customer_name').val(data.customer.customer_name || '');
                        $('#customer_address').val(data.customer.customer_address || '');
                        $('#customer_no_sync').prop('checked', false);
                        $('#customer_no').css('border-color', '#28a745');
                        setTimeout(function() {
                            $('#customer_no').css('border-color', '');
                        }, 2000);
                    }
                },
                error: function (xhr) {
                    $('#customer_no').css('border-color', '');
                    if (xhr.status !== 404 && xhr.responseJSON && xhr.responseJSON.error) {
                        console.log('Customer fetch error:', xhr.responseJSON.error);
                    }
                }
            });
        }

        function addItemRow() {
            itemCounter++;
            const rowHtml = `
                <div class="item-row" data-index="${itemCounter}">
                    <div class="row g-2 align-items-end">
                        <div class="col-md-2">
                            <label class="form-label">Item Type</label>
                            <select class="form-control item-type" name="items[${itemCounter}][item_type]">
                                <option value="serialized">Serialized</option>
                                <option value="bulk">Bulk Accessory</option>
                            </select>
                        </div>
                        <div class="col-md-3">
                            <label class="form-label item-search-label" for="itemSearch${itemCounter}">IMEI <span class="text-danger">*</span> <small class="text-danger item-search-error" style="display:none;"></small></label>
                            <input type="text" class="form-control item-search" placeholder="Search IMEI.." id="itemSearch${itemCounter}" name="items[${itemCounter}][item_search]" autocomplete="off">
                            <div class="list-group imei_suggestions item-suggestions"></div>
                            <input type="hidden" class="item-id" name="items[${itemCounter}][item_id]">
                        </div>
                        <div class="col-md-2">
                            <label class="form-label item-warranty-label">Warranty Expiry</label>
                            <input type="text" class="form-control item-warranty" autocomplete="off"
                                name="items[${itemCounter}][warranty_expiry_date]" placeholder="dd/mm/yyyy">
                        </div>
                        <div class="col-md-2">
                            <label class="form-label">Qty <span class="text-danger">*</span></label>
                            <input type="number" class="form-control item-quantity"
                                name="items[${itemCounter}][quantity]" value="1" min="1">
                        </div>
                        <div class="col-md-2">
                            <label class="form-label">Unit Price <span class="text-danger">*</span></label>
                            <input type="number" class="form-control item-price"
                                name="items[${itemCounter}][unit_price]" step="0.01" min="0" placeholder="0.00">
                        </div>
                        <div class="col-md-1">
                            <label class="form-label">Total</label>
                            <input type="text" class="form-control item-total" readonly value="0.00">
                        </div>
                    </div>
                    <div class="row g-2 mt-2">
                        <div class="col-md-10">
                            <label class="form-label">Description</label>
                            <textarea class="form-control item-description"
                                name="items[${itemCounter}][item_description]" rows="4"
                                placeholder="Enter item description..."></textarea>
                        </div>
                        <div class="col-md-2 d-flex align-items-end justify-content-end mt-2">
                            <button type="button" class="btn btn-outline-danger remove-item">
                                <i class="mdi mdi-delete mr-1"></i>Remove
                            </button>
                        </div>
                    </div>
                </div>`;
            $('#itemsContainer').append(rowHtml);
            syncItemTypeState($('#itemsContainer .item-row').last());
            $('.item-search').last().focus();
            $('.item-warranty').last().datepicker({ dateFormat: 'dd/mm/yy' });
        }

        function addDocumentRow() {
            documentCounter++;
            const rowHtml = `
                <div class="item-row" data-index="${documentCounter}">
                    <div class="row g-2 align-items-end">
                        <div class="col-md-3">
                            <label class="form-label">Document Type <span class="text-danger">*</span></label>
                            <select class="form-control document-type" name="documents[${documentCounter}][type]">
                                <option value="aadhar">Aadhar Card</option>
                                <option value="pan">PAN Card</option>
                                <option value="other">Other</option>
                            </select>
                        </div>
                        <div class="col-md-3 document-type-other-wrap" style="display:none;">
                            <label class="form-label">Document Name</label>
                            <input type="text" class="form-control" name="documents[${documentCounter}][type_other]" placeholder="e.g. Voter ID">
                        </div>
                        <div class="col-md-3">
                            <label class="form-label">Document Number <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" name="documents[${documentCounter}][number]" placeholder="Document number">
                        </div>
                        <div class="col-md-2">
                            <label class="form-label">Photo <span class="text-danger">*</span></label>
                            <input type="file" class="form-control document-image" name="documents[${documentCounter}][image]" accept="image/png,image/jpeg,image/webp">
                        </div>
                        <div class="col-md-1">
                            <img class="document-preview" style="display:none;max-height:44px;border-radius:8px;" />
                        </div>
                        <div class="col-md-12 d-flex justify-content-end mt-2">
                            <button type="button" class="btn btn-outline-danger remove-document">
                                <i class="mdi mdi-delete mr-1"></i>Remove
                            </button>
                        </div>
                    </div>
                </div>`;
            $('#documentsContainer').append(rowHtml);
        }

        function syncItemTypeState($row) {
            const isBulk = $row.find('.item-type').val() === 'bulk';

            $row.find('.item-search-label').html((isBulk ? 'Accessory / SKU' : 'IMEI') + ' <span class="text-danger">*</span> <small class="text-danger item-search-error" style="display:none;"></small>');
            $row.find('.item-search').attr('placeholder', isBulk ? 'Search accessory or SKU..' : 'Search IMEI..');
            $row.find('.item-quantity').prop('readonly', !isBulk).val(isBulk ? ($row.find('.item-quantity').val() || 1) : 1);
            $row.find('.item-warranty').prop('disabled', isBulk).val(isBulk ? '' : $row.find('.item-warranty').val());
            $row.find('.item-warranty-label').toggle(!isBulk);
            $row.find('.item-warranty').closest('.col-md-2').toggle(!isBulk);
            clearSelectedInventory($row, true);
            calculateItemTotal($row);
        }

        function clearSelectedInventory($row, clearSearch = true) {
            if (clearSearch) {
                $row.find('.item-search').val('');
            }

            $row.find('.item-id').val('');
            $row.find('.item-description').val('');
            $row.find('.item-price').val('0.00');
            $row.find('.item-total').val('0.00');
            $row.find('.item-suggestions').removeClass('show').empty();
            $row.find('.item-search-error').hide();
        }

        function getSelectedItemIds($currentRow) {
            const selectedIds = [];

            $('.item-row').each(function () {
                const $row = $(this);
                if ($row[0] === $currentRow[0]) {
                    return;
                }

                const selectedId = $row.find('.item-id').val();
                if (selectedId) {
                    selectedIds.push(String(selectedId));
                }
            });

            return selectedIds;
        }

        function buildItemDescription(item) {
            let desc = `Model: ${item['model'] || ''}\n`;

            if (item['sku']) desc += `SKU: ${item['sku']}\n`;
            if (item['color']) desc += `Color: ${item['color']}\n`;
            if (item['storage']) desc += `Storage: ${item['storage']}\n`;
            if (item['imei']) {
                desc += `IMEI: ${item['imei']}`;
            } else if (typeof item['available_quantity'] !== 'undefined') {
                desc += `Available Qty: ${item['available_quantity']}`;
            }

            return desc.trim();
        }

        function searchInventory($row) {
            const suggestions = $row.find(".item-suggestions")[0];
            const query = ($row.find('.item-search').val() || '').trim();
            const itemType = $row.find('.item-type').val();
            if (!query) return;

            const selectedIds = getSelectedItemIds($row);
            const endpoint = itemType === 'bulk' ? `/admin/fetchbulkstock/${encodeURIComponent(query)}` : `/admin/fetchstockonimei/${encodeURIComponent(query)}`;

            $.ajax({
                url: endpoint,
                type: 'GET',
                success: function (data) {
                    suggestions.innerHTML = "";
                    $row.find('.item-search-error').hide();

                    const filteredData = (data || []).filter(item => !selectedIds.includes(String(item['id'] || '')));

                    if (filteredData.length === 0) {
                        $row.find('.item-search-error').text(itemType === 'bulk' ? 'No bulk stock found for this search' : 'No available IMEI found for this search').show();
                        suggestions.classList.remove("show");
                        return;
                    }

                    filteredData.forEach(item => {
                        let option = document.createElement("a");
                        option.classList.add("list-group-item", "list-group-item-action");
                        option.textContent = itemType === 'bulk'
                            ? `${item['model']} (${item['available_quantity']} available)`
                            : `${item['imei']} - ${item['model']}`;
                        option.href = "#";

                        // Selection is bound to mousedown (not click) and prevents the
                        // default so the input never blurs. Binding to click instead lets
                        // mousedown -> blur fire first, which kicks off a fresh
                        // searchInventory() call whose async response lands after this
                        // handler's own cleanup and reopens the dropdown right after pick.
                        option.addEventListener("mousedown", function (e) {
                            e.preventDefault();
                            $row.find('.item-search').val(itemType === 'bulk' ? (item['sku'] || item['model']) : item['imei']);
                            $row.find('.item-id').val(item['id']);
                            $row.find('.item-description').val(buildItemDescription(item));
                            $row.find('.item-price').val(item['purchase_price']).trigger('input');
                            if (itemType !== 'bulk') {
                                $row.find('.item-quantity').val(1);
                            }

                            suggestions.classList.remove("show");
                            suggestions.innerHTML = "";
                            const searchInput = $row.find('.item-search')[0];
                            const length = searchInput.value.length;
                            searchInput.focus();
                            searchInput.setSelectionRange(length, length);
                        });

                        suggestions.appendChild(option);
                    });

                    suggestions.classList.add("show");
                },
                error: function () {
                    $row.find('.item-search-error').text(itemType === 'bulk' ? 'Bulk item not found' : 'IMEI not found').show();
                }
            });
        }

        function calculateItemTotal($row) {
            const qty = parseFloat($row.find('.item-quantity').val()) || 1;
            const price = parseFloat($row.find('.item-price').val()) || 0;
            const total = qty * price;
            $row.find('.item-total').val(total.toFixed(2));
            calculateTotals();
        }

        function calculateTotals() {
            let total = 0;
            $('.item-total').each(function () {
                total += parseFloat($(this).val()) || 0;
            });
            $('#totalAmountInput').val(total.toFixed(2));
            $('#totalAmountDisplay').text(total.toFixed(2));
            calculateNetAmount();
        }

        function calculateNetAmount() {
            const total = parseFloat($('#totalAmountInput').val()) || 0;
            const discount = parseFloat($('#discAmount').val()) || 0;
            const gstMode = $('#gstMode').length ? $('#gstMode').val() : 'none';

            let cgst = 0, sgst = 0, igst = 0;
            if (gstMode !== 'none') {
                cgst = parseFloat($('#cgst').val()) || 0;
                sgst = parseFloat($('#sgst').val()) || 0;
                igst = parseFloat($('#igst').val()) || 0;
            }

            let cgstAmt = 0, sgstAmt = 0, igstAmt = 0, tax = 0, net = 0, subtotal = total;

            if (gstMode === 'include') {
                // Item prices already include GST — back the tax portion out of
                // the total instead of adding it on top, so the customer-facing
                // total doesn't change just because GST is being itemized. The
                // displayed "Subtotal" is this tax-exclusive taxable value, so
                // Subtotal + GST - Discount reads as Net Amount on screen.
                const combinedRate = cgst + sgst + igst;
                const taxable = combinedRate > 0 ? total / (1 + combinedRate / 100) : total;
                tax = total - taxable;
                subtotal = taxable;
                cgstAmt = combinedRate > 0 ? tax * (cgst / combinedRate) : 0;
                sgstAmt = combinedRate > 0 ? tax * (sgst / combinedRate) : 0;
                igstAmt = combinedRate > 0 ? tax * (igst / combinedRate) : 0;
                net = total - discount;
            } else if (gstMode === 'exclude') {
                cgstAmt = (cgst / 100) * total;
                sgstAmt = (sgst / 100) * total;
                igstAmt = (igst / 100) * total;
                tax = cgstAmt + sgstAmt + igstAmt;
                net = total + tax - discount;
            } else {
                // 'none' — no GST at all on this invoice.
                net = total - discount;
            }

            $('#cgstDisplay').text(cgstAmt.toFixed(2));
            $('#sgstDisplay').text(sgstAmt.toFixed(2));
            $('#igstDisplay').text(igstAmt.toFixed(2));
            $('#cgstAmount').val(cgstAmt.toFixed(2));
            $('#sgstAmount').val(sgstAmt.toFixed(2));
            $('#igstAmount').val(igstAmt.toFixed(2));
            $('#taxDisplay').text(tax.toFixed(2));
            $('#taxAmount').val(tax.toFixed(2));
            $('#discountAmount').text(discount.toFixed(2));
            $('#totalAmountDisplay').text(subtotal.toFixed(2));
            $('#netAmountDisplay').text(net.toFixed(2));
            $('#netAmount').val(net.toFixed(2));

            const combinedRate = cgst + sgst + igst;
            $('#gstRateDisplay').text(combinedRate % 1 === 0 ? combinedRate : combinedRate.toFixed(2));
            $('#taxSummaryRow').toggle(gstMode !== 'none' && tax > 0);

            if (typeof updateSplitPaymentRemaining === 'function') {
                updateSplitPaymentRemaining();
            }
        }

        function toggleGstRateFields() {
            const $fields = $('#gstRateFields');
            if (!$fields.length) {
                return;
            }
            $fields.toggle($('#gstMode').val() !== 'none');
        }

        $(document).on('change', '#gstMode', function () {
            toggleGstRateFields();
            calculateNetAmount();
        });
        toggleGstRateFields();

        // A Tax Invoice needs an actual GST breakdown to make sense — if GST is
        // configured for this company but the mode is still "None", nudge it to
        // "Exclude GST" instead of silently printing a tax invoice with no tax on it.
        $(document).on('change', '#invoiceType', function () {
            const $gstMode = $('#gstMode');
            if ($(this).val() === 'tax' && $gstMode.length && $gstMode.val() === 'none') {
                $gstMode.val('exclude').trigger('change');
            }
        });

        $('#qrUploadModal').on('show.bs.modal', function () {
            qrUploadToken = null;
            $('#qrUploadCode').empty();
            $('#qrUploadStatus').text('Generating code...');
            $('#qrUploadCheckBtn').prop('disabled', true);

            $.ajax({
                url: "{{ route('document-uploads.create') }}",
                type: 'POST',
                success: function (response) {
                    qrUploadToken = response.token;
                    new QRCode(document.getElementById('qrUploadCode'), {
                        text: response.url,
                        width: 200,
                        height: 200,
                    });
                    $('#qrUploadStatus').text('Waiting for upload...');
                    $('#qrUploadCheckBtn').prop('disabled', false);
                },
                error: function () {
                    $('#qrUploadStatus').text('Could not generate a code. Please try again.');
                }
            });
        });

        $('#qrUploadModal').on('hidden.bs.modal', function () {
            qrUploadToken = null;
            $('#qrUploadCode').empty();
        });

        $('#qrUploadCheckBtn').on('click', function () {
            if (!qrUploadToken) {
                return;
            }

            const $btn = $(this);
            $btn.prop('disabled', true);
            $('#qrUploadStatus').text('Checking...');

            $.ajax({
                url: "{{ url('/admin/document-uploads') }}/" + qrUploadToken + '/status',
                type: 'GET',
                success: function (response) {
                    $btn.prop('disabled', false);

                    if (response.status === 'uploaded') {
                        addPendingDocumentRow(response);
                        appendDocumentNoteToFirstItem(response);
                        $('#qrUploadModal').modal('hide');
                    } else if (response.status === 'pending') {
                        $('#qrUploadStatus').text('Not uploaded yet — scan and submit on the phone, then check again.');
                    } else {
                        $('#qrUploadStatus').text('This code is no longer valid. Close and reopen to get a fresh one.');
                    }
                },
                error: function () {
                    $btn.prop('disabled', false);
                    $('#qrUploadStatus').text('Could not check right now. Try again.');
                }
            });
        });

        function addPendingDocumentRow(doc) {
            documentCounter++;
            const rowHtml = `
                <div class="item-row" data-index="${documentCounter}">
                    <div class="row g-2 align-items-center">
                        <div class="col-md-3">
                            <label class="form-label">Document Type</label>
                            <input type="text" class="form-control" value="${doc.document_type_label}" readonly>
                            <input type="hidden" name="documents[${documentCounter}][type]" value="${doc.document_type}">
                            <input type="hidden" name="documents[${documentCounter}][type_other]" value="${doc.document_type_other || ''}">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Document Number</label>
                            <input type="text" class="form-control" name="documents[${documentCounter}][number]" value="${doc.document_number}">
                        </div>
                        <div class="col-md-3">
                            <span class="badge badge-success"><i class="mdi mdi-cellphone-check mr-1"></i>Uploaded via phone</span>
                            <input type="hidden" name="documents[${documentCounter}][pending_token]" value="${doc.token}">
                        </div>
                        <div class="col-md-2 d-flex justify-content-end">
                            <button type="button" class="btn btn-outline-danger remove-document">
                                <i class="mdi mdi-delete mr-1"></i>Remove
                            </button>
                        </div>
                    </div>
                </div>`;
            $('#documentsContainer').append(rowHtml);
        }

        function appendDocumentNoteToFirstItem(doc) {
            const $description = $('#itemsContainer .item-row').first().find('.item-description');
            if (!$description.length) {
                return;
            }
            const last4 = (doc.document_number || '').slice(-4);
            const note = 'ID Verified: ' + doc.document_type_label + (last4 ? ' ending ' + last4 : '');
            const existing = $description.val();
            $description.val(existing ? existing + '\n' + note : note);
        }
    </script>
@endsection
