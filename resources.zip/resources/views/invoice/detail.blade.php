@extends('layout.app')

@section('title')
    Invoice Detail
@endsection
@section('content')
<div class="container-fluid">

    <div class="row">
        <div class="col-12">
            <div class="page-title-box">
                <h4 class="page-title font-weight-bold"> INVOICE DETAIL: #{{ $invoice->invoice_no }}</h4>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-12">
            <div class="card-box">
                <a href="{{ route('allinvoices') }}" class="btn btn-sm btn-blue waves-effect waves-light ">
                    <i class="mdi mdi-plus-circle"></i> Back
                </a>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-12">
            <div class="card-box">
                <h5 class="mb-3"><i class="mdi mdi-cart-outline me-1"></i> Items</h5>
                <div class="table-responsive">
                    <table class="table table-bordered mb-0">
                        <thead>
                            <tr>
                                <th>Item</th>
                                <th>Qty</th>
                                <th>Unit Price</th>
                                <th>Total</th>
                                <th>Returned</th>
                                <th style="width: 140px;">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach ($invoice->items as $item)
                                @php
                                    $returned = (int) ($returnedQuantities[$item->id] ?? 0);
                                    $returnable = max(0, (int) $item->quantity - $returned);
                                @endphp
                                <tr>
                                    <td>{!! nl2br(e($item->item_description)) !!}</td>
                                    <td>{{ $item->quantity }}</td>
                                    <td>₹{{ number_format($item->unit_price, 2) }}</td>
                                    <td>₹{{ number_format($item->total_amount, 2) }}</td>
                                    <td>{{ $returned }}</td>
                                    <td>
                                        @can('returns.create')
                                            @if ($returnable > 0 && $item->purchase)
                                                <button type="button" class="btn btn-sm btn-outline-danger open-return-modal"
                                                    data-item-id="{{ $item->id }}"
                                                    data-item-label="{{ $item->item_description }}"
                                                    data-returnable="{{ $returnable }}"
                                                    data-unit-price="{{ $item->unit_price }}">
                                                    Return
                                                </button>
                                            @else
                                                <span class="text-muted">—</span>
                                            @endif
                                        @endcan
                                    </td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    @can('returns.create')
        <div class="modal fade" id="returnItemModal" tabindex="-1" role="dialog" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content p-3">
                    <div class="modal-header">
                        <h5 class="modal-title">Return Item</h5>
                        <button type="button" class="close" data-dismiss="modal"><span>&times;</span></button>
                    </div>
                    <form action="{{ route('sale-returns.store') }}" method="POST">
                        @csrf
                        <input type="hidden" name="invoice_item_id" id="returnInvoiceItemId">
                        <div class="modal-body">
                            <p class="mb-3" id="returnItemLabel"></p>
                            <div class="form-group">
                                <label>Quantity to Return</label>
                                <input type="number" name="quantity" id="returnQuantity" class="form-control" min="1" required>
                            </div>
                            <div class="form-group">
                                <label>Condition</label>
                                <select name="condition" class="form-control" required>
                                    <option value="resellable">Resellable (restock)</option>
                                    <option value="damaged">Damaged (do not restock)</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label>Reason</label>
                                <input type="text" name="reason" class="form-control" placeholder="e.g. Customer changed mind, defective unit">
                            </div>
                            <div class="form-group">
                                <label>Notes (optional)</label>
                                <textarea name="notes" class="form-control" rows="2"></textarea>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                            <button type="submit" class="btn btn-danger">Process Return</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    @endcan

    @if($invoice->documents->isNotEmpty())
        <div class="row">
            <div class="col-12">
                <div class="card-box">
                    <h5 class="mb-3"><i class="mdi mdi-card-account-details-outline me-1"></i> Customer Identity Documents</h5>
                    <div class="row g-2">
                        @foreach($invoice->documents as $document)
                            <div class="col-md-3">
                                <div class="border rounded p-2 text-center">
                                    <img src="{{ $document->image_url }}" alt="{{ $document->document_type_label }}"
                                        style="max-height:110px;max-width:100%;border-radius:6px;">
                                    <div class="small fw-semibold mt-1">{{ $document->document_type_label }}</div>
                                    <div class="small text-muted">{{ $document->masked_number }}</div>
                                </div>
                            </div>
                        @endforeach
                    </div>
                </div>
            </div>
        </div>
    @endif
</div>
@endsection

@can('returns.create')
    @section('scripts')
        <script>
            $(document).on('click', '.open-return-modal', function () {
                const itemId = $(this).data('item-id');
                const label = $(this).data('item-label');
                const returnable = $(this).data('returnable');

                $('#returnInvoiceItemId').val(itemId);
                $('#returnItemLabel').text(label + ' — up to ' + returnable + ' unit(s) can be returned.');
                $('#returnQuantity').attr('max', returnable).val(1);

                $('#returnItemModal').modal('show');
            });
        </script>
    @endsection
@endcan