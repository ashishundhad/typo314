<?php $companySetting = \App\Models\CompanySetting::current(); ?>
<div class="invoice-box">
    <h2>{{ $invoice->invoice_type === 'tax' ? 'TAX INVOICE' : 'RECEIPT' }}</h2>

    <div class="invoice-header">
        <div class="company-block">
            @if($companySetting->logo)
                <img src="{{ asset($companySetting->logo) }}" alt="Logo" class="company-logo">
            @endif
            @if($companySetting->gst_enabled && $companySetting->gst_number)
                <div class="company-gstin"><b>GSTIN:</b> {{ $companySetting->gst_number }}</div>
            @endif
            <div class="company-address">
                <p>
                    {{ $companySetting->company_name }}<br>
                    @if($companySetting->address)
                        {{ $companySetting->address }}<br>
                    @endif
                    @if($companySetting->phone)
                        <b>Mo:</b> {{ $companySetting->phone }}<br>
                    @endif
                </p>
            </div>
        </div>

        <div class="invoice-details">
            <p><b>Invoice No:</b> #{{ $invoice->invoice_no }}</p>
            <p><b>Date:</b> {{ date('d/m/Y', strtotime($invoice->invoice_date)) }} {{ $invoice->created_at?->format('h:i A') }}</p>
        </div>
    </div>

    <div class="bill-to-box">
        <div>
            <div class="bill-to-box__label">Bill To</div>
            <div class="bill-to-box__name">{{ $invoice->customer_name }}</div>
            <div class="bill-to-box__meta">
                @if($invoice->customer_no)
                    Mobile: {{ $invoice->customer_no }}
                @else
                    Mobile: N/A
                @endif
            </div>
        </div>
    </div>

    <table>
        <thead>
            <tr>
                <th>#</th>
                <th>Particulars</th>
                <th>Qty</th>
                <th>Rate</th>
                <th>Amount</th>
            </tr>
        </thead>
        <tbody>
            @foreach($invoice->items as $index => $item)
                <tr>
                    <td align="center">{{ $index + 1 }}</td>
                    <td class="item-particulars">
                        @php echo nl2br($item->item_description) @endphp
                        @if($item->warranty_expiry_date)
                            <br><small><b>Warranty:</b> {{ date('d/m/Y', strtotime($item->warranty_expiry_date)) }}</small>
                        @endif
                    </td>
                    <td align="center">{{ $item->quantity }}</td>
                    <td align="right">₹{{ number_format($item->unit_price, 2) }}</td>
                    <td align="right">₹{{ number_format($item->total_amount, 2) }}</td>
                </tr>
            @endforeach
        </tbody>
    </table>

    <?php
        // When GST is "include" mode, item prices already contain tax, so total_amount
        // is tax-inclusive — show the tax-exclusive taxable value here instead, so
        // Subtotal + CGST + SGST (+ IGST) - Discount reads correctly as Net Total,
        // rather than double-counting the tax that's already baked into total_amount.
        $documentSubtotal = $invoice->gst_mode === 'include'
            ? $invoice->total_amount - ($invoice->tax_amount ?? 0)
            : $invoice->total_amount;
    ?>
    <table>
        <tbody>
            <tr class="totals">
                <td colspan="4">{{ $invoice->invoice_type === 'tax' ? 'Taxable Amount' : 'Subtotal' }}</td>
                <td>₹{{ number_format($documentSubtotal, 2) }}</td>
            </tr>
            @if($invoice->cgst_amount)
                <tr>
                    <td colspan="4" align="right">CGST ({{ $invoice->cgst_rate }}%)</td>
                    <td align="right">₹{{ number_format($invoice->cgst_amount, 2) }}</td>
                </tr>
            @endif
            @if($invoice->sgst_amount)
                <tr>
                    <td colspan="4" align="right">SGST ({{ $invoice->sgst_rate }}%)</td>
                    <td align="right">₹{{ number_format($invoice->sgst_amount, 2) }}</td>
                </tr>
            @endif
            @if($invoice->igst_amount)
                <tr>
                    <td colspan="4" align="right">IGST ({{ $invoice->igst_rate }}%)</td>
                    <td align="right">₹{{ number_format($invoice->igst_amount, 2) }}</td>
                </tr>
            @endif
            @if($invoice->discount)
                <tr>
                    <td colspan="4" align="right">Discount</td>
                    <td align="right">₹{{ number_format($invoice->discount, 2) }}</td>
                </tr>
            @endif
            <tr class="totals net-total-row">
                <td colspan="4">Net Total</td>
                <td>₹{{ number_format($invoice->net_amount, 2) }}</td>
            </tr>
        </tbody>
    </table>

    <div class="amount-words">
        Amount (in words): {{ $amountInWords }}
    </div>

    <div class="terms-image" style="margin-top: 10px; border-top: 2px solid #0986c6; padding-top: 10px;">
        <img src="{{ asset('assets/images/terms.png') }}" alt="Terms & Conditions" style="width: 100%; max-width: 100%;">
    </div>

    <div class="thanks-text">
        Thanks for Visit!
    </div>
    <div class="invoice-footer">
        Authorised Signatory<br><b>{{ $companySetting->company_name }}</b>
    </div>
</div>
