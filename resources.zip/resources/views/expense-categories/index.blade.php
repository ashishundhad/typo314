@extends('layout.app')

@section('title', 'Expense Categories')

@section('content')
    <div class="container-fluid">
        <div class="row align-items-center">
            <div class="col-md-6 mt-2 mb-2">
                <h4 class="page-title">Expense Categories</h4>
            </div>
            <div class="col-md-6 d-flex justify-content-end">
                <a href="{{ route('expenses') }}" class="btn btn-light mr-2">
                    <i class="mdi mdi-arrow-left"></i> Back to Expenses
                </a>
                @can('expense-categories.create')
                    <button type="button" class="btn btn-success" data-toggle="modal" data-target="#categoryModal">
                        Add Category
                    </button>
                @endcan
            </div>
        </div>

        <div class="card-box">
            <table id="categoryTable" class="table table-bordered">
                <thead>
                    <tr>
                        <th style="width: 5%;">#</th>
                        <th>Name</th>
                        <th>Expenses Using It</th>
                        <th style="width: 15%;">Action</th>
                    </tr>
                </thead>
                <tbody></tbody>
            </table>
        </div>

        @canany(['expense-categories.create', 'expense-categories.edit'])
            <div class="modal fade" id="categoryModal" tabindex="-1" role="dialog" aria-labelledby="categoryModalLabel" aria-hidden="true">
                <div class="modal-dialog" role="document">
                    <div class="modal-content p-3">
                        <div class="modal-header">
                            <h5 class="modal-title">Add Category</h5>
                            <button type="button" class="close" data-dismiss="modal">
                                <span>&times;</span>
                            </button>
                        </div>
                        <form action="{{ route('expense-categories.store') }}" method="POST">
                            @csrf
                            <input type="hidden" name="id" value="{{ old('id') }}">
                            <div class="modal-body">
                                <div class="form-group">
                                    <label>Category Name</label>
                                    <input value="{{ old('name') }}" type="text" name="name" class="form-control" required>
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                                <button type="submit" class="btn btn-primary modal-button">Create Category</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        @endcanany
    </div>
@endsection

@section('scripts')
    <script>
        $(function () {
            $('#categoryTable').DataTable({
                processing: true,
                serverSide: true,
                ajax: "{{ route('expense-categories.index') }}",
                columns: [
                    { data: 'DT_RowIndex', name: 'DT_RowIndex', className: 'text-center' },
                    { data: 'name', name: 'name' },
                    { data: 'expenses_count', name: 'expenses_count', className: 'text-center' },
                    {
                        data: 'id',
                        name: 'action',
                        className: 'text-center',
                        orderable: false,
                        searchable: false,
                        render: function (data, type, row) {
                            let html = '';
                            @can('expense-categories.edit')
                                html += '<button class="btn btn-primary btn-sm edit-category mr-2" data-id="' + row.id + '" data-name="' + row.name + '"><i class="fas fa-edit"></i></button>';
                            @endcan
                            @can('expense-categories.delete')
                                html += '<button class="btn btn-danger btn-sm delete-category" data-id="' + row.id + '" data-count="' + row.expenses_count + '"><i class="fas fa-trash"></i></button>';
                            @endcan
                            return html;
                        }
                    }
                ]
            });
        });

        $(document).on('click', '.edit-category', function () {
            const id = $(this).data('id');
            const name = $(this).data('name');
            const form = $('#categoryModal form');

            form.find('input[name="id"]').val(id);
            form.find('input[name="name"]').val(name);
            $('#categoryModal .modal-title').text('Edit Category');
            $('#categoryModal .modal-button').text('Update Category');
            $('#categoryModal').modal('show');
        });

        $('#categoryModal').on('hidden.bs.modal', function () {
            const form = $('#categoryModal form');
            form[0].reset();
            form.find('input[name="id"]').val('');
            $('#categoryModal .modal-title').text('Add Category');
            $('#categoryModal .modal-button').text('Create Category');
        });

        $('#categoryModal form').on('submit', function (e) {
            e.preventDefault();
            const form = $(this);

            $.ajax({
                url: form.attr('action'),
                type: 'POST',
                data: form.serialize(),
                success: function (response) {
                    if (response.status) {
                        toastr.success(response.message);
                        $('#categoryModal').modal('hide');
                        $('body').removeClass('modal-open');
                        $('.modal-backdrop').remove();
                        $('#categoryTable').DataTable().ajax.reload();
                    } else {
                        toastr.error(response.message || 'Failed to save category.');
                    }
                },
                error: function (xhr) {
                    const msg = xhr.responseJSON?.message || 'Something went wrong.';
                    toastr.error(msg);
                }
            });
        });

        $(document).on('click', '.delete-category', function () {
            const id = $(this).data('id');
            const count = $(this).data('count');

            if (count > 0) {
                toastr.error('This category is used by ' + count + ' expense(s) and cannot be deleted.');
                return;
            }

            Swal.fire({
                title: 'Are you sure?',
                text: "You won't be able to revert this!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Yes, delete it!'
            }).then((result) => {
                if (result.isConfirmed) {
                    $.ajax({
                        url: '{{ route("expense-categories.destroy", ":id") }}'.replace(':id', id),
                        type: 'DELETE',
                        data: { _token: '{{ csrf_token() }}' },
                        success: function (response) {
                            toastr.success(response.message || 'Category deleted successfully');
                            $('#categoryTable').DataTable().ajax.reload();
                        },
                        error: function (xhr) {
                            const msg = xhr.responseJSON?.message || 'Failed to delete category';
                            toastr.error(msg);
                            $('#categoryTable').DataTable().ajax.reload();
                        }
                    });
                }
            });
        });
    </script>
@endsection
