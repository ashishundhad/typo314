@extends('layout.app')

@section('title')
    Company Settings
@endsection

@section('content')
<div class="settings-shell">
    <div class="container-fluid">

        @if(session('message'))
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                {{ session('message') }}
                <button type="button" class="close" data-dismiss="alert">&times;</button>
            </div>
        @endif

        @php
            // gst_number/gst_percentage errors render inline under their own fields below,
            // so they're excluded here to avoid showing the same message twice.
            $topLevelErrors = collect($errors->getMessages())->except(['gst_number', 'gst_percentage'])->flatten();
        @endphp
        @if($topLevelErrors->isNotEmpty())
            <div class="alert alert-danger">
                <ul class="mb-0">
                    @foreach($topLevelErrors as $error)
                        <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
        @endif

        <div class="row">
            <div class="col-lg-9">
                <div class="card settings-card">
                    <div class="card-body">
                        <form method="POST" action="{{ route('admin.settings.update') }}" enctype="multipart/form-data">
                            @csrf
                            @method('PUT')

                            <div class="settings-section">
                                <!-- <div class="settings-section__eyebrow">Company</div> -->
                                <h2 class="settings-section__title">Store Information</h2>
                                <p class="settings-section__subtitle">Shown on invoices, receipts, and printed reports across the app.</p>

                                <div class="settings-panel">
                                    <div class="row">
                                        <div class="col-md-6 mb-3">
                                            <label class="settings-label">Store Name</label>
                                            <input type="text" class="form-control settings-input" name="company_name"
                                                value="{{ old('company_name', $setting->company_name) }}" required>
                                        </div>
                                        <div class="col-md-6 mb-3">
                                            <label class="settings-label">Phone</label>
                                            <input type="text" class="form-control settings-input" name="phone"
                                                value="{{ old('phone', $setting->phone) }}">
                                        </div>

                                        <div class="col-md-6 mb-3">
                                            <label class="settings-label">Email</label>
                                            <input type="email" class="form-control settings-input" name="email"
                                                value="{{ old('email', $setting->email) }}">
                                        </div>
                                        <div class="col-md-6 mb-3">
                                            <label class="settings-label">Logo</label>
                                            <input type="file" class="form-control settings-input" name="logo" accept="image/*">
                                            @if($setting->logo)
                                                <img src="{{ asset($setting->logo) }}" alt="Current logo" class="settings-logo-preview" height="50">
                                            @endif
                                        </div>

                                        <div class="col-md-12">
                                            <label class="settings-label">Address</label>
                                            <textarea class="form-control settings-input" name="address" rows="2">{{ old('address', $setting->address) }}</textarea>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="settings-section">
                                <!-- <div class="settings-section__eyebrow">Tax</div> -->
                                <h2 class="settings-section__title">GST Settings</h2>
                                <p class="settings-section__subtitle">Enable GST to show tax fields on invoices and reports.</p>

                                <div class="settings-panel">
                                    <div class="form-group custom-control custom-switch mb-3">
                                        <input type="hidden" name="gst_enabled" value="0">
                                        <input type="checkbox" class="custom-control-input" id="gstEnabled" name="gst_enabled" value="1"
                                            {{ old('gst_enabled', $setting->gst_enabled) ? 'checked' : '' }}>
                                        <label class="custom-control-label" for="gstEnabled">Enable GST</label>
                                    </div>

                                    <div id="gstNumberGroup" class="row" style="{{ old('gst_enabled', $setting->gst_enabled) ? '' : 'display:none;' }}">
                                        <div class="col-md-6 mb-3">
                                            <label class="settings-label">GST Number (GSTIN)</label>
                                            <input type="text" class="form-control settings-input @error('gst_number') is-invalid @enderror"
                                                name="gst_number" value="{{ old('gst_number', $setting->gst_number) }}"
                                                placeholder="e.g. 24ABCDE1234F1Z5">
                                            @error('gst_number')
                                                <div class="invalid-feedback d-block">{{ $message }}</div>
                                            @enderror
                                        </div>

                                        <div class="col-md-3 mb-3">
                                            <label class="settings-label">GST Percentage (%)</label>
                                            <input type="number" step="0.01" min="0" max="100"
                                                class="form-control settings-input @error('gst_percentage') is-invalid @enderror"
                                                name="gst_percentage" value="{{ old('gst_percentage', $setting->gst_percentage) }}"
                                                placeholder="e.g. 18">
                                            @error('gst_percentage')
                                                <div class="invalid-feedback d-block">{{ $message }}</div>
                                            @enderror
                                        </div>

                                        <div class="col-md-3 mb-3">
                                            <label class="settings-label">Prices Entered As</label>
                                            <?php $currentGstMode = old('default_gst_mode', $setting->default_gst_mode ?? 'exclude'); ?>
                                            <select class="form-control settings-input" name="default_gst_mode">
                                                <option value="exclude" @selected($currentGstMode === 'exclude')>Excluding GST</option>
                                                <option value="include" @selected($currentGstMode === 'include')>Including GST</option>
                                                <option value="none" @selected($currentGstMode === 'none')>None (don't count GST by default)</option>
                                            </select>
                                            <small class="form-text text-muted">"None" still shows your GSTIN on invoices — it just won't apply tax by default when creating one.</small>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="settings-actions">
                                <button type="submit" class="btn settings-btn btn-primary">Save Settings</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    document.getElementById('gstEnabled').addEventListener('change', function () {
        document.getElementById('gstNumberGroup').style.display = this.checked ? '' : 'none';
    });
</script>
@endsection
