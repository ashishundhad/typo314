<div class="supplier-ledger-detail-view">
    <div class="supplier-ledger-detail-hero">
        <div class="row align-items-center">
            <div class="col-lg-8">
                <!-- <div class="supplier-ledger-detail-hero__eyebrow">Supplier Ledger</div> -->
                <h1 class="supplier-ledger-detail-hero__title">{{ $supplierName }}</h1>
                <p class="supplier-ledger-detail-hero__meta">
                    {{ $timePeriod }}
                    @if($contactno)
                        | Contact: {{ $contactno }}
                    @endif
                    @if($latestPurchaseDate)
                        | Last purchase: {{ \Carbon\Carbon::parse($latestPurchaseDate)->format('d M Y') }}
                    @endif
                </p>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-md-6 col-xl-3 mb-3">
            <div class="card supplier-ledger-detail-metric">
                <div class="card-body">
                    <div class="supplier-ledger-detail-metric__label">Purchased Items</div>
                    <div class="supplier-ledger-detail-metric__value">{{ number_format($totalItems) }}</div>
                </div>
            </div>
        </div>
        <div class="col-md-6 col-xl-3 mb-3">
            <div class="card supplier-ledger-detail-metric">
                <div class="card-body">
                    <div class="supplier-ledger-detail-metric__label">Purchase Cost</div>
                    <div class="supplier-ledger-detail-metric__value">{{ config('constant.currency') }}{{ number_format($totalPurchaseAmount, 2) }}</div>
                </div>
            </div>
        </div>
        <div class="col-md-6 col-xl-3 mb-3">
            <div class="card supplier-ledger-detail-metric">
                <div class="card-body">
                    <div class="supplier-ledger-detail-metric__label">Repairing</div>
                    <div class="supplier-ledger-detail-metric__value">{{ config('constant.currency') }}{{ number_format($totalRepairingAmount, 2) }}</div>
                </div>
            </div>
        </div>
        <div class="col-md-6 col-xl-3 mb-3">
            <div class="card supplier-ledger-detail-metric">
                <div class="card-body">
                    <div class="supplier-ledger-detail-metric__label">Sold / Available</div>
                    <div class="supplier-ledger-detail-metric__value">{{ $soldItems }} / {{ $availableItems }}</div>
                </div>
            </div>
        </div>
    </div>

    <div class="card supplier-ledger-detail-card">
        <div class="card-body">
            <h2 class="supplier-ledger-detail-card__title">Purchase List</h2>
            <p class="supplier-ledger-detail-card__subtitle"></p>

            <div class="supplier-ledger-detail-filter">
                <form method="GET" class="js-supplier-ledger-modal-form" action="{{ route('supplier-ledger-detail') }}">
                    <input type="hidden" name="supplier" value="{{ $supplierFilter }}">
                    <input type="hidden" name="modal" value="1">
                    <div class="form-row align-items-end">
                        <div class="col-12 col-md-3 mb-3">
                            <label class="supplier-ledger-detail-label" for="detail-period">Report Period</label>
                            <select name="period" class="form-control" id="detail-period">
                                <option value="alls" @selected($period === 'alls')>All Time</option>
                                <option value="thismonth" @selected($period === 'thismonth')>This Month</option>
                                <option value="lastmonth" @selected($period === 'lastmonth')>Last Month</option>
                                <option value="thisyear" @selected($period === 'thisyear')>This Year</option>
                                <option value="lastyear" @selected($period === 'lastyear')>Last Year</option>
                                <option value="custom" @selected($period === 'custom')>Custom Range</option>
                            </select>
                        </div>
                        <div class="col-md-2 mb-3 supplier-ledger-detail-date-group @if($period === 'custom') d-block @endif">
                            <label class="supplier-ledger-detail-label" for="detail-fromdate">From Date</label>
                            <input type="date" id="detail-fromdate" name="fromdate" class="form-control" value="{{ $fromdate }}">
                        </div>
                        <div class="col-md-2 mb-3 supplier-ledger-detail-date-group @if($period === 'custom') d-block @endif">
                            <label class="supplier-ledger-detail-label" for="detail-todate">To Date</label>
                            <input type="date" id="detail-todate" name="todate" class="form-control" value="{{ $todate }}">
                        </div>
                        <div class="col-12 col-md-2 mb-3">
                            <label class="supplier-ledger-detail-label" for="detail-status">Stock Status</label>
                            <select name="status" class="form-control" id="detail-status">
                                <option value="" @selected($status === '')>All</option>
                                <option value="available" @selected($status === 'available')>Available</option>
                                <option value="sold" @selected($status === 'sold')>Sold</option>
                            </select>
                        </div>
                        <div class="col-12 col-md-3 mb-3">
                            <label class="supplier-ledger-detail-label" for="detail-search">Search</label>
                            <input type="text" id="detail-search" name="search" class="form-control" value="{{ $search }}" placeholder="IMEI, model, color, remark">
                        </div>
                        <div class="col-12 col-md-2 mb-3">
                            <button type="submit" class="btn btn-primary supplier-ledger-detail-btn">Filter List</button>
                        </div>
                        <div class="col-12 col-md-2 mb-3">
                            <a href="{{ route('supplier-ledger-detail', ['supplier' => $supplierFilter, 'modal' => 1]) }}" class="btn btn-outline-danger supplier-ledger-detail-btn js-supplier-ledger-modal-link">Clear</a>
                        </div>
                    </div>
                </form>
            </div>

            <div class="table-responsive">
                @if ($purchases->count())
                    <table class="table supplier-ledger-detail-table">
                        <thead>
                            <tr>
                                <th>Purchase Date</th>
                                <th>Device</th>
                                <th>IMEI / Variant</th>
                                <th>Costing</th>
                                <th>Status</th>
                                <th class="text-right">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach ($purchases as $purchase)
                                <tr>
                                    <td>
                                        <div class="supplier-ledger-detail-money">{{ \Carbon\Carbon::parse($purchase->purchase_date)->format('d M Y') }}</div>
                                        @if($purchase->sell_date)
                                            <div class="supplier-ledger-detail-device__meta mt-1">Sold on {{ \Carbon\Carbon::parse($purchase->sell_date)->format('d M Y') }}</div>
                                        @endif
                                    </td>
                                    <td>
                                        <div class="supplier-ledger-detail-device__name">{{ $purchase->model ?: 'Unnamed Device' }}</div>
                                        <div class="supplier-ledger-detail-device__meta">Source: {{ $purchase->purchase_from ?: 'Unknown Supplier' }}</div>
                                        @if($purchase->remark)
                                            <div class="supplier-ledger-detail-note mt-1">{{ $purchase->remark }}</div>
                                        @endif
                                    </td>
                                    <td>
                                        <div class="supplier-ledger-detail-money">{{ $purchase->imei ?: 'N/A' }}</div>
                                        <div class="supplier-ledger-detail-device__meta">Storage: {{ $purchase->storage ?: 'N/A' }}</div>
                                        <div class="supplier-ledger-detail-device__meta">Color: {{ $purchase->color ?: 'N/A' }}</div>
                                    </td>
                                    <td>
                                        <div class="supplier-ledger-detail-money">Buy: {{ config('constant.currency') }}{{ number_format((float) $purchase->purchase_cost, 2) }}</div>
                                        <div class="supplier-ledger-detail-device__meta">Repairing: {{ config('constant.currency') }}{{ number_format((float) ($purchase->repairing_charge ?: 0), 2) }}</div>
                                        <div class="supplier-ledger-detail-device__meta">Stock value: {{ config('constant.currency') }}{{ number_format((float) $purchase->purchase_price, 2) }}</div>
                                    </td>
                                    <td>
                                        <span class="supplier-ledger-detail-status supplier-ledger-detail-status--{{ $purchase->is_sold ? 'sold' : 'available' }}">
                                            {{ $purchase->is_sold ? 'Sold' : 'Available' }}
                                        </span>
                                    </td>
                                    <td class="text-right">
                                        <a href="{{ route('purchase-detail', $purchase->id) }}" class="btn btn-outline-primary supplier-ledger-detail-btn">
                                            Open Stock
                                        </a>
                                    </td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>

                    <div class="mt-3">
                        {{ $purchases->appends(request()->query())->links('vendor.pagination.bootstrap-5') }}
                    </div>
                @else
                    <div class="supplier-ledger-detail-empty">
                        <div class="supplier-ledger-detail-empty__icon">
                            <i class="mdi mdi-package-variant-closed"></i>
                        </div>
                        <h4 class="mb-2">No purchases found</h4>
                        <p class="text-muted mb-0">This supplier has no purchases for the current filters.</p>
                    </div>
                @endif
            </div>
        </div>
    </div>
</div>
