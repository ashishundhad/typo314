@if($documents->isNotEmpty())
    <div class="invoice-preview__documents-grid">
        @foreach($documents as $document)
            <div class="invoice-preview__document-card">
                <a href="{{ $document->image_url }}" target="_blank">
                    <img src="{{ $document->image_url }}" alt="{{ $document->document_type_label }}">
                </a>
                <div class="invoice-preview__document-meta">
                    <span class="invoice-preview__document-type">{{ $document->document_type_label }}</span>
                    <span class="invoice-preview__document-number" data-full="{{ $document->document_number }}" data-masked="{{ $document->masked_number }}">{{ $document->masked_number }}</span>
                    <button type="button" class="invoice-preview__document-reveal" title="Show / hide full number">
                        <i class="mdi mdi-eye-outline"></i>
                    </button>
                    @if($document->invoice)
                        <a href="{{ route('invoice-detail', $document->invoice_id) }}" class="d-block small mt-1" target="_blank">
                            From invoice #{{ $document->invoice->invoice_no }}
                        </a>
                    @endif
                </div>
            </div>
        @endforeach
    </div>
@else
    <div class="supplier-ledger-modal__state">
        <i class="mdi mdi-card-account-details-outline"></i>No identity documents on file for {{ $customer->name }}.
    </div>
@endif
