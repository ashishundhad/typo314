@extends('layout.app')

@section('title')
    Supplier Ledger Detail
@endsection

@section('content')

    <div class="container-fluid supplier-ledger-detail-shell">
        <div class="d-flex justify-content-end mb-3">
            <a href="{{ route('supplier-ledger', request()->except('supplier', 'page')) }}" class="btn btn-light supplier-ledger-detail-btn">
                <i class="mdi mdi-arrow-left mr-1"></i>Back to Ledger
            </a>
        </div>

        @include('reports._supplier-ledger-detail-content')
    </div>

    <script>
        (function () {
            const periodSelect = document.getElementById('detail-period');
            const dateGroups = document.querySelectorAll('.supplier-ledger-detail-date-group');

            if (!periodSelect) {
                return;
            }

            function sync() {
                const showDates = periodSelect.value === 'custom';

                dateGroups.forEach(function (group) {
                    group.style.display = showDates ? 'block' : 'none';
                });
            }

            periodSelect.addEventListener('change', sync);
            sync();
        })();
    </script>
@endsection
