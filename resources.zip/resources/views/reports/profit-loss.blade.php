@extends('layout.app')

@section('title')
    Profit & Loss Statement
@endsection

@section('content')

    <div class="container-fluid profit-loss-shell">
        <div class="profit-loss-hero">
            <div class="row align-items-center">
                <div class="col-lg-7 mb-3 mb-lg-0">
                    <!-- <div class="profit-loss-hero__eyebrow">Reports</div> -->
                    <h1 class="profit-loss-hero__title">Profit & Loss Statement</h1>
                    <p class="profit-loss-hero__subtitle">
                        Track revenue, expenses, and profitability across your chosen time period.
                    </p>
                </div>
                <div class="col-lg-5">
                    <form method="GET" action="{{ route('profit-loss') }}" class="profit-loss-toolbar profit-loss-no-print">
                        <div class="profit-loss-filter">
                            <!-- <label for="timePeriod">Time Period</label> -->
                            <select name="period" id="timePeriod" class="form-control">
                                <option value="today" {{ request()->get('period') === 'today' ? 'selected' : '' }}>Today</option>
                                <option value="week" {{ request()->get('period') === 'week' ? 'selected' : '' }}>This Week</option>
                                <option value="month" {{ request()->get('period') === 'month' ? 'selected' : '' }}>This Month</option>
                                <option value="quarter" {{ request()->get('period') === 'quarter' ? 'selected' : '' }}>This Quarter</option>
                                <option value="year" {{ request()->get('period') === 'year' ? 'selected' : '' }}>This Year</option>
                                <option value="custom" {{ request()->get('period') === 'custom' ? 'selected' : '' }}>Custom Range</option>
                                <option value="alls" {{ request()->get('period') === 'alls' ? 'selected' : '' }}>All Time</option>
                            </select>
                        </div>
                        <div class="profit-loss-filter profit-loss-filter--date {{ request()->get('period') === 'custom' ? 'is-visible' : '' }}" id="fromDateFilter">
                            <label for="profitLossFromDate">From Date</label>
                            <input type="date" name="fromdate" id="profitLossFromDate" class="form-control" value="{{ $fromdate }}">
                        </div>
                        <div class="profit-loss-filter profit-loss-filter--date {{ request()->get('period') === 'custom' ? 'is-visible' : '' }}" id="toDateFilter">
                            <label for="profitLossToDate">To Date</label>
                            <input type="date" name="todate" id="profitLossToDate" class="form-control" value="{{ $todate }}">
                        </div>
                        <button type="submit" class="btn btn-light">Apply</button>
                        <a href="{{ route('profit-loss') }}" class="btn btn-outline-light">Clear</a>
                        <button type="button" class="btn btn-outline-light" onclick="window.print()">Print</button>
                    </form>
                </div>
            </div>
        </div>

        <div class="row profit-loss-summary-row">
            <div class="col-md-6 col-xl-4">
                <div class="card profit-loss-summary">
                    <div class="card-body">
                        <div class="profit-loss-summary__label">Total Revenue</div>
                        <div class="profit-loss-summary__value">₹{{ number_format($totalRevenue, 2) }}</div>
                        <p class="profit-loss-summary__meta">{{ $invoiceCount }} invoice(s)</p>
                    </div>
                </div>
            </div>
            <div class="col-md-6 col-xl-4 ">
                <div class="card profit-loss-summary">
                    <div class="card-body">
                        <div class="profit-loss-summary__label">Gross Profit</div>
                        <div class="profit-loss-summary__value">₹{{ number_format($grossProfit, 2) }}</div>
                        <p class="profit-loss-summary__meta">{{ number_format($grossMargin, 1) }}% of revenue</p>
                    </div>
                </div>
            </div>
            <div class="col-md-6 col-xl-4">
                <div class="card profit-loss-summary {{ $netProfit >= 0 ? 'profit-loss-summary--good' : 'profit-loss-summary--danger' }}">
                    <div class="card-body">
                        <div class="profit-loss-summary__label">Net Profit</div>
                        <div class="profit-loss-summary__value">₹{{ number_format($netProfit, 2) }}</div>
                        <p class="profit-loss-summary__meta">{{ number_format($netMargin, 1) }}% net margin</p>
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-lg-6 mb-4">
                <div class="card profit-loss-card">
                    <div class="card-body">
                        <!-- <div class="profit-loss-card__eyebrow">Financial Overview</div> -->
                        <h2 class="profit-loss-card__title">Profit & Loss Breakdown</h2>
                        <p class="profit-loss-card__subtitle">A complete breakdown of your revenue and expenses for the period.</p>

                        <div class="profit-loss-stat">
                            <div class="profit-loss-stat__label">Total Revenue</div>
                            <div class="profit-loss-stat__value">₹{{ number_format($totalRevenue, 2) }}</div>
                        </div>
                        <div class="profit-loss-stat">
                            <div class="profit-loss-stat__label">Less: Purchase Cost</div>
                            <div class="profit-loss-stat__value is-negative">₹{{ number_format($purchaseSpend, 2) }}</div>
                        </div>
                        <div class="profit-loss-stat">
                            <div class="profit-loss-stat__label">Gross Profit</div>
                            <div class="profit-loss-stat__value is-positive">₹{{ number_format($grossProfit, 2) }}</div>
                        </div>
                        <div class="profit-loss-stat">
                            <div class="profit-loss-stat__label">Less: Total Expenses</div>
                            <div class="profit-loss-stat__value is-negative">₹{{ number_format($totalExpenses, 2) }}</div>
                        </div>
                        <div class="profit-loss-stat">
                            <div class="profit-loss-stat__label">Net Profit</div>
                            <div class="profit-loss-stat__value {{ $netProfit >= 0 ? 'is-positive' : 'is-negative' }}">₹{{ number_format($netProfit, 2) }}</div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-lg-6 mb-4">
                <div class="card profit-loss-card">
                    <div class="card-body">
                        <!-- <div class="profit-loss-card__eyebrow">Metrics</div> -->
                        <h2 class="profit-loss-card__title">Key Performance Indicators</h2>
                        <p class="profit-loss-card__subtitle">View profitability ratios and efficiency metrics.</p>

                        <div class="profit-loss-stat">
                            <div class="profit-loss-stat__label">Gross Margin</div>
                            <div class="profit-loss-stat__value">{{ number_format($grossMargin, 2) }}%</div>
                        </div>
                        <div class="profit-loss-stat">
                            <div class="profit-loss-stat__label">Net Margin</div>
                            <div class="profit-loss-stat__value {{ $netMargin >= 0 ? 'is-positive' : 'is-negative' }}">{{ number_format($netMargin, 2) }}%</div>
                        </div>
                        <div class="profit-loss-stat">
                            <div class="profit-loss-stat__label">Total Invoices</div>
                            <div class="profit-loss-stat__value">{{ $invoiceCount }}</div>
                        </div>
                        <div class="profit-loss-stat">
                            <div class="profit-loss-stat__label">Total Expenses</div>
                            <div class="profit-loss-stat__value">{{ $expenseCount }}</div>
                        </div>
                        <div class="profit-loss-stat">
                            <div class="profit-loss-stat__label">Total Purchases</div>
                            <div class="profit-loss-stat__value">{{ $purchaseCount }}</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        @if($expenseBreakdown->isNotEmpty())
            <div class="row">
                <div class="col-lg-6 mb-4">
                    <div class="card profit-loss-card">
                        <div class="card-body">
                            <!-- <div class="profit-loss-card__eyebrow">Expenses</div> -->
                            <h2 class="profit-loss-card__title">Top Expense Categories</h2>
                            <p class="profit-loss-card__subtitle">Your largest expense categories during this period.</p>

                            @foreach($expenseBreakdown as $expense)
                                <div class="profit-loss-stat">
                                    <div>
                                        <div class="profit-loss-stat__label text-dark">{{ $expense['label'] }}</div>
                                        <!-- <small class="text-muted">{{ $expense['count'] }} transaction(s)</small> -->
                                    </div>
                                    <div class="profit-loss-stat__value is-negative">₹{{ number_format($expense['amount'], 2) }}</div>
                                </div>
                            @endforeach
                        </div>
                    </div>
                </div>

                <div class="col-lg-6 mb-4">
                    <div class="card profit-loss-card">
                        <div class="card-body">
                            <!-- <div class="profit-loss-card__eyebrow">Summary</div> -->
                            <h2 class="profit-loss-card__title">Period Summary</h2>
                            <p class="profit-loss-card__subtitle">Report period: {{ $timePeriod }}</p>

                            <div class="profit-loss-stat">
                                <div class="profit-loss-stat__label">Revenue per Invoice</div>
                                <div class="profit-loss-stat__value">₹{{ number_format($invoiceCount > 0 ? $totalRevenue / $invoiceCount : 0, 2) }}</div>
                            </div>
                            <div class="profit-loss-stat">
                                <div class="profit-loss-stat__label">Profit per Invoice</div>
                                <div class="profit-loss-stat__value is-positive">₹{{ number_format($invoiceCount > 0 ? $grossProfit / $invoiceCount : 0, 2) }}</div>
                            </div>
                            <div class="profit-loss-stat">
                                <div class="profit-loss-stat__label">Average Expense</div>
                                <div class="profit-loss-stat__value is-negative">₹{{ number_format($expenseCount > 0 ? $totalExpenses / $expenseCount : 0, 2) }}</div>
                            </div>
                            <div class="profit-loss-stat">
                                <div class="profit-loss-stat__label">Period Net Profit</div>
                                <div class="profit-loss-stat__value {{ $netProfit >= 0 ? 'is-positive' : 'is-negative' }}">₹{{ number_format($netProfit, 2) }}</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        @endif

        @if($statementRows->isNotEmpty())
            <div class="row">
                <div class="col-12 mb-4">
                    <div class="card profit-loss-card">
                        <div class="card-body">
                            <!-- <div class="profit-loss-card__eyebrow">Details</div> -->
                            <h2 class="profit-loss-card__title">Period-wise Statement</h2>
                            <p class="profit-loss-card__subtitle">Revenue, expenses, and profit breakdown by {{ $timePeriod }}.</p>

                            <div class="table-responsive">
                                <div class="profit-loss-statement-row">
                                    <div class="profit-loss-statement-cell"><strong>Period</strong></div>
                                    <div class="profit-loss-statement-cell"><strong>Revenue</strong></div>
                                    <div class="profit-loss-statement-cell"><strong>Gross Profit</strong></div>
                                    <div class="profit-loss-statement-cell"><strong>Expenses</strong></div>
                                    <div class="profit-loss-statement-cell"><strong>Purchase Cost</strong></div>
                                    <div class="profit-loss-statement-cell"><strong>Net Profit</strong></div>
                                </div>

                                @foreach($statementRows as $row)
                                    <div class="profit-loss-statement-row">
                                        <div class="profit-loss-statement-cell">{{ $row['label'] }}</div>
                                        <div class="profit-loss-statement-cell">₹{{ number_format($row['revenue'], 2) }}</div>
                                        <div class="profit-loss-statement-cell">₹{{ number_format($row['gross_profit'], 2) }}</div>
                                        <div class="profit-loss-statement-cell">₹{{ number_format($row['expenses'], 2) }}</div>
                                        <div class="profit-loss-statement-cell">₹{{ number_format($row['purchase_spend'], 2) }}</div>
                                        <div class="profit-loss-statement-cell {{ $row['net_profit'] >= 0 ? 'text-success' : 'text-danger' }}">₹{{ number_format($row['net_profit'], 2) }}</div>
                                    </div>
                                @endforeach
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        @endif
    </div>

    <script>
        (function () {
            const periodSelect = document.getElementById('timePeriod');
            const fromDateFilter = document.getElementById('fromDateFilter');
            const toDateFilter = document.getElementById('toDateFilter');

            function toggleCustomDateFilters() {
                const isCustom = periodSelect && periodSelect.value === 'custom';

                if (fromDateFilter) {
                    fromDateFilter.classList.toggle('is-visible', isCustom);
                }

                if (toDateFilter) {
                    toDateFilter.classList.toggle('is-visible', isCustom);
                }
            }

            if (periodSelect) {
                periodSelect.addEventListener('change', toggleCustomDateFilters);
                toggleCustomDateFilters();
            }
        })();
    </script>
@endsection
