@extends('layout.app')

@section('title')
    Sales Charts Report
@endsection

@section('content')

    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

    <div class="container-fluid sales-chart-shell">
        <div class="sales-chart-hero">
            <div class="row align-items-center">
                <div class="col-lg-8">
                    <!-- <div class="sales-chart-hero__eyebrow">Analytics</div> -->
                    <h1 class="sales-chart-hero__title">Sales Analytics for {{ $timePeriod }}</h1>
                    <p class="sales-chart-hero__subtitle">
                        Track daily revenue, profit movement, and payment mode patterns for the current month in one place.
                    </p>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-4 mb-3">
                <div class="card sales-chart-summary">
                    <div class="card-body">
                        <div class="sales-chart-summary__label">Invoices This Month</div>
                        <div class="sales-chart-summary__value">{{ $invoiceCount }}</div>
                    </div>
                </div>
            </div>
            <div class="col-md-4 mb-3">
                <div class="card sales-chart-summary">
                    <div class="card-body">
                        <div class="sales-chart-summary__label">Total Sales</div>
                        <div class="sales-chart-summary__value">₹{{ number_format($totalSalesAmount, 2) }}</div>
                    </div>
                </div>
            </div>
            <div class="col-md-4 mb-3">
                <div class="card sales-chart-summary">
                    <div class="card-body">
                        <div class="sales-chart-summary__label">Total Profit</div>
                        <div class="sales-chart-summary__value">₹{{ number_format($totalProfitAmount, 2) }}</div>
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-lg-7 mb-4">
                <div class="card sales-chart-card">
                    <div class="card-body">
                        <!-- <div class="sales-chart-card__eyebrow">Revenue</div> -->
                        <h2 class="sales-chart-card__title">Daily Sales Overview</h2>
                        <p class="sales-chart-card__subtitle">Revenue trend across invoice dates for {{ $timePeriod }}.</p>
                        <canvas id="dailySalesChart" class="sales-chart-canvas"></canvas>
                    </div>
                </div>
            </div>
            <div class="col-lg-5 mb-4">
                <div class="card sales-chart-card">
                    <div class="card-body">
                        <!-- <div class="sales-chart-card__eyebrow">Payments</div> -->
                        <h2 class="sales-chart-card__title">Payment Mode Breakdown</h2>
                        <p class="sales-chart-card__subtitle">Invoice count split by payment method.</p>
                        <canvas id="paymentModeChart" class="sales-chart-canvas"></canvas>
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-lg-6 mb-4">
                <div class="card sales-chart-card">
                    <div class="card-body">
                        <!-- <div class="sales-chart-card__eyebrow">Invoices</div> -->
                        <h2 class="sales-chart-card__title">Daily Invoice Count</h2>
                        <p class="sales-chart-card__subtitle">How many invoices were created on each date.</p>
                        <canvas id="invoiceCountChart" class="sales-chart-canvas"></canvas>
                    </div>
                </div>
            </div>
            <div class="col-lg-6 mb-4">
                <div class="card sales-chart-card">
                    <div class="card-body">
                        <!-- <div class="sales-chart-card__eyebrow">Customers</div> -->
                        <h2 class="sales-chart-card__title">Top Customers by Revenue</h2>
                        <p class="sales-chart-card__subtitle">Highest-value customers for {{ $timePeriod }}.</p>
                        <canvas id="topCustomersChart" class="sales-chart-canvas"></canvas>
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-12">
                <div class="card sales-chart-card">
                    <div class="card-body">
                        <!-- <div class="sales-chart-card__eyebrow">Profit</div> -->
                        <h2 class="sales-chart-card__title">Daily Profit Analysis</h2>
                        <p class="sales-chart-card__subtitle">Profit generated from invoice items, grouped by invoice date.</p>
                        <canvas id="profitAnalysisChart" class="sales-chart-canvas"></canvas>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        const dailySalesLabels = @json($dailySalesLabels);
        const dailySalesValues = @json($dailySalesValues);
        const dailyProfitLabels = @json($dailyProfitLabels);
        const dailyProfitValues = @json($dailyProfitValues);
        const paymentModeLabels = @json($paymentModeLabels);
        const paymentModeValues = @json($paymentModeValues);
        const dailyInvoiceCountLabels = @json($dailyInvoiceCountLabels);
        const dailyInvoiceCountValues = @json($dailyInvoiceCountValues);
        const topCustomerLabels = @json($topCustomerLabels);
        const topCustomerValues = @json($topCustomerValues);

        const axisLabelColor = '#607086';
        const gridColor = 'rgba(148, 163, 184, 0.18)';
        const currencyTooltip = (value) => '₹' + Number(value).toLocaleString('en-IN', {
            minimumFractionDigits: 2,
            maximumFractionDigits: 2
        });

        new Chart(document.getElementById('dailySalesChart'), {
            type: 'bar',
            data: {
                labels: dailySalesLabels,
                datasets: [{
                    label: 'Revenue',
                    data: dailySalesValues,
                    backgroundColor: '#1abc9c',
                    borderRadius: 8,
                    maxBarThickness: 36
                }]
            },
            options: {
                maintainAspectRatio: false,
                interaction: {
                    mode: 'index',
                    intersect: false
                },
                plugins: {
                    legend: { display: false },
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                return ' Revenue: ' + currencyTooltip(context.parsed.y);
                            }
                        }
                    }
                },
                scales: {
                    x: {
                        ticks: { color: axisLabelColor },
                        grid: { display: false }
                    },
                    y: {
                        ticks: { color: axisLabelColor },
                        grid: { color: gridColor }
                    }
                }
            }
        });

        new Chart(document.getElementById('paymentModeChart'), {
            type: 'doughnut',
            data: {
                labels: paymentModeLabels,
                datasets: [{
                    data: paymentModeValues,
                    backgroundColor: ['#17324d', '#1abc9c', '#4f46e5', '#f59e0b', '#ef4444']
                }]
            },
            options: {
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'bottom',
                        labels: {
                            color: axisLabelColor,
                            boxWidth: 14,
                            padding: 16
                        }
                    }
                }
            }
        });

        new Chart(document.getElementById('invoiceCountChart'), {
            type: 'bar',
            data: {
                labels: dailyInvoiceCountLabels,
                datasets: [{
                    label: 'Invoices',
                    data: dailyInvoiceCountValues,
                    backgroundColor: '#4f46e5',
                    borderRadius: 8,
                    maxBarThickness: 34
                }]
            },
            options: {
                maintainAspectRatio: false,
                plugins: {
                    legend: { display: false }
                },
                scales: {
                    x: {
                        ticks: { color: axisLabelColor },
                        grid: { display: false }
                    },
                    y: {
                        ticks: { color: axisLabelColor, precision: 0 },
                        grid: { color: gridColor }
                    }
                }
            }
        });

        new Chart(document.getElementById('topCustomersChart'), {
            type: 'bar',
            data: {
                labels: topCustomerLabels,
                datasets: [{
                    label: 'Revenue',
                    data: topCustomerValues,
                    backgroundColor: '#f59e0b',
                    borderRadius: 8,
                    maxBarThickness: 32
                }]
            },
            options: {
                maintainAspectRatio: false,
                indexAxis: 'y',
                plugins: {
                    legend: { display: false },
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                return ' Revenue: ' + currencyTooltip(context.parsed.x);
                            }
                        }
                    }
                },
                scales: {
                    x: {
                        ticks: {
                            color: axisLabelColor,
                            callback: function(value) {
                                return '₹' + Number(value).toLocaleString('en-IN');
                            }
                        },
                        grid: { color: gridColor }
                    },
                    y: {
                        ticks: { color: axisLabelColor },
                        grid: { display: false }
                    }
                }
            }
        });

        new Chart(document.getElementById('profitAnalysisChart'), {
            type: 'line',
            data: {
                labels: dailyProfitLabels,
                datasets: [{
                    label: 'Profit',
                    data: dailyProfitValues,
                    borderColor: '#17324d',
                    backgroundColor: 'rgba(23, 50, 77, 0.08)',
                    fill: true,
                    tension: 0.35,
                    pointBackgroundColor: '#1abc9c',
                    pointBorderColor: '#ffffff',
                    pointBorderWidth: 2,
                    pointRadius: 4,
                    pointHoverRadius: 7,
                    pointHitRadius: 18,
                    pointHoverBorderWidth: 3
                }]
            },
            options: {
                maintainAspectRatio: false,
                interaction: {
                    mode: 'nearest',
                    intersect: false
                },
                plugins: {
                    legend: { display: false },
                    tooltip: {
                        enabled: true,
                        callbacks: {
                            label: function(context) {
                                return ' Profit: ' + currencyTooltip(context.parsed.y);
                            }
                        }
                    }
                },
                scales: {
                    x: {
                        ticks: { color: axisLabelColor },
                        grid: { color: 'transparent' }
                    },
                    y: {
                        ticks: { color: axisLabelColor },
                        grid: { color: gridColor }
                    }
                }
            }
        });
    </script>
@endsection
