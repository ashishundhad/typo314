<div class="table-responsive">
    @if ($suppliers->count())
        <table class="table supplier-ledger-table">
            <thead>
                <tr>
                    <th>Supplier</th>
                    <th>Purchases</th>
                    <th>Spend</th>
                    <th>Last Activity</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($suppliers as $supplier)
                    <tr>
                        <td>
                            <div class="supplier-ledger-supplier">
                                <div class="supplier-ledger-supplier__icon">
                                    <i class="mdi mdi-truck-delivery-outline"></i>
                                </div>
                                <div>
                                    <div class="supplier-ledger-supplier__name">{{ $supplier->supplier_name }}</div>
                                    <div class="supplier-ledger-supplier__meta">Phone: {{ $supplier->contactno ?: 'N/A' }}</div>
                                    <div class="supplier-ledger-supplier__meta">
                                        Repairing: {{ config('constant.currency') }}{{ number_format((float) $supplier->total_repairing_charge, 2) }}
                                    </div>
                                </div>
                            </div>
                        </td>
                        <td>
                            <div class="mb-2">
                                <span class="supplier-ledger-stat">{{ number_format($supplier->purchase_count) }} items</span>
                            </div>
                            <div class="supplier-ledger-supplier__meta">Sold: {{ number_format($supplier->sold_count) }}, Available: {{ number_format($supplier->available_count) }}</div>
                        </td>
                        <td>
                            <div class="supplier-ledger-spend__value">{{ config('constant.currency') }}{{ number_format((float) $supplier->total_purchase_cost, 2) }}</div>
                            <div class="supplier-ledger-spend__meta">Stock value: {{ config('constant.currency') }}{{ number_format((float) $supplier->total_stock_value, 2) }}</div>
                        </td>
                        <td>
                            <div class="supplier-ledger-date">
                                {{ $supplier->latest_purchase_date ? \Carbon\Carbon::parse($supplier->latest_purchase_date)->format('d M Y') : 'N/A' }}
                            </div>
                            <div class="supplier-ledger-supplier__meta">{{ $timePeriod }}</div>
                        </td>
                        <td class="text-center">
                            <a href="{{ route('supplier-ledger-detail', array_merge(request()->query(), ['supplier' => $supplier->supplier_filter])) }}"
                                class="btn btn-primary supplier-ledger-btn js-supplier-purchases-modal"
                                data-title="{{ $supplier->supplier_name }} Purchases">
                                View
                            </a>
                        </td>
                    </tr>
                @endforeach
            </tbody>
        </table>

        <div class="mt-3">
            {{ $suppliers->appends(request()->query())->links('vendor.pagination.bootstrap-5') }}
        </div>
    @else
        <div class="supplier-ledger-empty">
            <div class="supplier-ledger-empty__icon">
                <i class="mdi mdi-notebook-search-outline"></i>
            </div>
            <h4 class="mb-2">No suppliers found</h4>
            <p class="text-muted mb-0">Try a different date range or search term to view supplier purchase activity.</p>
        </div>
    @endif
</div>
