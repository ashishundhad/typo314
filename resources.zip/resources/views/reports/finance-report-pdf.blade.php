<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Finance Report</title>
    <style>
        body { font-family: DejaVu Sans, sans-serif; font-size: 11px; color: #222; }
        h2 { margin-bottom: 8px; }
        table { width: 100%; border-collapse: collapse; margin-top: 10px; }
        th, td { border: 1px solid #ccc; padding: 6px; text-align: left; }
        th { background: #f2f2f2; }
        .summary { margin-bottom: 12px; }
    </style>
</head>
<body>
    <h2>Finance Report</h2>
    <div class="summary">
        <strong>Period:</strong> {{ $timePeriod ?? 'Selected Range' }}<br>
        <strong>Sales:</strong> {{ number_format($summary['totalSales'], 2) }}<br>
        <strong>Purchase Cost:</strong> {{ number_format($summary['totalPurchaseCost'], 2) }}<br>
        <strong>Profit:</strong> {{ number_format($summary['totalProfit'], 2) }}<br>
        <strong>Items Sold:</strong> {{ $summary['itemsSold'] }}
    </div>
    <div class="summary">
        @foreach ($summary['paymentTypeBreakdown'] as $paymentType)
            <div>{{ $paymentType['label'] }}: {{ $paymentType['count'] }} invoice(s), sales {{ number_format($paymentType['sales'], 2) }}, profit {{ number_format($paymentType['profit'], 2) }}</div>
        @endforeach
    </div>
    <table>
        <thead>
            <tr>
                <th>Date</th>
                <th>Invoice No</th>
                <th>Customer</th>
                <th>Sales</th>
                <th>Purchase Cost</th>
                <th>Profit</th>
                <th>Items</th>
                <th>Payment</th>
            </tr>
        </thead>
        <tbody>
            @foreach ($invoices as $invoice)
                <tr>
                    <td>{{ $invoice->invoice_date }}</td>
                    <td>{{ $invoice->invoice_no }}</td>
                    <td>{{ $invoice->customer_name }}</td>
                    <td>{{ number_format((float) $invoice->net_amount, 2) }}</td>
                    <td>{{ number_format((float) ($invoice->items ?? collect())->sum(function ($item) {
                        return (float) (
                            $item->purchase->purchase_cost ??
                            $item->purchase->purchase_price ??
                            $item->purchase_cost ??
                            0
                        );
                    }), 2) }}</td>
                    <td>{{ number_format((float) ($invoice->items ?? collect())->sum('profit'), 2) }}</td>
                    <td>{{ (int) ($invoice->items ?? collect())->sum('quantity') }}</td>
                    <td>{{ $invoice->payment_type }}</td>
                </tr>
            @endforeach
        </tbody>
    </table>
</body>
</html>
