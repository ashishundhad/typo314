@extends('layout.app')

@section('title')
    Customers
@endsection

@section('content')
<div class="container-fluid customers-page">
    <div class="customers-topbar">
        <div>
            <h1 class="customers-topbar__title">Customers</h1>
            <p class="customers-topbar__subtitle">Everyone who has bought from you, with a quick way to reach them.</p>
        </div>
        <div class="customers-topbar__actions">
            <!-- <div class="customers-mini-stat">
                <div class="customers-mini-stat__label">Total</div>
                <div class="customers-mini-stat__value">{{ $totalcustomers }}</div>
            </div> -->
            @can('reports.customers.export')
                <a href="{{ route('exportcustomers') }}" class="expenses-link-btn">
                    <i class="mdi mdi-file-excel-box"></i> Export CSV
                </a>
            @endcan
        </div>
    </div>

    <div class="sales-card">
        <div class="sales-card__header">
            <div>
                <h4 class="sales-card__title">Customer Register</h4>
                <!-- <p class="sales-card__subtitle">Search by name or phone number.</p> -->
            </div>
        </div>

        <form action="{{ route('customers') }}" method="GET" id="filtercustomers" class="sales-filter-form">
            <div class="form-row align-items-end">
                <div class="form-group col-md-6 mb-0">
                    <div class="sales-search-group">
                        <input type="text" class="form-control" placeholder="Search by name or phone.." name="search"
                            value="{{ $search ?? request()->input('search') }}" id="searchcustomers">
                        <button class="btn btn-primary customer-search" type="submit">
                            <i class="mdi mdi-magnify"></i> Search
                        </button>
                        <input class="btn btn-danger customer-search" type="reset" value="X" onclick="window.location='{{ route('customers') }}'">
                    </div>
                </div>
            </div>
        </form>

        @if (count($customers))
            <div class="table-responsive sales-table-wrap">
                <table class="table sales-table table-hover m-0">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Customer Name</th>
                            <th>Phone Number</th>
                            <th class="text-right">Invoices</th>
                            <th class="text-center">Documents</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach ($customers as $index => $customer)
                            <tr>
                                <td class="sales-index">#{{ $customers->firstItem() + $index }}</td>
                                <td class="sales-customer__name">{{ $customer->name }}</td>
                                <td>
                                    @if($customer->phone)
                                        <a href="tel:{{ $customer->phone }}">{{ $customer->phone }}</a>
                                    @else
                                        <span class="text-muted">No contact number</span>
                                    @endif
                                </td>
                                <td class="text-right">{{ $customer->invoices_count }}</td>
                                <td class="text-center">
                                    @if($customer->documents_count > 0)
                                        <button type="button" class="btn btn-sm btn-primary js-customer-documents"
                                            data-id="{{ $customer->id }}" data-name="{{ $customer->name }}">
                                            View ({{ $customer->documents_count }})
                                        </button>
                                    @else
                                        <span class="text-muted">No documents</span>
                                    @endif
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>

            <div class="pagination-links px-3 pb-3">
                {{ $customers->links('vendor.pagination.bootstrap-5') }}
            </div>
        @else
            <div class="sales-empty">
                <div class="sales-empty__icon">
                    <i class="mdi mdi-account-search-outline"></i>
                </div>
                <h4>No customers found</h4>
                <p>Try a different search, or check back once your first invoice is created.</p>
            </div>
        @endif
    </div>
</div>

<div class="modal fade" id="customerDocumentsModal" tabindex="-1" role="dialog"
    aria-labelledby="customerDocumentsModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="customerDocumentsModalLabel">Customer Documents</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div id="customerDocumentsModalContent">
                    <div class="supplier-ledger-modal__state">
                        <i class="mdi mdi-card-account-details-outline"></i>Loading documents...
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection

@section('scripts')
    <script>
        $(document).on('click', '.js-customer-documents', function () {
            const customerId = $(this).data('id');
            const customerName = $(this).data('name');
            const $modal = $('#customerDocumentsModal');
            const $content = $('#customerDocumentsModalContent');

            $('#customerDocumentsModalLabel').text(customerName + "'s Documents");
            $content.html('<div class="supplier-ledger-modal__state"><i class="mdi mdi-loading mdi-spin"></i>Loading documents...</div>');
            $modal.modal('show');

            $.ajax({
                url: "{{ url('/admin/reports/customers') }}/" + customerId + '/documents',
                type: 'GET',
                success: function (response) {
                    $content.html(response);
                },
                error: function () {
                    $content.html('<div class="supplier-ledger-modal__state"><i class="mdi mdi-alert-circle-outline"></i>Unable to load documents right now.</div>');
                }
            });
        });
    </script>
@endsection
