@extends('layout.app')

@section('title', 'Finance Report')

@section('content')
<div class="container-fluid py-3">
    <div class="card shadow-sm border-0 rounded-4">
        <div class="card-body">
            <div class="d-flex flex-column flex-lg-row justify-content-between align-items-lg-center gap-3">
                <div>
                    <h4 class="mb-1">Finance Report</h4>
                    <p class="text-muted mb-0">Sales, profit, and item count for the selected period.</p>
                </div>
                <div class="d-flex flex-wrap gap-2">
                    <a href="{{ route('finance-report-export-csv', request()->query()) }}" class="btn btn-outline-success btn-sm">Export CSV</a>
                    <a href="{{ route('finance-report-export-pdf', request()->query()) }}" class="btn btn-outline-danger btn-sm">Export PDF</a>
                </div>
            </div>

            <form method="GET" action="{{ route('finance-report') }}" class="row g-3 mt-2 align-items-end">
                <div class="col-md-3">
                    <label class="form-label">Period</label>
                    <select name="period" class="form-control">
                        <option value="thismonth" {{ ($period ?? 'thismonth') === 'thismonth' ? 'selected' : '' }}>This Month</option>
                        <option value="lastmonth" {{ ($period ?? '') === 'lastmonth' ? 'selected' : '' }}>Last Month</option>
                        <option value="thisyear" {{ ($period ?? '') === 'thisyear' ? 'selected' : '' }}>This Year</option>
                        <option value="custom" {{ ($period ?? '') === 'custom' ? 'selected' : '' }}>Custom Range</option>
                    </select>
                </div>
                <div class="col-md-3">
                    <label class="form-label">From Date</label>
                    <input type="date" name="fromdate" class="form-control" value="{{ $fromdate ?? '' }}">
                </div>
                <div class="col-md-3">
                    <label class="form-label">To Date</label>
                    <input type="date" name="todate" class="form-control" value="{{ $todate ?? '' }}">
                </div>
                <div class="col-md-3">
                    <button type="submit" class="btn btn-primary w-100">Generate</button>
                </div>
            </form>

            <div class="row mt-4 g-3">
                <div class="col-md-3">
                    <div class="border rounded-3 p-3 bg-light h-100">
                        <div class="text-muted small">Sales</div>
                        <div class="fw-bold fs-4">{{ number_format($summary['totalSales'], 2) }}</div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="border rounded-3 p-3 bg-light h-100">
                        <div class="text-muted small">Purchase Cost</div>
                        <div class="fw-bold fs-4">{{ number_format($summary['totalPurchaseCost'], 2) }}</div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="border rounded-3 p-3 bg-light h-100">
                        <div class="text-muted small">Profit</div>
                        <div class="fw-bold fs-4">{{ number_format($summary['totalProfit'], 2) }}</div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="border rounded-3 p-3 bg-light h-100">
                        <div class="text-muted small">Items Sold</div>
                        <div class="fw-bold fs-4">{{ $summary['itemsSold'] }}</div>
                    </div>
                </div>
            </div>

            <div class="row mt-4 g-3">
                @foreach ($summary['paymentTypeBreakdown'] as $paymentType)
                    <div class="col-md-3">
                        <div class="border rounded-3 p-3 bg-white h-100">
                            <div class="text-muted small">{{ $paymentType['label'] }}</div>
                            <div class="fw-bold fs-5">{{ $paymentType['count'] }} invoice(s)</div>
                            <div class="small text-muted mt-2">Sales: {{ number_format($paymentType['sales'], 2) }}</div>
                            <div class="small text-muted">Profit: {{ number_format($paymentType['profit'], 2) }}</div>
                            <div class="small text-muted">Items: {{ $paymentType['itemsSold'] }}</div>
                        </div>
                    </div>
                @endforeach
            </div>

            <div class="table-responsive mt-4">
                <table class="table table-bordered table-hover align-middle">
                    <thead class="table-dark">
                        <tr>
                            <th>Date</th>
                            <th>Invoice No</th>
                            <th>Customer</th>
                            <th>Sales</th>
                            <th>Purchase Cost</th>
                            <th>Profit</th>
                            <th>Items</th>
                            <th>Payment</th>
                        </tr>
                    </thead>
                    <tbody>
                        @forelse ($invoices as $invoice)
                            <tr>
                                <td>{{ $invoice->invoice_date }}</td>
                                <td>{{ $invoice->invoice_no }}</td>
                                <td>{{ $invoice->customer_name }}</td>
                                <td>{{ number_format((float) $invoice->net_amount, 2) }}</td>
                                <td>{{ number_format((float) ($invoice->items ?? collect())->sum(function ($item) {
                                    return (float) (
                                        $item->purchase->purchase_cost ??
                                        $item->purchase->purchase_price ??
                                        $item->purchase_cost ??
                                        0
                                    );
                                }), 2) }}</td>
                                <td>{{ number_format((float) ($invoice->items ?? collect())->sum('profit'), 2) }}</td>
                                <td>{{ (int) ($invoice->items ?? collect())->sum('quantity') }}</td>
                                <td>{{ $invoice->payment_type }}</td>
                            </tr>
                        @empty
                            <tr>
                                <td colspan="7" class="text-center text-muted">No records found for this period.</td>
                            </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
@endsection
