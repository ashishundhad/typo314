@extends('layout.app')

@section('title')
    Purchase Report
@endsection

@section('content')

    <div class="container-fluid purchase-report-shell">
        <div class="purchase-report-hero">
            <div class="row align-items-center">
                <div class="col-lg-8">
                    <h1 class="purchase-report-hero__title">Purchase Items Report</h1>
                    <p class="purchase-report-hero__subtitle">
                        Review purchased inventory with date, supplier, device and cost details, then export the same filtered view as CSV or PDF.
                    </p>
                </div>
                <div class="col-lg-4">
                    <div class="purchase-report-actions">
                        <a href="{{ route('buy-export', request()->query()) }}" class="btn btn-light purchase-report-btn">
                            <i class="mdi mdi-file-delimited mr-1"></i>CSV
                        </a>
                        <a href="{{ route('purchase-report-pdf', request()->query()) }}" class="btn btn-outline-light purchase-report-btn">
                            <i class="mdi mdi-file-pdf-box mr-1"></i>PDF
                        </a>
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-6 col-xl-4 mb-3">
                <div class="card purchase-report-summary purchase-report-summary--cost">
                    <div class="card-body">
                        <div class="purchase-report-summary__label">Purchase Cost - {{ $timePeriod }}</div>
                        <div class="purchase-report-summary__value">{{ config('constant.currency') }}{{ number_format($totalPurchaseAmount, 2) }}</div>
                    </div>
                </div>
            </div>
            <!-- <div class="col-md-6 col-xl-3 mb-3">
                <div class="card purchase-report-summary purchase-report-summary--repair">
                    <div class="card-body">
                        <div class="purchase-report-summary__label">Repairing - {{ $timePeriod }}</div>
                        <div class="purchase-report-summary__value">{{ config('constant.currency') }}{{ number_format($totalRepairingAmount, 2) }}</div>
                    </div>
                </div>
            </div> -->
            <div class="col-md-6 col-xl-4 mb-3">
                <div class="card purchase-report-summary purchase-report-summary--value">
                    <div class="card-body">
                        <div class="purchase-report-summary__label">Stock Value - {{ $timePeriod }}</div>
                        <div class="purchase-report-summary__value">{{ config('constant.currency') }}{{ number_format($totalStockValue, 2) }}</div>
                    </div>
                </div>
            </div>
            <div class="col-md-6 col-xl-4 mb-3">
                <div class="card purchase-report-summary purchase-report-summary--sold">
                    <div class="card-body">
                        <div class="purchase-report-summary__label">Sold vs Available</div>
                        <div class="purchase-report-summary__value">{{ $soldItems }} / {{ $availableItems }}</div>
                    </div>
                </div>
            </div>
        </div>

        <div class="card purchase-report-card">
            <div class="card-body">
                <h2 class="purchase-report-card__title">Purchased Items [{{ $totalItems }}]</h2>
                <p class="purchase-report-card__subtitle">Apply filters to narrow the report, then export exactly what you see.</p>

                <div class="purchase-report-filter">
                    <form method="GET" id="purchase-report-form">
                        <div class="form-row align-items-end">
                            <div class="col-12 col-md-3 mb-3 mb-md-0">
                                <label class="purchase-report-label" for="purchase-period">Report Period</label>
                                <select name="period" class="form-control" id="purchase-period">
                                    <option value="alls" @selected($period == 'alls')>All Purchases</option>
                                    <option value="thismonth" @selected($period == 'thismonth')>This Month</option>
                                    <option value="lastmonth" @selected($period == 'lastmonth')>Last Month</option>
                                    <option value="thisyear" @selected($period == 'thisyear')>This Year</option>
                                    <option value="lastyear" @selected($period == 'lastyear')>Last Year</option>
                                    <option value="custom" @selected($period == 'custom')>Custom Range</option>
                                </select>
                            </div>
                            <div class="col-md-2 mb-3 mb-md-0 purchase-report-date-group @if($period == 'custom') showdefault @endif">
                                <label class="purchase-report-label" for="purchase-fromdate">From Date</label>
                                <input type="date" id="purchase-fromdate" name="fromdate" class="form-control" value="{{ $fromdate }}">
                            </div>
                            <div class="col-md-2 mb-3 mb-md-0 purchase-report-date-group @if($period == 'custom') showdefault @endif">
                                <label class="purchase-report-label" for="purchase-todate">To Date</label>
                                <input type="date" id="purchase-todate" name="todate" class="form-control" value="{{ $todate }}">
                            </div>
                            <div class="col-12 col-md-2 mb-3 mb-md-0">
                                <label class="purchase-report-label" for="purchase-status">Item Status</label>
                                <select name="status" class="form-control" id="purchase-status">
                                    <option value="" @selected($status === '')>All</option>
                                    <option value="available" @selected($status === 'available')>Available</option>
                                    <option value="sold" @selected($status === 'sold')>Sold</option>
                                </select>
                            </div>
                            <!-- <div class="col-12 col-md-3 mb-3 mb-md-0">
                                <label class="purchase-report-label" for="purchase-search">Search</label>
                                <input type="text" id="purchase-search" name="search" class="form-control" value="{{ $search }}" placeholder="IMEI, model, supplier, phone">
                            </div> -->
                            <div class="col-12 col-md-2 mb-3 mb-md-0">
                                <label class="purchase-report-label d-none d-md-block">&nbsp;</label>
                                <div class="purchase-report-filter-actions">
                                    <button type="submit" class="btn btn-primary purchase-report-btn">
                                    Filter Report
                                    </button>
                                    <a href="{{ route('purchase-report') }}" class="btn btn-outline-danger purchase-report-btn">
                                    Clear
                                    </a>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>

                <div class="table-responsive">
                    @if ($allPurchased->count())
                        <table class="table purchase-report-table">
                            <thead>
                                <tr>
                                    <th>Purchase Date</th>
                                    <th>Device</th>
                                    <th>Supplier</th>
                                    <th>Costing</th>
                                    <th>Status</th>
                                    <!-- <th>Notes</th> -->
                                </tr>
                            </thead>
                            <tbody>
                                @foreach($allPurchased as $purchase)
                                    <tr>
                                        <td>
                                            <span class="purchase-report-date">{{ \Carbon\Carbon::parse($purchase->purchase_date)->format('d/m/Y') }}</span>
                                            @if($purchase->sell_date)
                                                <div class="purchase-report-device__meta mt-2">Sold: {{ \Carbon\Carbon::parse($purchase->sell_date)->format('d/m/Y') }}</div>
                                            @endif
                                        </td>
                                        <td>
                                            <div class="purchase-report-device__name">{{ $purchase->model ?: 'Unnamed Device' }}</div>
                                            <div class="purchase-report-device__meta">IMEI: {{ $purchase->imei ?: 'N/A' }}</div>
                                            <div class="purchase-report-device__meta">Storage: {{ $purchase->storage ?: 'N/A' }} | Color: {{ $purchase->color ?: 'N/A' }}</div>
                                        </td>
                                        <td>
                                            <div class="purchase-report-source__name">{{ $purchase->purchase_from ?: 'Unknown Supplier' }}</div>
                                            <div class="purchase-report-source__meta">Phone: {{ $purchase->contactno ?: 'N/A' }}</div>
                                        </td>
                                        <td>
                                            <div class="purchase-report-money__label">Buy Cost</div>
                                            <div class="purchase-report-money__value">{{ config('constant.currency') }}{{ number_format((float) $purchase->purchase_cost, 2) }}</div>
                                            <!-- <div class="purchase-report-money__label">Repairing</div> -->
                                            <!-- <div class="purchase-report-money__value">{{ config('constant.currency') }}{{ number_format((float) ($purchase->repairing_charge ?: 0), 2) }}</div> -->
                                            <!-- <div class="purchase-report-money__label">Stock Value</div>
                                            <div class="purchase-report-money__value purchase-report-money__value--main">{{ config('constant.currency') }}{{ number_format((float) $purchase->purchase_price, 2) }}</div> -->
                                        </td>
                                        <td>
                                            <span class="purchase-report-status purchase-report-status--{{ $purchase->is_sold ? 'sold' : 'available' }}">
                                                {{ $purchase->is_sold ? 'Sold' : 'Available' }}
                                            </span>
                                        </td>
                                        <!-- <td>
                                            <div class="purchase-report-note">{{ $purchase->remark ?: 'No notes recorded' }}</div>
                                        </td> -->
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                        <div class="mt-3">
                            {{ $allPurchased->appends(request()->query())->links('vendor.pagination.bootstrap-5') }}
                        </div>
                    @else
                        <div class="purchase-report-empty">
                            <div class="purchase-report-empty__icon">
                                <i class="mdi mdi-package-variant-closed"></i>
                            </div>
                            <h4>No purchases found</h4>
                            <p>Try another date range, status, or search term to view purchase activity.</p>
                        </div>
                    @endif
                </div>
            </div>
        </div>
    </div>

    <script>
        (function () {
            const periodSelect = document.getElementById('purchase-period');
            const dateGroups = document.querySelectorAll('.purchase-report-date-group');

            function toggleCustomDateFields() {
                const showDates = periodSelect && periodSelect.value === 'custom';

                dateGroups.forEach(function (group) {
                    group.style.display = showDates ? 'block' : 'none';
                });
            }

            if (periodSelect) {
                periodSelect.addEventListener('change', toggleCustomDateFields);
                toggleCustomDateFields();
            }
        })();
    </script>
@endsection
