@extends('layout.app')

@section('title')
    Manage Sales
@endsection

@section('content')
<div class="container-fluid sales-page">
    <div class="sales-topbar">
        <div>
            <h1 class="sales-topbar__title">Sales</h1>
            <p class="sales-topbar__subtitle">Browse, search, and manage every recorded sale.</p>
        </div>
        <div class="sales-topbar__actions">
            <div class="sales-mini-stat">
                <div class="sales-mini-stat__label">Total</div>
                <div class="sales-mini-stat__value">{{ $totalItems }}</div>
            </div>
        </div>
    </div>

    <div class="sales-card">
        <!-- <div class="sales-card__header">
            <div>
                <h4 class="sales-card__title">Sales Register</h4>
                <p class="sales-card__subtitle">Search by ID, customer, or item, then filter by year and payment type.</p>
            </div>
        </div> -->

        <form action="{{ route('allsales') }}" method="GET" id="filtersales" class="sales-filter-form">
            <div class="form-row align-items-end">
                <div class="form-group col-md-5 mb-2 mb-md-0">
                    <!-- <label class="sales-filter-label" for="searchsales">Search</label> -->
                    <div class="sales-search-group">
                        <input type="text" class="form-control" placeholder="Search by ID, customer, item.." name="search"
                            value="{{ request()->input('search') }}" id="searchsales">
                        <button class="btn btn-primary" type="submit">
                            <i class="mdi mdi-magnify"></i> Search
                        </button>
                    </div>
                </div>

                <div class="form-group col-md-3 mb-2 mb-md-0">
                    <!-- <label class="sales-filter-label" for="selectyear">Year</label> -->
                    <select name="year" class="form-control" id="selectyear">
                        <option value="">All Years</option>
                        @for ($filterYear = now()->year; $filterYear >= 2024; $filterYear--)
                            <option value="{{ $filterYear }}" @selected((int) $year === $filterYear)>
                                {{ $filterYear }}
                            </option>
                        @endfor
                    </select>
                </div>
                <div class="form-group col-md-4 mb-0">
                    <!-- <label class="sales-filter-label" for="payments">Payment Type</label> -->
                    <select name="paymentType" class="form-control" id="payments">
                        <option value="">All Payment Types</option>
                        <option value="Online" @selected($paymentType == 'Online')>Online</option>
                        <option value="Credit Card" @selected($paymentType == 'Credit Card')>Credit Card</option>
                        <option value="Cash" @selected($paymentType == 'Cash')>Cash</option>
                    </select>
                </div>
            </div>
        </form>

        @if (count($allSales))
            <div class="table-responsive sales-table-wrap">
                <table class="table sales-table table-hover m-0 table-centered dt-responsive nowrap w-100" id="tickets-table">
                    <thead>
                        <tr>
                            <th>
                                <a class="sales-sort-link" href="{{ route('allsales', ['direction' => $sortDirection == 'asc' ? 'desc' : 'asc']) }}">
                                    Sr.No
                                    @if ($sortDirection == 'asc')
                                        <i class="mdi mdi-arrow-up"></i>
                                    @else
                                        <i class="mdi mdi-arrow-down"></i>
                                    @endif
                                </a>
                            </th>
                            <th>Item Detail</th>
                            <th>Customer</th>
                            <th>Payment</th>
                            <th>Date</th>
                            <th class="text-right">Amount</th>
                            <th class="text-right">Action</th>
                        </tr>
                    </thead>

                    <tbody>
                        @foreach($allSales as $sale)
                            <tr>
                                <td><a href="{{ route('saledetail', $sale->id) }}" class="sales-index">#{{ $sale->id }}</a></td>
                                <td>
                                    @if($sale->items->isEmpty())
                                        <div class="sales-product">
                                            <div class="sales-product__title">No items</div>
                                        </div>
                                    @else
                                        @foreach ($sale->items as $item)
                                            @php
                                                $p = $item->purchase; // can be null if the record was detached later
                                            @endphp
                                            <div class="sales-product">
                                                <div class="sales-product__title">{{ $p->model ?? 'Unknown Model' }}</div>
                                                <div class="sales-product__meta">
                                                    <span class="sales-chip">Color: {{ $p->color ?? '-' }}</span>
                                                    <span class="sales-chip">Storage: {{ $p->storage ?? '-' }}</span>
                                                    <span class="sales-chip">IMEI: {{ $p->imei ?? '-' }}</span>
                                                    <span class="sales-chip">Qty: {{ $item->qty ?? 1 }}</span>
                                                </div>
                                            </div>
                                        @endforeach
                                    @endif
                                </td>
                                <td>
                                    <div class="sales-customer__name">{{ $sale->customer_name ?: 'Walk-in Customer' }}</div>
                                    @if($sale->customer_no)
                                        <div class="sales-customer__contact">
                                            <a href="tel:{{ $sale->customer_no }}">{{ $sale->customer_no }}</a>
                                        </div>
                                    @else
                                        <div class="text-muted">No contact number</div>
                                    @endif
                                </td>
                                <td>
                                    @if($sale->payment_type == 'Cash')
                                        <span class="badge badge-soft-primary text-primary px-3 py-2">{{ $sale->payment_type }}</span>
                                    @elseif($sale->payment_type == 'Online')
                                        <span class="badge badge-soft-info text-info px-3 py-2">{{ $sale->payment_type }}</span>
                                    @elseif($sale->payment_type == 'Credit Card')
                                        <span class="badge badge-soft-warning text-warning px-3 py-2">{{ $sale->payment_type }}</span>
                                    @else
                                        <span class="badge badge-light px-3 py-2">{{ $sale->payment_type }}</span>
                                    @endif
                                </td>
                                <td>
                                    <div class="sales-date">{{ Carbon\Carbon::parse($sale->created_at)->format('d M Y') }}</div>
                                </td>
                                <td class="sales-amount">
                                    <span class="sales-amount__value">₹{{ $sale->net_amount }}</span>
                                </td>
                                <td class="sales-actions">
                                    @can('sales.view')
                                        <a href="{{ route('saledetail', $sale->id) }}" class="btn btn-light btn-sm mr-2" title="View">
                                            <i class="mdi mdi-eye-outline"></i>
                                        </a>
                                    @endcan
                                    <form method="post" action="{{ route('delete-sale', $sale->id) }}" style="display:inline;">
                                        @csrf
                                        @method('DELETE')
                                        <button type="submit" class="btn btn-danger btn-sm" onclick="sureToDelete(event)" title="Delete">
                                            <i class="mdi mdi-trash-can-outline"></i>
                                        </button>
                                    </form>
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>

            <div class="pagination-links px-3 pb-3">
                {{ $allSales->appends(request()->query())->links('vendor.pagination.bootstrap-5') }}
            </div>
        @else
            <div class="sales-empty">
                <div class="sales-empty__icon">
                    <i class="mdi mdi-chart-timeline-variant"></i>
                </div>
                <h4>No sales found</h4>
                <p>Try a different search or filter.</p>
            </div>
        @endif
    </div>
</div>
@endSection
