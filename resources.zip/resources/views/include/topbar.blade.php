<div class="navbar-custom">
    <div class="container-fluid">
        <ul class="list-unstyled topnav-menu float-right mb-0">
            @canany(['invoices.create', 'purchases.create'])
                <li class="dropdown d-none d-xl-block pr-3 topnav-new-btn">
                    <a class="btn btn-success btn-sm dropdown-toggle waves-effect waves-light" data-toggle="dropdown" href="#" role="button"
                        aria-haspopup="true" aria-expanded="false">
                        <i class="mdi mdi-plus mr-1"></i> New
                    </a>
                    <div class="dropdown-menu">
                        @can('invoices.create')
                            <a href="{{ route('newinvoice') }}" class="dropdown-item">
                                <i class="fa fa-file-invoice mr-1"></i> New Invoice
                            </a>
                        @endcan
                        @can('purchases.create')
                            <a href="{{ route('purchase.create') }}" class="dropdown-item">
                                <i class="fa fa-plus-circle mr-1"></i> New Stock (Single)
                            </a>
                            <a href="{{ route('purchase.create.multiple') }}" class="dropdown-item">
                                <i class="fa fa-layer-group mr-1"></i> New Stock (Multiple)
                            </a>
                        @endcan
                    </div>
                </li>
            @endcanany
            <li class="dropdown d-none d-lg-inline-block">
                <a class="nav-link dropdown-toggle arrow-none waves-effect waves-light" data-toggle="fullscreen" href="#">
                    <i class="fe-maximize noti-icon"></i>
                </a>
            </li>

            <li class="dropdown notification-list topbar-dropdown">
                <a class="nav-link dropdown-toggle nav-user mr-0 waves-effect waves-light" data-toggle="dropdown" href="#" role="button"
                    aria-haspopup="true" aria-expanded="false">
                    <img src="{{asset('admin/users/' . auth()->user()->profile_image)}}" alt="user-image" class="rounded-circle">
                    <span class="pro-user-name ml-1">
                    {{ ucfirst(auth()->user()->user_name) }} <i class="mdi mdi-chevron-down"></i>
                    </span>
                </a>

                <div class="dropdown-menu dropdown-menu-right profile-dropdown ">
                    <!-- item-->
                    <div class="dropdown-header noti-title">
                        <h6 class="text-overflow m-0">Welcome !</h6>
                    </div>

                    <!-- item-->
                    <a href="{{route('admin.profile')}}" class="dropdown-item notify-item">
                        <i class="fe-user"></i>
                        <span>My Profile</span>
                    </a>
                    <a href="{{route('admin.changepassword')}}" class="dropdown-item notify-item">
                        <i class="fe-user"></i>
                        <span>Change Password</span>
                    </a>

                    <!-- item-->
                    <a href="javascript:void(0);" class="dropdown-item notify-item">
                        <i class="fe-lock"></i>
                        <span>Lock Screen</span>
                    </a>

                    <div class="dropdown-divider"></div>

                    <form method="POST" action="{{ route('logout') }}">
                        @csrf
                        <a href="route('logout')"
                                onclick="event.preventDefault(); this.closest('form').submit();" class="dropdown-item notify-item">
                            <i class="fe-log-out"></i><span>{{ __('Log Out') }}</span>
                        </a>
                    </form>

                </div>
            </li>
        </ul>

        <!-- LOGO -->
        <?php $companySetting = \App\Models\CompanySetting::current(); ?>
        <div class="logo-box">
            <a href="{{ route('dashboard')}}" class="logo logo-dark text-center">
                <span class="logo-sm">
                    <img src="{{ $companySetting->logo ? asset($companySetting->logo) : asset('assets/images/new_logo/fonico_mobiles.jpg') }}" alt="{{ $companySetting->company_name }}" height="40">
                </span>
                <span class="logo-lg">
                    <img src="{{ $companySetting->logo ? asset($companySetting->logo) : asset('assets/images/new_logo/fonico_mobiles.jpg') }}" alt="{{ $companySetting->company_name }}" height="40">
                </span>
            </a>

            <a href="{{ route('dashboard')}}" class="logo logo-light text-center">
                <span class="logo-sm">
                    <img src="{{ $companySetting->logo ? asset($companySetting->logo) : asset('assets/images/new_logo/fonico_mobiles.jpg') }}" alt="{{ $companySetting->company_name }}" height="22">
                </span>
                <span class="logo-lg">
                    <img src="{{ $companySetting->logo ? asset($companySetting->logo) : asset('assets/images/new_logo/fonico_mobiles.jpg') }}" alt="{{ $companySetting->company_name }}" height="22">
                </span>
            </a>
        </div>

        <ul class="list-unstyled topnav-menu topnav-menu-left m-0">
            <li>
                <button class="button-menu-mobile waves-effect waves-light">
                    <i class="fe-menu"></i>
                </button>
            </li>

            <li>
                <!-- Mobile menu toggle (Horizontal Layout)-->
                <a class="navbar-toggle nav-link" data-toggle="collapse" data-target="#topnav-menu-content">
                    <div class="lines">
                        <span></span>
                        <span></span>
                        <span></span>
                    </div>
                </a>
                <!-- End mobile menu toggle-->
            </li>
            <li style="width:50%;">
                <!-- App Search-->
                <form action="{{ route('admin.search') }}" method="GET" class="app-search d-none d-lg-block"
                    style="max-width: 460px; padding:calc(32px / 2) 0;">
                    <div class="position-relative">
                        <input
                            type="text"
                            name="q"
                            class="form-control"
                            value="{{ request('q') }}"
                            placeholder="Search purchase, invoice, customer, supplier..."
                            style="border-radius: 20px; padding-right: 44px;">
                        <button type="submit"
                            style="position:absolute; right: 6px; top: 50%; transform: translateY(-50%); border:0; background:transparent; color:#64748b; width:32px; height:32px; cursor:pointer;">
                            <i class="mdi mdi-magnify"></i>
                        </button>
                    </div>
                </form>
            </li>
        </ul>
        
        <div class="clearfix"></div>
    </div>
</div>
