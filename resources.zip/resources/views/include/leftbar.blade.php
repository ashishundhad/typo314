@php
    $user = auth()->user();
    $profileImage = !empty($user->profile_image)
        ? asset('admin/users/' . $user->profile_image)
        : asset('assets/images/users/user-1.jpg');

    $stocksOpen = request()->routeIs('allpurchases', 'purchase.create', 'purchase.create.multiple', 'purchase.edit', 'purchase-detail', 'purchase.importform');
    $salesOpen = request()->routeIs('allsales', 'new-sale', 'saledetail');
    $invoiceOpen = request()->routeIs('allinvoices', 'newinvoice', 'invoice-detail', 'pos.index');
    $reportsOpen = request()->routeIs('sale-report', 'profit-loss', 'daily-closing', 'purchase-report', 'saleschart');
    $financeOpen = request()->routeIs('finance-report', 'finance-report-export-csv', 'finance-report-export-pdf');
    $expensesOpen = request()->routeIs('expenses', 'add-expense', 'expense-categories.*');
    $partyOpen = request()->routeIs('customers', 'parties.*', 'transactions.*', 'supplier-ledger', 'supplier-ledger-detail');
    $ledgerOpen = request()->routeIs('ledger.*');
    $adminOpen = request()->routeIs('roles.*', 'users.*');
    $aiAssistantOpen = request()->routeIs('ai.*');
@endphp

<div class="left-side-menu">
    <div class="h-100" data-simplebar>
        <!-- <div class="sidebar-brand-card">
            <div class="sidebar-brand-card__logo">
                <img src="{{ asset('assets/images/new_logo/fonico_mobiles.jpg') }}" alt="Fonico">
            </div>
            <div class="sidebar-brand-card__title">Fonico Mobile</div>
            <p class="sidebar-brand-card__text">Inventory, billing, and reporting in one focused workspace.</p>
        </div> -->
<!-- 
        <div class="sidebar-user-card">
            <img src="{{ $profileImage }}" alt="{{ $user->name ?? $user->user_name }}" class="sidebar-user-card__avatar">
            <div>
                <div class="sidebar-user-card__name">{{ $user->name ?? ucfirst($user->user_name) }}</div>
                <div class="sidebar-user-card__role">Signed In</div>
            </div>
        </div> -->

        <div id="sidebar-menu">
            <ul id="side-menu">
                @can('dashboard.view')
                    <li class="{{ request()->routeIs('dashboard') ? 'menuitem-active' : '' }}">
                        <a href="{{ route('dashboard') }}">
                            <i data-feather="airplay"></i>
                            <span>Dashboard</span>
                        </a>
                    </li>
                @endcan

                <li class="{{ $aiAssistantOpen ? 'menuitem-active' : '' }}">
                    <a href="{{ route('ai.index') }}">
                        <i data-feather="message-square"></i>
                        <span>AI Assistant</span>
                    </a>
                </li>

                @canany(['purchases.view', 'purchases.create', 'purchase.create.multiple', 'purchases.import'])
                    <li class="{{ $stocksOpen ? 'menuitem-open menuitem-active' : '' }}">
                        <a data-toggle="collapse" href="#stocksMenu" role="button" aria-expanded="{{ $stocksOpen ? 'true' : 'false' }}" aria-controls="stocksMenu">
                            <i data-feather="shopping-cart"></i>
                            <span>Stocks</span>
                            <span class="menu-arrow"></span>
                        </a>
                        <div class="collapse {{ $stocksOpen ? 'show' : '' }}" id="stocksMenu">
                            <ul class="nav-second-level">
                                @can('purchases.view')
                                    <li><a href="{{ route('allpurchases') }}" class="{{ request()->routeIs('allpurchases') ? 'active' : '' }}">All Stocks</a></li>
                                @endcan
                                @can('purchases.import')
                                    <li><a href="{{ route('purchase.importform') }}" class="{{ request()->routeIs('purchase.importform') ? 'active' : '' }}">Import Stocks</a></li>
                                @endcan
                            </ul>
                        </div>
                    </li>
                @endcanany

                @canany(['sales.view', 'sales.create'])
                    <li class="{{ $salesOpen ? 'menuitem-open menuitem-active' : '' }}">
                        <a data-toggle="collapse" href="#salesMenu" role="button" aria-expanded="{{ $salesOpen ? 'true' : 'false' }}" aria-controls="salesMenu">
                            <i data-feather="briefcase"></i>
                            <span>Sell</span>
                            <span class="menu-arrow"></span>
                        </a>
                        <div class="collapse {{ $salesOpen ? 'show' : '' }}" id="salesMenu">
                            <ul class="nav-second-level">
                                @can('sales.view')
                                    <li><a href="{{ route('allsales') }}" class="{{ request()->routeIs('allsales', 'saledetail') ? 'active' : '' }}">Sold Items</a></li>
                                @endcan
                                @can('sales.create')
                                    <li><a href="{{ route('new-sale') }}" class="{{ request()->routeIs('new-sale') ? 'active' : '' }}">New Sale</a></li>
                                @endcan
                            </ul>
                        </div>
                    </li>
                @endcanany

                @canany(['invoices.view', 'invoices.create'])
                    <li class="{{ $invoiceOpen ? 'menuitem-open menuitem-active' : '' }}">
                        <a data-toggle="collapse" href="#invoiceMenu" role="button" aria-expanded="{{ $invoiceOpen ? 'true' : 'false' }}" aria-controls="invoiceMenu">
                            <i class="fa fa-file-invoice"></i>
                            <span>Invoice</span>
                            <span class="menu-arrow"></span>
                        </a>
                        <div class="collapse {{ $invoiceOpen ? 'show' : '' }}" id="invoiceMenu">
                            <ul class="nav-second-level">
                                @can('invoices.view')
                                    <li><a href="{{ route('allinvoices') }}" class="{{ request()->routeIs('allinvoices', 'invoice-detail') ? 'active' : '' }}">Manage Invoice</a></li>
                                @endcan
                                @can('invoices.create')
                                    <li><a href="{{ route('newinvoice') }}" class="{{ request()->routeIs('newinvoice') ? 'active' : '' }}">New Invoice</a></li>
                                @endcan
                            </ul>
                        </div>
                    </li>
                @endcanany

                @can('returns.view')
                    <li class="{{ request()->routeIs('sale-returns.index') ? 'menuitem-active' : '' }}">
                        <a href="{{ route('sale-returns.index') }}">
                            <i class="fa fa-undo"></i>
                            <span>Sale Returns</span>
                        </a>
                    </li>
                @endcan

                @can('repairs.view')
                    <li class="{{ request()->routeIs('repairs.index') ? 'menuitem-active' : '' }}">
                        <a href="{{ route('repairs.index') }}">
                            <i class="fa fa-tools"></i>
                            <span>Repairs</span>
                        </a>
                    </li>
                @endcan

                @canany(['invoices.view', 'purchases.view'])
                    <li class="{{ request()->routeIs('documents.index') ? 'menuitem-active' : '' }}">
                        <a href="{{ route('documents.index') }}">
                            <i class="fa fa-folder-open"></i>
                            <span>Documents</span>
                        </a>
                    </li>
                @endcanany

                @canany(['reports.sales.view', 'reports.purchases.view', 'reports.charts.view'])
                    <li class="{{ $reportsOpen ? 'menuitem-open menuitem-active' : '' }}">
                        <a data-toggle="collapse" href="#reportsMenu" role="button" aria-expanded="{{ $reportsOpen ? 'true' : 'false' }}" aria-controls="reportsMenu">
                            <i class="fa fa-chart-line"></i>
                            <span>Reports</span>
                            <span class="menu-arrow"></span>
                        </a>
                        <div class="collapse {{ $reportsOpen ? 'show' : '' }}" id="reportsMenu">
                            <ul class="nav-second-level">
                                @can('reports.sales.view')
                                    <li><a href="{{ route('sale-report') }}" class="{{ request()->routeIs('sale-report') ? 'active' : '' }}">Sales</a></li>
                                    <li><a href="{{ route('profit-loss') }}" class="{{ request()->routeIs('profit-loss') ? 'active' : '' }}">Profit & Loss</a></li>
                                    <li><a href="{{ route('daily-closing') }}" class="{{ request()->routeIs('daily-closing') ? 'active' : '' }}">Daily Closing</a></li>
                                @endcan
                                @can('reports.purchases.view')
                                    <li><a href="{{ route('purchase-report') }}" class="{{ request()->routeIs('purchase-report') ? 'active' : '' }}">Purchase</a></li>
                                @endcan
                                @can('reports.charts.view')
                                    <li><a href="{{ route('saleschart') }}" class="{{ request()->routeIs('saleschart') ? 'active' : '' }}">Chart</a></li>
                                @endcan
                            </ul>
                        </div>
                    </li>
                @endcanany

                @canany(['reports.sales.view'])
                    <li class="{{ $financeOpen ? 'menuitem-open menuitem-active' : '' }}">
                        <a data-toggle="collapse" href="#financeMenu" role="button" aria-expanded="{{ $financeOpen ? 'true' : 'false' }}" aria-controls="financeMenu">
                            <i class="fa fa-money-bill-wave"></i>
                            <span>Finance</span>
                            <span class="menu-arrow"></span>
                        </a>
                        <div class="collapse {{ $financeOpen ? 'show' : '' }}" id="financeMenu">
                            <ul class="nav-second-level">
                                @can('reports.sales.view')
                                    <li><a href="{{ route('finance-report') }}" class="{{ request()->routeIs('finance-report', 'finance-report-export-csv', 'finance-report-export-pdf') ? 'active' : '' }}">Tax Report</a></li>
                                @endcan
                            </ul>
                        </div>
                    </li>
                @endcanany

                @canany(['expenses.view', 'expenses.create', 'expense-categories.view'])
                    <li class="{{ $expensesOpen ? 'menuitem-open menuitem-active' : '' }}">
                        <a data-toggle="collapse" href="#expensesMenu" role="button" aria-expanded="{{ $expensesOpen ? 'true' : 'false' }}" aria-controls="expensesMenu">
                            <i class="fa fa-wallet"></i>
                            <span>Expense Tracker</span>
                            <span class="menu-arrow"></span>
                        </a>
                        <div class="collapse {{ $expensesOpen ? 'show' : '' }}" id="expensesMenu">
                            <ul class="nav-second-level">
                                @can('expenses.view')
                                    <li><a href="{{ route('expenses') }}" class="{{ request()->routeIs('expenses') ? 'active' : '' }}">Expenses</a></li>
                                @endcan
                                @can('expense-categories.view')
                                    <li><a href="{{ route('expense-categories.index') }}" class="{{ request()->routeIs('expense-categories.*') ? 'active' : '' }}">Categories</a></li>
                                @endcan
                                <!-- @can('expenses.create')
                                    <li><a href="{{ route('expenses', ['open' => 'add']) }}" class="{{ request()->has('open') && request('open') === 'add' ? 'active' : '' }}">Add Expense</a></li>
                                @endcan -->
                            </ul>
                        </div>
                    </li>
                @endcanany

                @canany(['reports.customers.view', 'parties.view', 'transactions.view', 'reports.purchases.view'])
                    <li class="{{ $partyOpen ? 'menuitem-open menuitem-active' : '' }}">
                        <a data-toggle="collapse" href="#partyMenu" role="button" aria-expanded="{{ $partyOpen ? 'true' : 'false' }}" aria-controls="partyMenu">
                            <i class="mdi mdi-account-cash-outline"></i>
                            <span>Parties</span>
                            <span class="menu-arrow"></span>
                        </a>
                        <div class="collapse {{ $partyOpen ? 'show' : '' }}" id="partyMenu">
                            <ul class="nav-second-level">
                                @can('reports.customers.view')
                                    <li><a href="{{ route('customers') }}" class="{{ request()->routeIs('customers') ? 'active' : '' }}">Customers</a></li>
                                @endcan
                                @can('parties.view')
                                    <li><a href="{{ route('parties.suppliers') }}" class="{{ request()->routeIs('parties.suppliers') ? 'active' : '' }}">Suppliers</a></li>
                                @endcan
                                @can('transactions.view')
                                    <li><a href="{{ route('transactions.index') }}" class="{{ request()->routeIs('transactions.index') ? 'active' : '' }}">Transactions</a></li>
                                @endcan
                                @can('reports.purchases.view')
                                    <li><a href="{{ route('supplier-ledger') }}" class="{{ request()->routeIs('supplier-ledger', 'supplier-ledger-detail') ? 'active' : '' }}">Supplier Ledger</a></li>
                                @endcan
                            </ul>
                        </div>
                    </li>
                @endcan

                @canany(['ledger.view', 'ledger.create'])
                    <li class="{{ $ledgerOpen ? 'menuitem-open menuitem-active' : '' }}">
                        <a data-toggle="collapse" href="#ledgerMenu" role="button" aria-expanded="{{ $ledgerOpen ? 'true' : 'false' }}" aria-controls="ledgerMenu">
                            <i class="fa fa-book"></i>
                            <span>Ledger</span>
                            <span class="menu-arrow"></span>
                        </a>
                        <div class="collapse {{ $ledgerOpen ? 'show' : '' }}" id="ledgerMenu">
                            <ul class="nav-second-level">
                                @can('ledger.view')
                                    <li><a href="{{ route('ledger.index') }}" class="{{ request()->routeIs('ledger.index', 'ledger.index.alias') ? 'active' : '' }}">Ledger List</a></li>
                                @endcan
                                @can('ledger.create')
                                    <li><a href="{{ route('ledger.create') }}" class="{{ request()->routeIs('ledger.create') ? 'active' : '' }}">New Entry</a></li>
                                @endcan
                            </ul>
                        </div>
                    </li>
                @endcanany

                @canany(['roles.view', 'roles.create', 'users.view', 'users.create'])
                    <li class="{{ $adminOpen ? 'menuitem-open menuitem-active' : '' }}">
                        <a data-toggle="collapse" href="#adminMenu" role="button" aria-expanded="{{ $adminOpen ? 'true' : 'false' }}" aria-controls="adminMenu">
                            <i class="fa fa-user-shield"></i>
                            <span>Admin Tools</span>
                            <span class="menu-arrow"></span>
                        </a>
                        <div class="collapse {{ $adminOpen ? 'show' : '' }}" id="adminMenu">
                            <ul class="nav-second-level">
                                @can('roles.view')
                                    <li><a href="{{ route('roles.index') }}" class="{{ request()->routeIs('roles.*') ? 'active' : '' }}">Role List</a></li>
                                @endcan
                                @can('users.view')
                                    <li><a href="{{ route('users.index') }}" class="{{ request()->routeIs('users.*') ? 'active' : '' }}">Users List</a></li>
                                @endcan
                            </ul>
                        </div>
                    </li>
                @endcanany

                @canany(['invoices.view', 'invoices.create'])
                    <li class="{{ request()->routeIs('pos.*') ? 'menuitem-active' : '' }}">
                        <a href="{{ route('pos.index') }}">
                            <i class="fa fa-user-shield"></i>
                            <span>POS</span>
                        </a>
                    </li>
                @endcanany

                @role('super-admin')
                    <li class="{{ request()->routeIs('admin.settings.*') ? 'menuitem-active' : '' }}">
                        <a href="{{ route('admin.settings.edit') }}">
                            <i class="fa fa-cog"></i>
                            <span>Settings</span>
                        </a>
                    </li>
                @endrole
            </ul>
        </div>

        <div class="clearfix"></div>
    </div>
</div>
