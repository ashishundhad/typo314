@extends('layout.app')

@section('title')
    Expenses List
@endsection

@section('content')
@php
    $expenseCount = $expenses->count();
    $averageExpense = $expenseCount ? $expenses->avg('amount') : 0;
    $todayExpense = $expenses->filter(function ($expense) {
        return \Carbon\Carbon::parse($expense->entrydate)->isToday();
    })->sum('amount');

    $years = range(now()->year, now()->year - 3);
    $months = [
        'All',
        'January', 'February', 'March', 'April', 'May', 'June',
        'July', 'August', 'September', 'October', 'November', 'December',
    ];

    $oldExpenseId = old('expense_id');
    $oldEditExpense = $oldExpenseId ? $expenses->firstWhere('id', (int) $oldExpenseId) : null;

    $breakdown = $expenses
        ->groupBy(fn ($expense) => $expense->category?->name ?? 'Uncategorized')
        ->map(fn ($group) => $group->sum('amount'))
        ->sortDesc();
    $breakdownMax = $breakdown->max() ?: 1;
@endphp

<div class="container-fluid expenses-page">
    <div class="expenses-topbar">
        <div>
            <h1 class="expenses-topbar__title">Expenses</h1>
            <p class="expenses-topbar__subtitle">Track and record what the business spends.</p>
        </div>
        <div class="expenses-topbar__actions">
            <div class="expenses-mini-stats mr-3">
                <div class="expenses-mini-stat">
                    <div class="expenses-mini-stat__label">Total</div>
                    <div class="expenses-mini-stat__value">₹{{ number_format((float) $totalExpenseAmount, 2) }}</div>
                </div>
                <div class="expenses-mini-stat">
                    <div class="expenses-mini-stat__label">Entries</div>
                    <div class="expenses-mini-stat__value">{{ $expenseCount }}</div>
                </div>
            </div>
            @can('expense-categories.view')
                <a href="{{ route('expense-categories.index') }}" class="expenses-link-btn">
                    <i class="mdi mdi-shape-outline"></i> Manage Categories
                </a>
            @endcan
        </div>
    </div>

    @if (session('status'))
        <div class="alert alert-success expenses-alert" id="statusMessage">
            {{ session('status') }}
        </div>
    @endif

    <div class="row">
        <div class="col-lg-8 mb-4">
            <div class="expenses-card">
                <div class="expenses-card__header">
                    <div>
                        <h4 class="expenses-card__title">Recent expenses</h4>
                        <p class="expenses-card__subtitle">Newest first</p>
                    </div>
                    <form action="{{ route('expenses') }}" method="GET" id="filterexpense" class="expenses-card__filters">
                        <select name="year" class="form-control" id="selectyear">
                            @foreach($years as $selectableYear)
                                <option value="{{ $selectableYear }}" @selected((int) $year === (int) $selectableYear)>{{ $selectableYear }}</option>
                            @endforeach
                        </select>
                        <select name="month" class="form-control" id="selectmonth">
                            @foreach($months as $selectableMonth)
                                <option value="{{ $selectableMonth }}" @selected($month === $selectableMonth)>{{ $selectableMonth }}</option>
                            @endforeach
                        </select>
                    </form>
                </div>

                @if(count($expenses) > 0)
                    <div class="table-responsive expenses-table-wrap">
                        <table class="table expenses-table table-hover m-0 table-centered dt-responsive nowrap w-100" id="tickets-table">
                            <thead>
                                <tr>
                                    <th>Date</th>
                                    <th>What for</th>
                                    <th>Amount</th>
                                    <th class="text-right">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach($expenses as $expense)
                                    <tr>
                                        <td class="expense-date">{{ \Carbon\Carbon::parse($expense->entrydate)->format('d M') }}</td>
                                        <td>
                                            <div class="expense-what">
                                                {{ $expense->category?->name ?? 'Uncategorized' }}
                                                @if($expense->description)
                                                    <small>{{ \Illuminate\Support\Str::limit($expense->description, 60) }}</small>
                                                @endif
                                            </div>
                                        </td>
                                        <td class="expense-amount">₹{{ number_format($expense->amount, 2) }}</td>
                                        <td class="text-right">
                                            <div class="expense-actions">
                                                @can('expenses.edit')
                                                    <button
                                                        type="button"
                                                        class="btn expense-edit-link js-edit-expense"
                                                        title="Update"
                                                        data-toggle="modal"
                                                        data-target="#editExpenseModal"
                                                        data-id="{{ $expense->id }}"
                                                        data-category="{{ $expense->expense_category_id }}"
                                                        data-amount="{{ $expense->amount }}"
                                                        data-entrydate="{{ \Carbon\Carbon::parse($expense->entrydate)->format('Y-m-d\TH:i') }}"
                                                        data-description="{{ $expense->description }}">
                                                        <i class="mdi mdi-square-edit-outline"></i>
                                                    </button>
                                                @endcan
                                                @can('expenses.delete')
                                                    <form method="post" action="{{ route('delete-expense', $expense->id) }}" style="display:inline;">
                                                        @csrf
                                                        @method('DELETE')
                                                        <button type="submit" class="btn btn-danger btn-sm" onclick="sureToDelete(event)" title="Delete">
                                                            <i class="fas fa-trash"></i>
                                                        </button>
                                                    </form>
                                                @endcan
                                            </div>
                                        </td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                @else
                    <div class="expense-empty">
                        <h5 class="mb-2">No expenses found</h5>
                        <p class="mb-0">Try a different filter or add a new expense record to get started.</p>
                    </div>
                @endif
            </div>
        </div>

        <div class="col-lg-4 mb-4">
            @can('expenses.create')
                <div class="expenses-card">
                    <div class="expenses-card__header">
                        <div>
                            <h4 class="expenses-card__title">Add an expense</h4>
                        </div>
                    </div>
                    <form method="post" action="{{ route('save-expense') }}" id="addExpenseForm" class="add-expense-form">
                        @csrf
                        <div class="form-group">
                            <label for="category">Category</label>
                            <select id="category" class="form-control" name="expense_category_id" required>
                                <option value="">-- Select Category --</option>
                                @foreach ($categories as $category)
                                    <option value="{{ $category->id }}" @selected((int) old('expense_category_id') === $category->id)>{{ $category->name }}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="description">Description</label>
                            <input
                                type="text"
                                id="description"
                                class="form-control"
                                name="description"
                                placeholder="For example: Courier for restock"
                                value="{{ old('description') }}">
                        </div>
                        <div class="form-group">
                            <label for="amount">Amount</label>
                            <input
                                type="number"
                                id="amount"
                                class="form-control @error('amount') parsley-error @enderror"
                                name="amount"
                                placeholder="0.00"
                                value="{{ old('amount') }}"
                                required
                                min="0"
                                step="0.01">
                            @error('amount')
                                <ul class="parsley-errors-list filled mt-2 mb-0" aria-hidden="false">
                                    <li class="parsley-required">{{ $message }}</li>
                                </ul>
                            @enderror
                        </div>
                        <div class="form-group">
                            <label for="expensedate">Date</label>
                            <input
                                type="datetime-local"
                                id="expensedate"
                                class="form-control @error('entrydate') parsley-error @enderror"
                                name="entrydate"
                                value="{{ old('entrydate', now()->format('Y-m-d\TH:i')) }}"
                                required>
                            @error('entrydate')
                                <ul class="parsley-errors-list filled mt-2 mb-0" aria-hidden="false">
                                    <li class="parsley-required">{{ $message }}</li>
                                </ul>
                            @enderror
                        </div>
                        <button type="submit" class="btn btn-save-expense">Save expense</button>
                    </form>
                </div>
            @endcan
        </div>
    </div>

    <div class="row">
        <div class="col-12 mb-4">
            <div class="expenses-card">
                <div class="expenses-card__header">
                    <div>
                        <h4 class="expenses-card__title">Where the money goes</h4>
                        <p class="expenses-card__subtitle">{{ $periodLabel }} {{ $year }} by category</p>
                    </div>
                </div>
                <div class="add-expense-form">
                    @forelse($breakdown as $categoryName => $categoryTotal)
                        <div class="breakdown-row">
                            <div class="breakdown-row__label">{{ $categoryName }}</div>
                            <div class="breakdown-row__track">
                                <div class="breakdown-row__fill" style="width: {{ max(4, round($categoryTotal / $breakdownMax * 100)) }}%"></div>
                            </div>
                            <div class="breakdown-row__value">₹{{ number_format($categoryTotal, 2) }}</div>
                        </div>
                    @empty
                        <p class="text-muted mb-0">No expenses in this period yet.</p>
                    @endforelse
                </div>
            </div>
        </div>
    </div>
</div>

@can('expenses.edit')
    <div class="modal fade expense-modal" id="editExpenseModal" tabindex="-1" role="dialog" aria-labelledby="editExpenseModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <div>
                        <h4 class="modal-title" id="editExpenseModalLabel">Edit Expense</h4>
                        <!-- <div class="modal-subtitle">Update an existing expense entry without leaving this page.</div> -->
                    </div>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form method="post" action="{{ $oldEditExpense ? route('expenseedit', $oldEditExpense->id) : '#' }}" id="editExpenseForm">
                    @csrf
                    <input type="hidden" name="expense_id" id="edit_expense_id" value="{{ old('expense_id') }}">
                    <div class="modal-body">
                        <div class="form-row">
                            <div class="form-group col-md-6">
                                <label for="edit_category">Expense Category</label>
                                <select id="edit_category" class="form-control" name="expense_category_id" required>
                                    <option value="">-- Select Category --</option>
                                    @foreach ($categories as $category)
                                        <option value="{{ $category->id }}" @selected((int) old('expense_category_id', $oldEditExpense->expense_category_id ?? 0) === $category->id)>{{ $category->name }}</option>
                                    @endforeach
                                </select>
                            </div>
                            <div class="form-group col-md-6">
                                <label for="edit_amount">Amount</label>
                                <input
                                    type="number"
                                    id="edit_amount"
                                    class="form-control @error('amount') parsley-error @enderror"
                                    name="amount"
                                    placeholder="Enter amount"
                                    value="{{ old('amount', $oldEditExpense->amount ?? '') }}"
                                    required
                                    min="0"
                                    step="0.01">
                                @if($errors->any() && old('expense_id'))
                                    @error('amount')
                                        <ul class="parsley-errors-list filled mt-2 mb-0" aria-hidden="false">
                                            <li class="parsley-required">{{ $message }}</li>
                                        </ul>
                                    @enderror
                                @endif
                            </div>
                            <div class="form-group col-md-6">
                                <label for="edit_expensedate">Expense Date</label>
                                <input
                                    type="datetime-local"
                                    id="edit_expensedate"
                                    class="form-control @if($errors->any() && old('expense_id')) @error('entrydate') parsley-error @enderror @endif"
                                    name="entrydate"
                                    value="{{ old('entrydate', $oldEditExpense ? \Carbon\Carbon::parse($oldEditExpense->entrydate)->format('Y-m-d\TH:i') : '') }}"
                                    required>
                                @if($errors->any() && old('expense_id'))
                                    @error('entrydate')
                                        <ul class="parsley-errors-list filled mt-2 mb-0" aria-hidden="false">
                                            <li class="parsley-required">{{ $message }}</li>
                                        </ul>
                                    @enderror
                                @endif
                            </div>
                            <div class="form-group col-md-6">
                                <label for="edit_description">Note</label>
                                <textarea class="form-control" id="edit_description" rows="4" name="description" placeholder="Add a short note">{{ old('description', $oldEditExpense->description ?? '') }}</textarea>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-light" data-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-success">Update Expense</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
@endcan

@endsection

@section('scripts')
<script>
    setTimeout(function() {
        document.getElementById('statusMessage')?.remove();
    }, 5000);

    document.getElementById('selectyear')?.addEventListener('change', function () {
        document.getElementById('filterexpense').submit();
    });

    document.getElementById('selectmonth')?.addEventListener('change', function () {
        document.getElementById('filterexpense').submit();
    });

    @can('expenses.create')
        $(function () {
            const addExpenseForm = document.getElementById('addExpenseForm');
            if (addExpenseForm) {
                addExpenseForm.addEventListener('submit', function (event) {
                    if (!this.checkValidity()) {
                        event.preventDefault();
                        event.stopPropagation();
                        this.reportValidity();
                    }
                });
            }
        });
    @endcan

    @can('expenses.edit')
        $(function () {
            const editExpenseForm = document.getElementById('editExpenseForm');
            const editExpenseId = document.getElementById('edit_expense_id');
            const editCategory = document.getElementById('edit_category');
            const editAmount = document.getElementById('edit_amount');
            const editEntrydate = document.getElementById('edit_expensedate');
            const editDescription = document.getElementById('edit_description');

            $('#editExpenseModal').on('show.bs.modal', function (event) {
                const trigger = event.relatedTarget;
                if (!trigger || !editExpenseForm) {
                    return;
                }

                const expenseId = trigger.getAttribute('data-id');
                editExpenseForm.action = "{{ url('/admin/expenses/update') }}/" + expenseId;
                editExpenseId.value = expenseId || '';
                editCategory.value = trigger.getAttribute('data-category') || '';
                editAmount.value = trigger.getAttribute('data-amount') || '';
                editEntrydate.value = trigger.getAttribute('data-entrydate') || '';
                editDescription.value = trigger.getAttribute('data-description') || '';
            });

            if (editExpenseForm) {
                editExpenseForm.addEventListener('submit', function (event) {
                    if (!this.checkValidity()) {
                        event.preventDefault();
                        event.stopPropagation();
                        $('#editExpenseModal').modal('show');
                        this.reportValidity();
                    }
                });
            }

            const shouldOpenEditModal = {{ $errors->any() && $oldExpenseId ? 'true' : 'false' }};
            if (shouldOpenEditModal) {
                $('#editExpenseModal').modal('show');
            }
        });
    @endcan
</script>
@endsection
