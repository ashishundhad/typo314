<?php $companySetting = \App\Models\CompanySetting::current(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <title>Upload Document | {{ $companySetting->company_name }}</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="robots" content="noindex">
    <link rel="shortcut icon" href="{{ $companySetting->logo ? asset($companySetting->logo) : asset('assets/images/new_logo/favicon.ico') }}">
    <link href="{{ asset('assets/css/bootstrap.min.css') }}" rel="stylesheet" type="text/css" />
    <link href="{{ asset('assets/css/icons.min.css') }}" rel="stylesheet" type="text/css" />
    <link href="{{ asset('assets/css/tenant.css') }}" rel="stylesheet" type="text/css" />
</head>
<body class="doc-upload-page">
    <div class="doc-upload-shell">
        <div class="doc-upload-card">
            <div class="doc-upload-card__icon">
                <i class="mdi mdi-card-account-details-outline"></i>
            </div>
            <h1 class="doc-upload-card__title">Upload ID Document</h1>
            <p class="doc-upload-card__subtitle">
                Staff at {{ $companySetting->company_name }} asked you to upload an identity document for your invoice.
                Use your camera below — it'll appear on their screen as soon as you submit.
            </p>

            @if ($errors->any())
                <div class="alert alert-danger">
                    @foreach ($errors->all() as $error)
                        {{ $error }}
                    @endforeach
                </div>
            @endif

            <form method="POST" action="{{ route('doc-upload.store', $token) }}" enctype="multipart/form-data">
                @csrf
                <div class="form-group mb-3">
                    <label class="form-label">Document Type</label>
                    <select name="document_type" id="documentType" class="form-control" required>
                        <option value="aadhar" {{ old('document_type') === 'aadhar' ? 'selected' : '' }}>Aadhar Card</option>
                        <option value="pan" {{ old('document_type') === 'pan' ? 'selected' : '' }}>PAN Card</option>
                        <option value="other" {{ old('document_type') === 'other' ? 'selected' : '' }}>Other</option>
                    </select>
                </div>

                <div class="form-group mb-3" id="documentTypeOtherWrap" style="display:none;">
                    <label class="form-label">Document Name</label>
                    <input type="text" name="document_type_other" class="form-control" placeholder="e.g. Voter ID" value="{{ old('document_type_other') }}">
                </div>

                <div class="form-group mb-3">
                    <label class="form-label">Document Number</label>
                    <input type="text" name="document_number" class="form-control" placeholder="Document number" value="{{ old('document_number') }}" required>
                </div>

                <div class="form-group mb-3">
                    <label class="form-label">Photo</label>
                    <input type="file" name="image" class="form-control" accept="image/*" capture="environment" required>
                    <small class="text-muted">This opens your camera directly.</small>
                </div>

                <button type="submit" class="btn btn-primary btn-block doc-upload-submit">
                    <i class="mdi mdi-upload mr-1"></i>Upload
                </button>
            </form>
        </div>
    </div>

    <script>
        document.getElementById('documentType').addEventListener('change', function () {
            document.getElementById('documentTypeOtherWrap').style.display = this.value === 'other' ? 'block' : 'none';
        });
    </script>
</body>
</html>
