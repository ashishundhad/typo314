<?php $companySetting = \App\Models\CompanySetting::current(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <title>Link Expired | {{ $companySetting->company_name }}</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="robots" content="noindex">
    <link rel="shortcut icon" href="{{ $companySetting->logo ? asset($companySetting->logo) : asset('assets/images/new_logo/favicon.ico') }}">
    <link href="{{ asset('assets/css/bootstrap.min.css') }}" rel="stylesheet" type="text/css" />
    <link href="{{ asset('assets/css/icons.min.css') }}" rel="stylesheet" type="text/css" />
    <link href="{{ asset('assets/css/tenant.css') }}" rel="stylesheet" type="text/css" />
</head>
<body class="doc-upload-page">
    <div class="doc-upload-shell">
        <div class="doc-upload-card doc-upload-card--error">
            <div class="doc-upload-card__icon doc-upload-card__icon--error">
                <i class="mdi mdi-link-variant-off"></i>
            </div>
            <h1 class="doc-upload-card__title">This Link Has Expired</h1>
            <p class="doc-upload-card__subtitle">
                QR codes for document uploads only last a little while, and each one can only be used once.
                Please ask staff at the counter to generate a fresh one.
            </p>
        </div>
    </div>
</body>
</html>
