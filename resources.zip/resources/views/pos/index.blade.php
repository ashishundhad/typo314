@extends('layout.app')

@section('title')
    Point of Sale
@endsection

@section('content')
    <div class="container-fluid invoice-create-shell">
        <div class="invoice-create-hero">
            <div class="row align-items-center">
                <div class="col-lg-8">
                    <h1 class="invoice-create-hero__title mb-0">Point of Sale</h1>
                </div>
                <div class="col-lg-4 text-lg-right">
                    <div class="invoice-create-hero__badge mt-3 mt-lg-0">Invoice #{{ $invoiceNo }}</div>
                </div>
            </div>
        </div>

        <div class="card invoice-create-card">
            <div class="card-body">
                @include('include.alert')

                <form action="{{ route('create-invoice') }}" method="post" id="posForm"
                    class="@if(count($errors)) was-validated @endif">
                    @csrf
                    <input type="hidden" name="invoice_no" value="{{ $invoiceNo }}">
                    <input type="hidden" name="invoice_date" value="{{ date('d/m/Y') }}">
                    <input type="hidden" name="gst_mode" id="gstMode" value="{{ $companySetting->gst_enabled ? old('gst_mode', $companySetting->default_gst_mode ?? 'exclude') : 'none' }}">

                    <div class="row align-items-start">
                        <div class="col-lg-8">
                            <div class="invoice-create-section">
                                <h2 class="invoice-create-section__title mb-1">Scan or Search Item</h2>
                                <p class="invoice-create-section__subtitle">Use a barcode scanner or type an IMEI / model and press Enter.</p>

                                <div id="itemsContainer" class="mb-2"></div>

                                <button type="button" class="btn btn-outline-success invoice-create-add" id="addItemBtn">
                                    <i class="mdi mdi-plus-circle-outline mr-1"></i>Add Line
                                </button>
                            </div>
                        </div>

                        <div class="col-lg-4">
                            <div class="invoice-create-section">
                                <h2 class="invoice-create-section__title">Customer</h2>
                                <div class="invoice-create-panel">
                                    <div class="mb-1">
                                        <label class="invoice-create-label" for="customer_no">Contact No</label>
                                        <input type="text" name="customer_no" id="customer_no"
                                            class="form-control invoice-create-input" maxlength="10"
                                            placeholder="Walk-in customer (optional)" value="{{ old('customer_no') }}">
                                    </div>
                                    <div class="mb-1">
                                        <label class="invoice-create-label" for="customer_name">Customer Name <span class="text-danger">*</span></label>
                                        <input type="text" name="customer_name" id="customer_name" required
                                            class="form-control invoice-create-input @error('customer_name') parsley-error @enderror"
                                            value="{{ old('customer_name', 'Walk-in Customer') }}">
                                        @error('customer_name')
                                            <div class="invalid-feedback">{{ $message }}</div>
                                        @enderror
                                    </div>
                                    <div class="mb-0">
                                        <label class="invoice-create-label" for="customer_address">Address</label>
                                        <input type="text" name="customer_address" id="customer_address"
                                            class="form-control invoice-create-input" placeholder="Optional"
                                            value="{{ old('customer_address') }}">
                                    </div>
                                </div>
                            </div>

                            <div class="invoice-create-section">
                                <h2 class="invoice-create-section__title">Payment</h2>
                                <div class="invoice-create-panel mb-1">
                                    <div class="mb-3" id="paymentModeWrap">
                                        <label class="invoice-create-label" for="payment_type">Payment Mode <span class="text-danger">*</span></label>
                                        <select name="payment_type" id="payment_type"
                                            class="form-control invoice-create-input @error('payment_type') parsley-error @enderror"
                                            required>
                                            <option value="">Select</option>
                                            <option value="Cash" {{ old('payment_type') === 'Cash' ? 'selected' : '' }}>Cash</option>
                                            <option value="Online" {{ old('payment_type') === 'Online' ? 'selected' : '' }}>Online/UPI</option>
                                            <option value="Credit Card" {{ old('payment_type') === 'Credit Card' ? 'selected' : '' }}>Credit Card</option>
                                        </select>
                                    </div>

                                    <div class="custom-control custom-checkbox mb-3">
                                        <input type="checkbox" class="custom-control-input" id="splitPaymentToggle">
                                        <label class="custom-control-label" for="splitPaymentToggle">Split payment across multiple methods</label>
                                    </div>

                                    <div id="splitPaymentSection" style="display:none;" class="mb-3">
                                        <input type="hidden" name="split_payment" id="splitPaymentFlag" value="0">
                                        <div id="splitPaymentRows"></div>
                                        <button type="button" class="btn btn-sm btn-outline-success mt-1" id="addSplitPaymentRow">
                                            <i class="mdi mdi-plus-circle-outline mr-1"></i>Add Payment Method
                                        </button>
                                        <div class="small mt-2">
                                            Remaining to allocate: <strong>{{ config('constant.currency') }} <span id="splitPaymentRemaining">0.00</span></strong>
                                        </div>
                                    </div>

                                    <button type="button" class="btn btn-link p-0 mb-0" id="toggleAdvancedBtn">
                                        <i class="mdi mdi-tune-variant mr-1"></i><span id="toggleAdvancedLabel">Discount / GST options</span>
                                    </button>

                                    <div id="advancedOptions" style="display:none;">
                                        <div class="mb-3">
                                            <label class="invoice-create-label" for="discAmount">Discount Amount</label>
                                            <input type="number" class="form-control invoice-create-input" placeholder="0.00"
                                                name="discount_amount" id="discAmount" min="0" value="{{ old('discount_amount') }}">
                                        </div>

                                        @if($companySetting->gst_enabled)
                                            <?php
                                                $defaultGstMode = old('gst_mode', $companySetting->default_gst_mode ?? 'exclude');
                                                $defaultGstRate = $companySetting->gst_percentage ? number_format($companySetting->gst_percentage / 2, 2, '.', '') : '';
                                            ?>
                                            <div class="mb-3">
                                                <label class="invoice-create-label" for="gstModeSelect">GST</label>
                                                <select class="form-control invoice-create-input" id="gstModeSelect">
                                                    <option value="exclude" @selected($defaultGstMode === 'exclude')>Exclude GST</option>
                                                    <option value="include" @selected($defaultGstMode === 'include')>Include GST</option>
                                                    <option value="none" @selected($defaultGstMode === 'none')>None</option>
                                                </select>
                                            </div>
                                            <div class="row" id="gstRateFields">
                                                <div class="col-4">
                                                    <label class="invoice-create-label">CGST (%)</label>
                                                    <input type="text" class="form-control invoice-create-input"
                                                        name="cgst_rate" id="cgst" value="{{ old('cgst_rate', $defaultGstRate) }}">
                                                    <input type="hidden" id="cgstAmount" name="cgst_amount" value="{{ old('cgst_amount', 0) }}">
                                                </div>
                                                <div class="col-4">
                                                    <label class="invoice-create-label">SGST (%)</label>
                                                    <input type="text" class="form-control invoice-create-input"
                                                        name="sgst_rate" id="sgst" value="{{ old('sgst_rate', $defaultGstRate) }}">
                                                    <input type="hidden" id="sgstAmount" name="sgst_amount" value="{{ old('sgst_amount', 0) }}">
                                                </div>
                                                <div class="col-4">
                                                    <label class="invoice-create-label">IGST (%)</label>
                                                    <input type="text" class="form-control invoice-create-input"
                                                        name="igst_rate" id="igst" value="{{ old('igst_rate') }}">
                                                    <input type="hidden" id="igstAmount" name="igst_amount" value="{{ old('igst_amount', 0) }}">
                                                </div>
                                            </div>
                                        @else
                                            <input type="hidden" id="cgst" name="cgst_rate" value="0">
                                            <input type="hidden" id="cgstAmount" name="cgst_amount" value="0">
                                            <input type="hidden" id="sgst" name="sgst_rate" value="0">
                                            <input type="hidden" id="sgstAmount" name="sgst_amount" value="0">
                                            <input type="hidden" id="igst" name="igst_rate" value="0">
                                            <input type="hidden" id="igstAmount" name="igst_amount" value="0">
                                        @endif
                                    </div>
                                </div>
                            </div>

                            <div class="invoice-create-summary" style="height: auto;">
                                <div class="invoice-create-summary__row">
                                    <span>Subtotal</span>
                                    <strong>{{ config('constant.currency') }} <span id="totalAmountDisplay">0.00</span></strong>
                                </div>
                                <div class="invoice-create-summary__row">
                                    <span>Discount</span>
                                    <strong>{{ config('constant.currency') }} <span id="discountAmount">0.00</span></strong>
                                </div>
                                <div class="invoice-create-summary__row" id="taxSummaryRow" style="display:none;">
                                    <span>GST (<span id="gstRateDisplay">0</span>%)</span>
                                    <strong>{{ config('constant.currency') }} <span id="taxDisplay">0.00</span></strong>
                                </div>
                                <div class="invoice-create-summary__row invoice-create-summary__row--total">
                                    <span>Net Amount</span>
                                    <span>{{ config('constant.currency') }} <span id="netAmountDisplay">0.00</span></span>
                                </div>

                                <input type="hidden" name="total_amount" id="totalAmountInput" value="0">
                                <input type="hidden" name="tax_amount" id="taxAmount" value="0">
                                <input type="hidden" name="net_amount" id="netAmount" value="0">
                            </div>

                            <button type="submit" class="btn btn-primary btn-block invoice-create-btn mt-3" id="completeSaleBtn">
                                <i class="mdi mdi-check-circle-outline mr-1"></i>Complete Sale
                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
@endsection

@section('scripts')
    <script>
        let itemCounter = 0;

        $(document).ready(function () {
            addItemRow();

            $(document).on('click', '#addItemBtn', function () {
                addItemRow();
            });

            $(document).on('click', '.remove-item', function () {
                if ($('.item-row').length <= 1) {
                    clearSelectedInventory($(this).closest('.item-row'));
                    calculateTotals();
                    return;
                }
                $(this).closest('.item-row').remove();
                calculateTotals();
            });

            $('#posForm').on('submit', function (e) {
                const hasSelectedItem = $('.item-row .item-id').filter(function () {
                    return $(this).val();
                }).length > 0;

                if (!hasSelectedItem) {
                    e.preventDefault();
                    alert('Please scan or select at least one item before completing the sale.');
                    return false;
                }

                const isSplitPayment = $('#splitPaymentToggle').is(':checked');

                if (!isSplitPayment && !$('#payment_type').val()) {
                    e.preventDefault();
                    alert('Please select a payment mode.');
                    return false;
                }

                if (isSplitPayment) {
                    const remaining = parseFloat($('#netAmount').val() || 0) - splitPaymentTotal();

                    if ($('.split-payment-row').length < 2) {
                        e.preventDefault();
                        alert('Add at least two payment methods, or turn off split payment.');
                        return false;
                    }

                    if (Math.abs(remaining) > 0.01) {
                        e.preventDefault();
                        alert('Split payment amounts must add up to the net amount (' + '{{ config("constant.currency") }}' + parseFloat($('#netAmount').val() || 0).toFixed(2) + ').');
                        return false;
                    }
                }

                $('#completeSaleBtn').prop('disabled', true).html('<i class="mdi mdi-loading mdi-spin mr-1"></i>Processing...');
            });

            let splitPaymentRowIndex = 0;

            function splitPaymentTotal() {
                let total = 0;
                $('.split-payment-row .split-payment-amount').each(function () {
                    total += parseFloat($(this).val()) || 0;
                });
                return total;
            }

            function updateSplitPaymentRemaining() {
                const net = parseFloat($('#netAmount').val()) || 0;
                const remaining = net - splitPaymentTotal();
                $('#splitPaymentRemaining').text(remaining.toFixed(2)).toggleClass('text-danger', Math.abs(remaining) > 0.01);
            }

            function addSplitPaymentRow() {
                splitPaymentRowIndex++;
                const rowHtml = `
                    <div class="row g-2 align-items-end split-payment-row mb-2" data-index="${splitPaymentRowIndex}">
                        <div class="col-5">
                            <select class="form-control invoice-create-input split-payment-method" name="payments[${splitPaymentRowIndex}][method]">
                                <option value="Cash">Cash</option>
                                <option value="Online">Online/UPI</option>
                                <option value="Credit Card">Credit Card</option>
                            </select>
                        </div>
                        <div class="col-5">
                            <input type="number" class="form-control invoice-create-input split-payment-amount"
                                name="payments[${splitPaymentRowIndex}][amount]" step="0.01" min="0" placeholder="Amount">
                        </div>
                        <div class="col-2">
                            <button type="button" class="btn btn-outline-danger btn-block remove-split-payment-row"><i class="mdi mdi-delete"></i></button>
                        </div>
                    </div>`;
                $('#splitPaymentRows').append(rowHtml);
            }

            $('#splitPaymentToggle').on('change', function () {
                const isSplit = $(this).is(':checked');
                $('#splitPaymentSection').toggle(isSplit);
                $('#splitPaymentFlag').val(isSplit ? '1' : '0');
                $('#paymentModeWrap').toggle(!isSplit);
                $('#payment_type').prop('required', !isSplit);

                if (isSplit && $('.split-payment-row').length === 0) {
                    addSplitPaymentRow();
                    addSplitPaymentRow();
                    updateSplitPaymentRemaining();
                }
            });

            $('#addSplitPaymentRow').on('click', function () {
                addSplitPaymentRow();
                updateSplitPaymentRemaining();
            });

            $(document).on('click', '.remove-split-payment-row', function () {
                $(this).closest('.split-payment-row').remove();
                updateSplitPaymentRemaining();
            });

            $(document).on('input', '.split-payment-amount', updateSplitPaymentRemaining);

            $('#customer_no').on('blur', function () {
                let contactNo = $(this).val().trim().replace(/\D/g, '');
                if (contactNo.length >= 10) {
                    fetchCustomerByContact(contactNo);
                }
            });

            $('#toggleAdvancedBtn').on('click', function () {
                const $panel = $('#advancedOptions');
                const isOpen = $panel.is(':visible');
                $panel.slideToggle(150);
                $('#toggleAdvancedLabel').text(isOpen ? 'Discount / GST options' : 'Hide discount / GST options');
            });

            $(document).on('input keyup change', '.item-price, .item-quantity', function () {
                calculateItemTotal($(this).closest('.item-row'));
            });

            $(document).on('input keyup change', '#cgst, #sgst, #igst, #discAmount', function () {
                calculateNetAmount();
            });

            $('#gstModeSelect').on('change', function () {
                $('#gstMode').val($(this).val());
                toggleGstRateFields();
                calculateNetAmount();
            });

            toggleGstRateFields();
            calculateTotals();
        });

        function fetchCustomerByContact(contactNo) {
            $.ajax({
                url: `/admin/fetchcustomer/${contactNo}`,
                type: 'GET',
                success: function (data) {
                    if (data.customer) {
                        $('#customer_name').val(data.customer.customer_name || 'Walk-in Customer');
                        $('#customer_address').val(data.customer.customer_address || '');
                        $('#customer_no').css('border-color', '#28a745');
                        setTimeout(function () { $('#customer_no').css('border-color', ''); }, 1500);
                    }
                },
                error: function () {
                    $('#customer_no').css('border-color', '');
                }
            });
        }

        function addItemRow(focus = true) {
            itemCounter++;
            const rowHtml = `
                <div class="item-row" data-index="${itemCounter}">
                    <div class="row g-2 align-items-end">
                        <div class="col-md-2">
                            <label class="form-label">Item Type</label>
                            <select class="form-control item-type" name="items[${itemCounter}][item_type]">
                                <option value="serialized">Phone (IMEI)</option>
                                <option value="bulk">Accessory</option>
                            </select>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label item-search-label" for="itemSearch${itemCounter}">IMEI <span class="text-danger">*</span> <small class="text-danger item-search-error" style="display:none;"></small></label>
                            <input type="text" class="form-control item-search" placeholder="Scan or type IMEI.." id="itemSearch${itemCounter}" autocomplete="off">
                            <div class="list-group imei_suggestions item-suggestions"></div>
                            <input type="hidden" class="item-id" name="items[${itemCounter}][item_id]">
                            <input type="hidden" class="item-description" name="items[${itemCounter}][item_description]">
                        </div>
                        <div class="col-md-1">
                            <label class="form-label">Qty</label>
                            <input type="number" class="form-control item-quantity"
                                name="items[${itemCounter}][quantity]" value="1" min="1">
                        </div>
                        <div class="col-md-2">
                            <label class="form-label">Price</label>
                            <input type="number" class="form-control item-price"
                                name="items[${itemCounter}][unit_price]" step="0.01" min="0" placeholder="0.00">
                        </div>
                        <div class="col-md-2">
                            <label class="form-label">Total</label>
                            <input type="text" class="form-control item-total" readonly value="0.00">
                        </div>
                        <div class="col-md-1 d-flex align-items-end">
                            <button type="button" class="btn btn-outline-danger remove-item" title="Remove">
                                <i class="mdi mdi-delete"></i>
                            </button>
                        </div>
                    </div>
                </div>`;
            $('#itemsContainer').append(rowHtml);
            const $row = $('#itemsContainer .item-row').last();
            syncItemTypeState($row);

            if (focus) {
                $row.find('.item-search').focus();
            }
        }

        function syncItemTypeState($row) {
            const isBulk = $row.find('.item-type').val() === 'bulk';
            $row.find('.item-search-label').html((isBulk ? 'Accessory / SKU' : 'IMEI') + ' <span class="text-danger">*</span> <small class="text-danger item-search-error" style="display:none;"></small>');
            $row.find('.item-search').attr('placeholder', isBulk ? 'Search accessory or SKU..' : 'Scan or type IMEI..');
            $row.find('.item-quantity').prop('readonly', !isBulk).val(isBulk ? ($row.find('.item-quantity').val() || 1) : 1);
            clearSelectedInventory($row, true);
            calculateItemTotal($row);
        }

        $(document).on('change', '.item-type', function () {
            syncItemTypeState($(this).closest('.item-row'));
        });

        function clearSelectedInventory($row, clearSearch = true) {
            if (clearSearch) {
                $row.find('.item-search').val('');
            }
            $row.find('.item-id').val('');
            $row.find('.item-description').val('');
            $row.find('.item-price').val('0.00');
            $row.find('.item-total').val('0.00');
            $row.find('.item-suggestions').removeClass('show').empty();
            $row.find('.item-search-error').hide();
            $row.removeClass('item-row--filled item-row--flash');
        }

        function getSelectedItemIds($currentRow) {
            const selectedIds = [];
            $('.item-row').each(function () {
                const $row = $(this);
                if ($row[0] === $currentRow[0]) return;
                const selectedId = $row.find('.item-id').val();
                if (selectedId) selectedIds.push(String(selectedId));
            });
            return selectedIds;
        }

        function buildItemDescription(item) {
            let desc = `Model: ${item['model'] || ''}\n`;
            if (item['sku']) desc += `SKU: ${item['sku']}\n`;
            if (item['color']) desc += `Color: ${item['color']}\n`;
            if (item['storage']) desc += `Storage: ${item['storage']}\n`;
            if (item['imei']) {
                desc += `IMEI: ${item['imei']}`;
            } else if (typeof item['available_quantity'] !== 'undefined') {
                desc += `Available Qty: ${item['available_quantity']}`;
            }
            return desc.trim();
        }

        function selectInventoryItem($row, item, itemType) {
            $row.find('.item-search').val(itemType === 'bulk' ? (item['sku'] || item['model']) : item['imei']);
            $row.find('.item-id').val(item['id']);
            $row.find('.item-description').val(buildItemDescription(item));
            $row.find('.item-price').val(item['purchase_price']).trigger('input');
            if (itemType !== 'bulk') {
                $row.find('.item-quantity').val(1);
            }
            $row.find('.item-suggestions').removeClass('show').empty();

            // Line is filled in and ready — flash it so the cashier gets clear
            // confirmation the scan/search landed, then park focus on Price in
            // case it needs adjusting. A new line is only ever added via the
            // "Add Line" button, never automatically.
            $row.addClass('item-row--filled');
            window.setTimeout(function () {
                $row.removeClass('item-row--flash');
            }, 600);
            $row.addClass('item-row--flash');
            $row.find('.item-price').focus().select();
        }

        function searchInventory($row, autoSelectSingleMatch) {
            const suggestions = $row.find('.item-suggestions')[0];
            const query = ($row.find('.item-search').val() || '').trim();
            const itemType = $row.find('.item-type').val();
            if (!query) return;

            const selectedIds = getSelectedItemIds($row);
            const endpoint = itemType === 'bulk' ? `/admin/fetchbulkstock/${encodeURIComponent(query)}` : `/admin/fetchstockonimei/${encodeURIComponent(query)}`;

            $.ajax({
                url: endpoint,
                type: 'GET',
                success: function (data) {
                    suggestions.innerHTML = '';
                    $row.find('.item-search-error').hide();

                    const filteredData = (data || []).filter(item => !selectedIds.includes(String(item['id'] || '')));

                    if (filteredData.length === 0) {
                        $row.find('.item-search-error').text(itemType === 'bulk' ? 'No bulk stock found for this search' : 'No available IMEI found for this search').show();
                        suggestions.classList.remove('show');
                        return;
                    }

                    // Hardware scanners submit an exact IMEI followed by Enter — if that
                    // exact match is the only result, select it immediately instead of
                    // making the cashier click a dropdown entry.
                    if (autoSelectSingleMatch && filteredData.length === 1) {
                        selectInventoryItem($row, filteredData[0], itemType);
                        return;
                    }

                    filteredData.forEach(item => {
                        let option = document.createElement('a');
                        option.classList.add('list-group-item', 'list-group-item-action');
                        option.textContent = itemType === 'bulk'
                            ? `${item['model']} (${item['available_quantity']} available)`
                            : `${item['imei']} - ${item['model']}`;
                        option.href = '#';

                        option.addEventListener('mousedown', function (e) {
                            e.preventDefault();
                            selectInventoryItem($row, item, itemType);
                        });

                        suggestions.appendChild(option);
                    });

                    suggestions.classList.add('show');
                },
                error: function (xhr) {
                    const message = xhr.status === 403
                        ? "You don't have permission to search stock. Contact an admin."
                        : (itemType === 'bulk' ? 'Bulk item not found' : 'IMEI not found');
                    $row.find('.item-search-error').text(message).show();
                }
            });
        }

        $(document).on('input', '.item-search', function () {
            const $row = $(this).closest('.item-row');
            const query = $(this).val().trim();
            $row.find('.item-search-error').hide();

            if (!query) {
                clearSelectedInventory($row, false);
            }

            clearTimeout($(this).data('searchTimer'));

            if (query.length >= 2) {
                $(this).data('searchTimer', setTimeout(function () {
                    searchInventory($row, false);
                }, 300));
            } else {
                const suggestions = $row.find('.item-suggestions')[0];
                if (suggestions) {
                    suggestions.classList.remove('show');
                    suggestions.innerHTML = '';
                }
            }
        });

        $(document).on('blur', '.item-search', function () {
            const $row = $(this).closest('.item-row');
            setTimeout(function () {
                const suggestions = $row.find('.item-suggestions')[0];
                if (suggestions) {
                    suggestions.classList.remove('show');
                    suggestions.innerHTML = '';
                }
            }, 150);
        });

        $(document).on('keydown', '.item-search', function (e) {
            if (e.which === 13) {
                e.preventDefault();
                clearTimeout($(this).data('searchTimer'));
                searchInventory($(this).closest('.item-row'), true);
            }
        });

        function calculateItemTotal($row) {
            const qty = parseFloat($row.find('.item-quantity').val()) || 1;
            const price = parseFloat($row.find('.item-price').val()) || 0;
            const total = qty * price;
            $row.find('.item-total').val(total.toFixed(2));
            calculateTotals();
        }

        function calculateTotals() {
            let total = 0;
            $('.item-total').each(function () {
                total += parseFloat($(this).val()) || 0;
            });
            $('#totalAmountInput').val(total.toFixed(2));
            $('#totalAmountDisplay').text(total.toFixed(2));
            calculateNetAmount();
        }

        function calculateNetAmount() {
            const total = parseFloat($('#totalAmountInput').val()) || 0;
            const discount = parseFloat($('#discAmount').val()) || 0;
            const gstMode = $('#gstMode').val() || 'none';

            let cgst = 0, sgst = 0, igst = 0;
            if (gstMode !== 'none') {
                cgst = parseFloat($('#cgst').val()) || 0;
                sgst = parseFloat($('#sgst').val()) || 0;
                igst = parseFloat($('#igst').val()) || 0;
            }

            let cgstAmt = 0, sgstAmt = 0, igstAmt = 0, tax = 0, net = 0, subtotal = total;

            if (gstMode === 'include') {
                // Item prices already include GST — the displayed "Subtotal" is the
                // tax-exclusive taxable value, so Subtotal + GST - Discount reads as
                // Net Amount on screen instead of double-counting the tax.
                const combinedRate = cgst + sgst + igst;
                const taxable = combinedRate > 0 ? total / (1 + combinedRate / 100) : total;
                tax = total - taxable;
                subtotal = taxable;
                cgstAmt = combinedRate > 0 ? tax * (cgst / combinedRate) : 0;
                sgstAmt = combinedRate > 0 ? tax * (sgst / combinedRate) : 0;
                igstAmt = combinedRate > 0 ? tax * (igst / combinedRate) : 0;
                net = total - discount;
            } else if (gstMode === 'exclude') {
                cgstAmt = (cgst / 100) * total;
                sgstAmt = (sgst / 100) * total;
                igstAmt = (igst / 100) * total;
                tax = cgstAmt + sgstAmt + igstAmt;
                net = total + tax - discount;
            } else {
                net = total - discount;
            }

            $('#cgstAmount').val(cgstAmt.toFixed(2));
            $('#sgstAmount').val(sgstAmt.toFixed(2));
            $('#igstAmount').val(igstAmt.toFixed(2));
            $('#taxAmount').val(tax.toFixed(2));
            $('#taxDisplay').text(tax.toFixed(2));
            $('#discountAmount').text(discount.toFixed(2));
            $('#totalAmountDisplay').text(subtotal.toFixed(2));
            $('#netAmountDisplay').text(net.toFixed(2));
            $('#netAmount').val(net.toFixed(2));

            const combinedRate = cgst + sgst + igst;
            $('#gstRateDisplay').text(combinedRate % 1 === 0 ? combinedRate : combinedRate.toFixed(2));
            $('#taxSummaryRow').toggle(gstMode !== 'none' && tax > 0);

            if (typeof updateSplitPaymentRemaining === 'function') {
                updateSplitPaymentRemaining();
            }
        }

        function toggleGstRateFields() {
            const $fields = $('#gstRateFields');
            if (!$fields.length) return;
            $fields.toggle($('#gstMode').val() !== 'none');
        }
    </script>
@endsection
