@extends('layout.app')

@section('title')
    Global Search
@endsection

@section('content')

    @php
        $totalResults = $purchaseResults->count() + $invoiceResults->count();
    @endphp

    <div class="global-search-page">
        <div class="global-search-hero">
            <div>
                <h1 class="global-search-hero__title">Global Search</h1>
                <p class="global-search-hero__text">
                    Search across purchase stock and invoices from one place. You can look up inventory items,
                    invoice numbers, customer names, IMEI values, and purchase sources.
                </p>
            </div>

            <div class="global-search-hero__summary">
                <div class="global-search-hero__summary-label">Search Results</div>
                <div class="global-search-hero__summary-value">{{ $totalResults }}</div>
                <div class="global-search-hero__summary-note">
                    @if($query !== '')
                        Showing matches for "{{ $query }}"
                    @else
                        Start with a keyword from the top bar search.
                    @endif
                </div>
            </div>
        </div>

        @if($query === '')
            <div class="global-search-section">
                <div class="search-state">
                    <div class="search-state__icon">
                        <i class="mdi mdi-magnify"></i>
                    </div>
                    <h2 class="search-state__title">Search purchases and invoices</h2>
                    <p class="search-state__text">
                        Try an invoice ID, customer name, model, IMEI, or supplier name like purchase_from to quickly
                        jump to the right record.
                    </p>
                </div>
            </div>
        @else
            <div class="global-search-grid">
                @if($canViewPurchases)
                    <section class="global-search-section">
                        <div class="global-search-section__head">
                            <h2 class="global-search-section__title">Purchase Matches</h2>
                            <span class="global-search-section__count">{{ $purchaseResults->count() }}</span>
                        </div>

                        @if($purchaseResults->isEmpty())
                            <div class="search-state">
                                <div class="search-state__icon">
                                    <i class="mdi mdi-package-variant-closed"></i>
                                </div>
                                <h3 class="search-state__title">No purchase matches</h3>
                                <p class="search-state__text">No stock records matched "{{ $query }}".</p>
                            </div>
                        @else
                            <div class="global-search-results">
                                @foreach($purchaseResults as $purchase)
                                    <a href="{{ route('purchase-detail', $purchase->id) }}" class="search-card">
                                        <div class="search-card__top">
                                            <div>
                                                <div class="search-card__meta">Purchase #{{ $purchase->id }}</div>
                                                <h3 class="search-card__title">{{ ucfirst($purchase->model) }}</h3>
                                                <div class="search-card__value">
                                                    <strong>IMEI:</strong> {{ $purchase->imei }}
                                                </div>
                                            </div>

                                            <div class="search-card__price">
                                                <strong>{{ config('constant.currency') . number_format((float) $purchase->purchase_price, 2) }}</strong>
                                            </div>
                                        </div>

                                        <div class="search-card__bottom">
                                            <div class="search-card__label">
                                                <strong>Purchase From:</strong> {{ $purchase->purchase_from ?: 'N/A' }}<br>
                                                <strong>Date:</strong>
                                                {{ $purchase->purchase_date ? \Carbon\Carbon::parse($purchase->purchase_date)->format('d M Y') : 'N/A' }}
                                            </div>

                                            <div class="search-card__label text-right">
                                                <strong>Status:</strong> {{ $purchase->is_sold ? 'Sold' : 'Available' }}
                                            </div>
                                        </div>

                                        <div class="search-card__tags">
                                            @if($purchase->storage)
                                                <span class="search-card__tag">{{ $purchase->storage }} GB</span>
                                            @endif
                                            @if($purchase->color)
                                                <span class="search-card__tag">{{ ucfirst($purchase->color) }}</span>
                                            @endif
                                            @if($purchase->contactno)
                                                <span class="search-card__tag">{{ $purchase->contactno }}</span>
                                            @endif
                                        </div>
                                    </a>
                                @endforeach
                            </div>
                        @endif
                    </section>
                @endif

                @if($canViewInvoices)
                    <section class="global-search-section">
                        <div class="global-search-section__head">
                            <h2 class="global-search-section__title">Invoice Matches</h2>
                            <span class="global-search-section__count">{{ $invoiceResults->count() }}</span>
                        </div>

                        @if($invoiceResults->isEmpty())
                            <div class="search-state">
                                <div class="search-state__icon">
                                    <i class="mdi mdi-receipt"></i>
                                </div>
                                <h3 class="search-state__title">No invoice matches</h3>
                                <p class="search-state__text">No invoice records matched "{{ $query }}".</p>
                            </div>
                        @else
                            <div class="global-search-results">
                                @foreach($invoiceResults as $invoice)
                                    <a href="{{ $canOpenInvoiceDetail
                                        ? route('allinvoices', ['invoice' => $invoice->id])
                                        : route('allinvoices', ['search' => $invoice->invoice_no ?: $query, 'invoice' => $invoice->id]) }}"
                                        class="search-card">
                                        <div class="search-card__top">
                                            <div>
                                                <div class="search-card__meta">{{ $invoice->invoice_no ?: 'Invoice #' . $invoice->id }}</div>
                                                <h3 class="search-card__title">{{ $invoice->customer_name }}</h3>
                                                <div class="search-card__value">
                                                    <strong>Customer No:</strong> {{ $invoice->customer_no ?: 'N/A' }}
                                                </div>
                                            </div>

                                            <div class="search-card__price">
                                                <strong>{{ config('constant.currency') . number_format((float) $invoice->net_amount, 2) }}</strong>
                                            </div>
                                        </div>

                                        <div class="search-card__bottom">
                                            <div class="search-card__label">
                                                <strong>Invoice Date:</strong>
                                                {{ $invoice->invoice_date ? \Carbon\Carbon::parse($invoice->invoice_date)->format('d M Y') : 'N/A' }}<br>
                                                <strong>Payment:</strong> {{ $invoice->payment_type ?: 'N/A' }}
                                            </div>

                                            <div class="search-card__label text-right">
                                                <strong>Items:</strong> {{ $invoice->items->count() }}<br>
                                                <strong>ID:</strong> #{{ $invoice->id }}
                                            </div>
                                        </div>

                                        @if($invoice->items->isNotEmpty())
                                            <div class="search-card__tags">
                                                @foreach($invoice->items->take(3) as $item)
                                                    <span class="search-card__tag">
                                                        {{ $item->purchase->model ?? $item->item_description ?? 'Item' }}
                                                    </span>
                                                @endforeach
                                            </div>
                                        @endif
                                    </a>
                                @endforeach
                            </div>
                        @endif
                    </section>
                @endif
            </div>
        @endif
    </div>
@endsection
