@extends('layout.app')

@section('title', $pageTitle ?? 'Parties')

@section('content')
<div class="container-fluid parties-page">
    <div class="parties-topbar">
        <div>
            <h1 class="parties-topbar__title">{{ $pageTitle ?? 'Parties' }}</h1>
            <p class="parties-topbar__subtitle">Track who owes you, and who you owe, in one running ledger.</p>
        </div>
        <div class="parties-topbar__actions">
            <div class="parties-mini-stats">
                <div class="parties-mini-stat">
                    <div class="parties-mini-stat__label">Total</div>
                    <div class="parties-mini-stat__value">{{ $parties->total() }}</div>
                </div>
                <div class="parties-mini-stat">
                    <div class="parties-mini-stat__label">You'll Give</div>
                    <div class="parties-mini-stat__value parties-mini-stat__value--give">₹{{ number_format($totalCredit, 2) }}</div>
                </div>
                <div class="parties-mini-stat">
                    <div class="parties-mini-stat__label">You'll Get</div>
                    <div class="parties-mini-stat__value parties-mini-stat__value--get">₹{{ number_format($totalDebit, 2) }}</div>
                </div>
            </div>
            @can('parties.create')
                <button type="button" class="btn btn-primary" data-target="#addnewPartyModal" data-toggle="modal">
                    <i class="mdi mdi-plus-circle-outline"></i> Add Party
                </button>
            @endcan
        </div>
    </div>

    <div class="sales-card">
        <div class="sales-card__header">
            <div>
                <h4 class="sales-card__title">{{ $pageTitle ?? 'Parties' }} Register</h4>
                <p class="sales-card__subtitle">Search by name or phone, then filter by type.</p>
            </div>
        </div>

        <form action="{{ $formAction }}" method="GET" id="filterparties" class="sales-filter-form">
            <div class="form-row align-items-end">
                <div class="form-group col-md-6 mb-2 mb-md-0">
                    <div class="sales-search-group">
                        <input type="text" class="form-control" placeholder="Search by name or phone.." name="search"
                            value="{{ $search ?? '' }}" id="searchparties">
                        <button class="btn btn-primary" type="submit">
                            <i class="mdi mdi-magnify"></i> Search
                        </button>
                    </div>
                </div>
                <div class="form-group col-md-3 mb-0">
                    <select name="type" class="form-control" id="selecttype" onchange="document.getElementById('filterparties').submit();">
                        <option value="">All Types</option>
                        <option value="Customer" @selected(($type ?? '') === 'Customer')>Customer</option>
                        <option value="Supplier" @selected(($type ?? '') === 'Supplier')>Supplier</option>
                    </select>
                </div>
            </div>
        </form>

        @if (count($parties))
            <div class="table-responsive sales-table-wrap">
                <table class="table sales-table table-hover m-0">
                    <thead>
                        <tr>
                            <th>Party Name</th>
                            <th>Party Type</th>
                            <th class="text-right">Amount</th>
                            <th class="text-right">Action</th>
                        </tr>
                    </thead>

                    <tbody>
                        @foreach($parties as $party)
                            <tr>
                                <td>
                                    <div class="sales-product" style="display:flex; align-items:center; gap:10px;">
                                        <div class="avatar">{{ strtoupper(substr($party->party_name, 0, 1)) }}</div>
                                        <div>
                                            <div class="sales-customer__name">{{ ucfirst($party->party_name) }}</div>
                                            @php $lastTransaction = $party->transactions()->latest()->first(); @endphp
                                            <small class="text-muted">{{ $lastTransaction ? $lastTransaction->created_at->diffForHumans() : 'No activity yet' }}</small>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <span class="badge {{ $party->party_type === 'Supplier' ? 'badge-soft-info text-info' : 'badge-soft-primary text-primary' }} px-3 py-2">{{ $party->party_type }}</span>
                                </td>
                                <td class="text-right sales-amount">
                                    @if($party->balance > 0)
                                        <span class="sales-amount__value" style="color:#1abc9c;">₹{{ number_format($party->balance, 2) }}</span>
                                        <span class="sales-amount__label">You'll Give</span>
                                    @elseif($party->balance < 0)
                                        <span class="sales-amount__value" style="color:#ef4444;">₹{{ number_format(abs($party->balance), 2) }}</span>
                                        <span class="sales-amount__label">You'll Get</span>
                                    @else
                                        <span class="sales-amount__value">₹0.00</span>
                                    @endif
                                </td>
                                <td class="text-right sales-actions">
                                    <button type="button" data-id="{{ $party->id }}" class="add-transaction-btn btn btn-light btn-sm" title="Add Transaction">
                                        <i class="mdi mdi-plus"></i>
                                    </button>
                                    <button type="button" data-id="{{ $party->id }}" class="view-party-btn btn btn-light btn-sm" title="View">
                                        <i class="mdi mdi-eye-outline"></i>
                                    </button>
                                    <button data-id="{{ $party->id }}" class="btn btn-light btn-sm edit-party" title="Edit">
                                        <i class="mdi mdi-square-edit-outline"></i>
                                    </button>
                                    <button type="button" class="btn btn-danger btn-sm delete-party" data-id="{{ $party->id }}" title="Delete">
                                        <i class="mdi mdi-trash-can-outline"></i>
                                    </button>
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>

            <div class="pagination-links px-3 pb-3">
                {{ $parties->links('vendor.pagination.bootstrap-5') }}
            </div>
        @else
            <div class="sales-empty">
                <div class="sales-empty__icon">
                    <i class="mdi mdi-account-cash-outline"></i>
                </div>
                <h4>No {{ strtolower($pageTitle ?? 'parties') }} found</h4>
                <p>Try a different search or filter, or add your first one.</p>
            </div>
        @endif
    </div>
</div>

<!-- Party Detail Modal -->
<div class="modal fade" id="partyDetailModal" tabindex="-1" role="dialog" aria-labelledby="partyDetailLabel">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="partyDetailLabel"></h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span>&times;</span>
                </button>
            </div>
            <div class="modal-body pt-0" id="party-detail-content">
                Loading...
            </div>
        </div>
    </div>
</div>

<!-- Add New Party Modal -->
<div class="modal fade" id="addnewPartyModal" tabindex="-1" role="dialog" aria-labelledby="newpartyLabel">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="newpartyLabel">Add New Party</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span>&times;</span>
                </button>
            </div>
            <div class="modal-body pt-0" id="newpartyform-content">
                <form class="form-horizontal row g-3" method="post" id="addNewPartyForm" action="{{ route('parties.store')}}">
                    <input type="hidden" name="id" id="partyID">
                    @csrf
                    <div class="col-md-6 mb-3">
                        <label for="party_name" class="form-label">Party Name <span class="text-danger">*</span></label>
                        <input type="text" id="party_name" class="form-control @error('party_name') is-invalid @enderror" name="party_name" value="{{ old('party_name') }}" required tabindex="1" placeholder="Enter Name">
                        @error('party_name')
                            <ul class="parsley-errors-list filled">
                                <li class="parsley-required">{{ $message}}</li>
                            </ul>
                        @enderror
                    </div>
                    <div class="col-md-6 mb-3">
                        <label for="mobileno" class="form-label">Mobile Number</label>
                        <input type="number" id="mobileno" class="form-control" name="phone" value="{{ old('phone') }}" tabindex="2" placeholder="Enter mobile number">
                    </div>
                    <div class="col-md-6 mb-3">
                        <label for="email" class="form-label">Email</label>
                        <input type="text" id="email" class="form-control" name="email" value="{{ old('email') }}" tabindex="3" placeholder="Enter email">
                    </div>
                    <div class="col-md-6 mb-3">
                        <label for="party_type" class="form-label">Party Type</label>
                        <select id="party_type" class="form-control" name="party_type" tabindex="4">
                            <option value="Customer" @selected(($type ?? '') === 'Customer')>Customer</option>
                            <option value="Supplier" @selected(($type ?? '') !== 'Customer')>Supplier</option>
                        </select>
                    </div>

                    <div class="text-left col-12">
                        <button type="submit" class="btn btn-primary waves-effect waves-light col-md-2 mb-2" tabindex="13"><i class="fe-check-circle mr-1"></i>Save</button>
                        <button type="reset" class="btn btn-danger waves-effect waves-light col-md-2 mb-2" tabindex="14"><i class="fe-x mr-1"></i>Cancel</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
@endsection

@section('scripts')
<script>
@if(Session::has('message'))
     var type = "{{ Session::get('alert-type','info') }}"
     switch(type){
        case 'info':
        toastr.info(" {{ Session::get('message') }} ");
        break;

        case 'success':
        toastr.success(" {{ Session::get('message') }} ");
        break;

        case 'warning':
        toastr.warning(" {{ Session::get('message') }} ");
        break;

        case 'error':
        toastr.error(" {{ Session::get('message') }} ");
        break;
     }
@endif
</script>

<script>
    $(document).ready(function () {
        // Handle delete button click
        $('.delete-party').on('click', function () {
            var partyId = $(this).data('id');
            var deleteUrl = '/admin/parties/delete/' + partyId;

            Swal.fire({
                title: 'Are you sure?',
                text: "You won't be able to revert this!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Yes, delete it!',
                cancelButtonText: 'Cancel'
            }).then((result) => {
                if (result.isConfirmed) {
                    var form = $('<form method="POST" action="' + deleteUrl + '"></form>');
                    form.append('<input type="hidden" name="_token" value="{{ csrf_token() }}">');
                    $('body').append(form);
                    form.submit();
                }
            });
        });

        /* view Party detail modal */
        $(document).on('click', '.view-party-btn', function () {
            const partyId = $(this).data('id');
            jQuery('#party-detail-content').html('Loading...');
            jQuery.ajax({
                url: "/admin/parties/partydetail/" + partyId,
                type: 'GET',
                success: function (response) {
                    $("#partyDetailLabel").html('Party Detail ID : #'+partyId);
                    $('#party-detail-content').html(response);
                    jQuery('#partyDetailModal').modal('show');
                    $('#partyDetailModal').on('hide.bs.modal', function () {
                        document.activeElement.blur();
                    });
                },
                error: function () {
                    $('#party-detail-content').html('<p class="text-danger">Failed to load data.</p>');
                }
            });
        });

        $(document).on('click', '.edit-party', function() {
            const partyID = $(this).data('id');

            $('#addNewPartyForm')[0].reset();
            $('#addNewPartyForm').validate().resetForm();
            $('#partyID').val(partyID);

            $.ajax({
                url: "/admin/parties/edit/" + partyID,
                type: 'GET',
                success: function(response) {
                    $('#addNewPartyForm #party_name').val(response.party_name);
                    $('#addNewPartyForm #mobileno').val(response.phone);
                    $('#addNewPartyForm #email').val(response.email);
                    $('#addNewPartyForm #party_type').val(response.party_type).trigger('change');
                    $('#addNewPartyForm #address').html(response.address);
                    $('#addNewPartyForm #partyID').val(response.id);

                    $('#addnewPartyModal').modal('show');
                },
                error: function(xhr) {
                    toastr.error('Error fetching transaction details');
                }
            });
        })

        $("#addNewPartyForm").validate({
            rules: {
                party_name: "required"
            },
            messages: {
                party_name: "Please Enter Party"
            },
            submitHandler: function(form) {
                var formData = $(form).serialize();
                $.ajax({
                    url: $(form).attr('action'),
                    type: 'POST',
                    data: formData,
                    success: function(response) {
                        toastr.success(response.message);
                        $('#addnewPartyModal').modal('hide');

                        setTimeout(() => {
                            $('#addnewPartyModal').removeClass('show').hide();
                            $('body').removeClass('modal-open');
                            $('.modal-backdrop').remove();
                        }, 300);

                        $('#addNewPartyForm')[0].reset();

                        setTimeout(function () {
                            location.reload();
                        }, 1200);
                    },
                    error: function(xhr) {
                        toastr.error('Error storing transaction');
                    }
                });
                return false;
            }
        });
    });
</script>
@endsection
