@extends('layout.app')

@section('title', 'Ledger Entries')

@section('content')
<div class="container-fluid">
    <div class="row mb-4">
        <div class="col-md-12">
            <div class="d-flex justify-content-between align-items-center">
                <h2>Ledger Entries</h2>
                <div class="d-flex gap-2">
                    <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#quickEntryModal">
                        <i class="fas fa-plus"></i> Add New Entry
                    </button>
                    <a href="{{ route('ledger.create') }}" class="btn btn-outline-primary">
                        Full Form
                    </a>
                </div>
            </div>
        </div>
    </div>

    @if ($errors->any())
        <div class="alert alert-danger">
            <ul>
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    @if (session('success'))
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            {{ session('success') }}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    @endif

    @if (session('error'))
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            {{ session('error') }}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    @endif

    <div class="mb-4">
        <h4 class="mb-3">Transaction Management</h4>
        <div class="ledger-summary-grid">
            <div class="ledger-summary-card ledger-summary-purple">
                <h6>Total Balance</h6>
                <p id="summary-total-balance">₹ {{ number_format($summary['total_balance'] ?? 0, 2) }}</p>
            </div>
            <div class="ledger-summary-card ledger-summary-blue">
                <h6>Cash Balance</h6>
                <p id="summary-cash-balance">₹ {{ number_format($summary['cash_balance'] ?? 0, 2) }}</p>
            </div>
            <div class="ledger-summary-card ledger-summary-cyan">
                <h6>Bank Balance</h6>
                <p id="summary-bank-balance">₹ {{ number_format($summary['bank_balance'] ?? 0, 2) }}</p>
            </div>
            <div class="ledger-summary-card ledger-summary-green">
                <h6>Total In</h6>
                <p id="summary-total-in">₹ {{ number_format($summary['total_in'] ?? 0, 2) }}</p>
            </div>
            <div class="ledger-summary-card ledger-summary-red">
                <h6>Total Out</h6>
                <p id="summary-total-out">₹ {{ number_format($summary['total_out'] ?? 0, 2) }}</p>
            </div>
        </div>
    </div>

    <!-- Filter Section -->
    <div class="card mb-4">
        <div class="card-header">
            <h5>Filters</h5>
        </div>
        <div class="card-body">
            <form class="row g-3" id="filter-form">
                <div class="col-md-3">
                    <label for="date_from" class="form-label">From Date</label>
                    <input type="date" class="form-control" id="date_from" name="date_from" 
                           value="{{ request('date_from') }}">
                </div>
                <div class="col-md-3">
                    <label for="date_to" class="form-label">To Date</label>
                    <input type="date" class="form-control" id="date_to" name="date_to"
                           value="{{ request('date_to') }}">
                </div>
                <div class="col-md-3">
                    <label for="party_id" class="form-label">Party</label>
                    <select class="form-control" id="party_id" name="party_id">
                        <option value="">-- All Parties --</option>
                        @foreach ($parties as $party)
                            <option value="{{ $party->id }}" {{ request('party_id') == $party->id ? 'selected' : '' }}>
                                {{ $party->name }}
                            </option>
                        @endforeach
                    </select>
                </div>
                <div class="col-md-3">
                    <label for="entry_type" class="form-label">Entry Type</label>
                    <select class="form-control" id="entry_type" name="entry_type">
                        <option value="">-- All Types --</option>
                        <option value="SALE" {{ request('entry_type') == 'SALE' ? 'selected' : '' }}>Sale</option>
                        <option value="PURCHASE" {{ request('entry_type') == 'PURCHASE' ? 'selected' : '' }}>Purchase</option>
                        <option value="EXPENSE" {{ request('entry_type') == 'EXPENSE' ? 'selected' : '' }}>Expense</option>
                        <option value="PAYMENT" {{ request('entry_type') == 'PAYMENT' ? 'selected' : '' }}>Payment</option>
                        <option value="RECEIPT" {{ request('entry_type') == 'RECEIPT' ? 'selected' : '' }}>Receipt</option>
                    </select>
                </div>
                <div class="col-md-12 mt-3">
                    <button type="button" class="btn btn-info" id="filter-btn">
                        <i class="fas fa-filter"></i> Apply Filters
                    </button>
                    <button type="button" class="btn btn-secondary" id="reset-btn">
                        <i class="fas fa-redo"></i> Reset
                    </button>
                </div>
            </form>
        </div>
    </div>

    <!-- Data Table -->
    <div class="card">
        <div class="card-header">
            <h5>Ledger Entries List</h5>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table id="ledger-table" class="table table-striped table-hover">
                    <thead class="table-dark">
                        <tr>
                            <th>#</th>
                            <th>Date</th>
                            <th>Party</th>
                            <th>Type</th>
                            <th>Debit (₹)</th>
                            <th>Credit (₹)</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="quickEntryModal" tabindex="-1" aria-labelledby="quickEntryModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-scrollable">
        <div class="modal-content">
            <form method="POST" action="{{ route('ledger.store') }}" id="quick-entry-form">
                @csrf
                <div class="modal-header">
                    <h5 class="modal-title" id="quickEntryModalLabel">Add Ledger Entry</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label for="quick_party_id" class="form-label">Party</label>
                            <select name="party_id" id="quick_party_id" class="form-control" required>
                                <option value="">-- Select Party --</option>
                                @foreach ($parties as $party)
                                    <option value="{{ $party->id }}">{{ $party->party_name }}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label for="quick_entry_date" class="form-label">Entry Date</label>
                            <input type="date" class="form-control" id="quick_entry_date" name="entry_date" value="{{ now()->toDateString() }}" required>
                        </div>
                        <div class="col-md-6">
                            <label for="quick_entry_type" class="form-label">Entry Type</label>
                            <select name="entry_type" id="quick_entry_type" class="form-control" required>
                                <option value="">-- Select Type --</option>
                                <option value="SALE">Sale</option>
                                <option value="PURCHASE">Purchase</option>
                                <option value="EXPENSE">Expense</option>
                                <option value="PAYMENT">Payment</option>
                                <option value="RECEIPT">Receipt</option>
                                <option value="TRANSFER">Transfer</option>
                                <option value="OPENING_BALANCE">Opening Balance</option>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label for="quick_payment_method_id" class="form-label">Payment Method</label>
                            <select name="payment_method_id" id="quick_payment_method_id" class="form-control">
                                <option value="">-- Select Method --</option>
                                @foreach ($paymentMethods as $method)
                                    <option value="{{ $method->id }}">{{ $method->method_name }}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="col-md-4">
                            <label for="quick_amount" class="form-label">Amount</label>
                            <input type="number" class="form-control" id="quick_amount" name="amount" min="0" step="0.01" required>
                        </div>
                        <div class="col-md-4">
                            <label for="quick_amount_direction" class="form-label">Direction</label>
                            <select name="amount_direction" id="quick_amount_direction" class="form-control" required>
                                <option value="debit">Debit</option>
                                <option value="credit">Credit</option>
                            </select>
                        </div>
                        <div class="col-md-4 d-flex align-items-end">
                            <div class="alert alert-light border w-100 mb-0 py-2" id="quick-entry-hint">
                                Amount will be saved as debit.
                            </div>
                        </div>
                        <div class="col-md-6">
                            <label for="quick_reference_number" class="form-label">Reference Number</label>
                            <input type="text" class="form-control" id="quick_reference_number" name="reference_number">
                        </div>
                        <div class="col-md-6">
                            <label for="quick_description" class="form-label">Description</label>
                            <input type="text" class="form-control" id="quick_description" name="description">
                        </div>
                        <div class="col-12">
                            <label for="quick_notes" class="form-label">Notes</label>
                            <textarea class="form-control" id="quick_notes" name="notes" rows="3"></textarea>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">Save Entry</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Delete Modal -->
<div class="modal fade" id="deleteModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Delete Entry</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                Are you sure you want to delete this ledger entry?
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <button type="button" class="btn btn-danger" id="confirm-delete">Delete</button>
            </div>
        </div>
    </div>
</div>

@endsection

@section('css')
<link rel="stylesheet" href="https://cdn.datatables.net/1.11.5/css/jquery.dataTables.min.css">
@endsection

@section('scripts')
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
<script>
$(document).ready(function() {
    const entryDirectionDefaults = {
        SALE: 'credit',
        RECEIPT: 'credit',
        OPENING_BALANCE: 'credit',
        PURCHASE: 'debit',
        EXPENSE: 'debit',
        PAYMENT: 'debit'
    };

    function formatCurrency(amount) {
        return '₹ ' + Number(amount || 0).toLocaleString('en-IN', {
            minimumFractionDigits: 2,
            maximumFractionDigits: 2
        });
    }

    function updateSummary(summary) {
        if (!summary) {
            return;
        }

        $('#summary-total-balance').text(formatCurrency(summary.total_balance));
        $('#summary-cash-balance').text(formatCurrency(summary.cash_balance));
        $('#summary-bank-balance').text(formatCurrency(summary.bank_balance));
        $('#summary-total-in').text(formatCurrency(summary.total_in));
        $('#summary-total-out').text(formatCurrency(summary.total_out));
    }

    function syncQuickEntryDirection() {
        const entryType = $('#quick_entry_type').val();
        const defaultDirection = entryDirectionDefaults[entryType];

        if (defaultDirection) {
            $('#quick_amount_direction').val(defaultDirection);
        }

        const directionLabel = ($('#quick_amount_direction').val() || 'debit').toUpperCase();
        $('#quick-entry-hint').text('Amount will be saved as ' + directionLabel.toLowerCase() + '.');
    }

    let table = $('#ledger-table').DataTable({
        processing: true,
        serverSide: true,
        ajax: {
            url: "{{ route('ledger.index') }}",
            data: function(d) {
                d.date_from = $('#date_from').val();
                d.date_to = $('#date_to').val();
                d.party_id = $('#party_id').val();
                d.entry_type = $('#entry_type').val();
            },
            dataSrc: function(json) {
                updateSummary(json.summary);
                return json.data;
            }
        },
        columns: [
            { data: 'DT_RowIndex', name: 'DT_RowIndex' },
            { data: 'entry_date', name: 'entry_date' },
            { data: 'party_name', name: 'party_name' },
            { data: 'entry_type', name: 'entry_type' },
            { data: 'debit_display', name: 'debit_display' },
            { data: 'credit_display', name: 'credit_display' },
            { data: 'action', name: 'action', orderable: false, searchable: false }
        ]
    });

    $('#filter-btn').click(function() {
        table.draw();
    });

    $('#reset-btn').click(function() {
        $('#date_from').val('');
        $('#date_to').val('');
        $('#party_id').val('');
        $('#entry_type').val('');
        table.draw();
    });

    $('#quick_entry_type, #quick_amount_direction').on('change', syncQuickEntryDirection);
    syncQuickEntryDirection();

    $('#quick-entry-form').on('submit', function() {
        const amount = parseFloat($('#quick_amount').val() || 0);
        const direction = $('#quick_amount_direction').val();

        if (amount <= 0 || !direction) {
            alert('Please enter a valid amount.');
            return false;
        }

        return true;
    });

    let deleteId = null;
    $(document).on('click', '.delete-btn', function() {
        deleteId = $(this).data('id');
        new bootstrap.Modal(document.getElementById('deleteModal')).show();
    });

    $('#confirm-delete').click(function() {
        $.ajax({
            url: '/admin/ledger/' + deleteId,
            type: 'DELETE',
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            success: function(response) {
                bootstrap.Modal.getInstance(document.getElementById('deleteModal')).hide();
                table.draw();
                alert('Entry deleted successfully');
            },
            error: function(error) {
                alert('Error deleting entry');
            }
        });
    });
});
</script>
@endsection
