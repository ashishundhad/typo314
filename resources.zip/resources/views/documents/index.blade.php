@extends('layout.app')

@section('title')
    Documents
@endsection

@section('content')

    <div class="container-fluid documents-page-shell">
        <div class="documents-page-hero">
            <div class="row align-items-center">
                <div class="col-lg-8">
                    <h1 class="documents-page-hero__title mb-0">Documents</h1>
                    <p class="documents-page-hero__text">Every identity and receipt document uploaded against an invoice or a purchase, in one place.</p>
                </div>
                <div class="col-lg-4 text-lg-right">
                    <div class="documents-page-hero__badge mt-3 mt-lg-0">
                        <i class="mdi mdi-file-document-multiple-outline"></i>
                        <span>{{ $invoiceDocumentCount + $purchaseDocumentCount }} Documents</span>
                    </div>
                </div>
            </div>
        </div>

        <div class="card documents-page-card">
            <div class="card-body">
                <ul class="nav nav-tabs documents-page-tabs" id="documentsTabs" role="tablist">
                    <li class="nav-item">
                        <a class="nav-link {{ $activeTab === 'invoice' ? 'active' : '' }}" id="invoice-tab" data-toggle="tab" href="#invoiceDocumentsPane" role="tab">
                            <i class="fa fa-file-invoice mr-1"></i>Invoice Documents
                            <span class="badge documents-page-tab-count">{{ $invoiceDocumentCount }}</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link {{ $activeTab === 'purchase' ? 'active' : '' }}" id="purchase-tab" data-toggle="tab" href="#purchaseDocumentsPane" role="tab">
                            <i class="fa fa-shopping-cart mr-1"></i>Purchase Documents
                            <span class="badge documents-page-tab-count">{{ $purchaseDocumentCount }}</span>
                        </a>
                    </li>
                </ul>

                <div class="tab-content documents-page-tab-content">
                    <div class="tab-pane fade {{ $activeTab === 'invoice' ? 'show active' : '' }}" id="invoiceDocumentsPane" role="tabpanel">
                        <form method="GET" id="invoiceDocumentsSearchForm" action="{{ route('documents.index') }}" class="documents-page-search">
                            <input type="hidden" name="tab" value="invoice">
                            <div class="documents-page-search__input-group">
                                <i class="mdi mdi-magnify"></i>
                                <input type="text" id="invoice-documents-search" name="invoice_search" class="form-control" value="{{ $invoiceSearch }}" placeholder="Search by customer, invoice no, or document number">
                            </div>
                        </form>

                        <div id="invoiceDocumentsList">
                            @include('documents._invoice-documents-list')
                        </div>
                    </div>

                    <div class="tab-pane fade {{ $activeTab === 'purchase' ? 'show active' : '' }}" id="purchaseDocumentsPane" role="tabpanel">
                        <form method="GET" id="purchaseDocumentsSearchForm" action="{{ route('documents.index') }}" class="documents-page-search">
                            <input type="hidden" name="tab" value="purchase">
                            <div class="documents-page-search__input-group">
                                <i class="mdi mdi-magnify"></i>
                                <input type="text" id="purchase-documents-search" name="purchase_search" class="form-control" value="{{ $purchaseSearch }}" placeholder="Search by device model, IMEI, supplier, or document number">
                            </div>
                        </form>

                        <div id="purchaseDocumentsList">
                            @include('documents._purchase-documents-list')
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        (function () {
            function wireTab(options) {
                var $searchInput = $(options.searchInputSelector);
                var $list = $(options.listSelector);
                var searchDebounce = null;
                var activeRequest = null;

                function loadResults(query) {
                    if (activeRequest) {
                        activeRequest.abort();
                    }

                    activeRequest = $.ajax({
                        url: options.ajaxUrl,
                        method: 'GET',
                        data: query,
                        success: function (response) {
                            $list.html(response);
                        },
                        complete: function () {
                            activeRequest = null;
                        }
                    });
                }

                if ($searchInput.length) {
                    $searchInput.on('input', function () {
                        clearTimeout(searchDebounce);
                        var value = $(this).val();

                        searchDebounce = setTimeout(function () {
                            loadResults(options.paramName + '=' + encodeURIComponent(value));
                        }, 400);
                    });
                }

                $(document).on('click', options.listSelector + ' .pagination a', function (event) {
                    event.preventDefault();
                    var url = new URL($(this).attr('href'), window.location.origin);
                    var params = new URLSearchParams(url.search);
                    params.set(options.paramName, $searchInput.val());
                    loadResults(params.toString());
                });
            }

            wireTab({
                searchInputSelector: '#invoice-documents-search',
                listSelector: '#invoiceDocumentsList',
                ajaxUrl: '{{ route('documents.invoice') }}',
                paramName: 'invoice_search'
            });

            wireTab({
                searchInputSelector: '#purchase-documents-search',
                listSelector: '#purchaseDocumentsList',
                ajaxUrl: '{{ route('documents.purchase') }}',
                paramName: 'purchase_search'
            });

            $('#documentsTabs a[data-toggle="tab"]').on('shown.bs.tab', function (event) {
                var tab = $(event.target).attr('id') === 'purchase-tab' ? 'purchase' : 'invoice';

                if (window.history && window.history.replaceState) {
                    var url = new URL(window.location.href);
                    url.searchParams.set('tab', tab);
                    window.history.replaceState(null, '', url.toString());
                }
            });
        })();
    </script>
@endsection
