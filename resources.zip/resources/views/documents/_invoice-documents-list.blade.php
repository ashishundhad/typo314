@if($invoiceDocuments->isNotEmpty())
    <div class="table-responsive">
        <table class="table documents-page-table">
            <thead>
                <tr>
                    <th>Type</th>
                    <th>Number</th>
                    <th>Customer</th>
                    <th>Invoice</th>
                    <th>Uploaded</th>
                    <th class="text-right">Action</th>
                </tr>
            </thead>
            <tbody>
                @foreach($invoiceDocuments as $document)
                    <tr>
                        <td><span class="documents-page-card__type">{{ $document->document_type_label }}</span></td>
                        <td>
                            @if($document->document_number)
                                <span class="invoice-preview__document-number" data-full="{{ $document->document_number }}" data-masked="{{ $document->masked_number }}">{{ $document->masked_number }}</span>
                                <button type="button" class="invoice-preview__document-reveal" title="Show / hide full number">
                                    <i class="mdi mdi-eye-outline"></i>
                                </button>
                            @else
                                <span class="text-muted">—</span>
                            @endif
                        </td>
                        <td>{{ $document->customer->name ?? 'Unknown Customer' }}</td>
                        <td>
                            @if($document->invoice)
                                <a href="{{ route('invoice-detail', $document->invoice_id) }}" target="_blank">#{{ $document->invoice->invoice_no }}</a>
                            @else
                                <span class="text-muted">—</span>
                            @endif
                        </td>
                        <td class="documents-page-table__date">{{ $document->created_at->format('d M Y, h:i A') }}</td>
                        <td class="text-right">
                            <a href="{{ $document->image_url }}" target="_blank" class="btn btn-sm btn-primary documents-page-view-btn">
                                <i class="mdi mdi-eye-outline mr-1"></i>View
                            </a>
                        </td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    </div>

    <div class="documents-page-pagination">
        {{ $invoiceDocuments->links() }}
    </div>
@else
    <div class="documents-page-empty">
        <i class="mdi mdi-file-document-outline"></i>
        <p>No invoice documents found.</p>
    </div>
@endif
