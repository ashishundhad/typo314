<?php
/** @var \App\Models\Tenant $tenant */
/** @var \App\Models\Subscription|null $subscription */

$whatsappNumber = '917600384075';

$headline = match (true) {
    ! $subscription => 'Your subscription is inactive',
    $subscription->isOnTrial() => 'Your free trial has ended',
    $subscription->isCancelled() => 'Your subscription was cancelled',
    $subscription->isActive() => 'Your billing period has ended',
    default => 'Your subscription is on hold',
};

$plan = $subscription?->plan;
$currentPrice = $subscription?->planPrice;

$waMessage = "Hi, I'd like to renew {$tenant->name}'s Invoxa subscription (" . ($tenant->domains->first()->domain ?? '') . ').';
$waLink = "https://wa.me/{$whatsappNumber}?text=" . rawurlencode($waMessage);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Subscription inactive — Invoxa</title>
<meta name="robots" content="noindex">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">

<style>
    .si-reset * { box-sizing: border-box; }

    .si-shell {
        margin: 0;
        min-height: 100vh;
        min-height: 100dvh;
        display: flex;
        align-items: center;
        justify-content: center;
        padding: 24px;
        background: #f6f4fb;
        font-family: "Plus Jakarta Sans", sans-serif;
        color: #1c1f2b;
    }

    .si-card {
        width: 100%;
        max-width: 460px;
        background: #fff;
        border-radius: 22px;
        border: 1px solid #e7e2f5;
        box-shadow: 0 30px 70px rgba(109, 40, 217, 0.12);
        padding: 40px 36px 32px;
        text-align: center;
    }

    .si-icon {
        width: 60px;
        height: 60px;
        margin: 0 auto 18px;
        border-radius: 50%;
        background: #f2edfb;
        color: #6d28d9;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        font-size: 1.6rem;
    }

    .si-shop {
        font-size: 0.8rem;
        font-weight: 700;
        letter-spacing: 0.06em;
        text-transform: uppercase;
        color: #8b93a7;
        margin: 0 0 8px;
    }

    .si-headline {
        font-size: 1.5rem;
        font-weight: 800;
        margin: 0 0 10px;
        letter-spacing: -0.02em;
    }

    .si-lead {
        color: #6b7280;
        font-size: 0.95rem;
        margin: 0 0 24px;
        line-height: 1.6;
    }

    .si-plan {
        background: #f8f8fb;
        border: 1px solid #eef0f3;
        border-radius: 14px;
        padding: 16px 18px;
        margin-bottom: 24px;
        text-align: left;
    }

    .si-plan__row {
        display: flex;
        align-items: center;
        justify-content: space-between;
        font-size: 0.9rem;
    }

    .si-plan__row + .si-plan__row {
        margin-top: 8px;
    }

    .si-plan__label {
        color: #6b7280;
    }

    .si-plan__value {
        font-weight: 700;
        color: #1c1f2b;
    }

    .si-btn {
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 8px;
        width: 100%;
        height: 52px;
        border-radius: 12px;
        border: 0;
        background: #25d366;
        color: #fff;
        font-weight: 700;
        font-size: 0.98rem;
        text-decoration: none;
        box-shadow: 0 14px 28px rgba(37, 211, 102, 0.28);
    }

    .si-btn:hover {
        filter: brightness(0.96);
        color: #fff;
    }

    .si-logout {
        display: inline-block;
        margin-top: 18px;
        font-size: 0.85rem;
        color: #8b93a7;
        text-decoration: none;
    }

    .si-logout:hover {
        color: #6d28d9;
    }
</style>
</head>

<body class="si-reset">
<div class="si-shell">
    <div class="si-card">
        <div class="si-icon">⏸</div>
        <p class="si-shop">{{ $tenant->name }}</p>
        <h1 class="si-headline">{{ $headline }}</h1>
        <p class="si-lead">
            Renew to get back into your dashboard, stock, invoices, and reports — nothing has been deleted, everything picks up right where you left off.
        </p>

        @if($plan)
            <div class="si-plan">
                <div class="si-plan__row">
                    <span class="si-plan__label">Plan</span>
                    <span class="si-plan__value">{{ $plan->name }}</span>
                </div>
                @if($currentPrice)
                    <div class="si-plan__row">
                        <span class="si-plan__label">Billing</span>
                        <span class="si-plan__value">{{ ucfirst($currentPrice->billing_cycle) }} — {{ $currentPrice->currency }} {{ number_format((float) $currentPrice->amount, 0) }}</span>
                    </div>
                @endif
            </div>
        @endif

        <a href="{{ $waLink }}" class="si-btn" target="_blank" rel="noopener noreferrer">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M12.04 2C6.58 2 2.13 6.45 2.13 11.91c0 1.75.46 3.46 1.32 4.96L2.05 22l5.25-1.38a9.9 9.9 0 0 0 4.74 1.21h.01c5.46 0 9.91-4.45 9.91-9.91 0-2.65-1.03-5.14-2.9-7.01A9.87 9.87 0 0 0 12.05 2Zm0 18.06h-.01a8.23 8.23 0 0 1-4.2-1.15l-.3-.18-3.12.82.83-3.04-.2-.31a8.19 8.19 0 0 1-1.27-4.39c0-4.53 3.69-8.22 8.23-8.22 2.2 0 4.26.86 5.82 2.41a8.15 8.15 0 0 1 2.41 5.82c0 4.53-3.69 8.24-8.19 8.24Zm4.51-6.16c-.25-.12-1.47-.72-1.69-.81-.23-.08-.39-.12-.56.13-.17.25-.64.81-.78.97-.14.17-.29.19-.53.06-.25-.12-1.05-.39-2-1.23-.74-.66-1.24-1.47-1.39-1.72-.14-.25-.02-.38.11-.51.11-.11.25-.29.37-.43.12-.15.16-.25.24-.41.08-.17.04-.31-.02-.44-.06-.12-.56-1.35-.77-1.85-.2-.48-.41-.42-.56-.42h-.48c-.17 0-.44.06-.67.31-.23.25-.87.85-.87 2.08s.89 2.41 1.02 2.58c.12.17 1.75 2.67 4.24 3.74.59.26 1.05.41 1.41.52.59.19 1.13.16 1.56.1.48-.07 1.47-.6 1.68-1.18.21-.58.21-1.08.14-1.18-.06-.11-.23-.17-.48-.29Z"/></svg>
            Renew via WhatsApp
        </a>

        <form method="POST" action="{{ route('logout') }}">
            @csrf
            <button type="submit" class="si-logout" style="background:none;border:0;cursor:pointer;">Log out</button>
        </form>
    </div>
</div>
</body>
</html>
