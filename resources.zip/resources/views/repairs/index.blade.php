@extends('layout.app')

@section('title', 'Repairs')

@section('content')
    <div class="container-fluid repair-shell">
        <div class="repair-hero">
            <div class="row align-items-center">
                <div class="col-lg-8">
                    <h1 class="repair-hero__title mb-0">Repairs</h1>
                    <!-- <p class="repair-hero__subtitle">Track devices in for service and bill the repair once it's delivered.</p> -->
                </div>
                <div class="col-lg-4 text-lg-right">
                    <div class="repair-hero__badge mt-3 mt-lg-0">
                        <i class="mdi mdi-cash-multiple"></i>
                        <!-- <span>{{ config('constant.currency') }}{{ number_format($totalProfit, 2) }} total repair profit</span> -->
                    </div>
                </div>
            </div>
        </div>

        @include('include.alert')

        <div class="row">
            <div class="col-md-6 col-lg-4 col-xl">
                <div class="card repair-metric mb-1">
                    <div class="card-body">
                        <div class="repair-metric__label">Total Repairs</div>
                        <div class="repair-metric__value">{{ number_format($totalRepairs) }}</div>
                    </div>
                </div>
            </div>
            <div class="col-md-6 col-lg-4 col-xl">
                <div class="card repair-metric mb-1">
                    <div class="card-body">
                        <div class="repair-metric__label">Received</div>
                        <div class="repair-metric__value">{{ number_format($receivedCount) }}</div>
                    </div>
                </div>
            </div>
            <div class="col-md-6 col-lg-4 col-xl ">
                <div class="card repair-metric mb-1">
                    <div class="card-body">
                        <div class="repair-metric__label">Repairing</div>
                        <div class="repair-metric__value">{{ number_format($repairingCount) }}</div>
                    </div>
                </div>
            </div>
            <div class="col-md-6 col-lg-4 col-xl ">
                <div class="card repair-metric mb-1">
                    <div class="card-body">
                        <div class="repair-metric__label">Delivered</div>
                        <div class="repair-metric__value">{{ number_format($deliveredCount) }}</div>
                    </div>
                </div>
            </div>
            <div class="col-md-6 col-lg-4 col-xl ">
                <div class="card repair-metric mb-1">
                    <div class="card-body">
                        <div class="repair-metric__label">Total Profit</div>
                        <div class="repair-metric__value {{ $totalProfit < 0 ? 'repair-metric__value--negative' : 'repair-metric__value--positive' }}">
                            {{ config('constant.currency') }}{{ number_format($totalProfit, 2) }}
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="card repair-section">
            <div class="card-body">
                <div class="repair-section__top">
                    <h2 class="repair-section__title mb-0">All Repair Jobs</h2>

                    <div class="repair-section__actions">
                        <div class="btn-group">
                            <button type="button" class="btn btn-outline-secondary repair-btn dropdown-toggle"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="mdi mdi-file-download-outline mr-1"></i>Export
                            </button>
                            <div class="dropdown-menu dropdown-menu-right mt-2">
                                <a class="dropdown-item" href="{{ request()->fullUrlWithQuery(['download' => 'csv']) }}">
                                    <i class="mdi mdi-file-delimited-outline mr-1"></i>Download CSV
                                </a>
                                <a class="dropdown-item" href="{{ request()->fullUrlWithQuery(['download' => 'pdf']) }}">
                                    <i class="mdi mdi-file-pdf-box mr-1"></i>Download PDF
                                </a>
                            </div>
                        </div>

                        @can('repairs.create')
                            <button type="button" class="btn btn-primary repair-btn" data-toggle="modal" data-target="#repairModal">
                                <i class="mdi mdi-plus-circle-outline mr-1"></i>Add Repair
                            </button>
                        @endcan
                    </div>
                </div>

                <div class="repair-filter">
                    <form method="GET" action="{{ route('repairs.index') }}" id="repairFilterForm">
                        <div class="form-row align-items-end">
                            <div class="col-12 col-md-3 mb-3">
                                <label class="repair-filter__label" for="repair-search">Search</label>
                                <input type="text" id="repair-search" name="search" class="form-control"
                                    value="{{ $search }}" placeholder="Customer name or issue">
                            </div>
                            <div class="col-6 col-md-2 mb-3">
                                <label class="repair-filter__label" for="repair-status">Status</label>
                                <select name="status" id="repair-status" class="form-control">
                                    <option value="" @selected($status === '')>All</option>
                                    <option value="received" @selected($status === 'received')>Received</option>
                                    <option value="repairing" @selected($status === 'repairing')>Repairing</option>
                                    <option value="delivered" @selected($status === 'delivered')>Delivered</option>
                                </select>
                            </div>
                            <div class="col-6 col-md-2 mb-3">
                                <label class="repair-filter__label" for="repair-period">Report Period</label>
                                <select name="period" id="repair-period" class="form-control">
                                    <option value="alls" @selected($period === 'alls')>All Time</option>
                                    <option value="thismonth" @selected($period === 'thismonth')>This Month</option>
                                    <option value="lastmonth" @selected($period === 'lastmonth')>Last Month</option>
                                    <option value="thisyear" @selected($period === 'thisyear')>This Year</option>
                                    <option value="lastyear" @selected($period === 'lastyear')>Last Year</option>
                                    <option value="custom" @selected($period === 'custom')>Custom Range</option>
                                </select>
                            </div>
                            <div class="col-6 col-md-2 mb-3 repair-filter__date-group @if($period === 'custom') d-block @endif">
                                <label class="repair-filter__label" for="repair-fromdate">From Date</label>
                                <input type="date" id="repair-fromdate" name="fromdate" class="form-control" value="{{ $fromdate }}">
                            </div>
                            <div class="col-6 col-md-2 mb-3 repair-filter__date-group @if($period === 'custom') d-block @endif">
                                <label class="repair-filter__label" for="repair-todate">To Date</label>
                                <input type="date" id="repair-todate" name="todate" class="form-control" value="{{ $todate }}">
                            </div>
                            <div class="col-6 col-md-2 mb-3">
                                <button type="submit" class="btn btn-primary repair-btn btn-block">
                                    <i class="mdi mdi-magnify"></i> Filter
                                </button>
                            </div>
                            <div class="col-6 col-md-2 mb-3">
                                <a href="{{ route('repairs.index') }}" class="btn btn-outline-danger repair-btn btn-block">Clear</a>
                            </div>
                        </div>
                    </form>
                </div>

                <div class="table-responsive">
                    @if ($repairs->count())
                        <table class="table repair-table">
                            <thead>
                                <tr>
                                    <th>Customer</th>
                                    <th>Issue</th>
                                    <th>Repair Date</th>
                                    <th class="align-right">Parts Cost</th>
                                    <th class="align-right">Repair Fee</th>
                                    <th class="align-right">Profit</th>
                                    <th>Status</th>
                                    <th class="text-center">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach ($repairs as $repair)
                                    <tr>
                                        <td>{{ $repair->customer_name ?: 'Walk-in Customer' }}</td>
                                        <td>{{ \Illuminate\Support\Str::limit($repair->issue_description, 60) ?: '-' }}</td>
                                        <td>{{ $repair->repair_date ? $repair->repair_date->format('d M Y') : '-' }}</td>
                                        <td class="align-right">{{ config('constant.currency') }}{{ number_format((float) $repair->parts_cost, 2) }}</td>
                                        <td class="align-right">{{ config('constant.currency') }}{{ number_format((float) $repair->repair_fee, 2) }}</td>
                                        <td class="align-right repair-profit {{ $repair->profit < 0 ? 'repair-profit--negative' : '' }}">
                                            {{ config('constant.currency') }}{{ number_format($repair->profit, 2) }}
                                        </td>
                                        <td>
                                            <span class="repair-status repair-status--{{ $repair->status }}">{{ $repair->status_label }}</span>
                                        </td>
                                        <td class="text-center">
                                            <div class="repair-actions">
                                                @can('repairs.edit')
                                                    <button type="button" class="btn btn-primary btn-sm js-edit-repair" title="Edit"
                                                        data-id="{{ $repair->id }}"
                                                        data-customer_name="{{ $repair->customer_name }}"
                                                        data-issue_description="{{ $repair->issue_description }}"
                                                        data-repair_date="{{ $repair->repair_date ? $repair->repair_date->format('Y-m-d') : '' }}"
                                                        data-parts_cost="{{ $repair->parts_cost }}"
                                                        data-repair_fee="{{ $repair->repair_fee }}"
                                                        data-status="{{ $repair->status }}">
                                                        <i class="mdi mdi-square-edit-outline"></i>
                                                    </button>
                                                @endcan

                                                @can('repairs.edit')
                                                    @if ($repair->isBilled())
                                                        <a href="{{ route('print-invoice', $repair->invoice_id) }}" class="btn btn-success btn-sm" title="View Invoice" target="_blank">
                                                            <i class="mdi mdi-receipt"></i>
                                                        </a>
                                                    @else
                                                        <button type="button" class="btn btn-outline-success btn-sm js-bill-repair" title="Generate Invoice"
                                                            data-id="{{ $repair->id }}"
                                                            data-fee="{{ number_format((float) $repair->repair_fee, 2) }}"
                                                            {{ (float) $repair->repair_fee <= 0 ? 'disabled' : '' }}>
                                                            <i class="mdi mdi-cash-register"></i>
                                                        </button>
                                                    @endif
                                                @endcan

                                                @can('repairs.delete')
                                                    <form method="POST" action="{{ route('repairs.destroy', $repair->id) }}" class="d-inline">
                                                        @csrf
                                                        @method('DELETE')
                                                        <button type="submit" class="btn btn-danger btn-sm" title="Delete" onclick="sureToDelete(event)">
                                                            <i class="fas fa-trash"></i>
                                                        </button>
                                                    </form>
                                                @endcan
                                            </div>
                                        </td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>

                        <div class="mt-3">
                            {{ $repairs->appends(request()->query())->links('vendor.pagination.bootstrap-5') }}
                        </div>
                    @else
                        <div class="repair-empty">
                            <div class="repair-empty__icon">
                                <i class="mdi mdi-wrench-outline"></i>
                            </div>
                            <h4 class="mb-2">No repair jobs found</h4>
                            <p class="text-muted mb-0">Add a repair job to start tracking it here.</p>
                        </div>
                    @endif
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="repairModal" tabindex="-1" role="dialog" aria-labelledby="repairModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="repairModalLabel">Add Repair</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form method="POST" action="{{ route('repairs.store') }}" id="repairForm">
                    @csrf
                    <div class="modal-body">
                        <div class="form-group">
                            <label for="repair_customer_name">Customer Name</label>
                            <input type="text" class="form-control" id="repair_customer_name" name="customer_name" placeholder="Customer Name">
                        </div>
                        <div class="form-group">
                            <label for="repair_issue_description">Issue Description</label>
                            <textarea class="form-control" id="repair_issue_description" name="issue_description" rows="3" placeholder="Description"></textarea>
                        </div>
                        <div class="form-row">
                            <div class="form-group col-md-6">
                                <label for="repair_date">Repair Date</label>
                                <input type="date" class="form-control" id="repair_date" name="repair_date">
                            </div>
                            <div class="form-group col-md-6">
                                <label for="repair_status">Status</label>
                                <select class="form-control" id="repair_status" name="status">
                                    <option value="received">Received</option>
                                    <option value="repairing">Repairing</option>
                                    <option value="delivered">Delivered</option>
                                </select>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group col-md-6">
                                <label for="repair_parts_cost">Parts Cost</label>
                                <input type="number" class="form-control" id="repair_parts_cost" name="parts_cost" min="0" step="0.01" placeholder="0.00">
                            </div>
                            <div class="form-group col-md-6">
                                <label for="repair_fee">Repair Fee</label>
                                <input type="number" class="form-control" id="repair_fee" name="repair_fee" min="0" step="0.01" placeholder="0.00">
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-light" data-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary repair-modal-submit">Save Repair</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <div class="modal fade" id="billRepairModal" tabindex="-1" role="dialog" aria-labelledby="billRepairModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="billRepairModalLabel">Generate Invoice</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form method="POST" action="" id="billRepairForm">
                    @csrf
                    <div class="modal-body">
                        <p class="mb-3">This will create an invoice for <strong id="billRepairFee"></strong> and mark this repair as delivered.</p>
                        <div class="form-group mb-0">
                            <label for="bill_payment_type">Payment Mode <span class="text-danger">*</span></label>
                            <select class="form-control" id="bill_payment_type" name="payment_type" required>
                                <option value="">Select</option>
                                <option value="Cash">Cash</option>
                                <option value="Online">Online/UPI</option>
                                <option value="Credit Card">Credit Card</option>
                            </select>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-light" data-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-success">Generate Invoice</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
@endsection

@section('scripts')
    <script>
        $(document).ready(function () {
            const periodSelect = document.getElementById('repair-period');
            const dateGroups = document.querySelectorAll('.repair-filter__date-group');

            function toggleDateGroups() {
                const showDates = periodSelect && periodSelect.value === 'custom';

                dateGroups.forEach(function (group) {
                    group.style.display = showDates ? 'block' : 'none';
                });
            }

            if (periodSelect) {
                periodSelect.addEventListener('change', toggleDateGroups);
                toggleDateGroups();
            }

            const $repairForm = $('#repairForm');
            const $repairModalLabel = $('#repairModalLabel');
            const $repairModalSubmit = $('.repair-modal-submit');

            function resetRepairForm() {
                $repairForm[0].reset();
                $repairForm.attr('action', "{{ route('repairs.store') }}");
                $repairModalLabel.text('Add Repair');
                $repairModalSubmit.text('Save Repair');
            }

            $('#repairModal').on('hidden.bs.modal', resetRepairForm);

            $(document).on('click', '.js-edit-repair', function () {
                const $btn = $(this);
                const id = $btn.data('id');

                $repairForm.attr('action', "{{ url('/admin/repairs') }}/" + id);
                $repairModalLabel.text('Edit Repair');
                $repairModalSubmit.text('Update Repair');

                $('#repair_customer_name').val($btn.data('customer_name'));
                $('#repair_issue_description').val($btn.data('issue_description'));
                $('#repair_date').val($btn.data('repair_date'));
                $('#repair_parts_cost').val($btn.data('parts_cost'));
                $('#repair_fee').val($btn.data('repair_fee'));
                $('#repair_status').val($btn.data('status'));

                $('#repairModal').modal('show');
            });

            $(document).on('click', '.js-bill-repair', function () {
                const id = $(this).data('id');
                const fee = $(this).data('fee');

                $('#billRepairForm').attr('action', "{{ url('/admin/repairs') }}/" + id + '/bill');
                $('#billRepairFee').text('{{ config('constant.currency') }}' + fee);
                $('#bill_payment_type').val('');
                $('#billRepairModal').modal('show');
            });
        });
    </script>
@endsection
