@extends('layout.app')

@section('title')
    Multiple Stock Entry
@endsection

@section('content')
    <!-- Start Content-->
    <div class="container-fluid">

        <!-- start page title -->
        <div class="row">
            <div class="col-8">
                <div class="page-title-box">
                    <h4 class="page-title">Multiple Stock Entry</h4>
                </div>
            </div>
            <div class="col-4">
                <div class="page-title-box text-right">
                    <h4 class="page-title">
                        <a href="{{ route('allpurchases') }}" class="btn btn-sm btn-success">
                            <i class="mdi mdi-keyboard-backspace"></i> Back
                        </a>
                    </h4>
                </div>
            </div>
        </div>
        <!-- end page title -->

        <div class="row">
            <div class="col-12">
                @include('include.alert')
                <div class="card shadow-lg rounded-3 border-0">
                    <div class="card-body p-4">
                        <h4 class="mb-3 fw-bold text-primary">Multiple Stock Entry</h4>
                        <form class="form-horizontal" method="post" enctype="multipart/form-data"
                            action="{{ route('purchase.store')}}" id="purchaseForm">
                            @csrf
                            <input type="hidden" name="entry_type" value="multiple">

                            {{-- Common Fields Section --}}
                            <div class="border rounded p-2 mb-3 bg-light">
                                <h5 class="mb-3 fw-bold text-secondary">Common Information</h5>

                                {{-- Row 1: Device Type + Model --}}
                                <div class="row mb-3">
                                    <div class="col-md-4">
                                        <label for="devicetype" class="form-label fw-semibold">Device Type</label>
                                        <select class="form-select form-control" id="devicetype" name="device_type"
                                            required>
                                            <option value="Phone" @selected(old('device_type') == 'Phone')>Phone</option>
                                            <option value="Tablet" @selected(old('device_type') == 'Tablet')>Tablet</option>
                                            <option value="Laptop" @selected(old('device_type') == 'Laptop')>Laptop</option>
                                            <option value="Accessories" @selected(old('device_type') == 'Accessories')>
                                                Accessories</option>
                                            <option value="Smartwatch" @selected(old('device_type') == 'Smartwatch')>
                                                Smartwatch</option>
                                        </select>
                                    </div>

                                    <div class="col-md-4">
                                        <label for="partyname" class="form-label fw-semibold">Party Name <span
                                                class="text-danger">*</span></label>
                                        <div class="party-autocomplete-wrapper">
                                            <input type="text" id="partyname" class="form-control form-control"
                                                name="purchase_from" value="{{ old('purchase_from') }}" required autocomplete="off">
                                            <div id="parties_suggestions" class="list-group"></div>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <label for="contactno" class="form-label fw-semibold">Party Contact No <span
                                                class="text-danger">*</span></label>
                                        <input type="text" id="contactno" class="form-control form-control" name="contactno"
                                            value="{{ old('contactno') }}" required>
                                    </div>
                                </div>

                                {{-- Row 2: Warranty + Party Info --}}
                                {{-- <div class="row mb-3">
                                    <div class="col-md-6">
                                        <label for="warrenty" class="form-label fw-semibold">Brand Warranty <span
                                                class="text-danger">*</span></label>
                                        <select class="form-select form-control" id="warrenty" name="warrenty"
                                            value="{{ old('warrenty') ?? 'Non warrenty' }}" required>
                                            <option value="Non warrenty" @selected(old('warrenty')=='Non warrenty' )>Non
                                                Warranty</option>
                                            <option value="Warrenty" @selected(old('warrenty')=='Warrenty' )>Warranty
                                            </option>
                                        </select>
                                        <div class="warrentydate" style="display:none;">
                                            <input type="date" id="warrentydate" class="form-control form-control mt-2"
                                                name="warrentydate" value="{{ old('warrentydate') }}">
                                        </div>
                                    </div>
                                </div> --}}

                                {{-- <div class="col-md-6">
                                    <label for="model" class="form-label fw-semibold">Model <span class="text-danger">*</span></label>
                                    <input type="text" id="model" class="form-control form-control" name="model" value="{{ old('model') }}" required>
                                </div> --}}

                                {{-- Row 3: Contact + Purchase Date --}}
                                {{-- <div class="row mb-3">
                                    <div class="col-md-6">
                                        <label for="contactno" class="form-label fw-semibold">Party Contact No</label>
                                        <input type="text" id="contactno" class="form-control form-control" name="contactno"
                                            value="{{ old('contactno') }}">
                                    </div>
                                    <div class="col-md-6">
                                        <label for="purchasedate" class="form-label fw-semibold">Purchase Date <span
                                                class="text-danger">*</span></label>
                                        <input type="date" id="purchasedate" class="form-control form-control"
                                            name="purchase_date" value="{{ old('purchase_date') }}" required>
                                    </div>
                                </div> --}}

                                {{-- Row 4: Repairing Charge + Remark --}}
                                {{-- <div class="row mb-3">
                                    <div class="col-md-6">
                                        <label for="repairingcharge" class="form-label fw-semibold">Repairing Charge</label>
                                        <input type="number" id="repairingcharge" class="form-control form-control"
                                            name="repairing_charge" value="{{ old('repairing_charge') }}"
                                            placeholder="Enter Repairing Charge">
                                    </div>
                                    <div class="col-md-6">
                                        <label for="remark" class="form-label fw-semibold">Remark</label>
                                        <textarea id="remark" class="form-control" name="remark"
                                            placeholder="Enter Remark">{{ old('remark') }}</textarea>
                                    </div>
                                </div> --}}
                            </div>

                            {{-- Stock Items Section --}}
                            <div class="border-top pt-2">
                                <h5 class="mb-1 fw-bold text-secondary">Stock Items</h5>
                                <div id="stockItems">
                                    <div class="stock-item border rounded p-3 mb-3" data-index="0">
                                        <div class="d-flex justify-content-between align-items-center mb-3">
                                            <h6 class="mb-0 text-primary">Stock Item #1</h6>
                                            <button type="button" class="btn btn-sm btn-outline-danger remove-stock-item"
                                                style="display: none;">
                                                <i class="fe-minus"></i>
                                            </button>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-3">
                                                <label class="form-label fw-semibold">Model <span class="text-danger">*</span></label>
                                                <input type="text" class="form-control" name="stock_items[0][model]" required>
                                            </div>
                                            <div class="col-md-3">
                                                <label class="form-label fw-semibold">IMEI <span
                                                        class="text-danger">*</span></label>
                                                <input type="text" class="form-control imei-input" name="stock_items[0][imei]"
                                                    required autocomplete="off">
                                                <div class="invalid-feedback imei-feedback" style="display: none;"></div>
                                            </div>
                                            <div class="col-md-2">
                                                <label class="form-label fw-semibold">Storage (GB) <span
                                                        class="text-danger">*</span></label>
                                                <input type="text" class="form-control" name="stock_items[0][storage]"
                                                    required>
                                            </div>
                                            <div class="col-md-2">
                                                <label class="form-label fw-semibold">Color <span
                                                        class="text-danger">*</span></label>
                                                <input type="text" class="form-control" name="stock_items[0][color]"
                                                    required>
                                            </div>
                                        </div>
                                        <div class="row mt-2">
                                            <div class="col-md-3">
                                                <label class="form-label fw-semibold">Buying Cost <span class="text-danger">*</span></label>
                                                <input type="number" class="form-control"
                                                    name="stock_items[0][purchase_cost]" required>
                                            </div>
                                            <div class="col-md-3">
                                                <label class="form-label fw-semibold">MSP<span class="text-danger">*</span></label>
                                                <input type="number" class="form-control"
                                                    name="stock_items[0][msp]" value="0">
                                            </div>
                                            <div class="col-md-3">
                                                <label class="form-label fw-semibold">Purchase Date<span
                                                        class="text-danger">*</span></label>
                                                <input type="date" class="form-control form-control"
                                                    name="stock_items[0][purchase_date]">
                                            </div>
                                            <div class="col-md-3">
                                                <label class="form-label fw-semibold">Warranty Date</label>
                                                <input type="date" class="form-control" name="stock_items[0][warrentydate]">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="text-center">
                                    <button type="button" class="btn btn-outline-success" id="addStockItem">
                                        <i class="fe-plus me-1"></i> Add Another Stock Item
                                    </button>
                                </div>
                            </div>

                            {{-- Buttons --}}
                            <div class="text-right mt-4">
                                <button type="reset" class="btn btn-outline-danger">
                                    <i class="fe-x me-1"></i> Cancel
                                </button>
                                <button type="submit" class="btn btn-outline-success mx-2">
                                    <i class="fe-check-circle me-1"></i> Save All Stock Items
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <!-- end row -->
    </div> <!-- container -->

@endsection

@section('scripts')
    <script>
        $(document).ready(function () {
            let stockItemIndex = 0;
            let partySearchTimeout = null;
            let activeSuggestionIndex = -1;
            const $partyName = $('#partyname');
            const $contactNo = $('#contactno');
            const $suggestions = $('#parties_suggestions');

            function hidePartySuggestions() {
                $suggestions.hide().empty();
                activeSuggestionIndex = -1;
            }

            function setActiveSuggestion(index) {
                const $items = $suggestions.find('.party-suggestion-item');

                $items.removeClass('active');

                if (!$items.length || index < 0 || index >= $items.length) {
                    activeSuggestionIndex = -1;
                    return;
                }

                activeSuggestionIndex = index;
                const $activeItem = $items.eq(index);
                $activeItem.addClass('active');

                const itemTop = $activeItem.position().top;
                const itemBottom = itemTop + $activeItem.outerHeight();
                const currentScroll = $suggestions.scrollTop();
                const visibleBottom = currentScroll + $suggestions.innerHeight();

                if (itemBottom > visibleBottom) {
                    $suggestions.scrollTop(currentScroll + (itemBottom - visibleBottom));
                } else if (itemTop < 0) {
                    $suggestions.scrollTop(currentScroll + itemTop);
                }
            }

            function selectParty(partyName, contactNo) {
                $partyName.val(partyName);
                $contactNo.val(contactNo || '');
                hidePartySuggestions();
            }

            function renderPartySuggestions(parties) {
                if (!parties.length) {
                    $suggestions.html('<div class="party-suggestion-empty">No matching party found.</div>').show();
                    activeSuggestionIndex = -1;
                    return;
                }

                const items = parties.map(function (party) {
                    const partyName = $('<div>').text(party.purchase_from || '').html();
                    const phone = $('<div>').text(party.contactno || '').html();

                    return `
                        <button type="button" class="party-suggestion-item"
                            data-party-name="${partyName}"
                            data-contact-no="${phone}">
                            <span class="party-suggestion-name">${partyName}</span>
                            <span class="party-suggestion-phone">${phone || 'No contact no'}</span>
                        </button>
                    `;
                }).join('');

                $suggestions.html(items).show();
                setActiveSuggestion(0);
            }

            $partyName.on('input', function () {
                const query = $(this).val().trim();

                clearTimeout(partySearchTimeout);

                if (query.length < 3) {
                    hidePartySuggestions();
                    return;
                }

                partySearchTimeout = setTimeout(function () {
                    $.ajax({
                        url: "{{ route('purchase.getchparties') }}",
                        type: 'GET',
                        data: {
                            partname: query
                        },
                        success: function (response) {
                            renderPartySuggestions(Array.isArray(response) ? response : []);
                        },
                        error: function () {
                            hidePartySuggestions();
                        }
                    });
                }, 250);
            });

            $partyName.on('keydown', function (event) {
                const $items = $suggestions.find('.party-suggestion-item');

                if (!$suggestions.is(':visible') || !$items.length) {
                    return;
                }

                if (event.key === 'ArrowDown') {
                    event.preventDefault();
                    setActiveSuggestion(activeSuggestionIndex + 1 >= $items.length ? 0 : activeSuggestionIndex + 1);
                } else if (event.key === 'ArrowUp') {
                    event.preventDefault();
                    setActiveSuggestion(activeSuggestionIndex <= 0 ? $items.length - 1 : activeSuggestionIndex - 1);
                } else if (event.key === 'Enter') {
                    event.preventDefault();
                    const selectionIndex = activeSuggestionIndex >= 0 ? activeSuggestionIndex : 0;
                    $items.eq(selectionIndex).trigger('click');
                } else if (event.key === 'Escape') {
                    hidePartySuggestions();
                }
            });

            $(document).on('mouseenter', '.party-suggestion-item', function () {
                setActiveSuggestion($(this).index());
            });

            $(document).on('click', '.party-suggestion-item', function () {
                selectParty($(this).data('party-name'), $(this).data('contact-no'));
            });

            $(document).on('click', function (event) {
                if (!$(event.target).closest('.party-autocomplete-wrapper').length) {
                    hidePartySuggestions();
                }
            });

            // Add stock item
            $('#addStockItem').on('click', function () {
                stockItemIndex++;
                const newItem = `
                    <div class="stock-item border rounded p-3 mb-3" data-index="${stockItemIndex}">
                        <div class="d-flex justify-content-between align-items-center mb-3">
                            <h6 class="mb-0 text-primary">Stock Item #${stockItemIndex + 1}</h6>
                            <button type="button" class="btn btn-sm btn-outline-danger remove-stock-item">
                                <i class="fe-minus"></i>
                            </button>
                        </div>
                        <div class="row">
                            <div class="col-md-3">
                                <label class="form-label fw-semibold">Model <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" name="stock_items[${stockItemIndex}][model]" required>
                            </div>
                            <div class="col-md-3">
                                <label class="form-label fw-semibold">IMEI <span class="text-danger">*</span></label>
                                <input type="text" class="form-control imei-input" name="stock_items[${stockItemIndex}][imei]" required autocomplete="off">
                                <div class="invalid-feedback imei-feedback" style="display: none;"></div>
                            </div>
                            <div class="col-md-2">
                                <label class="form-label fw-semibold">Storage (GB) <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" name="stock_items[${stockItemIndex}][storage]" required>
                            </div>
                            <div class="col-md-2">
                                <label class="form-label fw-semibold">Color <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" name="stock_items[${stockItemIndex}][color]" required>
                            </div>
                        </div>
                        <div class="row mt-3">
                            <div class="col-md-3">
                                <label class="form-label fw-semibold">Buying Cost <span class="text-danger">*</span></label>
                                <input type="number" class="form-control"
                                    name="stock_items[${stockItemIndex}][purchase_cost]" required>
                            </div>
                            <div class="col-md-3">
                                <label class="form-label fw-semibold">MSP<span class="text-danger">*</span></label>
                                <input type="number" class="form-control"
                                    name="stock_items[${stockItemIndex}][msp]" required>
                            </div>
                            <div class="col-md-3">
                                <label for="purchasedate" class="form-label fw-semibold">Purchase Date<span
                                        class="text-danger">*</span></label>
                                <input type="date" id="purchasedate" class="form-control form-control"
                                    name="stock_items[${stockItemIndex}][purchase_date]">
                            </div>
                            <div class="col-md-3">
                                <label class="form-label fw-semibold">Warranty Date</label>
                                <input type="date" class="form-control" name="stock_items[${stockItemIndex}][warrentydate]">
                            </div>
                        </div>
                    </div>
                `;
                $('#stockItems').append(newItem);
                updateRemoveButtons();
            });

            // Remove stock item
            $(document).on('click', '.remove-stock-item', function () {
                $(this).closest('.stock-item').remove();
                updateRemoveButtons();
                updateStockItemNumbers();
            });

            // Update remove buttons visibility
            function updateRemoveButtons() {
                const stockItems = $('.stock-item');
                if (stockItems.length > 1) {
                    $('.remove-stock-item').show();
                } else {
                    $('.remove-stock-item').hide();
                }
            }

            // Update stock item numbers
            function updateStockItemNumbers() {
                $('.stock-item').each(function (index) {
                    $(this).find('h6').text(`Stock Item #${index + 1}`);
                    $(this).attr('data-index', index);
                    // Update input names
                    $(this).find('input[name*="imei"]').attr('name', `stock_items[${index}][imei]`);
                    $(this).find('input[name*="storage"]').attr('name', `stock_items[${index}][storage]`);
                    $(this).find('input[name*="color"]').attr('name', `stock_items[${index}][color]`);
                    $(this).find('input[name*="purchase_cost"]').attr('name', `stock_items[${index}][purchase_cost]`);
                    $(this).find('input[name*="purchase_date"]').attr('name', `stock_items[${index}][purchase_date]`);
                    $(this).find('input[name*="msp"]').attr('name', `stock_items[${index}][msp]`);

                    // Update the stock item index
                    stockItemIndex = index;
                });
            }

            // Warranty toggle
            $('#warrenty').on('change', function () {
                if ($(this).val() === 'Warrenty') {
                    $('.warrentydate').show();
                } else {
                    $('#warrentydate').hide();
                }
            });

            @if(old('purchase_from') && old('contactno'))
                selectParty(@json(old('purchase_from')), @json(old('contactno')));
            @endif

            // Duplicate IMEI check (on blur, both against existing stock and within this form)
            function setImeiDuplicateState($input, isDuplicate, message) {
                const $feedback = $input.closest('.col-md-3').find('.imei-feedback');

                $input.data('imei-duplicate', isDuplicate);
                $input.toggleClass('is-invalid', isDuplicate);

                if (isDuplicate) {
                    $feedback.text(message).show();
                } else {
                    $feedback.hide().text('');
                }
            }

            function checkImeiWithinForm(imei, $currentInput) {
                let duplicateInForm = false;

                $('.imei-input').not($currentInput).each(function () {
                    if ($(this).val().trim() === imei) {
                        duplicateInForm = true;
                    }
                });

                return duplicateInForm;
            }

            $(document).on('blur', '.imei-input', function () {
                const $input = $(this);
                const imei = $input.val().trim();

                if (!imei) {
                    setImeiDuplicateState($input, false, '');
                    return;
                }

                if (checkImeiWithinForm(imei, $input)) {
                    setImeiDuplicateState($input, true, 'Duplicate IMEI entered more than once in this form.');
                    return;
                }

                $.ajax({
                    url: "{{ route('purchase.checkimei') }}",
                    type: 'GET',
                    data: { imei: imei },
                    success: function (response) {
                        if (response && response.exists) {
                            setImeiDuplicateState($input, true, 'This IMEI already exists in stock.');
                        } else {
                            setImeiDuplicateState($input, false, '');
                        }
                    }
                });
            });

            $(document).on('input', '.imei-input', function () {
                if ($(this).data('imei-duplicate')) {
                    setImeiDuplicateState($(this), false, '');
                }
            });

            $('#purchaseForm').on('submit', function (event) {
                let hasDuplicate = false;

                $('.imei-input').each(function () {
                    if ($(this).data('imei-duplicate')) {
                        hasDuplicate = true;
                    }
                });

                if (hasDuplicate) {
                    event.preventDefault();
                }
            });
        });
    </script>
@endsection
