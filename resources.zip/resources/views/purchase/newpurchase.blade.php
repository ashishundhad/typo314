@extends('layout.app')

@section('title')
    {{ isset($purchase) ? 'Edit Stock' : 'New Stock' }}
@endsection

@section('content')
    <div class="settings-shell">
        <div class="container-fluid">

            @include('include.alert')

            <div class="row">
                <div class="col-12">
                    <div class="card settings-card">
                        <div class="card-body">
                            <div class="settings-card__header">
                                <div>
                                    <!-- <div class="settings-section__eyebrow">Stock Intake</div> -->
                                    <h2 class="settings-section__title mb-0">{{ isset($purchase) ? 'Add Stock' : 'New Stock' }} Entry</h2>
                                </div>
                                <a href="{{ route('allpurchases') }}" class="settings-back-link">
                                    <i class="mdi mdi-keyboard-backspace"></i> Back
                                </a>
                            </div>

                            <form class="form-horizontal" method="post" enctype="multipart/form-data"
                                action="{{ route('purchase.store')}}" id="purchaseForm">
                                @csrf
                                <input type="hidden" name="id" value="{{ isset($purchase) ? $purchase->id : '' }}">
                                <input type="hidden" name="entry_type" value="single">

                                <div class="settings-section">
                                    <!-- <div class="settings-section__eyebrow">Device</div> -->
                                    <!-- <h2 class="settings-section__title">Device Details</h2> -->
                                    <!-- <p class="settings-section__subtitle">What this unit is and how it's tracked in stock.</p> -->

                                    <div class="settings-panel">
                                        <div class="row">
                                    <div class="col-md-2 mb-3">
                                    <label for="devicetype" class="settings-label">Device Type</label>
                                    <select class="form-select settings-input" id="devicetype" name="device_type" required>
                                        <option value="Phone" @selected(old('device_type', $purchase->device_type) == 'Phone')>
                                            Phone</option>
                                        <option value="Tablet"
                                            @selected(old('device_type', $purchase->device_type) == 'Tablet')>Tablet</option>
                                        <option value="Laptop"
                                            @selected(old('device_type', $purchase->device_type) == 'Laptop')>Laptop</option>
                                        <option value="Accessories"
                                            @selected(old('device_type', $purchase->device_type) == 'Accessories')>Accessories</option>
                                        <option value="Smartwatch"
                                            @selected(old('device_type', $purchase->device_type) == 'Smartwatch')>Smartwatch</option>
                                    </select>
                                </div>
                            <div class="col-md-2 mb-3">
                                    <label for="trackingtype" class="settings-label">Inventory Tracking</label>
                                    <select class="form-select settings-input" id="trackingtype" name="tracking_type" required>
                                        <option value="serialized" @selected(old('tracking_type', $purchase->tracking_type ?? ($purchase->device_type === 'Accessories' ? 'bulk' : 'serialized')) == 'serialized')>
                                            Serialized</option>
                                        <option value="bulk" @selected(old('tracking_type', $purchase->tracking_type ?? ($purchase->device_type === 'Accessories' ? 'bulk' : 'serialized')) == 'bulk')>
                                            Bulk Quantity</option>
                                    </select>
                                </div>
                            <div class="col-md-4 mb-3">
                                    <label for="model" class="settings-label">Model <span
                                            class="text-danger">*</span></label>
                                    <input type="text" id="model" class="form-control settings-input @error('storage') is-invalid @enderror" name="model"
                                        value="{{ old('model', $purchase->model) }}" required>
                                </div>

                            <div class="col-md-4 mb-3 serialized-only-field">
                                    <label for="imei" class="settings-label imei-label">IMEI <span
                                            class="text-danger">*</span></label>
                                    <div class="imei-input-group">
                                        <input type="text" id="imei"
                                            class="form-control settings-input @error('imei') is-invalid @enderror" name="imei"
                                            value="{{ old('imei', $purchase->imei) }}" autocomplete="off">
                                        <button type="button" id="imeiScanButton" class="imei-scan-trigger"
                                            aria-label="Scan IMEI from box" title="Scan IMEI from box">
                                            <i class="mdi mdi-barcode-scan"></i>
                                        </button>
                                    </div>
                                    <div id="imeiDuplicateFeedback" class="invalid-feedback" style="display: none;"></div>
                                </div>
                            <div class="col-md-3 mb-3 bulk-only-field">
                                    <label for="sku" class="settings-label">SKU / Code</label>
                                    <input type="text" id="sku" class="form-control settings-input" name="sku"
                                        value="{{ old('sku', $purchase->sku) }}" placeholder="Optional internal code">
                                </div>
                            <div class="col-md-3 mb-3 bulk-only-field">
                                    <label for="quantity" class="settings-label">Quantity <span
                                            class="text-danger">*</span></label>
                                    <input type="number" id="quantity" class="form-control settings-input" name="quantity" min="1"
                                        value="{{ old('quantity', $purchase->quantity ?? 1) }}">
                                </div>
                            <div class="col-md-4 mb-3">
                                    <label for="storage" class="settings-label storage-label">Storage (GB) <span
                                            class="text-danger serialized-required">*</span></label>
                                    <div class="autocomplete-wrapper">
                                        <input type="text" id="storage"
                                            class="form-control settings-input @error('storage') is-invalid @enderror"
                                            name="storage" value="{{ old('storage', $purchase->storage) }}" autocomplete="off">
                                        <div id="storage_suggestions" class="autocomplete-suggestions-list"></div>
                                    </div>
                                </div>
                            <div class="col-md-4 mb-3">
                                    <label for="color" class="settings-label color-label">Color <span
                                            class="text-danger serialized-required">*</span></label>
                                    <div class="autocomplete-wrapper">
                                        <input type="text" id="color" class="form-control settings-input" name="color"
                                            value="{{ old('color', $purchase->color) }}" autocomplete="off">
                                        <div id="color_suggestions" class="autocomplete-suggestions-list"></div>
                                    </div>
                                </div>
                            <div class="col-md-4 mb-3">
                                    <label for="warrenty" class="settings-label">Brand Warranty <span
                                            class="text-danger">*</span></label>
                                    <select class="form-select settings-input" id="warrenty" name="warrenty" value="{{ old('warrentydate', $purchase->warrentydate) ?? 'Non warrenty' }}" required>
                                        <option value="Non warrenty" @selected(old('warrentydate', $purchase->warrentydate) == 'Non warrenty')>Non Warranty</option>
                                        <option value="Warrenty" @selected(old('warrentydate', $purchase->warrentydate) == 'Warrenty')>Warranty</option>
                                    </select>
                                    <div class="warrentydate mt-2" style="display:none;">
                                        <input type="date" id="warrentydate" class="form-control settings-input"
                                            name="warrentydate" value="{{ old('warrentydate', $purchase->warrentydate) }}">
                                    </div>
                                </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="settings-section">
                                    <!-- <div class="settings-section__eyebrow">Source</div> -->
                                    <h2 class="settings-section__title">Party &amp; Pricing</h2>
                                    <!-- <p class="settings-section__subtitle">Who you bought it from, and what it cost.</p> -->

                                    <div class="settings-panel">
                                        <div class="row">
                            <div class="col-md-6 mb-3">
                                    <label for="partyname" class="settings-label">Party Name</label>
                                    <input type="text" id="partyname" class="form-control settings-input" name="purchase_from"
                                        value="{{ old('purchase_from', $purchase->purchase_from) }}" autocomplete="off">
                                    <div id="parties_suggestions" class="list-group"></div>
                                </div>
                            <div class="col-md-6 mb-3">
                                    <label for="contactno" class="settings-label">Party Contact No</label>
                                    <input type="text" id="contactno" class="form-control settings-input" name="contactno"
                                        value="{{ old('contactno', $purchase->contactno) }}">
                                </div>

                            <div class="col-md-4 mb-3">
                                    <label for="purchasedate" class="settings-label">Purchase Date <span
                                            class="text-danger">*</span></label>
                                    <input type="date" id="purchasedate" class="form-control settings-input"
                                        name="purchase_date" value="{{ old('purchase_date', $purchase->purchase_date) }}">
                                </div>
                            <div class="col-md-4 mb-3">
                                    <label for="purchasecost" class="settings-label">Purchase Cost <span
                                            class="text-danger">*</span></label>
                                    <input type="number" id="purchasecost" class="form-control settings-input"
                                        name="purchase_cost" value="{{ old('purchase_cost', $purchase->purchase_cost) }}"
                                        required placeholder="Enter Purchase Cost">
                                </div>
                            <div class="col-md-4 mb-3">
                                    <label for="msp" class="settings-label">MSP <span class="text-danger">*</span></label>
                                    <input type="number" id="msp" class="form-control settings-input @error('storage') is-invalid @enderror"
                                        name="msp" value="{{ old('msp', $purchase->msp) }}"
                                        required placeholder="Enter MSP">
                                </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="settings-section">
                                    <div class="d-flex justify-content-between align-items-center flex-wrap mb-3">
                                        <div>
                                            <h2 class="settings-section__title mb-1">Supporting Documents</h2>
                                            <p class="text-muted mb-0" style="font-size:13px;">Attach supplier receipts or other paperwork for this purchase. Photos are optimized automatically.</p>
                                        </div>
                                        <div class="mt-3 mt-md-0">
                                            <button type="button" class="btn btn-outline-success" id="addPurchaseDocumentBtn">
                                                <i class="mdi mdi-plus-circle-outline mr-1"></i>Add Document
                                            </button>
                                            <button type="button" class="btn btn-primary" id="qrUploadBtn" data-toggle="modal" data-target="#qrUploadModal">
                                                <i class="mdi mdi-qrcode mr-1"></i>Via Phone (QR)
                                            </button>
                                        </div>
                                    </div>

                                    <div id="purchaseDocumentsContainer" class="mb-2"></div>
                                </div>

                                <div class="settings-section">
                                    <!-- <div class="settings-section__eyebrow">Notes</div> -->
                                    <h2 class="settings-section__title">Remark</h2>

                                    <div class="settings-panel">
                                        <textarea id="remark" class="form-control settings-input" name="remark" rows="2"
                                            placeholder="Enter Remark">{{ old('remark', $purchase->remark) }}</textarea>
                                    </div>
                                </div>

                                <div class="settings-actions">
                                    <button type="reset" class="btn btn-danger">
                                        <i class="fe-x me-1"></i> Cancel
                                    </button>
                                    <button type="submit" class="btn settings-btn btn-primary">
                                        <i class="fe-check-circle me-1"></i> {{ isset($purchase->id) ? 'Update' : 'Save' }}
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div id="imeiScannerModal" class="imei-scanner-modal" aria-hidden="true">
        <div class="imei-scanner-card" role="dialog" aria-modal="true" aria-labelledby="imeiScannerTitle">
            <div class="imei-scanner-header">
                <h5 class="mb-0" id="imeiScannerTitle">Scan IMEI</h5>
                <button type="button" class="btn btn-sm btn-light" id="closeImeiScanner">Close</button>
            </div>
            <div class="imei-scanner-body">
                <div class="imei-scanner-preview">
                    <video id="imeiScannerVideo" playsinline muted></video>
                    <div class="imei-scanner-frame"></div>
                </div>
                <div id="imeiScannerStatus" class="imei-scanner-status">
                    Align the IMEI barcode inside the frame.
                </div>
                <div class="imei-scanner-actions">
                    <button type="button" class="btn btn-outline-secondary btn-sm" id="stopImeiScanner">Cancel</button>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="qrUploadModal" tabindex="-1" role="dialog" aria-labelledby="qrUploadModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="qrUploadModalLabel">Upload Document via Phone</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body text-center">
                    <p class="text-muted mb-3">Scan this with a phone — no webcam needed. It'll appear here once uploaded.</p>
                    <div id="qrUploadCode" class="mb-3 d-flex justify-content-center"></div>
                    <div id="qrUploadStatus" class="small text-muted mb-3">Generating code...</div>
                    <button type="button" class="btn btn-outline-primary" id="qrUploadCheckBtn" disabled>
                        <i class="mdi mdi-refresh mr-1"></i>Check for Upload
                    </button>
                </div>
            </div>
        </div>
    </div>

@endsection

@section('scripts')
    <script src="https://cdn.jsdelivr.net/npm/qrcodejs@1.0.0/qrcode.min.js"></script>
    <script>
        $(document).ready(function () {
            let storageSearchTimeout = null;
            let activeStorageSuggestionIndex = -1;
            let colorSearchTimeout = null;
            let activeColorSuggestionIndex = -1;
            const $storageInput = $('#storage');
            const $storageSuggestions = $('#storage_suggestions');
            const $colorInput = $('#color');
            const $colorSuggestions = $('#color_suggestions');
            const $deviceType = $('#devicetype');
            const $trackingType = $('#trackingtype');
            const $imeiInput = $('#imei');
            const $imeiScanButton = $('#imeiScanButton');
            const $imeiScannerModal = $('#imeiScannerModal');
            const $imeiScannerStatus = $('#imeiScannerStatus');
            const videoElement = document.getElementById('imeiScannerVideo');
            const storageElement = document.getElementById('storage');
            const $quantityInput = $('#quantity');
            const $skuInput = $('#sku');
            const hasBarcodeDetector = 'BarcodeDetector' in window;
            const permissionRequestStorageKey = 'imei-scanner-camera-requested';
            const permissionStateStorageKey = 'imei-scanner-camera-state';
            let barcodeDetector = null;
            let scannerStream = null;
            let scannerAnimationFrame = null;
            let scannerActive = false;

            function isMobileDevice() {
                return window.matchMedia('(max-width: 991px)').matches
                    && /Android|iPhone|iPad|iPod|webOS|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent || '');
            }

            function sanitizeImeiScanValue(rawValue) {
                return String(rawValue || '').replace(/\D/g, '');
            }

            function moveToNextFieldAfterScan() {
                $imeiInput.trigger('blur');

                window.setTimeout(function () {
                    if (storageElement) {
                        storageElement.focus();
                        storageElement.select();
                    }
                }, 60);
            }

            function setScannerStatus(message) {
                $imeiScannerStatus.text(message);
            }

            function stopScannerLoop() {
                if (scannerAnimationFrame) {
                    window.cancelAnimationFrame(scannerAnimationFrame);
                    scannerAnimationFrame = null;
                }
            }

            function closeImeiScanner() {
                scannerActive = false;
                stopScannerLoop();

                if (scannerStream) {
                    scannerStream.getTracks().forEach(function (track) {
                        track.stop();
                    });
                    scannerStream = null;
                }

                if (videoElement) {
                    videoElement.pause();
                    videoElement.srcObject = null;
                }

                $imeiScannerModal.removeClass('is-open').attr('aria-hidden', 'true');
                $imeiScanButton.prop('disabled', false);
            }

            function handleDetectedImei(rawValue) {
                const imei = sanitizeImeiScanValue(rawValue);

                if (imei.length < 10) {
                    return false;
                }

                $imeiInput.val(imei).trigger('input').trigger('change');
                closeImeiScanner();
                moveToNextFieldAfterScan();

                return true;
            }

            async function scanFrame() {
                if (!scannerActive || !barcodeDetector || !videoElement || videoElement.readyState < 2) {
                    scannerAnimationFrame = window.requestAnimationFrame(scanFrame);
                    return;
                }

                try {
                    const barcodes = await barcodeDetector.detect(videoElement);

                    if (Array.isArray(barcodes)) {
                        for (const barcode of barcodes) {
                            if (handleDetectedImei(barcode.rawValue)) {
                                return;
                            }
                        }
                    }
                } catch (error) {
                    setScannerStatus('Unable to read barcode yet. Hold steady and try again.');
                }

                if (scannerActive) {
                    scannerAnimationFrame = window.requestAnimationFrame(scanFrame);
                }
            }

            async function startImeiScanner() {
                if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
                    setScannerStatus('Camera access is not supported on this device.');
                    return;
                }

                if (!hasBarcodeDetector) {
                    setScannerStatus('Barcode scanning is not supported in this browser. Please type the IMEI.');
                    return;
                }

                if (localStorage.getItem(permissionStateStorageKey) === 'denied') {
                    alert('Camera access is blocked. Please enable camera permission in browser settings to scan IMEI.');
                    return;
                }

                if (!barcodeDetector) {
                    try {
                        barcodeDetector = new BarcodeDetector({
                            formats: ['code_128', 'ean_13', 'ean_8', 'upc_a', 'upc_e']
                        });
                    } catch (error) {
                        setScannerStatus('Barcode scanning is not available in this browser. Please type the IMEI.');
                        return;
                    }
                }

                $imeiScanButton.prop('disabled', true);
                $imeiScannerModal.addClass('is-open').attr('aria-hidden', 'false');
                setScannerStatus('Point the camera at the IMEI barcode on the box.');

                try {
                    localStorage.setItem(permissionRequestStorageKey, '1');

                    scannerStream = await navigator.mediaDevices.getUserMedia({
                        video: {
                            facingMode: {
                                ideal: 'environment'
                            }
                        },
                        audio: false
                    });

                    if (!videoElement) {
                        throw new Error('Scanner preview is unavailable.');
                    }

                    videoElement.srcObject = scannerStream;
                    await videoElement.play();
                    localStorage.setItem(permissionStateStorageKey, 'granted');

                    scannerActive = true;
                    scannerAnimationFrame = window.requestAnimationFrame(scanFrame);
                } catch (error) {
                    closeImeiScanner();

                    const permissionAsked = localStorage.getItem(permissionRequestStorageKey) === '1';
                    localStorage.setItem(permissionStateStorageKey, 'denied');
                    const deniedMessage = permissionAsked
                        ? 'Camera access is blocked. Please enable camera permission in browser settings to scan IMEI.'
                        : 'Camera permission is required to scan IMEI.';

                    alert(deniedMessage);
                }
            }

            function syncImeiScannerVisibility() {
                const shouldShow = isMobileDevice() && navigator.mediaDevices && navigator.mediaDevices.getUserMedia;
                $imeiScanButton.toggleClass('is-visible', !!shouldShow);
            }

            function syncTrackingTypeFromDevice() {
                if ($deviceType.val() === 'Accessories' && $trackingType.val() === 'serialized') {
                    $trackingType.val('bulk');
                }
            }

            function syncTrackingFields() {
                const isBulk = $trackingType.val() === 'bulk';

                $('.bulk-only-field').toggle(isBulk);
                $('.serialized-only-field').toggle(!isBulk);
                $('.serialized-required').toggle(!isBulk);

                $imeiInput.prop('required', !isBulk);
                $('#storage').prop('required', !isBulk);
                $('#color').prop('required', !isBulk);
                $quantityInput.prop('required', isBulk);

                if (isBulk) {
                    closeImeiScanner();
                    $imeiInput.val('');
                    $quantityInput.val($quantityInput.val() || 1);
                } else {
                    $quantityInput.val(1);
                }
            }

            function hideStorageSuggestions() {
                $storageSuggestions.hide().empty();
                activeStorageSuggestionIndex = -1;
            }

            function setActiveStorageSuggestion(index) {
                const $items = $storageSuggestions.find('.autocomplete-suggestion-item');

                $items.removeClass('active');

                if (!$items.length || index < 0 || index >= $items.length) {
                    activeStorageSuggestionIndex = -1;
                    return;
                }

                activeStorageSuggestionIndex = index;
                const $activeItem = $items.eq(index);
                $activeItem.addClass('active');

                const itemTop = $activeItem.position().top;
                const itemBottom = itemTop + $activeItem.outerHeight();
                const currentScroll = $storageSuggestions.scrollTop();
                const visibleBottom = currentScroll + $storageSuggestions.innerHeight();

                if (itemBottom > visibleBottom) {
                    $storageSuggestions.scrollTop(currentScroll + (itemBottom - visibleBottom));
                } else if (itemTop < 0) {
                    $storageSuggestions.scrollTop(currentScroll + itemTop);
                }
            }

            function selectStorage(storage) {
                $storageInput.val(storage);
                hideStorageSuggestions();
            }

            function renderStorageSuggestions(storages) {
                if (!storages.length) {
                    $storageSuggestions.html('<div class="autocomplete-suggestion-empty">No matching storage found.</div>').show();
                    activeStorageSuggestionIndex = -1;
                    return;
                }

                const items = storages.map(function (item) {
                    const storage = $('<div>').text(item.storage || '').html();

                    return `
                        <button type="button" class="autocomplete-suggestion-item storage-suggestion-item" data-storage="${storage}">
                            ${storage}
                        </button>
                    `;
                }).join('');

                $storageSuggestions.html(items).show();
                setActiveStorageSuggestion(0);
            }

            function hideColorSuggestions() {
                $colorSuggestions.hide().empty();
                activeColorSuggestionIndex = -1;
            }

            function setActiveColorSuggestion(index) {
                const $items = $colorSuggestions.find('.autocomplete-suggestion-item');

                $items.removeClass('active');

                if (!$items.length || index < 0 || index >= $items.length) {
                    activeColorSuggestionIndex = -1;
                    return;
                }

                activeColorSuggestionIndex = index;
                const $activeItem = $items.eq(index);
                $activeItem.addClass('active');

                const itemTop = $activeItem.position().top;
                const itemBottom = itemTop + $activeItem.outerHeight();
                const currentScroll = $colorSuggestions.scrollTop();
                const visibleBottom = currentScroll + $colorSuggestions.innerHeight();

                if (itemBottom > visibleBottom) {
                    $colorSuggestions.scrollTop(currentScroll + (itemBottom - visibleBottom));
                } else if (itemTop < 0) {
                    $colorSuggestions.scrollTop(currentScroll + itemTop);
                }
            }

            function selectColor(color) {
                $colorInput.val(color);
                hideColorSuggestions();
            }

            function renderColorSuggestions(colors) {
                if (!colors.length) {
                    $colorSuggestions.html('<div class="autocomplete-suggestion-empty">No matching color found.</div>').show();
                    activeColorSuggestionIndex = -1;
                    return;
                }

                const items = colors.map(function (item) {
                    const color = $('<div>').text(item.color || '').html();

                    return `
                        <button type="button" class="autocomplete-suggestion-item color-suggestion-item" data-color="${color}">
                            ${color}
                        </button>
                    `;
                }).join('');

                $colorSuggestions.html(items).show();
                setActiveColorSuggestion(0);
            }

            @if(isset($purchase) && $purchase->warrentydate != null)
                $('#warrenty').hide();
                $('.warrentydate').show();
            @endif

            // Warranty toggle
            $('#warrenty').on('change', function () {
                if ($(this).val() === 'Warrenty') {
                    $('.warrentydate').show();
                } else {
                    $('#warrentydate').hide();
                }
            });

            $storageInput.on('input', function () {
                const query = $(this).val().trim();

                clearTimeout(storageSearchTimeout);

                if (query.length < 2) {
                    hideStorageSuggestions();
                    return;
                }

                storageSearchTimeout = setTimeout(function () {
                    $.ajax({
                        url: "{{ route('purchase.getstorages') }}",
                        type: 'GET',
                        data: {
                            storage: query
                        },
                        success: function (response) {
                            renderStorageSuggestions(Array.isArray(response) ? response : []);
                        },
                        error: function () {
                            hideStorageSuggestions();
                        }
                    });
                }, 250);
            });

            $storageInput.on('keydown', function (event) {
                const $items = $storageSuggestions.find('.storage-suggestion-item');

                if (!$storageSuggestions.is(':visible') || !$items.length) {
                    return;
                }

                if (event.key === 'ArrowDown') {
                    event.preventDefault();
                    setActiveStorageSuggestion(activeStorageSuggestionIndex + 1 >= $items.length ? 0 : activeStorageSuggestionIndex + 1);
                } else if (event.key === 'ArrowUp') {
                    event.preventDefault();
                    setActiveStorageSuggestion(activeStorageSuggestionIndex <= 0 ? $items.length - 1 : activeStorageSuggestionIndex - 1);
                } else if (event.key === 'Enter') {
                    event.preventDefault();
                    const selectionIndex = activeStorageSuggestionIndex >= 0 ? activeStorageSuggestionIndex : 0;
                    $items.eq(selectionIndex).trigger('click');
                } else if (event.key === 'Escape') {
                    hideStorageSuggestions();
                }
            });

            $colorInput.on('input', function () {
                const query = $(this).val().trim();

                clearTimeout(colorSearchTimeout);

                if (query.length < 2) {
                    hideColorSuggestions();
                    return;
                }

                colorSearchTimeout = setTimeout(function () {
                    $.ajax({
                        url: "{{ route('purchase.getcolors') }}",
                        type: 'GET',
                        data: {
                            color: query
                        },
                        success: function (response) {
                            renderColorSuggestions(Array.isArray(response) ? response : []);
                        },
                        error: function () {
                            hideColorSuggestions();
                        }
                    });
                }, 250);
            });

            $colorInput.on('keydown', function (event) {
                const $items = $colorSuggestions.find('.color-suggestion-item');

                if (!$colorSuggestions.is(':visible') || !$items.length) {
                    return;
                }

                if (event.key === 'ArrowDown') {
                    event.preventDefault();
                    setActiveColorSuggestion(activeColorSuggestionIndex + 1 >= $items.length ? 0 : activeColorSuggestionIndex + 1);
                } else if (event.key === 'ArrowUp') {
                    event.preventDefault();
                    setActiveColorSuggestion(activeColorSuggestionIndex <= 0 ? $items.length - 1 : activeColorSuggestionIndex - 1);
                } else if (event.key === 'Enter') {
                    event.preventDefault();
                    const selectionIndex = activeColorSuggestionIndex >= 0 ? activeColorSuggestionIndex : 0;
                    $items.eq(selectionIndex).trigger('click');
                } else if (event.key === 'Escape') {
                    hideColorSuggestions();
                }
            });

            $(document).on('mouseenter', '.storage-suggestion-item', function () {
                setActiveStorageSuggestion($(this).index());
            });

            $(document).on('mouseenter', '.color-suggestion-item', function () {
                setActiveColorSuggestion($(this).index());
            });

            $(document).on('click', '.storage-suggestion-item', function () {
                selectStorage($(this).data('storage'));
            });

            $(document).on('click', '.color-suggestion-item', function () {
                selectColor($(this).data('color'));
            });

            $(document).on('click', function (event) {
                if (!$(event.target).closest('.autocomplete-wrapper').length) {
                    hideStorageSuggestions();
                    hideColorSuggestions();
                }
            });

            syncTrackingTypeFromDevice();
            syncTrackingFields();
            syncImeiScannerVisibility();

            $(window).on('resize', syncImeiScannerVisibility);

            $deviceType.on('change', function () {
                syncTrackingTypeFromDevice();
                syncTrackingFields();
            });

            $trackingType.on('change', function () {
                syncTrackingFields();
            });

            $imeiScanButton.on('click', function () {
                startImeiScanner();
            });

            $('#closeImeiScanner, #stopImeiScanner').on('click', function () {
                closeImeiScanner();
            });

            $imeiScannerModal.on('click', function (event) {
                if (event.target === this) {
                    closeImeiScanner();
                }
            });

            // Multiple documents preview
            $('#document').on('change', function () {
                $('#document-preview').empty(); // clear old previews
                const files = this.files;

                if (!files.length) return;

                Array.from(files).forEach(file => {
                    const reader = new FileReader();
                    reader.onload = function (e) {
                        let preview;
                        if (file.type.startsWith('image/')) {
                            preview = `<div class="mr-2">
                                          <div class="border rounded shadow-sm p-1">
                                              <img src="${e.target.result}" class="img-fluid rounded" style="height:120px; object-fit:cover;">
                                          </div>
                                       </div>`;
                        } else if (file.type === 'application/pdf') {
                            preview = `<div class="mr-2">
                                          <div class="border rounded shadow-sm p-3 text-center bg-light">
                                              <i class="fe-file-text text-danger fs-3"></i>
                                              <p class="small mt-2">${file.name}</p>
                                          </div>
                                       </div>`;
                        } else {
                            preview = `<div class="mr-2">
                                          <div class="border rounded shadow-sm p-3 text-center bg-light">
                                              <i class="fe-file text-secondary fs-3"></i>
                                              <p class="small mt-2">${file.name}</p>
                                          </div>
                                       </div>`;
                        }
                        $('#document-preview').append(preview);
                    };
                    reader.readAsDataURL(file);
                });
            });

            $(window).on('beforeunload', function () {
                closeImeiScanner();
            });

            // Duplicate IMEI check on blur
            const $imeiFeedback = $('#imeiDuplicateFeedback');
            const currentPurchaseId = {{ isset($purchase) && $purchase->id ? (int) $purchase->id : 'null' }};
            let imeiIsDuplicate = false;

            function clearImeiDuplicateState() {
                imeiIsDuplicate = false;
                $imeiInput.removeClass('is-invalid');
                $imeiFeedback.hide().text('');
            }

            function showImeiDuplicateState() {
                imeiIsDuplicate = true;
                $imeiInput.addClass('is-invalid');
                $imeiFeedback.text('This IMEI already exists in stock.').show();
            }

            $imeiInput.on('blur', function () {
                const imei = $(this).val().trim();

                if (!imei) {
                    clearImeiDuplicateState();
                    return;
                }

                $.ajax({
                    url: "{{ route('purchase.checkimei') }}",
                    type: 'GET',
                    data: {
                        imei: imei,
                        exclude_id: currentPurchaseId
                    },
                    success: function (response) {
                        if (response && response.exists) {
                            showImeiDuplicateState();
                        } else {
                            clearImeiDuplicateState();
                        }
                    }
                });
            });

            $imeiInput.on('input', function () {
                if (imeiIsDuplicate) {
                    clearImeiDuplicateState();
                }
            });

            $('#purchaseForm').on('submit', function (event) {
                if (imeiIsDuplicate) {
                    event.preventDefault();
                    $imeiInput.trigger('focus');
                }
            });

            // Supporting documents — manual upload row + QR phone-handoff, mirroring
            // the same pattern built for Invoice (see invoice/add.blade.php).
            let purchaseDocumentCounter = 0;
            let qrUploadToken = null;

            function addPurchaseDocumentRow() {
                purchaseDocumentCounter++;
                const rowHtml = `
                    <div class="item-row" data-index="${purchaseDocumentCounter}">
                        <div class="row g-2 align-items-end">
                            <div class="col-md-3">
                                <label class="form-label">Document Type</label>
                                <select class="form-control document-type" name="documents[${purchaseDocumentCounter}][type]">
                                    <option value="aadhar">Aadhar Card</option>
                                    <option value="pan">PAN Card</option>
                                    <option value="other" selected>Other</option>
                                </select>
                            </div>
                            <div class="col-md-3 document-type-other-wrap">
                                <label class="form-label">Document Name</label>
                                <input type="text" class="form-control" name="documents[${purchaseDocumentCounter}][type_other]" placeholder="e.g. Supplier Invoice">
                            </div>
                            <div class="col-md-3">
                                <label class="form-label">Reference Number</label>
                                <input type="text" class="form-control" name="documents[${purchaseDocumentCounter}][number]" placeholder="Optional">
                            </div>
                            <div class="col-md-2">
                                <label class="form-label">Photo <span class="text-danger">*</span></label>
                                <input type="file" class="form-control" name="documents[${purchaseDocumentCounter}][image]" accept="image/png,image/jpeg,image/webp">
                            </div>
                            <div class="col-md-1 d-flex align-items-end">
                                <button type="button" class="btn btn-outline-danger remove-document" title="Remove">
                                    <i class="mdi mdi-delete"></i>
                                </button>
                            </div>
                        </div>
                    </div>`;
                $('#purchaseDocumentsContainer').append(rowHtml);
            }

            $('#addPurchaseDocumentBtn').on('click', addPurchaseDocumentRow);

            $(document).on('click', '#purchaseDocumentsContainer .remove-document', function () {
                $(this).closest('.item-row').remove();
            });

            $(document).on('change', '#purchaseDocumentsContainer .document-type', function () {
                $(this).closest('.item-row').find('.document-type-other-wrap').toggle($(this).val() === 'other');
            });

            $('#qrUploadModal').on('show.bs.modal', function () {
                qrUploadToken = null;
                $('#qrUploadCode').empty();
                $('#qrUploadStatus').text('Generating code...');
                $('#qrUploadCheckBtn').prop('disabled', true);

                $.ajax({
                    url: "{{ route('document-uploads.create') }}",
                    type: 'POST',
                    success: function (response) {
                        qrUploadToken = response.token;
                        new QRCode(document.getElementById('qrUploadCode'), {
                            text: response.url,
                            width: 200,
                            height: 200,
                        });
                        $('#qrUploadStatus').text('Waiting for upload...');
                        $('#qrUploadCheckBtn').prop('disabled', false);
                    },
                    error: function () {
                        $('#qrUploadStatus').text('Could not generate a code. Please try again.');
                    }
                });
            });

            $('#qrUploadModal').on('hidden.bs.modal', function () {
                qrUploadToken = null;
                $('#qrUploadCode').empty();
            });

            $('#qrUploadCheckBtn').on('click', function () {
                if (!qrUploadToken) {
                    return;
                }

                const $btn = $(this);
                $btn.prop('disabled', true);
                $('#qrUploadStatus').text('Checking...');

                $.ajax({
                    url: "{{ url('/admin/document-uploads') }}/" + qrUploadToken + '/status',
                    type: 'GET',
                    success: function (response) {
                        $btn.prop('disabled', false);

                        if (response.status === 'uploaded') {
                            addPendingPurchaseDocumentRow(response);
                            $('#qrUploadModal').modal('hide');
                        } else if (response.status === 'pending') {
                            $('#qrUploadStatus').text('Not uploaded yet — scan and submit on the phone, then check again.');
                        } else {
                            $('#qrUploadStatus').text('This code is no longer valid. Close and reopen to get a fresh one.');
                        }
                    },
                    error: function () {
                        $btn.prop('disabled', false);
                        $('#qrUploadStatus').text('Could not check right now. Try again.');
                    }
                });
            });

            function addPendingPurchaseDocumentRow(doc) {
                purchaseDocumentCounter++;
                const rowHtml = `
                    <div class="item-row" data-index="${purchaseDocumentCounter}">
                        <div class="row g-2 align-items-center">
                            <div class="col-md-3">
                                <label class="form-label">Document Type</label>
                                <input type="text" class="form-control" value="${doc.document_type_label}" readonly>
                                <input type="hidden" name="documents[${purchaseDocumentCounter}][type]" value="${doc.document_type}">
                                <input type="hidden" name="documents[${purchaseDocumentCounter}][type_other]" value="${doc.document_type_other || ''}">
                            </div>
                            <div class="col-md-4">
                                <label class="form-label">Reference Number</label>
                                <input type="text" class="form-control" name="documents[${purchaseDocumentCounter}][number]" value="${doc.document_number || ''}">
                            </div>
                            <div class="col-md-3">
                                <span class="badge badge-success"><i class="mdi mdi-cellphone-check mr-1"></i>Uploaded via phone</span>
                                <input type="hidden" name="documents[${purchaseDocumentCounter}][pending_token]" value="${doc.token}">
                            </div>
                            <div class="col-md-2 d-flex justify-content-end">
                                <button type="button" class="btn btn-outline-danger remove-document">
                                    <i class="mdi mdi-delete mr-1"></i>Remove
                                </button>
                            </div>
                        </div>
                    </div>`;
                $('#purchaseDocumentsContainer').append(rowHtml);
            }
        });

    </script>
@endsection
