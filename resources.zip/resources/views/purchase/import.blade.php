@extends('layout.app')


@section('title')
    Import Stock Data
@endsection

@section('content')
<div class="container-fluid">
    <div class="row">
        <div class="col">
            <div class="page-title-box">
                <h2 class="page-title font-weight-bold text-uppercase">Import Stocks</h2>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-12 col-lg-7">
            <div class="card">
                <div class="card-body">
                    @include('include.alert')

                    <hr>
                    <form action="{{ route('purchase.import') }}" enctype="multipart/form-data" method="post" class="@if(count($errors)) was-validated @endif">
                        @csrf
                        <div class="row">
                            <div class="form-group row mb-4">
                                <label for="file" class="col-4 col-form-label">Import Stocks*:</label>
                                <div class="col-8">
                                    <input name="stockdata" class="form-control" type="file"  id="file" required>
                                </div>
                                @error('stockdata')
                                    <div class="invalid-feedback">{{ $message}} </div>
                                @enderror
                            </div>
                        </div>

                        <div class="row mt-3">
                            <div class="col-md-4">
                                <a class="btn btn-danger float-right mb-2 ml-2" href="{{ route('allinvoices') }}">
                                    <i class="mdi mdi-keyboard-backspace"></i>Cancel</a>
                                <button type="submit" class="btn btn-primary float-right mb-2 ml-2">IMPORT</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <div class="col-12 col-lg-5">
            <div class="card">
                <div class="card-body">
                    <h4 class="header-title mb-2">File format</h4>
                    <p class="text-muted mb-3">
                        Semicolon-separated (<code>;</code>) CSV, one row per phone. The first row is
                        treated as a header and skipped — keep it, but its exact wording doesn't matter.
                        Only serialized phone stock (tracked by IMEI) can be imported this way — bulk /
                        accessory stock without an IMEI needs to be added individually instead.
                    </p>

                    <a href="{{ asset('samples/purchase-import-template.csv') }}" class="btn btn-outline-primary btn-sm mb-3" download>
                        <i class="mdi mdi-download mr-1"></i>Download sample CSV
                    </a>

                    <div class="table-responsive">
                        <table class="table table-sm table-bordered mb-0">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Column</th>
                                    <th>Notes</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr><td>1</td><td>Sr No</td><td class="text-muted">Ignored — for your own reference only</td></tr>
                                <tr><td>2</td><td>Purchase Date</td><td class="text-muted"><code>dd.mm.yyyy</code>, e.g. 25.08.2026</td></tr>
                                <tr><td>3</td><td>IMEI</td><td class="text-muted">Required</td></tr>
                                <tr><td>4</td><td>Model</td><td class="text-muted">e.g. iPhone 13</td></tr>
                                <tr><td>5</td><td>Storage</td><td class="text-muted">e.g. 128GB</td></tr>
                                <tr><td>6</td><td>Color</td><td></td></tr>
                                <tr><td>7</td><td>Purchased From</td><td class="text-muted">Supplier / customer name</td></tr>
                                <tr><td>8</td><td>Contact No</td><td class="text-muted">Optional</td></tr>
                                <tr><td>9</td><td>Sold</td><td class="text-muted"><code>1</code> if already resold, otherwise <code>0</code> or blank</td></tr>
                                <tr><td>10</td><td>Purchase Cost</td><td></td></tr>
                                <tr><td>11</td><td>Repairing Charge</td><td class="text-muted">Optional, defaults to 0</td></tr>
                                <tr><td>12</td><td>Remark</td><td class="text-muted">Optional</td></tr>
                                <tr><td>13</td><td>Purchase Price</td><td class="text-muted">Intended resale price</td></tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection