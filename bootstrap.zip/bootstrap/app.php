<?php

use Illuminate\Foundation\Application;
use Illuminate\Foundation\Configuration\Exceptions;
use Illuminate\Foundation\Configuration\Middleware;
use Illuminate\Support\Facades\Route;
use App\Http\Middleware\EnsureSubscriptionActive;
use App\Http\Middleware\InitializeTenancyUnlessLegacy;
use Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains;

return Application::configure(basePath: dirname(__DIR__))
    ->withRouting(
        commands: __DIR__.'/../routes/console.php',
        health: '/up',
        then: function (): void {
            // A single, domain-less registration of the app's routes — NOT one
            // copy per domain class. Two copies with identical route names
            // (login, dashboard, ...) would collide: Illuminate\Routing\
            // RouteCollection::refreshNameLookups() rebuilds the name lookup by
            // iterating $allRoutes, and domain-HAVING routes are always reordered
            // to the front of that array (see addToCollections()) regardless of
            // registration order — so a domain-pinned copy's name would always
            // win reverse-routing (route('login')) over a domain-less one, no
            // matter which one was registered first. Duplicating routes.php per
            // domain class was tried and hit exactly this.
            //
            // Instead, InitializeTenancyUnlessLegacy (not Stancl's stock
            // InitializeTenancyByDomain) decides per-request whether to swap to
            // a tenant DB connection at all — it's a no-op for central domains,
            // leaving them on the central connection, and behaves like normal
            // tenancy initialization for every other host.
            Route::middleware([
                'web',
                InitializeTenancyUnlessLegacy::class,
                PreventAccessFromCentralDomains::class,
                EnsureSubscriptionActive::class,
            ])->group(__DIR__.'/../routes/app-web.php');

            Route::middleware([
                'api',
                InitializeTenancyUnlessLegacy::class,
                PreventAccessFromCentralDomains::class,
            ])->prefix('api')->group(__DIR__.'/../routes/app-api.php');

            Route::middleware('web')->group(__DIR__.'/../routes/central.php');
        },
    )
    ->withMiddleware(function (Middleware $middleware): void {
        $middleware->alias([
            'auth.api' => \App\Http\Middleware\AuthenticateApiToken::class,
            'permission' => \Spatie\Permission\Middleware\PermissionMiddleware::class,
            'role' => \Spatie\Permission\Middleware\RoleMiddleware::class,
            'role_or_permission' => \Spatie\Permission\Middleware\RoleOrPermissionMiddleware::class,
            'central.domain' => \App\Http\Middleware\EnsureCentralDomain::class,
        ]);
    })
    ->withExceptions(function (Exceptions $exceptions): void {
        $exceptions->render(function (\Stancl\Tenancy\Exceptions\TenantCouldNotBeIdentifiedOnDomainException $e) {
            abort(404);
        });
    })->create();
