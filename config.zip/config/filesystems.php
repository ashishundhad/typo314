<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Default Filesystem Disk
    |--------------------------------------------------------------------------
    |
    | Here you may specify the default filesystem disk that should be used
    | by the framework. The "local" disk, as well as a variety of cloud
    | based disks are available to your application for file storage.
    |
    */

    'default' => env('FILESYSTEM_DISK', 'local'),

    /*
    |--------------------------------------------------------------------------
    | Filesystem Disks
    |--------------------------------------------------------------------------
    |
    | Below you may configure as many filesystem disks as necessary, and you
    | may even configure multiple disks for the same driver. Examples for
    | most supported storage drivers are configured here for reference.
    |
    | Supported drivers: "local", "ftp", "sftp", "s3"
    |
    */

    'disks' => [

        'local' => [
            'driver' => 'local',
            'root' => storage_path('app/private'),
            // Deliberately NOT served: this disk's default visibility is
            // 'private', and Laravel's auto-serve route (FilesystemServiceProvider)
            // registers by disk order — with this at 'serve' => true and no
            // 'url' of its own, it silently claimed the /storage URI ahead of
            // the 'public' disk below (which never got auto-served at all
            // without this key), so every public disk file 403'd/404'd
            // instead of being served. 'public' now owns /storage instead.
            'throw' => false,
            'report' => false,
        ],

        'public' => [
            'driver' => 'local',
            'root' => storage_path('app/public'),
            'url' => env('APP_URL').'/storage',
            'visibility' => 'public',
            'serve' => true,
            'throw' => false,
            'report' => false,
        ],

        // Invoice PDFs shared as public links (WhatsApp, etc.) must resolve to a
        // fixed URL regardless of which tenant generated them — but config('tenancy.filesystem.disks')
        // suffixes the 'public' disk's root per-tenant (storage_tenantXXX/app/public/...)
        // whenever tenancy is initialized, same as storage_path() itself, and that
        // suffixed location is never reachable through the single shared
        // public/storage symlink (see 'links' below). This disk is deliberately
        // NOT listed in config/tenancy.php's filesystem.disks, so its root is
        // never suffixed and always resolves to the same storage/app/public the
        // symlink actually points at. Filenames already carry the invoice number
        // plus a random suffix, so cross-tenant collisions aren't a concern.
        'invoice_pdfs' => [
            'driver' => 'local',
            'root' => storage_path('app/public'),
            'url' => env('APP_URL').'/storage',
            'visibility' => 'public',
            'throw' => false,
            'report' => false,
        ],

        's3' => [
            'driver' => 's3',
            'key' => env('AWS_ACCESS_KEY_ID'),
            'secret' => env('AWS_SECRET_ACCESS_KEY'),
            'region' => env('AWS_DEFAULT_REGION'),
            'bucket' => env('AWS_BUCKET'),
            'url' => env('AWS_URL'),
            'endpoint' => env('AWS_ENDPOINT'),
            'use_path_style_endpoint' => env('AWS_USE_PATH_STYLE_ENDPOINT', false),
            'throw' => false,
            'report' => false,
        ],

    ],

    /*
    |--------------------------------------------------------------------------
    | Symbolic Links
    |--------------------------------------------------------------------------
    |
    | Here you may configure the symbolic links that will be created when the
    | `storage:link` Artisan command is executed. The array keys should be
    | the locations of the links and the values should be their targets.
    |
    */

    'links' => [
        public_path('storage') => storage_path('app/public'),
    ],

];
