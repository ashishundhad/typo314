<?php

use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Models\{Invoice, InvoicePayment, Purchase, InvoiceItem};
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Ai\AiAssistantController;
use App\Http\Controllers\Auth\PasswordController;
use App\Http\Controllers\Auth\NewPasswordController;
use App\Http\Controllers\Auth\VerifyEmailController;
use App\Http\Controllers\Auth\RegisteredUserController;
use App\Http\Controllers\Auth\PasswordResetLinkController;
use App\Http\Controllers\Auth\ConfirmablePasswordController;
use App\Http\Controllers\Auth\AuthenticatedSessionController;
use App\Http\Controllers\Auth\EmailVerificationPromptController;
use App\Http\Controllers\Auth\EmailVerificationNotificationController;
use App\Http\Controllers\{AdminController, DocumentController, DocumentUploadController, ExpenseCategoryController, ExpenseController, GlobalSearchController, GoogleContactController, InvoiceController, PosController, ProfileController, PurchaseController, RepairController, ReportController, RoleController, SaleController, SaleReturnController, SettingsController, TransactionController, UserController, PartyController};
use App\Http\Controllers\Ledger\LedgerEntryController;

// Auth Routes
Route::get('/', fn() => Auth::check() ? redirect()->route('dashboard') : redirect()->route('login'));
Route::get('/home', fn() => view('welcome'));

Route::middleware('guest')->group(function () {
    // Route::get('register', [RegisteredUserController::class, 'create'])->name('register');
    // Route::post('register', [RegisteredUserController::class, 'store']);
    Route::get('login', [AuthenticatedSessionController::class, 'create'])->name('login');
    Route::post('login', [AuthenticatedSessionController::class, 'store']);
    Route::get('forgot-password', [PasswordResetLinkController::class, 'create'])->name('password.request');
    Route::post('forgot-password', [PasswordResetLinkController::class, 'store'])->name('password.email');
    Route::get('reset-password/{token}', [NewPasswordController::class, 'create'])->name('password.reset');
    Route::post('reset-password', [NewPasswordController::class, 'store'])->name('password.store');
});

// Authenticated Users
Route::middleware('auth')->group(function () {
    Route::get('verify-email', EmailVerificationPromptController::class)->name('verification.notice');
    Route::get('verify-email/{id}/{hash}', VerifyEmailController::class)->middleware(['signed', 'throttle:6,1'])->name('verification.verify');
    Route::post('email/verification-notification', [EmailVerificationNotificationController::class, 'store'])->middleware('throttle:6,1')->name('verification.send');
    Route::get('confirm-password', [ConfirmablePasswordController::class, 'show'])->name('password.confirm');
    Route::post('confirm-password', [ConfirmablePasswordController::class, 'store']);
    Route::put('password', [PasswordController::class, 'update'])->name('password.update');
    Route::post('logout', [AuthenticatedSessionController::class, 'destroy'])->name('logout');
});

// Dashboard
Route::middleware(['auth', 'permission:dashboard.view'])->get('/dashboard', function (Request $request) {
    $today        = Carbon::today();
    $yesterday    = Carbon::yesterday();
    $startOfMonth = Carbon::now()->startOfMonth();
    $endOfMonth   = Carbon::now();
    $sevenDaysAgo = Carbon::now()->subDays(7);
    $user = auth()->user();
    $scopedStoreLocation = null;

    if ($user && ! $user->hasRole('super-admin') && filled($user->storelocation)) {
        $scopedStoreLocation = strtolower(trim((string) $user->storelocation));
    }

    $purchaseBaseQuery = Purchase::query();
    $invoiceBaseQuery = Invoice::query();
    $invoiceItemBaseQuery = InvoiceItem::query();

    if ($scopedStoreLocation !== null) {
        $purchaseBaseQuery->where('storelocation', $scopedStoreLocation);
        $invoiceBaseQuery->whereHas('items.purchase', function ($query) use ($scopedStoreLocation) {
            $query->where('storelocation', $scopedStoreLocation);
        });
        $invoiceItemBaseQuery->whereHas('purchase', function ($query) use ($scopedStoreLocation) {
            $query->where('storelocation', $scopedStoreLocation);
        });
    }

    $stocksInHand      = (clone $purchaseBaseQuery)->where('is_sold', 0)->where('deleted', 0)->count();
    // Mirrors Purchase::getAvailableStockValueAttribute() (purchase_price * available_units)
    // as a DB-side aggregate via ->toBase() — see PurchaseController::index() for the
    // identical pattern and why ->toBase() is required (Eloquent would otherwise hydrate a
    // Purchase model and let its own accessor of the same name shadow this raw SUM).
    $totalStockValue   = (float) (clone $purchaseBaseQuery)
        ->where('deleted', 0)
        ->toBase()
        ->selectRaw("SUM(purchase_price * (CASE WHEN tracking_type = 'bulk' THEN GREATEST(available_quantity, 0) ELSE (CASE WHEN is_sold = 1 THEN 0 ELSE 1 END) END)) as total")
        ->value('total');
    $totalSales        = (clone $invoiceBaseQuery)->whereDate('invoice_date', $today)->where('deleted', 0)->sum('net_amount');
    $currentMonthSales = (clone $invoiceBaseQuery)->whereBetween('invoice_date', [$startOfMonth, $endOfMonth])->where('deleted', 0)->sum('net_amount');

    $filter   = $request->input('filtertime');
    $fromdate = Carbon::parse($request->input('fromdate'))->startOfDay();
    $todate   = Carbon::parse($request->input('todate'))->startOfDay();

    $invoices = match ($filter) {
        'yesterday' => (clone $invoiceBaseQuery)->whereDate('invoice_date', $yesterday),
        'lastweek' => (clone $invoiceBaseQuery)->whereBetween('invoice_date', [$sevenDaysAgo, $today]),
        'month'    => (clone $invoiceBaseQuery)->whereBetween('invoice_date', [$startOfMonth, $endOfMonth]),
        'custom'   => (clone $invoiceBaseQuery)->whereBetween('invoice_date', [$fromdate, $todate]),
        default    => (clone $invoiceBaseQuery)->whereDate('invoice_date', $today),
    };

    $invoices                    = $invoices->where('deleted', 0)->orderBy('created_at', 'desc')->paginate(10);
    $numberOfProductsSoldInMonth = (clone $invoiceItemBaseQuery)->whereBetween('created_at', [$startOfMonth, $endOfMonth])->where('deleted', 0)->count();

    // Built from invoice_payments (via the invoices already scoped by $invoiceBaseQuery)
    // rather than invoices.payment_type directly, so a split-payment invoice contributes
    // its actual amount to each method's bucket instead of all of it landing in one.
    $todaysPaymentTotals = (clone $invoiceBaseQuery)
        ->whereDate('invoice_date', $today)
        ->where('deleted', 0)
        ->with('payments')
        ->get()
        ->flatMap(fn ($invoice) => $invoice->payments)
        ->groupBy(fn ($payment) => $payment->payment_method ?: 'Other')
        ->map(fn ($rows) => (float) $rows->sum('amount'))
        ->sortDesc();

    $todaysPaymentTotal = (float) $todaysPaymentTotals->sum();
    $todaysPaymentBreakdown = $todaysPaymentTotals->map(function ($amount, $label) use ($todaysPaymentTotal) {
        return [
            'label'   => $label,
            'amount'  => $amount,
            'percent' => $todaysPaymentTotal > 0 ? round($amount / $todaysPaymentTotal * 100, 1) : 0,
        ];
    })->values();

    return view('dashboard', [
        'stocksInHand'                => $stocksInHand,
        'totalStockValue'             => number_format($totalStockValue, 0, '.', ','),
        'totalSales'                  => number_format($totalSales, 0, '.', ','),
        'currentMonthSales'           => number_format($currentMonthSales, 0, '.', ','),
        'currentMonth'                => Carbon::now()->format('F'),
        'numberOfProductsSoldInMonth' => $numberOfProductsSoldInMonth,
        'todaysSales'                 => $invoices,
        'filtertime'                  => $filter,
        'fromdate'                    => $fromdate->format('Y-m-d'),
        'todate'                      => $todate->format('Y-m-d'),
        'totalRecords'                => $invoices->total(),
        'todaysPaymentBreakdown'      => $todaysPaymentBreakdown,
    ]);
})->name('dashboard');

// AJAX data source for the "How customers paid" period dropdown on the dashboard
// — deliberately re-derives the scoped invoice query rather than sharing a helper
// with the /dashboard route above: that route is a closure (not a controller), so
// there's no natural shared method to extract into without restructuring the
// whole file's style for one small query.
Route::middleware(['auth', 'permission:dashboard.view'])->get('/dashboard/payment-breakdown', function (Request $request) {
    $user = auth()->user();
    $scopedStoreLocation = null;

    if ($user && ! $user->hasRole('super-admin') && filled($user->storelocation)) {
        $scopedStoreLocation = strtolower(trim((string) $user->storelocation));
    }

    $invoiceBaseQuery = Invoice::query();

    if ($scopedStoreLocation !== null) {
        $invoiceBaseQuery->whereHas('items.purchase', function ($query) use ($scopedStoreLocation) {
            $query->where('storelocation', $scopedStoreLocation);
        });
    }

    $period = $request->input('period', 'today');

    $query = match ($period) {
        'yesterday' => (clone $invoiceBaseQuery)->whereDate('invoice_date', Carbon::yesterday()),
        'week'      => (clone $invoiceBaseQuery)->whereBetween('invoice_date', [Carbon::now()->subDays(7)->toDateString(), Carbon::now()->toDateString()]),
        'month'     => (clone $invoiceBaseQuery)->whereBetween('invoice_date', [Carbon::now()->startOfMonth()->toDateString(), Carbon::now()->toDateString()]),
        default     => (clone $invoiceBaseQuery)->whereDate('invoice_date', Carbon::today()),
    };

    // Built from invoice_payments rather than invoices.payment_type directly — see the
    // identical note on the /dashboard route above.
    $paymentTotals = $query
        ->where('deleted', 0)
        ->with('payments')
        ->get()
        ->flatMap(fn ($invoice) => $invoice->payments)
        ->groupBy(fn ($payment) => $payment->payment_method ?: 'Other')
        ->map(fn ($rows) => (float) $rows->sum('amount'))
        ->sortDesc();

    $total = (float) $paymentTotals->sum();

    $breakdown = $paymentTotals->map(function ($amount, $label) use ($total) {
        return [
            'label'   => $label,
            'amount'  => $amount,
            'percent' => $total > 0 ? round($amount / $total * 100, 1) : 0,
        ];
    })->values();

    return response()->json(['breakdown' => $breakdown]);
})->name('dashboard.payment-breakdown');

// Profile Routes
Route::middleware(['auth'])->group(function () {
    Route::get('/profile', [ProfileController::class, 'edit'])->middleware('permission:profile.view')->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->middleware('permission:profile.update')->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->middleware('permission:profile.update')->name('profile.destroy');
    Route::get('/admin/profile', [AdminController::class, 'profile'])->middleware('permission:profile.view')->name('admin.profile');
    Route::get('/admin/changepassword', [AdminController::class, 'changePassword'])->middleware('permission:profile.password.change')->name('admin.changepassword');
    Route::put('/admin/reset-password', [AdminController::class, 'newPassword'])->middleware('permission:profile.password.change')->name('reset-password');
    Route::post('/admin/storeprofile', [AdminController::class, 'updateProfile'])->middleware('permission:profile.update')->name('store.profile');
    Route::get('/admin/search', [GlobalSearchController::class, 'index'])->name('admin.search');
    Route::get('/admin/settings', [SettingsController::class, 'edit'])->middleware('role:super-admin')->name('admin.settings.edit');
    Route::put('/admin/settings', [SettingsController::class, 'update'])->middleware('role:super-admin')->name('admin.settings.update');
});

// AI Assistant
Route::middleware(['auth'])->prefix('admin/ai')->name('ai.')->group(function () {
    Route::get('/assistant', [AiAssistantController::class, 'index'])->name('index');
    Route::post('/assistant', [AiAssistantController::class, 'store'])->name('store');
});

// Purchases
Route::middleware(['auth'])->group(function () {
    Route::get('/admin/purchases', [PurchaseController::class, 'index'])->middleware('permission:purchases.view')->name('allpurchases');
    Route::get('/admin/purchase/add', [PurchaseController::class, 'newPurchase'])->middleware('permission:purchases.create')->name('purchase.create');
    Route::get('/admin/purchase/add-multiple', [PurchaseController::class, 'newMultiplePurchase'])->middleware('permission:purchases.create')->name('purchase.create.multiple');
    Route::post('/admin/purchase/add', [PurchaseController::class, 'savePurchase'])->middleware('permission:purchases.create')->name('purchase.store');
    Route::get('/admin/purchase/edit/{id}', [PurchaseController::class, 'editPurchase'])->middleware('permission:purchases.edit')->name('purchase.edit');
    Route::post('/admin/purchase/update/{id}', [PurchaseController::class, 'updatePurchase'])->middleware('permission:purchases.edit')->name('purchase.update');
    Route::delete('/admin/purchase/delete/{id}', [PurchaseController::class, 'deleteStock'])->middleware('permission:purchases.delete')->name('delete-stock');
    Route::get('/admin/purchase-detail/{id}', [PurchaseController::class, 'purchaseDetail'])->middleware('permission:purchases.view')->name('purchase-detail');
    Route::get('/admin/purchase-documents/{id}/file', [PurchaseController::class, 'viewDocument'])->middleware('permission:purchases.view')->name('purchase-document.file');
    Route::get('/admin/purchase/import', [PurchaseController::class, 'importStocks'])->middleware('permission:purchases.import')->name('purchase.importform');
    Route::post('/admin/purchase/importdata', [PurchaseController::class, 'importStocksData'])->middleware('permission:purchases.import')->name('purchase.import');
    Route::get('/admin/purchase/downloadstock', [PurchaseController::class, 'downloadStock'])->middleware('permission:purchases.download.stock')->name('purchase.downloadstock');
    Route::get('/admin/purchase/getparties', [PurchaseController::class, 'getParties'])->name('purchase.getchparties');
    Route::get('/admin/purchase/getcolors', [PurchaseController::class, 'getColors'])->name('purchase.getcolors');
    Route::get('/admin/purchase/getstorages', [PurchaseController::class, 'getStorages'])->name('purchase.getstorages');
    Route::get('/admin/purchase/checkimei', [PurchaseController::class, 'checkImei'])->name('purchase.checkimei');
});

// Sales
Route::middleware(['auth'])->group(function () {
    Route::get('/admin/sales', [SaleController::class, 'index'])->middleware('permission:sales.view')->name('allsales');
    Route::get('/admin/sales/edit/{id}', [SaleController::class, 'editSale'])->middleware('permission:sales.edit')->name('saleedit');
    Route::get('/admin/sales/{id}', [SaleController::class, 'saleDetail'])->middleware('permission:sales.view')->name('saledetail');
    Route::get('/admin/sale', [SaleController::class, 'newSale'])->middleware('permission:sales.create')->name('new-sale');
    Route::post('/admin/sale', [SaleController::class, 'saveSale'])->middleware('permission:sales.create')->name('save-sale');
    Route::delete('admin/sale/delete/{id}', [SaleController::class, 'deleteSale'])->middleware('permission:sales.delete')->name('delete-sale');
    Route::get('/admin/fetchstockdata/{id}', [SaleController::class, 'fetchModelData'])->middleware('permission:sales.fetch.stock')->name('fetchmodeldata');
    Route::get('/admin/fetchstockonimei/{imei}', [InvoiceController::class, 'fetchModelData'])->middleware('permission:sales.fetch.stock|invoices.create')->name('fetchmodeldata');
    Route::get('/admin/fetchbulkstock/{term}', [InvoiceController::class, 'fetchBulkStock'])->middleware('permission:sales.fetch.stock|invoices.create')->name('fetchbulkstock');
    Route::get('/admin/fetchcustomer/{contactNo}', [InvoiceController::class, 'fetchCustomerByContact'])->middleware('permission:invoices.create')->name('fetchcustomer');
});

// Invoices
Route::middleware(['auth'])->group(function () {
    Route::get('/admin/pos', [PosController::class, 'index'])->middleware('permission:invoices.create')->name('pos.index');
    Route::get('/admin/invoices', [InvoiceController::class, 'index'])->middleware('permission:invoices.view')->name('allinvoices');
    Route::get('/admin/invoice/add', [InvoiceController::class, 'newInvoice'])->middleware('permission:invoices.create')->name('newinvoice');
    Route::post('admin/invoice/create-invoice', [InvoiceController::class, 'createInvoice'])->middleware('permission:invoices.create')->name('create-invoice');
    Route::get('/admin/invoice/{id}', [InvoiceController::class, 'invoiceDetail'])->middleware('permission:invoices.detail')->name('invoice-detail');
    Route::get('/admin/invoice/print/{id}', [InvoiceController::class, 'printInvoice'])->middleware('permission:invoices.print')->name('print-invoice');
    Route::get('/admin/invoice/download-pdf/{id}', [InvoiceController::class, 'downloadPdf'])->middleware('permission:invoices.print')->name('download-pdf');
    Route::get('/admin/invoice/edit/{id}', [InvoiceController::class, 'editInvoice'])->middleware('permission:invoices.edit')->name('invoice-edit');
    Route::post('/admin/invoice/update/{id}', [InvoiceController::class, 'updateInvoice'])->middleware('permission:invoices.edit')->name('invoice-update');
    Route::post('/admin/invoice/delete/{id}', [InvoiceController::class, 'deleteInvoice'])->middleware('permission:invoices.delete')->name('invoice-delete');
    Route::post('/admin/invoice/{invoiceId}/document/{documentId}/delete', [InvoiceController::class, 'deleteDocument'])->middleware('permission:invoices.edit')->name('invoice-document-delete');
    Route::get('/admin/invoice/send-whatsapp/{id}', [InvoiceController::class, 'sendWhatsapp'])->name('send-whatsapp');

    // QR-code document upload handoff (desktop side — generate a session, then poll it)
    Route::post('/admin/document-uploads', [DocumentUploadController::class, 'create'])->middleware('permission:invoices.create')->name('document-uploads.create');
    Route::get('/admin/document-uploads/{token}/status', [DocumentUploadController::class, 'status'])->middleware('permission:invoices.create')->name('document-uploads.status');

    // Unified Documents view — Invoice documents + Purchase documents in one tabbed screen
    Route::get('/admin/documents', [DocumentController::class, 'index'])->middleware('permission:invoices.view|purchases.view')->name('documents.index');
    Route::get('/admin/documents/invoice', [DocumentController::class, 'invoiceDocuments'])->middleware('permission:invoices.view')->name('documents.invoice');
    Route::get('/admin/documents/purchase', [DocumentController::class, 'purchaseDocuments'])->middleware('permission:purchases.view')->name('documents.purchase');
});

// QR-code document upload handoff (phone side — no auth, reachable only with the token)
Route::get('/doc-upload/{token}', [DocumentUploadController::class, 'showUploadForm'])->name('doc-upload.show');
Route::post('/doc-upload/{token}', [DocumentUploadController::class, 'submitUpload'])->name('doc-upload.store');

// Sale Returns
Route::middleware(['auth'])->prefix('admin/sale-returns')->name('sale-returns.')->group(function () {
    Route::get('/', [SaleReturnController::class, 'index'])->middleware('permission:returns.view')->name('index');
    Route::post('/', [SaleReturnController::class, 'store'])->middleware('permission:returns.create')->name('store');
    Route::post('/{id}/void', [SaleReturnController::class, 'destroy'])->middleware('permission:returns.delete')->name('destroy');
});

// Repairs
Route::middleware(['auth'])->prefix('admin/repairs')->name('repairs.')->group(function () {
    Route::get('/', [RepairController::class, 'index'])->middleware('permission:repairs.view')->name('index');
    Route::post('/', [RepairController::class, 'store'])->middleware('permission:repairs.create')->name('store');
    Route::get('/{id}/edit', [RepairController::class, 'edit'])->middleware('permission:repairs.edit')->name('edit');
    Route::post('/{id}', [RepairController::class, 'update'])->middleware('permission:repairs.edit')->name('update');
    Route::delete('/{id}', [RepairController::class, 'destroy'])->middleware('permission:repairs.delete')->name('destroy');
    Route::post('/{id}/bill', [RepairController::class, 'bill'])->middleware('permission:repairs.edit')->name('bill');
});

// Public Routes
Route::get('/public/invoice/pdf/{id}', [InvoiceController::class, 'publicPdf'])->name('public-invoice-pdf')->middleware('signed');

// Reports
Route::middleware(['auth'])->group(function () {
    Route::get('/admin/reports/finance', [ReportController::class, 'financeReport'])->middleware('permission:reports.sales.view')->name('finance-report');
    Route::get('/admin/reports/finance/export/csv', [ReportController::class, 'exportFinanceReportCsv'])->middleware('permission:reports.sales.export')->name('finance-report-export-csv');
    Route::get('/admin/reports/finance/export/pdf', [ReportController::class, 'exportFinanceReportPdf'])->middleware('permission:reports.sales.export')->name('finance-report-export-pdf');
    Route::get('/admin/reports/sales', [ReportController::class, 'sale'])->middleware('permission:reports.sales.view')->name('sale-report');
    Route::get('/admin/reports/profit-loss', [ReportController::class, 'profitLoss'])->middleware('permission:reports.sales.view')->name('profit-loss');
    Route::get('/admin/reports/daily-closing', [ReportController::class, 'dailyClosing'])->middleware('permission:reports.sales.view')->name('daily-closing');
    Route::get('/admin/reports/excel', [ReportController::class, 'downloadExcel'])->middleware('permission:reports.sales.export')->name('sale-export');
    Route::get('/admin/reports/sales/pdf', [ReportController::class, 'downloadSalesPdf'])->middleware('permission:reports.sales.export')->name('sale-export-pdf');
    Route::get('/admin/reports/buyexcel', [ReportController::class, 'downloadPurchaseExcel'])->middleware('permission:reports.purchases.export')->name('buy-export');
    Route::get('/admin/reports/purchasereport', [ReportController::class, 'downloadPurchaseReport'])->middleware('permission:reports.purchases.view')->name('purchase-report');
    Route::get('/admin/reports/purchasereport/pdf', [ReportController::class, 'downloadPurchasePdf'])->middleware('permission:reports.purchases.export')->name('purchase-report-pdf');
    Route::get('/admin/reports/supplier-ledger', [ReportController::class, 'supplierLedger'])->middleware('permission:reports.purchases.view')->name('supplier-ledger');
    Route::get('/admin/reports/supplier-ledger/view', [ReportController::class, 'supplierLedgerDetail'])->middleware('permission:reports.purchases.view')->name('supplier-ledger-detail');
    Route::get('/admin/reports/salescharts', [ReportController::class, 'displayCharts'])->middleware('permission:reports.charts.view')->name('saleschart');
    Route::get('/admin/reports/customers', [ReportController::class, 'customers'])->middleware('permission:reports.customers.view')->name('customers');
    Route::get('/admin/reports/customers/{id}/documents', [ReportController::class, 'customerDocuments'])->middleware('permission:reports.customers.view')->name('customer-documents');
    Route::get('/admin/customer-documents/{id}/file', [ReportController::class, 'viewCustomerDocument'])->middleware('permission:reports.customers.view')->name('customer-document.file');
    Route::get('/admin/reports/exportcustomers', [ReportController::class, 'exportcustomers'])->middleware('permission:reports.customers.export')->name('exportcustomers');
});

// Expenses
Route::middleware(['auth'])->group(function () {
    Route::get('/admin/expenses', [ExpenseController::class, 'index'])->middleware('permission:expenses.view')->name('expenses');
    Route::get('/admin/expenses/add', [ExpenseController::class, 'addExpense'])->middleware('permission:expenses.create')->name('add-expense');
    Route::post('/admin/expenses/save-expense', [ExpenseController::class, 'saveExpense'])->middleware('permission:expenses.create')->name('save-expense');
    Route::get('/admin/expenses/edit/{id}', [ExpenseController::class, 'editExpense'])->middleware('permission:expenses.edit')->name('edit-expense');
    Route::post('/admin/expenses/update/{id}', [ExpenseController::class, 'updateExpense'])->middleware('permission:expenses.edit')->name('expenseedit');
    Route::delete('/admin/expenses/delete/{id}', [ExpenseController::class, 'deleteExpense'])->middleware('permission:expenses.delete')->name('delete-expense');
});

// Expense Categories
Route::middleware(['auth'])->prefix('admin/expense-categories')->name('expense-categories.')->group(function () {
    Route::get('/', [ExpenseCategoryController::class, 'index'])->middleware('permission:expense-categories.view')->name('index');
    Route::post('/', [ExpenseCategoryController::class, 'store'])->middleware('permission:expense-categories.create|expense-categories.edit')->name('store');
    Route::delete('/{id}', [ExpenseCategoryController::class, 'destroy'])->middleware('permission:expense-categories.delete')->name('destroy');
});

// Transactions
Route::middleware(['auth'])->prefix('admin/transactions')->name('transactions.')->group(function () {
    Route::get('/', [TransactionController::class, 'index'])->middleware('permission:transactions.view')->name('index');
    Route::post('/store', [TransactionController::class, 'store'])->middleware('permission:transactions.create')->name('store');
    Route::delete('/delete/{id}', [TransactionController::class, 'delete'])->middleware('permission:transactions.delete')->name('destroy');
    Route::get('/edit/{id}', [TransactionController::class, 'edit'])->middleware('permission:transactions.edit')->name('edit');
    Route::get('/resync', [TransactionController::class, 'resyncBalances'])->middleware('permission:transactions.resync')->name('resync');
});

// Party
Route::middleware(['auth'])->prefix('admin/parties')->name('parties.')->group(function () {
    Route::get('/', [PartyController::class, 'index'])->middleware('permission:parties.view')->name('listparties');
    Route::get('/suppliers', [PartyController::class, 'suppliers'])->middleware('permission:parties.view')->name('suppliers');
    Route::get('/add', [PartyController::class, 'addParty'])->middleware('permission:parties.create')->name('create');
    // Was also named 'create' (a duplicate — Laravel's route() name lookup
    // then silently resolved to whichever was registered last, i.e. this one,
    // not /add). Nothing in the app referenced 'parties.create' expecting the
    // add-party page, so this was a dormant bug; renamed since it's free to fix
    // while this route block is already being touched.
    Route::get('/partydetail/{id}', [PartyController::class, 'detailParty'])->middleware('permission:parties.viewdetail')->name('detail');
    Route::get('/edit/{id}', [PartyController::class, 'editParty'])->middleware('permission:parties.edit')->name('edit');
    Route::post('/store', [PartyController::class, 'saveParty'])->middleware('permission:parties.store')->name('store');
    Route::post('/delete/{id}', [PartyController::class, 'deleteParty'])->middleware('permission:parties.delete')->name('delete');
});

// Google Contacts
Route::get('/google/redirect', [GoogleContactController::class, 'redirectToGoogle'])->middleware(['auth'])->name('google.redirect');
Route::get('/google-callback', [GoogleContactController::class, 'handleGoogleCallback'])->middleware(['auth'])->name('google.callback');
Route::post('/sync-contact', [GoogleContactController::class, 'syncContact'])->middleware(['auth', 'permission:google.sync'])->name('sync.contact');

// Roles & Users
Route::middleware(['auth'])->group(function () {
    Route::resource('roles', RoleController::class)->except(['show'])->middleware('permission:roles.view');
    Route::post('/roles', [RoleController::class, 'store'])->middleware('permission:roles.create')->name('roles.store');

    Route::resource('users', UserController::class)->except(['show'])->middleware('permission:users.view');
    Route::post('/users', [UserController::class, 'store'])->middleware('permission:users.create')->name('users.store');
});

// Ledger Module Routes
Route::middleware(['auth'])->prefix('admin/ledger')->name('ledger.')->group(function () {
    // Ledger Entries
    Route::get('/', [LedgerEntryController::class, 'index'])->middleware('permission:ledger.view')->name('index');
    Route::get('/create', [LedgerEntryController::class, 'create'])->middleware('permission:ledger.create')->name('create');
    Route::post('/store', [LedgerEntryController::class, 'store'])->middleware('permission:ledger.create')->name('store');
    Route::get('/{entry}/show', [LedgerEntryController::class, 'show'])->middleware('permission:ledger.view')->name('show');
    Route::get('/{entry}/edit', [LedgerEntryController::class, 'edit'])->middleware('permission:ledger.edit')->name('edit');
    Route::put('/{entry}', [LedgerEntryController::class, 'update'])->middleware('permission:ledger.edit')->name('update');
    Route::delete('/{entry}', [LedgerEntryController::class, 'destroy'])->middleware('permission:ledger.delete')->name('destroy');
    Route::post('/{entry}/reconcile', [LedgerEntryController::class, 'reconcile'])->middleware('permission:ledger.reconcile')->name('reconcile');
});
