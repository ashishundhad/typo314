<?php

// Route registration for this app now happens in bootstrap/app.php's `then`
// closure, not here — registration ORDER between the tenant-scoped and legacy
// domain-pinned copies of these routes is load-bearing for named-route
// resolution (see the comment there), which required moving it out of the
// separate web.php/api.php/tenant.php auto-load mechanisms. The actual route
// definitions live in routes/app-web.php.
