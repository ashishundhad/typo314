<?php

use App\Http\Controllers\Central\Auth\LoginController;
use App\Http\Controllers\Central\PaymentController;
use App\Http\Controllers\Central\PlanController;
use App\Http\Controllers\Central\PublicSignupController;
use App\Http\Controllers\Central\SubscriptionController;
use App\Http\Controllers\Central\TenantController;
use Illuminate\Support\Facades\Route;

// Constrained to an actual Route::domain() (not just middleware) so these paths
// never collide with routes/web.php's identical paths (e.g. /login) on other hosts —
// the router picks by domain match, not registration order.
$centralDomainPattern = implode('|', array_map(
    fn (string $domain) => preg_quote($domain, '#'),
    config('tenancy.central_domains', [])
));

Route::domain('{central_domain}')
    ->where(['central_domain' => $centralDomainPattern])
    ->middleware('central.domain')
    ->name('central.')
    ->group(function () {
        // Public marketing page — the SaaS product's own homepage, not gated
        // behind central-admin auth. Operator sign-in lives at /login below,
        // linked from the admin's own bookmarks/muscle memory rather than
        // surfaced to prospective customers here — the page's own signup CTAs
        // point at /signup instead.
        Route::get('/', fn () => response()->file(public_path('landing.html')))->name('landing');

        // Public self-service signup: a prospective shop owner picks a plan and
        // gets a brand new tenant provisioned immediately on that plan's free
        // trial (see PublicSignupController / TenantService::provision()). No
        // central-admin approval step. Throttled since it's unauthenticated and
        // provisions real resources (a database, a domain) per submission.
        Route::middleware('throttle:6,1')->group(function () {
            Route::get('/signup', [PublicSignupController::class, 'create'])->name('signup');
            Route::post('/signup', [PublicSignupController::class, 'store'])->name('signup.store');
        });

        Route::middleware('guest:central_admin')->group(function () {
            Route::get('/login', [LoginController::class, 'create'])->name('login');
            Route::post('/login', [LoginController::class, 'store'])->name('login.store');
        });

        Route::middleware('auth:central_admin')->group(function () {
            Route::post('/logout', [LoginController::class, 'destroy'])->name('logout');

            Route::get('/tenants', [TenantController::class, 'index'])->name('tenants.index');
            Route::get('/tenants/create', [TenantController::class, 'create'])->name('tenants.create');
            Route::post('/tenants', [TenantController::class, 'store'])->name('tenants.store');
            Route::get('/tenants/{tenant}', [TenantController::class, 'show'])->name('tenants.show');
            Route::post('/tenants/{tenant}/suspend', [TenantController::class, 'suspend'])->name('tenants.suspend');
            Route::post('/tenants/{tenant}/reactivate', [TenantController::class, 'reactivate'])->name('tenants.reactivate');
            Route::post('/tenants/{tenant}/record-payment', [TenantController::class, 'recordPayment'])->name('tenants.record-payment');
            Route::post('/tenants/{tenant}/retry-provisioning', [TenantController::class, 'retryProvisioning'])->name('tenants.retry-provisioning');

            Route::get('/plan', [PlanController::class, 'edit'])->name('plan.edit');
            Route::put('/plan/{plan}', [PlanController::class, 'update'])->name('plan.update');

            Route::get('/subscriptions', [SubscriptionController::class, 'index'])->name('subscriptions.index');
            Route::put('/subscriptions/{subscription}', [SubscriptionController::class, 'update'])->name('subscriptions.update');

            Route::get('/payments', [PaymentController::class, 'index'])->name('payments.index');
        });
    });
