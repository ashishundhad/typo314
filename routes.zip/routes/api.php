<?php

// Route registration for this app now happens in bootstrap/app.php's `then`
// closure, not here — see routes/web.php and bootstrap/app.php for why. The
// actual route definitions live in routes/app-api.php.
