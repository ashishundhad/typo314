<?php

use Illuminate\Foundation\Inspiring;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\Schedule;

Artisan::command('inspire', function () {
    $this->comment(Inspiring::quote());
})->purpose('Display an inspiring quote');

Schedule::command('pdfs:delete')->everyMinute();
// Actual access enforcement is real-time (Subscription::hasAccess() checks the
// expiry timestamp directly, not this job's output — see EnsureSubscriptionActive).
// This just keeps tenants.status/subscriptions.status fresh for the admin UI
// (badges, filters) without a day-long lag.
Schedule::command('subscriptions:expire')->hourly();
