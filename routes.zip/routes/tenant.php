<?php

// Stancl's TenancyServiceProvider auto-loads this file (if present) via a
// deferred app->booted() callback, which always fires after every other
// provider has booted — too late to control named-route registration order
// against the legacy domain-pinned copy (see bootstrap/app.php's `then`
// closure for why that order matters). So tenant-scoped routing is registered
// explicitly there instead, at the right point in the sequence, and this file
// is deliberately left empty.
