<?php $__env->startSection('title', 'Repairs'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid repair-shell">
        <div class="repair-hero">
            <div class="row align-items-center">
                <div class="col-lg-8">
                    <h1 class="repair-hero__title mb-0">Repairs</h1>
                    <!-- <p class="repair-hero__subtitle">Track devices in for service and bill the repair once it's delivered.</p> -->
                </div>
                <div class="col-lg-4 text-lg-right">
                    <div class="repair-hero__badge mt-3 mt-lg-0">
                        <i class="mdi mdi-cash-multiple"></i>
                        <!-- <span><?php echo e(config('constant.currency')); ?><?php echo e(number_format($totalProfit, 2)); ?> total repair profit</span> -->
                    </div>
                </div>
            </div>
        </div>

        <?php echo $__env->make('include.alert', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        <div class="row">
            <div class="col-md-6 col-lg-4 col-xl">
                <div class="card repair-metric mb-1">
                    <div class="card-body">
                        <div class="repair-metric__label">Total Repairs</div>
                        <div class="repair-metric__value"><?php echo e(number_format($totalRepairs)); ?></div>
                    </div>
                </div>
            </div>
            <div class="col-md-6 col-lg-4 col-xl">
                <div class="card repair-metric mb-1">
                    <div class="card-body">
                        <div class="repair-metric__label">Received</div>
                        <div class="repair-metric__value"><?php echo e(number_format($receivedCount)); ?></div>
                    </div>
                </div>
            </div>
            <div class="col-md-6 col-lg-4 col-xl ">
                <div class="card repair-metric mb-1">
                    <div class="card-body">
                        <div class="repair-metric__label">Repairing</div>
                        <div class="repair-metric__value"><?php echo e(number_format($repairingCount)); ?></div>
                    </div>
                </div>
            </div>
            <div class="col-md-6 col-lg-4 col-xl ">
                <div class="card repair-metric mb-1">
                    <div class="card-body">
                        <div class="repair-metric__label">Delivered</div>
                        <div class="repair-metric__value"><?php echo e(number_format($deliveredCount)); ?></div>
                    </div>
                </div>
            </div>
            <div class="col-md-6 col-lg-4 col-xl ">
                <div class="card repair-metric mb-1">
                    <div class="card-body">
                        <div class="repair-metric__label">Total Profit</div>
                        <div class="repair-metric__value <?php echo e($totalProfit < 0 ? 'repair-metric__value--negative' : 'repair-metric__value--positive'); ?>">
                            <?php echo e(config('constant.currency')); ?><?php echo e(number_format($totalProfit, 2)); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="card repair-section">
            <div class="card-body">
                <div class="repair-section__top">
                    <h2 class="repair-section__title mb-0">All Repair Jobs</h2>

                    <div class="repair-section__actions">
                        <div class="btn-group">
                            <button type="button" class="btn btn-outline-secondary repair-btn dropdown-toggle"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="mdi mdi-file-download-outline mr-1"></i>Export
                            </button>
                            <div class="dropdown-menu dropdown-menu-right mt-2">
                                <a class="dropdown-item" href="<?php echo e(request()->fullUrlWithQuery(['download' => 'csv'])); ?>">
                                    <i class="mdi mdi-file-delimited-outline mr-1"></i>Download CSV
                                </a>
                                <a class="dropdown-item" href="<?php echo e(request()->fullUrlWithQuery(['download' => 'pdf'])); ?>">
                                    <i class="mdi mdi-file-pdf-box mr-1"></i>Download PDF
                                </a>
                            </div>
                        </div>

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('repairs.create')): ?>
                            <button type="button" class="btn btn-primary repair-btn" data-toggle="modal" data-target="#repairModal">
                                <i class="mdi mdi-plus-circle-outline mr-1"></i>Add Repair
                            </button>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="repair-filter">
                    <form method="GET" action="<?php echo e(route('repairs.index')); ?>" id="repairFilterForm">
                        <div class="form-row align-items-end">
                            <div class="col-12 col-md-3 mb-3">
                                <label class="repair-filter__label" for="repair-search">Search</label>
                                <input type="text" id="repair-search" name="search" class="form-control"
                                    value="<?php echo e($search); ?>" placeholder="Customer name or issue">
                            </div>
                            <div class="col-6 col-md-2 mb-3">
                                <label class="repair-filter__label" for="repair-status">Status</label>
                                <select name="status" id="repair-status" class="form-control">
                                    <option value="" <?php if($status === ''): echo 'selected'; endif; ?>>All</option>
                                    <option value="received" <?php if($status === 'received'): echo 'selected'; endif; ?>>Received</option>
                                    <option value="repairing" <?php if($status === 'repairing'): echo 'selected'; endif; ?>>Repairing</option>
                                    <option value="delivered" <?php if($status === 'delivered'): echo 'selected'; endif; ?>>Delivered</option>
                                </select>
                            </div>
                            <div class="col-6 col-md-2 mb-3">
                                <label class="repair-filter__label" for="repair-period">Report Period</label>
                                <select name="period" id="repair-period" class="form-control">
                                    <option value="alls" <?php if($period === 'alls'): echo 'selected'; endif; ?>>All Time</option>
                                    <option value="thismonth" <?php if($period === 'thismonth'): echo 'selected'; endif; ?>>This Month</option>
                                    <option value="lastmonth" <?php if($period === 'lastmonth'): echo 'selected'; endif; ?>>Last Month</option>
                                    <option value="thisyear" <?php if($period === 'thisyear'): echo 'selected'; endif; ?>>This Year</option>
                                    <option value="lastyear" <?php if($period === 'lastyear'): echo 'selected'; endif; ?>>Last Year</option>
                                    <option value="custom" <?php if($period === 'custom'): echo 'selected'; endif; ?>>Custom Range</option>
                                </select>
                            </div>
                            <div class="col-6 col-md-2 mb-3 repair-filter__date-group <?php if($period === 'custom'): ?> d-block <?php endif; ?>">
                                <label class="repair-filter__label" for="repair-fromdate">From Date</label>
                                <input type="date" id="repair-fromdate" name="fromdate" class="form-control" value="<?php echo e($fromdate); ?>">
                            </div>
                            <div class="col-6 col-md-2 mb-3 repair-filter__date-group <?php if($period === 'custom'): ?> d-block <?php endif; ?>">
                                <label class="repair-filter__label" for="repair-todate">To Date</label>
                                <input type="date" id="repair-todate" name="todate" class="form-control" value="<?php echo e($todate); ?>">
                            </div>
                            <div class="col-6 col-md-2 mb-3">
                                <button type="submit" class="btn btn-primary repair-btn btn-block">
                                    <i class="mdi mdi-magnify"></i> Filter
                                </button>
                            </div>
                            <div class="col-6 col-md-2 mb-3">
                                <a href="<?php echo e(route('repairs.index')); ?>" class="btn btn-outline-danger repair-btn btn-block">Clear</a>
                            </div>
                        </div>
                    </form>
                </div>

                <div class="table-responsive">
                    <?php if($repairs->count()): ?>
                        <table class="table repair-table">
                            <thead>
                                <tr>
                                    <th>Customer</th>
                                    <th>Issue</th>
                                    <th>Repair Date</th>
                                    <th class="align-right">Parts Cost</th>
                                    <th class="align-right">Repair Fee</th>
                                    <th class="align-right">Profit</th>
                                    <th>Status</th>
                                    <th class="text-center">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $repairs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $repair): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($repair->customer_name ?: 'Walk-in Customer'); ?></td>
                                        <td><?php echo e(\Illuminate\Support\Str::limit($repair->issue_description, 60) ?: '-'); ?></td>
                                        <td><?php echo e($repair->repair_date ? $repair->repair_date->format('d M Y') : '-'); ?></td>
                                        <td class="align-right"><?php echo e(config('constant.currency')); ?><?php echo e(number_format((float) $repair->parts_cost, 2)); ?></td>
                                        <td class="align-right"><?php echo e(config('constant.currency')); ?><?php echo e(number_format((float) $repair->repair_fee, 2)); ?></td>
                                        <td class="align-right repair-profit <?php echo e($repair->profit < 0 ? 'repair-profit--negative' : ''); ?>">
                                            <?php echo e(config('constant.currency')); ?><?php echo e(number_format($repair->profit, 2)); ?>

                                        </td>
                                        <td>
                                            <span class="repair-status repair-status--<?php echo e($repair->status); ?>"><?php echo e($repair->status_label); ?></span>
                                        </td>
                                        <td class="text-center">
                                            <div class="repair-actions">
                                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('repairs.edit')): ?>
                                                    <button type="button" class="btn btn-primary btn-sm js-edit-repair" title="Edit"
                                                        data-id="<?php echo e($repair->id); ?>"
                                                        data-customer_name="<?php echo e($repair->customer_name); ?>"
                                                        data-issue_description="<?php echo e($repair->issue_description); ?>"
                                                        data-repair_date="<?php echo e($repair->repair_date ? $repair->repair_date->format('Y-m-d') : ''); ?>"
                                                        data-parts_cost="<?php echo e($repair->parts_cost); ?>"
                                                        data-repair_fee="<?php echo e($repair->repair_fee); ?>"
                                                        data-status="<?php echo e($repair->status); ?>">
                                                        <i class="mdi mdi-square-edit-outline"></i>
                                                    </button>
                                                <?php endif; ?>

                                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('repairs.edit')): ?>
                                                    <?php if($repair->isBilled()): ?>
                                                        <a href="<?php echo e(route('print-invoice', $repair->invoice_id)); ?>" class="btn btn-success btn-sm" title="View Invoice" target="_blank">
                                                            <i class="mdi mdi-receipt"></i>
                                                        </a>
                                                    <?php else: ?>
                                                        <button type="button" class="btn btn-outline-success btn-sm js-bill-repair" title="Generate Invoice"
                                                            data-id="<?php echo e($repair->id); ?>"
                                                            data-fee="<?php echo e(number_format((float) $repair->repair_fee, 2)); ?>"
                                                            <?php echo e((float) $repair->repair_fee <= 0 ? 'disabled' : ''); ?>>
                                                            <i class="mdi mdi-cash-register"></i>
                                                        </button>
                                                    <?php endif; ?>
                                                <?php endif; ?>

                                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('repairs.delete')): ?>
                                                    <form method="POST" action="<?php echo e(route('repairs.destroy', $repair->id)); ?>" class="d-inline">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('DELETE'); ?>
                                                        <button type="submit" class="btn btn-danger btn-sm" title="Delete" onclick="sureToDelete(event)">
                                                            <i class="fas fa-trash"></i>
                                                        </button>
                                                    </form>
                                                <?php endif; ?>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>

                        <div class="mt-3">
                            <?php echo e($repairs->appends(request()->query())->links('vendor.pagination.bootstrap-5')); ?>

                        </div>
                    <?php else: ?>
                        <div class="repair-empty">
                            <div class="repair-empty__icon">
                                <i class="mdi mdi-wrench-outline"></i>
                            </div>
                            <h4 class="mb-2">No repair jobs found</h4>
                            <p class="text-muted mb-0">Add a repair job to start tracking it here.</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="repairModal" tabindex="-1" role="dialog" aria-labelledby="repairModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="repairModalLabel">Add Repair</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form method="POST" action="<?php echo e(route('repairs.store')); ?>" id="repairForm">
                    <?php echo csrf_field(); ?>
                    <div class="modal-body">
                        <div class="form-group">
                            <label for="repair_customer_name">Customer Name</label>
                            <input type="text" class="form-control" id="repair_customer_name" name="customer_name" placeholder="Customer Name">
                        </div>
                        <div class="form-group">
                            <label for="repair_issue_description">Issue Description</label>
                            <textarea class="form-control" id="repair_issue_description" name="issue_description" rows="3" placeholder="Description"></textarea>
                        </div>
                        <div class="form-row">
                            <div class="form-group col-md-6">
                                <label for="repair_date">Repair Date</label>
                                <input type="date" class="form-control" id="repair_date" name="repair_date">
                            </div>
                            <div class="form-group col-md-6">
                                <label for="repair_status">Status</label>
                                <select class="form-control" id="repair_status" name="status">
                                    <option value="received">Received</option>
                                    <option value="repairing">Repairing</option>
                                    <option value="delivered">Delivered</option>
                                </select>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group col-md-6">
                                <label for="repair_parts_cost">Parts Cost</label>
                                <input type="number" class="form-control" id="repair_parts_cost" name="parts_cost" min="0" step="0.01" placeholder="0.00">
                            </div>
                            <div class="form-group col-md-6">
                                <label for="repair_fee">Repair Fee</label>
                                <input type="number" class="form-control" id="repair_fee" name="repair_fee" min="0" step="0.01" placeholder="0.00">
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-light" data-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary repair-modal-submit">Save Repair</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <div class="modal fade" id="billRepairModal" tabindex="-1" role="dialog" aria-labelledby="billRepairModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="billRepairModalLabel">Generate Invoice</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form method="POST" action="" id="billRepairForm">
                    <?php echo csrf_field(); ?>
                    <div class="modal-body">
                        <p class="mb-3">This will create an invoice for <strong id="billRepairFee"></strong> and mark this repair as delivered.</p>
                        <div class="form-group mb-0">
                            <label for="bill_payment_type">Payment Mode <span class="text-danger">*</span></label>
                            <select class="form-control" id="bill_payment_type" name="payment_type" required>
                                <option value="">Select</option>
                                <option value="Cash">Cash</option>
                                <option value="Online">Online/UPI</option>
                                <option value="Credit Card">Credit Card</option>
                            </select>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-light" data-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-success">Generate Invoice</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        $(document).ready(function () {
            const periodSelect = document.getElementById('repair-period');
            const dateGroups = document.querySelectorAll('.repair-filter__date-group');

            function toggleDateGroups() {
                const showDates = periodSelect && periodSelect.value === 'custom';

                dateGroups.forEach(function (group) {
                    group.style.display = showDates ? 'block' : 'none';
                });
            }

            if (periodSelect) {
                periodSelect.addEventListener('change', toggleDateGroups);
                toggleDateGroups();
            }

            const $repairForm = $('#repairForm');
            const $repairModalLabel = $('#repairModalLabel');
            const $repairModalSubmit = $('.repair-modal-submit');

            function resetRepairForm() {
                $repairForm[0].reset();
                $repairForm.attr('action', "<?php echo e(route('repairs.store')); ?>");
                $repairModalLabel.text('Add Repair');
                $repairModalSubmit.text('Save Repair');
            }

            $('#repairModal').on('hidden.bs.modal', resetRepairForm);

            $(document).on('click', '.js-edit-repair', function () {
                const $btn = $(this);
                const id = $btn.data('id');

                $repairForm.attr('action', "<?php echo e(url('/admin/repairs')); ?>/" + id);
                $repairModalLabel.text('Edit Repair');
                $repairModalSubmit.text('Update Repair');

                $('#repair_customer_name').val($btn.data('customer_name'));
                $('#repair_issue_description').val($btn.data('issue_description'));
                $('#repair_date').val($btn.data('repair_date'));
                $('#repair_parts_cost').val($btn.data('parts_cost'));
                $('#repair_fee').val($btn.data('repair_fee'));
                $('#repair_status').val($btn.data('status'));

                $('#repairModal').modal('show');
            });

            $(document).on('click', '.js-bill-repair', function () {
                const id = $(this).data('id');
                const fee = $(this).data('fee');

                $('#billRepairForm').attr('action', "<?php echo e(url('/admin/repairs')); ?>/" + id + '/bill');
                $('#billRepairFee').text('<?php echo e(config('constant.currency')); ?>' + fee);
                $('#bill_payment_type').val('');
                $('#billRepairModal').modal('show');
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/html/resources/views/repairs/index.blade.php ENDPATH**/ ?>