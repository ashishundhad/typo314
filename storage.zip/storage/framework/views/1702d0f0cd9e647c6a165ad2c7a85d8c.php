<?php $__env->startSection('title'); ?>
    Invoice #<?php echo e($invoice->invoice_no); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-container">
        <div class="invoice-print-wrap">
            <div class="invoice-admin-actions no-print">
                <div class="invoice-admin-actions__group">
                    <button type="button" class="invoice-admin-actions__btn invoice-admin-actions__btn--back" onclick="window.history.back()">
                        <i class="mdi mdi-arrow-left"></i>
                        <span>Back</span>
                    </button>
                </div>

                <div class="invoice-admin-actions__group">
                    <button type="button" class="invoice-admin-actions__btn invoice-admin-actions__btn--print" onclick="window.print()">
                        <i class="mdi mdi-printer"></i>
                        <span>Print</span>
                    </button>

                    <a href="<?php echo e(route('download-pdf', $invoice->id)); ?>" class="invoice-admin-actions__btn invoice-admin-actions__btn--pdf">
                        <i class="mdi mdi-file-pdf-box"></i>
                        <span>Download</span>
                    </a>

                    <?php if($invoice->customer_no): ?>
                        <a href="<?php echo e(route('send-whatsapp', ['id' => $invoice->id])); ?>" target="_blank" class="invoice-admin-actions__btn invoice-admin-actions__btn--wa">
                            <i class="mdi mdi-whatsapp"></i>
                            <span>WhatsApp</span>
                        </a>
                    <?php endif; ?>
                </div>
            </div>

            <?php echo $__env->make('invoice._document', ['invoice' => $invoice, 'amountInWords' => $amountInWords], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/html/resources/views/invoice/print.blade.php ENDPATH**/ ?>