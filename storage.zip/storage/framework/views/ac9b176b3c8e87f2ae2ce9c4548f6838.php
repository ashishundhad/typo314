<?php $__env->startSection('title'); ?>
    Customers
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid customers-page">
    <div class="customers-topbar">
        <div>
            <h1 class="customers-topbar__title">Customers</h1>
            <p class="customers-topbar__subtitle">Everyone who has bought from you, with a quick way to reach them.</p>
        </div>
        <div class="customers-topbar__actions">
            <!-- <div class="customers-mini-stat">
                <div class="customers-mini-stat__label">Total</div>
                <div class="customers-mini-stat__value"><?php echo e($totalcustomers); ?></div>
            </div> -->
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('reports.customers.export')): ?>
                <a href="<?php echo e(route('exportcustomers')); ?>" class="expenses-link-btn">
                    <i class="mdi mdi-file-excel-box"></i> Export CSV
                </a>
            <?php endif; ?>
        </div>
    </div>

    <div class="sales-card">
        <div class="sales-card__header">
            <div>
                <h4 class="sales-card__title">Customer Register</h4>
                <!-- <p class="sales-card__subtitle">Search by name or phone number.</p> -->
            </div>
        </div>

        <form action="<?php echo e(route('customers')); ?>" method="GET" id="filtercustomers" class="sales-filter-form">
            <div class="form-row align-items-end">
                <div class="form-group col-md-6 mb-0">
                    <div class="sales-search-group">
                        <input type="text" class="form-control" placeholder="Search by name or phone.." name="search"
                            value="<?php echo e($search ?? request()->input('search')); ?>" id="searchcustomers">
                        <button class="btn btn-primary customer-search" type="submit">
                            <i class="mdi mdi-magnify"></i> Search
                        </button>
                        <input class="btn btn-danger customer-search" type="reset" value="X" onclick="window.location='<?php echo e(route('customers')); ?>'">
                    </div>
                </div>
            </div>
        </form>

        <?php if(count($customers)): ?>
            <div class="table-responsive sales-table-wrap">
                <table class="table sales-table table-hover m-0">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Customer Name</th>
                            <th>Phone Number</th>
                            <th class="text-right">Invoices</th>
                            <th class="text-center">Documents</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="sales-index">#<?php echo e($customers->firstItem() + $index); ?></td>
                                <td class="sales-customer__name"><?php echo e($customer->name); ?></td>
                                <td>
                                    <?php if($customer->phone): ?>
                                        <a href="tel:<?php echo e($customer->phone); ?>"><?php echo e($customer->phone); ?></a>
                                    <?php else: ?>
                                        <span class="text-muted">No contact number</span>
                                    <?php endif; ?>
                                </td>
                                <td class="text-right"><?php echo e($customer->invoices_count); ?></td>
                                <td class="text-center">
                                    <?php if($customer->documents_count > 0): ?>
                                        <button type="button" class="btn btn-sm btn-primary js-customer-documents"
                                            data-id="<?php echo e($customer->id); ?>" data-name="<?php echo e($customer->name); ?>">
                                            View (<?php echo e($customer->documents_count); ?>)
                                        </button>
                                    <?php else: ?>
                                        <span class="text-muted">No documents</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>

            <div class="pagination-links px-3 pb-3">
                <?php echo e($customers->links('vendor.pagination.bootstrap-5')); ?>

            </div>
        <?php else: ?>
            <div class="sales-empty">
                <div class="sales-empty__icon">
                    <i class="mdi mdi-account-search-outline"></i>
                </div>
                <h4>No customers found</h4>
                <p>Try a different search, or check back once your first invoice is created.</p>
            </div>
        <?php endif; ?>
    </div>
</div>

<div class="modal fade" id="customerDocumentsModal" tabindex="-1" role="dialog"
    aria-labelledby="customerDocumentsModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="customerDocumentsModalLabel">Customer Documents</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div id="customerDocumentsModalContent">
                    <div class="supplier-ledger-modal__state">
                        <i class="mdi mdi-card-account-details-outline"></i>Loading documents...
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        $(document).on('click', '.js-customer-documents', function () {
            const customerId = $(this).data('id');
            const customerName = $(this).data('name');
            const $modal = $('#customerDocumentsModal');
            const $content = $('#customerDocumentsModalContent');

            $('#customerDocumentsModalLabel').text(customerName + "'s Documents");
            $content.html('<div class="supplier-ledger-modal__state"><i class="mdi mdi-loading mdi-spin"></i>Loading documents...</div>');
            $modal.modal('show');

            $.ajax({
                url: "<?php echo e(url('/admin/reports/customers')); ?>/" + customerId + '/documents',
                type: 'GET',
                success: function (response) {
                    $content.html(response);
                },
                error: function () {
                    $content.html('<div class="supplier-ledger-modal__state"><i class="mdi mdi-alert-circle-outline"></i>Unable to load documents right now.</div>');
                }
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/html/resources/views/reports/customers.blade.php ENDPATH**/ ?>