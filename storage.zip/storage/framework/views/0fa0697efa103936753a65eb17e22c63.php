<div class="row">
    <div class="col-md-6 col-xl-3">
        <div class="card supplier-ledger-metric">
            <div class="card-body">
                <div class="supplier-ledger-metric__label">Suppliers</div>
                <div class="supplier-ledger-metric__value"><?php echo e(number_format($supplierCount)); ?></div>
            </div>
        </div>
    </div>
    <div class="col-md-6 col-xl-3">
        <div class="card supplier-ledger-metric">
            <div class="card-body">
                <div class="supplier-ledger-metric__label">Purchased Items</div>
                <div class="supplier-ledger-metric__value"><?php echo e(number_format($totalItems)); ?></div>
            </div>
        </div>
    </div>
    <div class="col-md-6 col-xl-3">
        <div class="card supplier-ledger-metric">
            <div class="card-body">
                <div class="supplier-ledger-metric__label">Purchase Cost</div>
                <div class="supplier-ledger-metric__value"><?php echo e(config('constant.currency')); ?><?php echo e(number_format($totalPurchaseAmount, 2)); ?></div>
            </div>
        </div>
    </div>
    <div class="col-md-6 col-xl-3">
        <div class="card supplier-ledger-metric">
            <div class="card-body">
                <div class="supplier-ledger-metric__label">Stock Value</div>
                <div class="supplier-ledger-metric__value"><?php echo e(config('constant.currency')); ?><?php echo e(number_format($totalStockValue, 2)); ?></div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH /var/www/html/resources/views/reports/_supplier-ledger-metrics.blade.php ENDPATH**/ ?>