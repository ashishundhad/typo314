<?php $companySetting = \App\Models\CompanySetting::current(); ?>
<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>

    <meta charset="utf-8" />
    <title><?php echo $__env->yieldContent('title'); ?> - <?php echo e($companySetting->company_name); ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta content="● Buy-Sell ● <?php echo e($companySetting->company_name); ?> One Stop solution for old phones" name="description" />
    <meta content="<?php echo e($companySetting->company_name); ?>" name="author" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <!-- App favicon -->
    <link rel="shortcut icon" href="<?php echo e($companySetting->logo ? asset($companySetting->logo) : asset('assets/images/new_logo/favicon.ico')); ?>">

    <!-- Plugins css -->
    <link href="<?php echo e(asset('assets/libs/selectize/css/selectize.bootstrap3.css')); ?>" rel="stylesheet" type="text/css" />

    <link href="<?php echo e(asset('assets/libs/datatables.net-bs4/css/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet"type="text/css" />
    <!-- App css -->
    <link href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>" rel="stylesheet" type="text/css"id="bs-default-stylesheet" />
    <link href="<?php echo e(asset('assets/css/app.min.css')); ?>" rel="stylesheet" type="text/css" id="app-default-stylesheet" />

    <!-- <link href="<?php echo e(asset('assets/css/bootstrap-dark.min.css')); ?>" rel="stylesheet" type="text/css" id="bs-dark-stylesheet" disabled /> -->
    <link href="<?php echo e(asset('assets/css/app-dark.min.css')); ?>" rel="stylesheet" type="text/css" id="app-dark-stylesheet"
        disabled />

    <!-- icons -->
    <link href="<?php echo e(asset('assets/css/icons.min.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />

    <!-- Page-specific styles, consolidated out of each view's own <style> block -->
    <link href="<?php echo e(asset('assets/css/tenant.css')); ?>" rel="stylesheet" type="text/css" />

    <!-- Custom overrides (loaded last so it wins over the theme/vendor/tenant CSS above) -->
    <link href="<?php echo e(asset('assets/css/custom.css')); ?>" rel="stylesheet" type="text/css" />
    <?php echo $__env->yieldContent('css'); ?>
</head>

<body
    data-layout='{"mode": "light", "width": "fluid", "menuPosition": "fixed", "sidebar": { "color": "light", "size": "default", "showuser": false}, "topbar": {"color": "dark"}, "showRightSidebarOnPageLoad": true}'>

    <!-- Begin page -->
    <div id="wrapper">

        <!-- Topbar Start -->
        <?php echo $__env->make('include.topbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <!-- end Topbar -->

        <!-- ========== Left Sidebar Start ========== -->
        <?php echo $__env->make('include.leftbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <!-- Left Sidebar End -->

        <!-- ============================================================== -->
        <!-- Start Page Content here -->
        <!-- ============================================================== -->

        <div class="content-page">
            <div class="content">

                <!-- Start Content-->
                <?php echo $__env->yieldContent('content'); ?>

            </div> 

            <footer class="footer">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-md-6">
                            <script>document.write(new Date().getFullYear())</script> &copy;
                            Created by
                            <a href="https://www.ascentwebservices.com" target="_blank" style="text-decoration:none; color:inherit;">
                                AscentWebServices
                            </a>
                        </div>
                    </div>
                </div>
            </footer>
        </div>

    </div>
    <!-- END wrapper -->

    <!-- Vendor js -->
    <script src="<?php echo e(asset('assets/js/vendor.min.js')); ?>"></script>

    <script src="<?php echo e(asset('assets/libs/selectize/js/standalone/selectize.min.js')); ?>"></script>

    <script src="<?php echo e(asset('assets/libs/datatables.net/js/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/libs/datatables.net-bs4/js/dataTables.bootstrap4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/libs/datatables.net-responsive/js/dataTables.responsive.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/libs/datatables.net-responsive-bs4/js/responsive.bootstrap4.min.js')); ?>"></script>
    <!-- datatables.js -->
    <script src="<?php echo e(asset('assets/js/pages/tickets.js')); ?>"></script>

    <!-- custom.js -->
    <script src="<?php echo e(asset('assets/js/custom.js')); ?>?v=<?php echo e(filemtime(public_path('assets/js/custom.js'))); ?>"></script>
    <!-- App js-->
    <script src="<?php echo e(asset('assets/js/app.min.js')); ?>"></script>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.0/jquery.validate.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.29.1/moment.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script>
        $(function () {
            var $profileToggle = $('.topbar-dropdown > .dropdown-toggle');

            if ($profileToggle.length && $.fn.dropdown) {
                $profileToggle.dropdown();
            }
        });
    </script>
</body>

<footer>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>

    <?php echo $__env->yieldContent('scripts'); ?>
</footer>

</html>
<?php /**PATH /var/www/html/resources/views/layout/app.blade.php ENDPATH**/ ?>