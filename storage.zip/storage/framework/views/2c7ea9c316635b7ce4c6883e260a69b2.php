<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Repair Report</title>
    <style>
        @page {
            margin: 12px 18px;
        }

        body {
            font-family: DejaVu Sans, sans-serif;
            color: #1f2937;
            font-size: 12px;
            margin: 0;
            padding: 0;
        }

        .report-shell {
            padding: 0;
        }

        .report-hero {
            background-color: #17324d;
            border-radius: 18px;
            padding: 18px 24px;
            color: #fff;
            margin-bottom: 18px;
        }

        .report-hero__title {
            font-size: 28px;
            font-weight: 700;
            margin: 0 0 6px;
        }

        .report-hero__subtitle {
            font-size: 12px;
            opacity: 0.84;
            margin: 0;
        }

        .report-meta {
            margin-top: 14px;
            font-size: 11px;
            opacity: 0.9;
        }

        .summary-grid {
            width: 100%;
            border-collapse: separate;
            border-spacing: 12px 0;
            margin: 0 0 18px;
        }

        .summary-card {
            background: #f8fbfd;
            border: 1px solid #e5edf5;
            border-radius: 16px;
            padding: 16px;
            vertical-align: top;
        }

        .summary-card__label {
            font-size: 10px;
            letter-spacing: 0.12em;
            text-transform: uppercase;
            color: #6b7b8f;
            margin-bottom: 8px;
        }

        .summary-card__value {
            font-size: 22px;
            font-weight: 700;
            color: #17324d;
        }

        .repair-table {
            width: 100%;
            border-collapse: collapse;
        }

        .repair-table thead th {
            background: #17324d;
            color: #edf7ff;
            padding: 11px 10px;
            font-size: 10px;
            text-transform: uppercase;
            letter-spacing: 0.08em;
            text-align: left;
            white-space: nowrap;
        }

        .repair-table tbody td {
            padding: 11px 10px;
            border-bottom: 1px solid #e8eef5;
            vertical-align: top;
            color: #425466;
        }

        .repair-index {
            color: #4f46e5;
            font-weight: 700;
        }

        .repair-status {
            display: inline-block;
            padding: 4px 9px;
            border-radius: 999px;
            font-size: 10px;
            font-weight: 700;
        }

        .repair-status--received {
            background: #eef3f8;
            color: #46587a;
        }

        .repair-status--repairing {
            background: #fdf3df;
            color: #b45309;
        }

        .repair-status--delivered {
            background: #e9f8f4;
            color: #169c82;
        }

        .align-right {
            text-align: right;
        }
    </style>
</head>
<body>
    <div class="report-shell">
        <div class="report-hero">
            <div class="report-hero__title">Repair Report</div>
            <p class="report-hero__subtitle">A summary of repair jobs, parts cost, repair fees, and profit.</p>
            <div class="report-meta">
                Period: <?php echo e($timePeriod); ?><br>
                Generated: <?php echo e(now()->format('d M Y, h:i A')); ?>

            </div>
        </div>

        <table class="summary-grid">
            <tr>
                <td width="25%">
                    <div class="summary-card">
                        <div class="summary-card__label">Records</div>
                        <div class="summary-card__value"><?php echo e($repairs->count()); ?></div>
                    </div>
                </td>
                <td width="25%">
                    <div class="summary-card">
                        <div class="summary-card__label">Parts Cost</div>
                        <div class="summary-card__value">₹<?php echo e(number_format($totalPartsCost, 2)); ?></div>
                    </div>
                </td>
                <td width="25%">
                    <div class="summary-card">
                        <div class="summary-card__label">Repair Fee</div>
                        <div class="summary-card__value">₹<?php echo e(number_format($totalRepairFee, 2)); ?></div>
                    </div>
                </td>
                <td width="25%">
                    <div class="summary-card">
                        <div class="summary-card__label">Profit</div>
                        <div class="summary-card__value">₹<?php echo e(number_format($totalProfit, 2)); ?></div>
                    </div>
                </td>
            </tr>
        </table>

        <table class="repair-table">
            <thead>
                <tr>
                    <th>Sr No</th>
                    <th>Customer</th>
                    <th>Issue</th>
                    <th>Repair Date</th>
                    <th class="align-right">Parts Cost</th>
                    <th class="align-right">Repair Fee</th>
                    <th class="align-right">Profit</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $repairs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $repair): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="repair-index">#<?php echo e($index + 1); ?></td>
                        <td><?php echo e($repair->customer_name ?: 'Walk-in Customer'); ?></td>
                        <td><?php echo e($repair->issue_description ?: '-'); ?></td>
                        <td><?php echo e($repair->repair_date ? $repair->repair_date->format('d-m-Y') : '-'); ?></td>
                        <td class="align-right">₹<?php echo e(number_format((float) $repair->parts_cost, 2)); ?></td>
                        <td class="align-right">₹<?php echo e(number_format((float) $repair->repair_fee, 2)); ?></td>
                        <td class="align-right">₹<?php echo e(number_format($repair->profit, 2)); ?></td>
                        <td>
                            <span class="repair-status repair-status--<?php echo e($repair->status); ?>"><?php echo e($repair->status_label); ?></span>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</body>
</html>
<?php /**PATH /var/www/html/resources/views/repairs/repair-pdf.blade.php ENDPATH**/ ?>