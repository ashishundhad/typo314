<?php $__env->startSection('title'); ?>
    Supplier Ledger Detail
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="container-fluid supplier-ledger-detail-shell">
        <div class="d-flex justify-content-end mb-3">
            <a href="<?php echo e(route('supplier-ledger', request()->except('supplier', 'page'))); ?>" class="btn btn-light supplier-ledger-detail-btn">
                <i class="mdi mdi-arrow-left mr-1"></i>Back to Ledger
            </a>
        </div>

        <?php echo $__env->make('reports._supplier-ledger-detail-content', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </div>

    <script>
        (function () {
            const periodSelect = document.getElementById('detail-period');
            const dateGroups = document.querySelectorAll('.supplier-ledger-detail-date-group');

            if (!periodSelect) {
                return;
            }

            function sync() {
                const showDates = periodSelect.value === 'custom';

                dateGroups.forEach(function (group) {
                    group.style.display = showDates ? 'block' : 'none';
                });
            }

            periodSelect.addEventListener('change', sync);
            sync();
        })();
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/html/resources/views/reports/supplier-ledger-detail.blade.php ENDPATH**/ ?>