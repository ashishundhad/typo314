<?php $__env->startSection('title', 'List Purchases'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid purchase-shell">
        <div class="purchase-hero">
            <div class="row align-items-center">
                <div class="col-lg-8">
                    <!-- <div class="purchase-hero__eyebrow">Inventory Management</div> -->
                    <h1 class="purchase-hero__title">List Purchases</h1>
                    <!-- <p class="purchase-hero__subtitle">
                        Track every stocked device, filter inventory quickly, and manage product lifecycle from one clean view.
                    </p> -->
                </div>
                <div class="col-lg-4">
                    <div class="purchase-hero__summary float-lg-right">
                        <div class="purchase-hero__summary-label">Available Stock Value</div>
                        <div class="purchase-hero__summary-value">
                            <?php echo e(config('constant.currency')); ?> <?php echo e(number_format($totalAvailableStockAmount, 2)); ?>

                        </div>
                        <!-- <p class="purchase-hero__summary-meta">Current unsold inventory value in stock</p> -->
                    </div>
                </div>
            </div>
        </div>

        <?php echo $__env->make('include.alert', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        <div class="card purchase-section">
            <div class="card-body">
                <div class="purchase-section__top">
                    <div>
                        <!-- <div class="purchase-section__eyebrow">Stock Registry</div> -->
                        <h2 class="purchase-section__title">Manage Purchase [<?php echo e($totalItems); ?>]</h2>
                        <!-- <p class="purchase-section__subtitle">
                            Search by IMEI or model, refine the list by store, year, storage, color, and stock status.
                        </p> -->
                    </div>

                    <div class="purchase-actions">
                        <div class="btn-group">
                            <button type="button" class="btn btn-info purchase-btn dropdown-toggle"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="mdi mdi-plus-circle-outline mr-1"></i>Add Stock
                            </button>
                            <div class="dropdown-menu dropdown-menu-right mt-2">
                                <a class="dropdown-item" href="<?php echo e(route('purchase.create')); ?>">
                                    <i class="mdi mdi-plus-circle-outline mr-1"></i>Single Stock
                                </a>
                                <a class="dropdown-item" href="<?php echo e(route('purchase.create.multiple')); ?>">
                                    <i class="mdi mdi-plus-box-multiple-outline mr-1"></i>Multiple Stock
                                </a>
                            </div>
                        </div>

                        <div class="btn-group">
                            <button type="button" class="btn btn-primary purchase-btn dropdown-toggle"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="mdi mdi-file-download-outline mr-1"></i>Export Stock
                            </button>
                            <div class="dropdown-menu dropdown-menu-right mt-2">
                                <a class="dropdown-item" href="<?php echo e(request()->fullUrlWithQuery(['download' => 'csv'])); ?>">
                                    <i class="mdi mdi-file-delimited-outline mr-1"></i>Download CSV
                                </a>
                                <a class="dropdown-item" href="<?php echo e(request()->fullUrlWithQuery(['download' => 'pdf'])); ?>">
                                    <i class="mdi mdi-file-pdf-box mr-1"></i>Download PDF
                                </a>
                            </div>
                        </div>
                    </div>
                </div>

                <?php if(count($allPurchases)): ?>
                    <div class="purchase-filter">
                        <form action="<?php echo e(route('allpurchases')); ?>" method="GET" id="filterpurchase">
                            <div class="form-row purchase-filter__row">
                                <div class="col-12 col-lg-4 mb-3 mb-lg-0">
                                    <!-- <label class="purchase-filter__label" for="searchstock">Search Inventory</label> -->
                                    <div class="input-group purchase-search">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text"><i class="mdi mdi-magnify"></i></span>
                                        </div>
                                        <input type="text" class="form-control" placeholder="Search by model or IMEI"
                                            name="search" value="<?php echo e(request()->input('search')); ?>" id="searchstock">
                                        <div class="input-group-append">
                                            <button class="btn btn-dark" type="submit">Search</button>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-6 col-md-3 col-lg-1 mb-3 mb-lg-0">
                                    <!-- <label class="purchase-filter__label" for="selectyear">Year</label> -->
                                    <select name="year" class="form-control" id="selectyear">
                                        <option value="">Year</option>
                                        <?php for($filterYear = now()->year; $filterYear >= 2024; $filterYear--): ?>
                                            <option value="<?php echo e($filterYear); ?>" <?php if((int) $year === $filterYear): echo 'selected'; endif; ?>>
                                                <?php echo e($filterYear); ?>

                                            </option>
                                        <?php endfor; ?>
                                    </select>
                                </div>

                                <div class="col-6 col-md-3 col-lg-2 mb-3 mb-lg-0">
                                    <!-- <label class="purchase-filter__label" for="selectstorage">Storage</label> -->
                                    <select name="storage" class="form-control" id="selectstorage">
                                        <option value="">Select Storage</option>
                                        <option value="64" <?php if($storage == 64): echo 'selected'; endif; ?>>64 GB</option>
                                        <option value="128" <?php if($storage == 128): echo 'selected'; endif; ?>>128 GB</option>
                                        <option value="256" <?php if($storage == 256): echo 'selected'; endif; ?>>256 GB</option>
                                        <option value="512" <?php if($storage == 512): echo 'selected'; endif; ?>>512 GB</option>
                                        <option value="1024" <?php if($storage == 1024): echo 'selected'; endif; ?>>1 TB</option>
                                        <option value="2048" <?php if($storage == 2048): echo 'selected'; endif; ?>>2 TB</option>
                                    </select>
                                </div>

                                <div class="col-6 col-md-3 col-lg-2 mb-3 mb-lg-0">
                                    <!-- <label class="purchase-filter__label" for="selectcolor">Color</label> -->
                                    <select name="color" class="form-control" id="selectcolor">
                                        <option value="">Select Color</option>
                                        <?php $__currentLoopData = $colors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $color): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($color->color); ?>"
                                                <?php if(strtolower($color->color) == strtolower($selectedcolor)): echo 'selected'; endif; ?>>
                                                <?php echo e($color->color); ?>

                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>

                                <div class="col-6 col-md-3 col-lg-2 mb-3 mb-lg-0">
                                    <!-- <label class="purchase-filter__label" for="findbysold">Status</label> -->
                                    <select name="is_sold" class="form-control" id="findbysold">
                                        <option value="">Select Status</option>
                                        <option value="2" <?php if($issold == 2): echo 'selected'; endif; ?>>In Stock</option>
                                        <option value="1" <?php if($issold == 1): echo 'selected'; endif; ?>>Sold</option>
                                    </select>
                                </div>

                                <div class="col-12 col-md-3 col-lg-1">
                                    <!-- <label class="purchase-filter__label d-none d-md-block">&nbsp;</label> -->
                                    <button class="btn btn-outline-danger btn-block purchase-btn" type="button"
                                        onclick="clearFilters()">Clear</button>
                                </div>
                            </div>
                        </form>
                    </div>

                    <div class="table-responsive">
                        <table class="table purchase-table">
                            <thead>
                                <tr>
                                    <th>
                                        <a href="<?php echo e(route('allpurchases', ['direction' => $sortDirection == 'asc' ? 'desc' : 'asc'])); ?>"
                                            class="text-decoration-none">
                                            Sr. No
                                            <?php if($sortDirection == 'asc'): ?>
                                                <i class="fa fa-arrow-up ml-1"></i>
                                            <?php else: ?>
                                                <i class="fa fa-arrow-down ml-1"></i>
                                            <?php endif; ?>
                                        </a>
                                    </th>
                                    <th>Model</th>
                                    <th>Code</th>
                                    <!-- <th>Qty</th>
                                    <th>Available</th> -->
                                    <th>Storage</th>
                                    <th>Color</th>
                                    <th class="text-right">Stock Value</th>
                                    <th>Buy Date</th>
                                    <!-- <th>Sale Date</th> -->
                                    <th>Status</th>
                                    <th class="text-right">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $allPurchases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $purchase): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td>
                                            <a href="<?php echo e(route('purchase-detail', $purchase->id)); ?>" class="purchase-index">
                                                #<?php echo e($purchase->id); ?>

                                            </a>
                                        </td>
                                        <td class="purchase-model">
                                            <a href="<?php echo e(route('purchase-detail', $purchase->id)); ?>">
                                                <?php echo e(ucfirst($purchase->model)); ?>

                                            </a>
                                            <!-- <div class="purchase-meta">Stock entry details</div> -->
                                        </td>
                                        <td>
                                            <?php if($purchase->display_code): ?>
                                                <span class="purchase-imei" onclick="copyToClipboard('<?php echo e($purchase->display_code); ?>')"
                                                    title="Click to copy code">
                                                    <i class="mdi mdi-content-copy"></i><?php echo e($purchase->display_code); ?>

                                                </span>
                                            <?php else: ?>
                                                --
                                            <?php endif; ?>
                                        </td>
                                        <!-- <td>
                                            <span class="purchase-chip"><?php echo e($purchase->total_units); ?></span>
                                        </td>
                                        <td>
                                            <span class="purchase-chip"><?php echo e($purchase->available_units); ?></span>
                                        </td> -->
                                        <td>
                                            <span class="purchase-chip">
                                                <?php echo e($purchase->storage ? $purchase->storage . ' GB' : '--'); ?>

                                            </span>
                                        </td>
                                        <td>
                                            <span class="purchase-chip"><?php echo e($purchase->color ? ucfirst($purchase->color) : '--'); ?></span>
                                        </td>
                                        <td class="text-right">
                                            <span class="purchase-amount">
                                                <?php echo e(config('constant.currency') . number_format($purchase->isBulkTracked() ? $purchase->available_stock_value : $purchase->purchase_price, 2)); ?>

                                            </span>
                                        </td>
                                        <td>
                                            <span class="purchase-date">
                                                <?php echo e(\Carbon\Carbon::parse($purchase->purchase_date)->format('d/m/Y')); ?>

                                            </span>
                                        </td>
                                        <!-- <td>
                                            <span class="purchase-date">
                                                <?php if($purchase->sell_date && $purchase->sold_units > 0): ?>
                                                    <?php echo e(\Carbon\Carbon::parse($purchase->sell_date)->format('d/m/Y')); ?>

                                                <?php else: ?>
                                                    --
                                                <?php endif; ?>
                                            </span>
                                        </td> -->
                                        <td>
                                            <?php if($purchase->status_label === 'Sold'): ?>
                                                <span class="purchase-status purchase-status--sold">Sold</span>
                                            <?php elseif($purchase->status_label === 'Partial'): ?>
                                                <span class="purchase-status purchase-status--available">Partial</span>
                                            <?php else: ?>
                                                <span class="purchase-status purchase-status--available">Available</span>
                                            <?php endif; ?>
                                        </td>
                                        <td class="purchase-actions-col">
                                            <div class="purchase-action-icons">
                                                <?php if($purchase->available_units > 0): ?>
                                                    <a href="<?php echo e(route('purchase.edit', $purchase->id)); ?>"
                                                        class="purchase-action-icon purchase-action-icon--edit"
                                                        title="Edit">
                                                        <i class="mdi mdi-square-edit-outline"></i>
                                                    </a>
                                                <?php endif; ?>

                                                <a href="<?php echo e(route('purchase-detail', $purchase->id)); ?>"
                                                    class="purchase-action-icon purchase-action-icon--view js-purchase-detail"
                                                    data-title="Stock Detail #<?php echo e($purchase->id); ?>"
                                                    title="View">
                                                    <i class="mdi mdi-eye-outline"></i>
                                                </a>

                                                <form method="post" action="<?php echo e(route('delete-stock', $purchase->id)); ?>" class="d-inline-block mb-0">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <button type="submit"
                                                        class="purchase-action-icon purchase-action-icon--delete"
                                                        onclick="sureToDelete(event)"
                                                        title="Delete">
                                                        <i class="mdi mdi-trash-can-outline"></i>
                                                    </button>
                                                </form>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>

                    <div class="pagination-links">
                        <?php echo e($allPurchases->appends(request()->query())->links('vendor.pagination.bootstrap-5')); ?>

                    </div>
                <?php else: ?>
                    <div class="purchase-empty">
                        <div class="purchase-empty__icon">
                            <i class="mdi mdi-cellphone-plus"></i>
                        </div>
                        <h4>No stock found</h4>
                        <p>Start by adding your first stock item or return to the full inventory view.</p>
                        <a href="<?php echo e(route('allpurchases')); ?>" class="btn btn-primary purchase-btn">
                            <i class="mdi mdi-refresh mr-1"></i>Reload Inventory
                        </a>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <div class="modal fade purchase-detail-modal" id="purchaseDetailModal" tabindex="-1" role="dialog"
        aria-labelledby="purchaseDetailModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-xl" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="purchaseDetailModalLabel">Purchase Detail</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div id="purchaseDetailModalContent" class="purchase-detail-modal__content">
                        <div class="purchase-detail-modal__state">
                            <i class="mdi mdi-package-variant-closed"></i>Choose a purchase to view its details.
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        function copyToClipboard(text) {
            navigator.clipboard.writeText(text);
            toastr.success('Copied to clipboard');
        }

        function clearFilters() {
            window.location.href = "<?php echo e(route('allpurchases')); ?>";
        }

        $(document).on('click', '.js-purchase-detail', function(e) {
            e.preventDefault();

            const url = $(this).attr('href');
            const title = $(this).data('title') || 'Purchase Detail';

            $('#purchaseDetailModalLabel').text(title);
            $('#purchaseDetailModal').modal('show');
            $('#purchaseDetailModalContent').html(
                '<div class="purchase-detail-modal__state"><i class="mdi mdi-loading mdi-spin"></i>Loading purchase details...</div>'
            );

            $.ajax({
                url: url,
                method: 'GET',
                data: {
                    modal: 1
                },
                success: function(response) {
                    $('#purchaseDetailModalContent').html(response);
                },
                error: function() {
                    $('#purchaseDetailModalContent').html(
                        '<div class="purchase-detail-modal__state"><i class="mdi mdi-alert-circle-outline"></i>Unable to load purchase details right now.</div>'
                    );
                }
            });
        });

        $('#purchaseDetailModal').on('hidden.bs.modal', function() {
            $('#purchaseDetailModalContent').html(
                '<div class="purchase-detail-modal__state"><i class="mdi mdi-package-variant-closed"></i>Choose a purchase to view its details.</div>'
            );
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/html/resources/views/purchase/purchases.blade.php ENDPATH**/ ?>