<?php
    $user = auth()->user();
    $profileImage = !empty($user->profile_image)
        ? asset('admin/users/' . $user->profile_image)
        : asset('assets/images/users/user-1.jpg');

    $stocksOpen = request()->routeIs('allpurchases', 'purchase.create', 'purchase.create.multiple', 'purchase.edit', 'purchase-detail', 'purchase.importform');
    $salesOpen = request()->routeIs('allsales', 'new-sale', 'saledetail');
    $invoiceOpen = request()->routeIs('allinvoices', 'newinvoice', 'invoice-detail', 'pos.index');
    $reportsOpen = request()->routeIs('sale-report', 'profit-loss', 'daily-closing', 'purchase-report', 'saleschart');
    $financeOpen = request()->routeIs('finance-report', 'finance-report-export-csv', 'finance-report-export-pdf');
    $expensesOpen = request()->routeIs('expenses', 'add-expense', 'expense-categories.*');
    $partyOpen = request()->routeIs('customers', 'parties.*', 'transactions.*', 'supplier-ledger', 'supplier-ledger-detail');
    $ledgerOpen = request()->routeIs('ledger.*');
    $adminOpen = request()->routeIs('roles.*', 'users.*');
    $aiAssistantOpen = request()->routeIs('ai.*');
?>

<div class="left-side-menu">
    <div class="h-100" data-simplebar>
        <!-- <div class="sidebar-brand-card">
            <div class="sidebar-brand-card__logo">
                <img src="<?php echo e(asset('assets/images/new_logo/fonico_mobiles.jpg')); ?>" alt="Fonico">
            </div>
            <div class="sidebar-brand-card__title">Fonico Mobile</div>
            <p class="sidebar-brand-card__text">Inventory, billing, and reporting in one focused workspace.</p>
        </div> -->
<!-- 
        <div class="sidebar-user-card">
            <img src="<?php echo e($profileImage); ?>" alt="<?php echo e($user->name ?? $user->user_name); ?>" class="sidebar-user-card__avatar">
            <div>
                <div class="sidebar-user-card__name"><?php echo e($user->name ?? ucfirst($user->user_name)); ?></div>
                <div class="sidebar-user-card__role">Signed In</div>
            </div>
        </div> -->

        <div id="sidebar-menu">
            <ul id="side-menu">
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('dashboard.view')): ?>
                    <li class="<?php echo e(request()->routeIs('dashboard') ? 'menuitem-active' : ''); ?>">
                        <a href="<?php echo e(route('dashboard')); ?>">
                            <i data-feather="airplay"></i>
                            <span>Dashboard</span>
                        </a>
                    </li>
                <?php endif; ?>

                <li class="<?php echo e($aiAssistantOpen ? 'menuitem-active' : ''); ?>">
                    <a href="<?php echo e(route('ai.index')); ?>">
                        <i data-feather="message-square"></i>
                        <span>AI Assistant</span>
                    </a>
                </li>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['purchases.view', 'purchases.create', 'purchase.create.multiple', 'purchases.import'])): ?>
                    <li class="<?php echo e($stocksOpen ? 'menuitem-open menuitem-active' : ''); ?>">
                        <a data-toggle="collapse" href="#stocksMenu" role="button" aria-expanded="<?php echo e($stocksOpen ? 'true' : 'false'); ?>" aria-controls="stocksMenu">
                            <i data-feather="shopping-cart"></i>
                            <span>Stocks</span>
                            <span class="menu-arrow"></span>
                        </a>
                        <div class="collapse <?php echo e($stocksOpen ? 'show' : ''); ?>" id="stocksMenu">
                            <ul class="nav-second-level">
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('purchases.view')): ?>
                                    <li><a href="<?php echo e(route('allpurchases')); ?>" class="<?php echo e(request()->routeIs('allpurchases') ? 'active' : ''); ?>">All Stocks</a></li>
                                <?php endif; ?>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('purchases.import')): ?>
                                    <li><a href="<?php echo e(route('purchase.importform')); ?>" class="<?php echo e(request()->routeIs('purchase.importform') ? 'active' : ''); ?>">Import Stocks</a></li>
                                <?php endif; ?>
                            </ul>
                        </div>
                    </li>
                <?php endif; ?>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['sales.view', 'sales.create'])): ?>
                    <li class="<?php echo e($salesOpen ? 'menuitem-open menuitem-active' : ''); ?>">
                        <a data-toggle="collapse" href="#salesMenu" role="button" aria-expanded="<?php echo e($salesOpen ? 'true' : 'false'); ?>" aria-controls="salesMenu">
                            <i data-feather="briefcase"></i>
                            <span>Sell</span>
                            <span class="menu-arrow"></span>
                        </a>
                        <div class="collapse <?php echo e($salesOpen ? 'show' : ''); ?>" id="salesMenu">
                            <ul class="nav-second-level">
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('sales.view')): ?>
                                    <li><a href="<?php echo e(route('allsales')); ?>" class="<?php echo e(request()->routeIs('allsales', 'saledetail') ? 'active' : ''); ?>">Sold Items</a></li>
                                <?php endif; ?>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('sales.create')): ?>
                                    <li><a href="<?php echo e(route('new-sale')); ?>" class="<?php echo e(request()->routeIs('new-sale') ? 'active' : ''); ?>">New Sale</a></li>
                                <?php endif; ?>
                            </ul>
                        </div>
                    </li>
                <?php endif; ?>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['invoices.view', 'invoices.create'])): ?>
                    <li class="<?php echo e($invoiceOpen ? 'menuitem-open menuitem-active' : ''); ?>">
                        <a data-toggle="collapse" href="#invoiceMenu" role="button" aria-expanded="<?php echo e($invoiceOpen ? 'true' : 'false'); ?>" aria-controls="invoiceMenu">
                            <i class="fa fa-file-invoice"></i>
                            <span>Invoice</span>
                            <span class="menu-arrow"></span>
                        </a>
                        <div class="collapse <?php echo e($invoiceOpen ? 'show' : ''); ?>" id="invoiceMenu">
                            <ul class="nav-second-level">
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('invoices.view')): ?>
                                    <li><a href="<?php echo e(route('allinvoices')); ?>" class="<?php echo e(request()->routeIs('allinvoices', 'invoice-detail') ? 'active' : ''); ?>">Manage Invoice</a></li>
                                <?php endif; ?>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('invoices.create')): ?>
                                    <li><a href="<?php echo e(route('newinvoice')); ?>" class="<?php echo e(request()->routeIs('newinvoice') ? 'active' : ''); ?>">New Invoice</a></li>
                                <?php endif; ?>
                            </ul>
                        </div>
                    </li>
                <?php endif; ?>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('returns.view')): ?>
                    <li class="<?php echo e(request()->routeIs('sale-returns.index') ? 'menuitem-active' : ''); ?>">
                        <a href="<?php echo e(route('sale-returns.index')); ?>">
                            <i class="fa fa-undo"></i>
                            <span>Sale Returns</span>
                        </a>
                    </li>
                <?php endif; ?>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('repairs.view')): ?>
                    <li class="<?php echo e(request()->routeIs('repairs.index') ? 'menuitem-active' : ''); ?>">
                        <a href="<?php echo e(route('repairs.index')); ?>">
                            <i class="fa fa-tools"></i>
                            <span>Repairs</span>
                        </a>
                    </li>
                <?php endif; ?>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['invoices.view', 'purchases.view'])): ?>
                    <li class="<?php echo e(request()->routeIs('documents.index') ? 'menuitem-active' : ''); ?>">
                        <a href="<?php echo e(route('documents.index')); ?>">
                            <i class="fa fa-folder-open"></i>
                            <span>Documents</span>
                        </a>
                    </li>
                <?php endif; ?>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['reports.sales.view', 'reports.purchases.view', 'reports.charts.view'])): ?>
                    <li class="<?php echo e($reportsOpen ? 'menuitem-open menuitem-active' : ''); ?>">
                        <a data-toggle="collapse" href="#reportsMenu" role="button" aria-expanded="<?php echo e($reportsOpen ? 'true' : 'false'); ?>" aria-controls="reportsMenu">
                            <i class="fa fa-chart-line"></i>
                            <span>Reports</span>
                            <span class="menu-arrow"></span>
                        </a>
                        <div class="collapse <?php echo e($reportsOpen ? 'show' : ''); ?>" id="reportsMenu">
                            <ul class="nav-second-level">
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('reports.sales.view')): ?>
                                    <li><a href="<?php echo e(route('sale-report')); ?>" class="<?php echo e(request()->routeIs('sale-report') ? 'active' : ''); ?>">Sales</a></li>
                                    <li><a href="<?php echo e(route('profit-loss')); ?>" class="<?php echo e(request()->routeIs('profit-loss') ? 'active' : ''); ?>">Profit & Loss</a></li>
                                    <li><a href="<?php echo e(route('daily-closing')); ?>" class="<?php echo e(request()->routeIs('daily-closing') ? 'active' : ''); ?>">Daily Closing</a></li>
                                <?php endif; ?>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('reports.purchases.view')): ?>
                                    <li><a href="<?php echo e(route('purchase-report')); ?>" class="<?php echo e(request()->routeIs('purchase-report') ? 'active' : ''); ?>">Purchase</a></li>
                                <?php endif; ?>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('reports.charts.view')): ?>
                                    <li><a href="<?php echo e(route('saleschart')); ?>" class="<?php echo e(request()->routeIs('saleschart') ? 'active' : ''); ?>">Chart</a></li>
                                <?php endif; ?>
                            </ul>
                        </div>
                    </li>
                <?php endif; ?>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['reports.sales.view'])): ?>
                    <li class="<?php echo e($financeOpen ? 'menuitem-open menuitem-active' : ''); ?>">
                        <a data-toggle="collapse" href="#financeMenu" role="button" aria-expanded="<?php echo e($financeOpen ? 'true' : 'false'); ?>" aria-controls="financeMenu">
                            <i class="fa fa-money-bill-wave"></i>
                            <span>Finance</span>
                            <span class="menu-arrow"></span>
                        </a>
                        <div class="collapse <?php echo e($financeOpen ? 'show' : ''); ?>" id="financeMenu">
                            <ul class="nav-second-level">
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('reports.sales.view')): ?>
                                    <li><a href="<?php echo e(route('finance-report')); ?>" class="<?php echo e(request()->routeIs('finance-report', 'finance-report-export-csv', 'finance-report-export-pdf') ? 'active' : ''); ?>">Tax Report</a></li>
                                <?php endif; ?>
                            </ul>
                        </div>
                    </li>
                <?php endif; ?>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['expenses.view', 'expenses.create', 'expense-categories.view'])): ?>
                    <li class="<?php echo e($expensesOpen ? 'menuitem-open menuitem-active' : ''); ?>">
                        <a data-toggle="collapse" href="#expensesMenu" role="button" aria-expanded="<?php echo e($expensesOpen ? 'true' : 'false'); ?>" aria-controls="expensesMenu">
                            <i class="fa fa-wallet"></i>
                            <span>Expense Tracker</span>
                            <span class="menu-arrow"></span>
                        </a>
                        <div class="collapse <?php echo e($expensesOpen ? 'show' : ''); ?>" id="expensesMenu">
                            <ul class="nav-second-level">
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('expenses.view')): ?>
                                    <li><a href="<?php echo e(route('expenses')); ?>" class="<?php echo e(request()->routeIs('expenses') ? 'active' : ''); ?>">Expenses</a></li>
                                <?php endif; ?>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('expense-categories.view')): ?>
                                    <li><a href="<?php echo e(route('expense-categories.index')); ?>" class="<?php echo e(request()->routeIs('expense-categories.*') ? 'active' : ''); ?>">Categories</a></li>
                                <?php endif; ?>
                                <!-- <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('expenses.create')): ?>
                                    <li><a href="<?php echo e(route('expenses', ['open' => 'add'])); ?>" class="<?php echo e(request()->has('open') && request('open') === 'add' ? 'active' : ''); ?>">Add Expense</a></li>
                                <?php endif; ?> -->
                            </ul>
                        </div>
                    </li>
                <?php endif; ?>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['reports.customers.view', 'parties.view', 'transactions.view', 'reports.purchases.view'])): ?>
                    <li class="<?php echo e($partyOpen ? 'menuitem-open menuitem-active' : ''); ?>">
                        <a data-toggle="collapse" href="#partyMenu" role="button" aria-expanded="<?php echo e($partyOpen ? 'true' : 'false'); ?>" aria-controls="partyMenu">
                            <i class="mdi mdi-account-cash-outline"></i>
                            <span>Parties</span>
                            <span class="menu-arrow"></span>
                        </a>
                        <div class="collapse <?php echo e($partyOpen ? 'show' : ''); ?>" id="partyMenu">
                            <ul class="nav-second-level">
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('reports.customers.view')): ?>
                                    <li><a href="<?php echo e(route('customers')); ?>" class="<?php echo e(request()->routeIs('customers') ? 'active' : ''); ?>">Customers</a></li>
                                <?php endif; ?>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('parties.view')): ?>
                                    <li><a href="<?php echo e(route('parties.suppliers')); ?>" class="<?php echo e(request()->routeIs('parties.suppliers') ? 'active' : ''); ?>">Suppliers</a></li>
                                <?php endif; ?>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('transactions.view')): ?>
                                    <li><a href="<?php echo e(route('transactions.index')); ?>" class="<?php echo e(request()->routeIs('transactions.index') ? 'active' : ''); ?>">Transactions</a></li>
                                <?php endif; ?>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('reports.purchases.view')): ?>
                                    <li><a href="<?php echo e(route('supplier-ledger')); ?>" class="<?php echo e(request()->routeIs('supplier-ledger', 'supplier-ledger-detail') ? 'active' : ''); ?>">Supplier Ledger</a></li>
                                <?php endif; ?>
                            </ul>
                        </div>
                    </li>
                <?php endif; ?>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['ledger.view', 'ledger.create'])): ?>
                    <li class="<?php echo e($ledgerOpen ? 'menuitem-open menuitem-active' : ''); ?>">
                        <a data-toggle="collapse" href="#ledgerMenu" role="button" aria-expanded="<?php echo e($ledgerOpen ? 'true' : 'false'); ?>" aria-controls="ledgerMenu">
                            <i class="fa fa-book"></i>
                            <span>Ledger</span>
                            <span class="menu-arrow"></span>
                        </a>
                        <div class="collapse <?php echo e($ledgerOpen ? 'show' : ''); ?>" id="ledgerMenu">
                            <ul class="nav-second-level">
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('ledger.view')): ?>
                                    <li><a href="<?php echo e(route('ledger.index')); ?>" class="<?php echo e(request()->routeIs('ledger.index', 'ledger.index.alias') ? 'active' : ''); ?>">Ledger List</a></li>
                                <?php endif; ?>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('ledger.create')): ?>
                                    <li><a href="<?php echo e(route('ledger.create')); ?>" class="<?php echo e(request()->routeIs('ledger.create') ? 'active' : ''); ?>">New Entry</a></li>
                                <?php endif; ?>
                            </ul>
                        </div>
                    </li>
                <?php endif; ?>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['roles.view', 'roles.create', 'users.view', 'users.create'])): ?>
                    <li class="<?php echo e($adminOpen ? 'menuitem-open menuitem-active' : ''); ?>">
                        <a data-toggle="collapse" href="#adminMenu" role="button" aria-expanded="<?php echo e($adminOpen ? 'true' : 'false'); ?>" aria-controls="adminMenu">
                            <i class="fa fa-user-shield"></i>
                            <span>Admin Tools</span>
                            <span class="menu-arrow"></span>
                        </a>
                        <div class="collapse <?php echo e($adminOpen ? 'show' : ''); ?>" id="adminMenu">
                            <ul class="nav-second-level">
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('roles.view')): ?>
                                    <li><a href="<?php echo e(route('roles.index')); ?>" class="<?php echo e(request()->routeIs('roles.*') ? 'active' : ''); ?>">Role List</a></li>
                                <?php endif; ?>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('users.view')): ?>
                                    <li><a href="<?php echo e(route('users.index')); ?>" class="<?php echo e(request()->routeIs('users.*') ? 'active' : ''); ?>">Users List</a></li>
                                <?php endif; ?>
                            </ul>
                        </div>
                    </li>
                <?php endif; ?>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['invoices.view', 'invoices.create'])): ?>
                    <li class="<?php echo e(request()->routeIs('pos.*') ? 'menuitem-active' : ''); ?>">
                        <a href="<?php echo e(route('pos.index')); ?>">
                            <i class="fa fa-user-shield"></i>
                            <span>POS</span>
                        </a>
                    </li>
                <?php endif; ?>

                <?php if (\Illuminate\Support\Facades\Blade::check('role', 'super-admin')): ?>
                    <li class="<?php echo e(request()->routeIs('admin.settings.*') ? 'menuitem-active' : ''); ?>">
                        <a href="<?php echo e(route('admin.settings.edit')); ?>">
                            <i class="fa fa-cog"></i>
                            <span>Settings</span>
                        </a>
                    </li>
                <?php endif; ?>
            </ul>
        </div>

        <div class="clearfix"></div>
    </div>
</div>
<?php /**PATH /var/www/html/resources/views/include/leftbar.blade.php ENDPATH**/ ?>