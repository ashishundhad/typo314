<?php $companySetting = \App\Models\CompanySetting::current(); ?>
<div class="invoice-box">
    <h2><?php echo e($invoice->invoice_type === 'tax' ? 'TAX INVOICE' : 'RECEIPT'); ?></h2>

    <div class="invoice-header">
        <div class="company-block">
            <?php if($companySetting->logo): ?>
                <img src="<?php echo e(asset($companySetting->logo)); ?>" alt="Logo" class="company-logo">
            <?php endif; ?>
            <?php if($companySetting->gst_enabled && $companySetting->gst_number): ?>
                <div class="company-gstin"><b>GSTIN:</b> <?php echo e($companySetting->gst_number); ?></div>
            <?php endif; ?>
            <div class="company-address">
                <p>
                    <?php echo e($companySetting->company_name); ?><br>
                    <?php if($companySetting->address): ?>
                        <?php echo e($companySetting->address); ?><br>
                    <?php endif; ?>
                    <?php if($companySetting->phone): ?>
                        <b>Mo:</b> <?php echo e($companySetting->phone); ?><br>
                    <?php endif; ?>
                </p>
            </div>
        </div>

        <div class="invoice-details">
            <p><b>Invoice No:</b> #<?php echo e($invoice->invoice_no); ?></p>
            <p><b>Date:</b> <?php echo e(date('d/m/Y', strtotime($invoice->invoice_date))); ?> <?php echo e($invoice->created_at?->format('h:i A')); ?></p>
        </div>
    </div>

    <div class="bill-to-box">
        <div>
            <div class="bill-to-box__label">Bill To</div>
            <div class="bill-to-box__name"><?php echo e($invoice->customer_name); ?></div>
            <div class="bill-to-box__meta">
                <?php if($invoice->customer_no): ?>
                    Mobile: <?php echo e($invoice->customer_no); ?>

                <?php else: ?>
                    Mobile: N/A
                <?php endif; ?>
            </div>
        </div>
    </div>

    <table>
        <thead>
            <tr>
                <th>#</th>
                <th>Particulars</th>
                <th>Qty</th>
                <th>Rate</th>
                <th>Amount</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $invoice->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td align="center"><?php echo e($index + 1); ?></td>
                    <td class="item-particulars">
                        <?php echo nl2br($item->item_description) ?>
                        <?php if($item->warranty_expiry_date): ?>
                            <br><small><b>Warranty:</b> <?php echo e(date('d/m/Y', strtotime($item->warranty_expiry_date))); ?></small>
                        <?php endif; ?>
                    </td>
                    <td align="center"><?php echo e($item->quantity); ?></td>
                    <td align="right">₹<?php echo e(number_format($item->unit_price, 2)); ?></td>
                    <td align="right">₹<?php echo e(number_format($item->total_amount, 2)); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <?php
        // When GST is "include" mode, item prices already contain tax, so total_amount
        // is tax-inclusive — show the tax-exclusive taxable value here instead, so
        // Subtotal + CGST + SGST (+ IGST) - Discount reads correctly as Net Total,
        // rather than double-counting the tax that's already baked into total_amount.
        $documentSubtotal = $invoice->gst_mode === 'include'
            ? $invoice->total_amount - ($invoice->tax_amount ?? 0)
            : $invoice->total_amount;
    ?>
    <table>
        <tbody>
            <tr class="totals">
                <td colspan="4"><?php echo e($invoice->invoice_type === 'tax' ? 'Taxable Amount' : 'Subtotal'); ?></td>
                <td>₹<?php echo e(number_format($documentSubtotal, 2)); ?></td>
            </tr>
            <?php if($invoice->cgst_amount): ?>
                <tr>
                    <td colspan="4" align="right">CGST (<?php echo e($invoice->cgst_rate); ?>%)</td>
                    <td align="right">₹<?php echo e(number_format($invoice->cgst_amount, 2)); ?></td>
                </tr>
            <?php endif; ?>
            <?php if($invoice->sgst_amount): ?>
                <tr>
                    <td colspan="4" align="right">SGST (<?php echo e($invoice->sgst_rate); ?>%)</td>
                    <td align="right">₹<?php echo e(number_format($invoice->sgst_amount, 2)); ?></td>
                </tr>
            <?php endif; ?>
            <?php if($invoice->igst_amount): ?>
                <tr>
                    <td colspan="4" align="right">IGST (<?php echo e($invoice->igst_rate); ?>%)</td>
                    <td align="right">₹<?php echo e(number_format($invoice->igst_amount, 2)); ?></td>
                </tr>
            <?php endif; ?>
            <?php if($invoice->discount): ?>
                <tr>
                    <td colspan="4" align="right">Discount</td>
                    <td align="right">₹<?php echo e(number_format($invoice->discount, 2)); ?></td>
                </tr>
            <?php endif; ?>
            <tr class="totals net-total-row">
                <td colspan="4">Net Total</td>
                <td>₹<?php echo e(number_format($invoice->net_amount, 2)); ?></td>
            </tr>
        </tbody>
    </table>

    <div class="amount-words">
        Amount (in words): <?php echo e($amountInWords); ?>

    </div>

    <div class="terms-image" style="margin-top: 10px; border-top: 2px solid #0986c6; padding-top: 10px;">
        <img src="<?php echo e(asset('assets/images/terms.png')); ?>" alt="Terms & Conditions" style="width: 100%; max-width: 100%;">
    </div>

    <div class="thanks-text">
        Thanks for Visit!
    </div>
    <div class="invoice-footer">
        Authorised Signatory<br><b><?php echo e($companySetting->company_name); ?></b>
    </div>
</div>
<?php /**PATH /var/www/html/resources/views/invoice/_document.blade.php ENDPATH**/ ?>