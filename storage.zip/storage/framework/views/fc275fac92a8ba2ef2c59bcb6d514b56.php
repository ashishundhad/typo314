<?php $__env->startSection('title', $pageTitle ?? 'Parties'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid parties-page">
    <div class="parties-topbar">
        <div>
            <h1 class="parties-topbar__title"><?php echo e($pageTitle ?? 'Parties'); ?></h1>
            <p class="parties-topbar__subtitle">Track who owes you, and who you owe, in one running ledger.</p>
        </div>
        <div class="parties-topbar__actions">
            <div class="parties-mini-stats">
                <div class="parties-mini-stat">
                    <div class="parties-mini-stat__label">Total</div>
                    <div class="parties-mini-stat__value"><?php echo e($parties->total()); ?></div>
                </div>
                <div class="parties-mini-stat">
                    <div class="parties-mini-stat__label">You'll Give</div>
                    <div class="parties-mini-stat__value parties-mini-stat__value--give">₹<?php echo e(number_format($totalCredit, 2)); ?></div>
                </div>
                <div class="parties-mini-stat">
                    <div class="parties-mini-stat__label">You'll Get</div>
                    <div class="parties-mini-stat__value parties-mini-stat__value--get">₹<?php echo e(number_format($totalDebit, 2)); ?></div>
                </div>
            </div>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('parties.create')): ?>
                <button type="button" class="btn btn-primary" data-target="#addnewPartyModal" data-toggle="modal">
                    <i class="mdi mdi-plus-circle-outline"></i> Add Party
                </button>
            <?php endif; ?>
        </div>
    </div>

    <div class="sales-card">
        <div class="sales-card__header">
            <div>
                <h4 class="sales-card__title"><?php echo e($pageTitle ?? 'Parties'); ?> Register</h4>
                <p class="sales-card__subtitle">Search by name or phone, then filter by type.</p>
            </div>
        </div>

        <form action="<?php echo e($formAction); ?>" method="GET" id="filterparties" class="sales-filter-form">
            <div class="form-row align-items-end">
                <div class="form-group col-md-6 mb-2 mb-md-0">
                    <div class="sales-search-group">
                        <input type="text" class="form-control" placeholder="Search by name or phone.." name="search"
                            value="<?php echo e($search ?? ''); ?>" id="searchparties">
                        <button class="btn btn-primary" type="submit">
                            <i class="mdi mdi-magnify"></i> Search
                        </button>
                    </div>
                </div>
                <div class="form-group col-md-3 mb-0">
                    <select name="type" class="form-control" id="selecttype" onchange="document.getElementById('filterparties').submit();">
                        <option value="">All Types</option>
                        <option value="Customer" <?php if(($type ?? '') === 'Customer'): echo 'selected'; endif; ?>>Customer</option>
                        <option value="Supplier" <?php if(($type ?? '') === 'Supplier'): echo 'selected'; endif; ?>>Supplier</option>
                    </select>
                </div>
            </div>
        </form>

        <?php if(count($parties)): ?>
            <div class="table-responsive sales-table-wrap">
                <table class="table sales-table table-hover m-0">
                    <thead>
                        <tr>
                            <th>Party Name</th>
                            <th>Party Type</th>
                            <th class="text-right">Amount</th>
                            <th class="text-right">Action</th>
                        </tr>
                    </thead>

                    <tbody>
                        <?php $__currentLoopData = $parties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $party): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <div class="sales-product" style="display:flex; align-items:center; gap:10px;">
                                        <div class="avatar"><?php echo e(strtoupper(substr($party->party_name, 0, 1))); ?></div>
                                        <div>
                                            <div class="sales-customer__name"><?php echo e(ucfirst($party->party_name)); ?></div>
                                            <?php $lastTransaction = $party->transactions()->latest()->first(); ?>
                                            <small class="text-muted"><?php echo e($lastTransaction ? $lastTransaction->created_at->diffForHumans() : 'No activity yet'); ?></small>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <span class="badge <?php echo e($party->party_type === 'Supplier' ? 'badge-soft-info text-info' : 'badge-soft-primary text-primary'); ?> px-3 py-2"><?php echo e($party->party_type); ?></span>
                                </td>
                                <td class="text-right sales-amount">
                                    <?php if($party->balance > 0): ?>
                                        <span class="sales-amount__value" style="color:#1abc9c;">₹<?php echo e(number_format($party->balance, 2)); ?></span>
                                        <span class="sales-amount__label">You'll Give</span>
                                    <?php elseif($party->balance < 0): ?>
                                        <span class="sales-amount__value" style="color:#ef4444;">₹<?php echo e(number_format(abs($party->balance), 2)); ?></span>
                                        <span class="sales-amount__label">You'll Get</span>
                                    <?php else: ?>
                                        <span class="sales-amount__value">₹0.00</span>
                                    <?php endif; ?>
                                </td>
                                <td class="text-right sales-actions">
                                    <button type="button" data-id="<?php echo e($party->id); ?>" class="add-transaction-btn btn btn-light btn-sm" title="Add Transaction">
                                        <i class="mdi mdi-plus"></i>
                                    </button>
                                    <button type="button" data-id="<?php echo e($party->id); ?>" class="view-party-btn btn btn-light btn-sm" title="View">
                                        <i class="mdi mdi-eye-outline"></i>
                                    </button>
                                    <button data-id="<?php echo e($party->id); ?>" class="btn btn-light btn-sm edit-party" title="Edit">
                                        <i class="mdi mdi-square-edit-outline"></i>
                                    </button>
                                    <button type="button" class="btn btn-danger btn-sm delete-party" data-id="<?php echo e($party->id); ?>" title="Delete">
                                        <i class="mdi mdi-trash-can-outline"></i>
                                    </button>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>

            <div class="pagination-links px-3 pb-3">
                <?php echo e($parties->links('vendor.pagination.bootstrap-5')); ?>

            </div>
        <?php else: ?>
            <div class="sales-empty">
                <div class="sales-empty__icon">
                    <i class="mdi mdi-account-cash-outline"></i>
                </div>
                <h4>No <?php echo e(strtolower($pageTitle ?? 'parties')); ?> found</h4>
                <p>Try a different search or filter, or add your first one.</p>
            </div>
        <?php endif; ?>
    </div>
</div>

<!-- Party Detail Modal -->
<div class="modal fade" id="partyDetailModal" tabindex="-1" role="dialog" aria-labelledby="partyDetailLabel">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="partyDetailLabel"></h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span>&times;</span>
                </button>
            </div>
            <div class="modal-body pt-0" id="party-detail-content">
                Loading...
            </div>
        </div>
    </div>
</div>

<!-- Add New Party Modal -->
<div class="modal fade" id="addnewPartyModal" tabindex="-1" role="dialog" aria-labelledby="newpartyLabel">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="newpartyLabel">Add New Party</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span>&times;</span>
                </button>
            </div>
            <div class="modal-body pt-0" id="newpartyform-content">
                <form class="form-horizontal row g-3" method="post" id="addNewPartyForm" action="<?php echo e(route('parties.store')); ?>">
                    <input type="hidden" name="id" id="partyID">
                    <?php echo csrf_field(); ?>
                    <div class="col-md-6 mb-3">
                        <label for="party_name" class="form-label">Party Name <span class="text-danger">*</span></label>
                        <input type="text" id="party_name" class="form-control <?php $__errorArgs = ['party_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="party_name" value="<?php echo e(old('party_name')); ?>" required tabindex="1" placeholder="Enter Name">
                        <?php $__errorArgs = ['party_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <ul class="parsley-errors-list filled">
                                <li class="parsley-required"><?php echo e($message); ?></li>
                            </ul>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label for="mobileno" class="form-label">Mobile Number</label>
                        <input type="number" id="mobileno" class="form-control" name="phone" value="<?php echo e(old('phone')); ?>" tabindex="2" placeholder="Enter mobile number">
                    </div>
                    <div class="col-md-6 mb-3">
                        <label for="email" class="form-label">Email</label>
                        <input type="text" id="email" class="form-control" name="email" value="<?php echo e(old('email')); ?>" tabindex="3" placeholder="Enter email">
                    </div>
                    <div class="col-md-6 mb-3">
                        <label for="party_type" class="form-label">Party Type</label>
                        <select id="party_type" class="form-control" name="party_type" tabindex="4">
                            <option value="Customer" <?php if(($type ?? '') === 'Customer'): echo 'selected'; endif; ?>>Customer</option>
                            <option value="Supplier" <?php if(($type ?? '') !== 'Customer'): echo 'selected'; endif; ?>>Supplier</option>
                        </select>
                    </div>

                    <div class="text-left col-12">
                        <button type="submit" class="btn btn-primary waves-effect waves-light col-md-2 mb-2" tabindex="13"><i class="fe-check-circle mr-1"></i>Save</button>
                        <button type="reset" class="btn btn-danger waves-effect waves-light col-md-2 mb-2" tabindex="14"><i class="fe-x mr-1"></i>Cancel</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
<?php if(Session::has('message')): ?>
     var type = "<?php echo e(Session::get('alert-type','info')); ?>"
     switch(type){
        case 'info':
        toastr.info(" <?php echo e(Session::get('message')); ?> ");
        break;

        case 'success':
        toastr.success(" <?php echo e(Session::get('message')); ?> ");
        break;

        case 'warning':
        toastr.warning(" <?php echo e(Session::get('message')); ?> ");
        break;

        case 'error':
        toastr.error(" <?php echo e(Session::get('message')); ?> ");
        break;
     }
<?php endif; ?>
</script>

<script>
    $(document).ready(function () {
        // Handle delete button click
        $('.delete-party').on('click', function () {
            var partyId = $(this).data('id');
            var deleteUrl = '/admin/parties/delete/' + partyId;

            Swal.fire({
                title: 'Are you sure?',
                text: "You won't be able to revert this!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Yes, delete it!',
                cancelButtonText: 'Cancel'
            }).then((result) => {
                if (result.isConfirmed) {
                    var form = $('<form method="POST" action="' + deleteUrl + '"></form>');
                    form.append('<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">');
                    $('body').append(form);
                    form.submit();
                }
            });
        });

        /* view Party detail modal */
        $(document).on('click', '.view-party-btn', function () {
            const partyId = $(this).data('id');
            jQuery('#party-detail-content').html('Loading...');
            jQuery.ajax({
                url: "/admin/parties/partydetail/" + partyId,
                type: 'GET',
                success: function (response) {
                    $("#partyDetailLabel").html('Party Detail ID : #'+partyId);
                    $('#party-detail-content').html(response);
                    jQuery('#partyDetailModal').modal('show');
                    $('#partyDetailModal').on('hide.bs.modal', function () {
                        document.activeElement.blur();
                    });
                },
                error: function () {
                    $('#party-detail-content').html('<p class="text-danger">Failed to load data.</p>');
                }
            });
        });

        $(document).on('click', '.edit-party', function() {
            const partyID = $(this).data('id');

            $('#addNewPartyForm')[0].reset();
            $('#addNewPartyForm').validate().resetForm();
            $('#partyID').val(partyID);

            $.ajax({
                url: "/admin/parties/edit/" + partyID,
                type: 'GET',
                success: function(response) {
                    $('#addNewPartyForm #party_name').val(response.party_name);
                    $('#addNewPartyForm #mobileno').val(response.phone);
                    $('#addNewPartyForm #email').val(response.email);
                    $('#addNewPartyForm #party_type').val(response.party_type).trigger('change');
                    $('#addNewPartyForm #address').html(response.address);
                    $('#addNewPartyForm #partyID').val(response.id);

                    $('#addnewPartyModal').modal('show');
                },
                error: function(xhr) {
                    toastr.error('Error fetching transaction details');
                }
            });
        })

        $("#addNewPartyForm").validate({
            rules: {
                party_name: "required"
            },
            messages: {
                party_name: "Please Enter Party"
            },
            submitHandler: function(form) {
                var formData = $(form).serialize();
                $.ajax({
                    url: $(form).attr('action'),
                    type: 'POST',
                    data: formData,
                    success: function(response) {
                        toastr.success(response.message);
                        $('#addnewPartyModal').modal('hide');

                        setTimeout(() => {
                            $('#addnewPartyModal').removeClass('show').hide();
                            $('body').removeClass('modal-open');
                            $('.modal-backdrop').remove();
                        }, 300);

                        $('#addNewPartyForm')[0].reset();

                        setTimeout(function () {
                            location.reload();
                        }, 1200);
                    },
                    error: function(xhr) {
                        toastr.error('Error storing transaction');
                    }
                });
                return false;
            }
        });
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/html/resources/views/party/index.blade.php ENDPATH**/ ?>