<?php if($invoiceDocuments->isNotEmpty()): ?>
    <div class="table-responsive">
        <table class="table documents-page-table">
            <thead>
                <tr>
                    <th>Type</th>
                    <th>Number</th>
                    <th>Customer</th>
                    <th>Invoice</th>
                    <th>Uploaded</th>
                    <th class="text-right">Action</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $invoiceDocuments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $document): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><span class="documents-page-card__type"><?php echo e($document->document_type_label); ?></span></td>
                        <td>
                            <?php if($document->document_number): ?>
                                <span class="invoice-preview__document-number" data-full="<?php echo e($document->document_number); ?>" data-masked="<?php echo e($document->masked_number); ?>"><?php echo e($document->masked_number); ?></span>
                                <button type="button" class="invoice-preview__document-reveal" title="Show / hide full number">
                                    <i class="mdi mdi-eye-outline"></i>
                                </button>
                            <?php else: ?>
                                <span class="text-muted">—</span>
                            <?php endif; ?>
                        </td>
                        <td><?php echo e($document->customer->name ?? 'Unknown Customer'); ?></td>
                        <td>
                            <?php if($document->invoice): ?>
                                <a href="<?php echo e(route('invoice-detail', $document->invoice_id)); ?>" target="_blank">#<?php echo e($document->invoice->invoice_no); ?></a>
                            <?php else: ?>
                                <span class="text-muted">—</span>
                            <?php endif; ?>
                        </td>
                        <td class="documents-page-table__date"><?php echo e($document->created_at->format('d M Y, h:i A')); ?></td>
                        <td class="text-right">
                            <a href="<?php echo e($document->image_url); ?>" target="_blank" class="btn btn-sm btn-primary documents-page-view-btn">
                                <i class="mdi mdi-eye-outline mr-1"></i>View
                            </a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>

    <div class="documents-page-pagination">
        <?php echo e($invoiceDocuments->links()); ?>

    </div>
<?php else: ?>
    <div class="documents-page-empty">
        <i class="mdi mdi-file-document-outline"></i>
        <p>No invoice documents found.</p>
    </div>
<?php endif; ?>
<?php /**PATH /var/www/html/resources/views/documents/_invoice-documents-list.blade.php ENDPATH**/ ?>