<?php $__env->startSection('title'); ?>
    Documents
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="container-fluid documents-page-shell">
        <div class="documents-page-hero">
            <div class="row align-items-center">
                <div class="col-lg-8">
                    <h1 class="documents-page-hero__title mb-0">Documents</h1>
                    <p class="documents-page-hero__text">Every identity and receipt document uploaded against an invoice or a purchase, in one place.</p>
                </div>
                <div class="col-lg-4 text-lg-right">
                    <div class="documents-page-hero__badge mt-3 mt-lg-0">
                        <i class="mdi mdi-file-document-multiple-outline"></i>
                        <span><?php echo e($invoiceDocumentCount + $purchaseDocumentCount); ?> Documents</span>
                    </div>
                </div>
            </div>
        </div>

        <div class="card documents-page-card">
            <div class="card-body">
                <ul class="nav nav-tabs documents-page-tabs" id="documentsTabs" role="tablist">
                    <li class="nav-item">
                        <a class="nav-link <?php echo e($activeTab === 'invoice' ? 'active' : ''); ?>" id="invoice-tab" data-toggle="tab" href="#invoiceDocumentsPane" role="tab">
                            <i class="fa fa-file-invoice mr-1"></i>Invoice Documents
                            <span class="badge documents-page-tab-count"><?php echo e($invoiceDocumentCount); ?></span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php echo e($activeTab === 'purchase' ? 'active' : ''); ?>" id="purchase-tab" data-toggle="tab" href="#purchaseDocumentsPane" role="tab">
                            <i class="fa fa-shopping-cart mr-1"></i>Purchase Documents
                            <span class="badge documents-page-tab-count"><?php echo e($purchaseDocumentCount); ?></span>
                        </a>
                    </li>
                </ul>

                <div class="tab-content documents-page-tab-content">
                    <div class="tab-pane fade <?php echo e($activeTab === 'invoice' ? 'show active' : ''); ?>" id="invoiceDocumentsPane" role="tabpanel">
                        <form method="GET" id="invoiceDocumentsSearchForm" action="<?php echo e(route('documents.index')); ?>" class="documents-page-search">
                            <input type="hidden" name="tab" value="invoice">
                            <div class="documents-page-search__input-group">
                                <i class="mdi mdi-magnify"></i>
                                <input type="text" id="invoice-documents-search" name="invoice_search" class="form-control" value="<?php echo e($invoiceSearch); ?>" placeholder="Search by customer, invoice no, or document number">
                            </div>
                        </form>

                        <div id="invoiceDocumentsList">
                            <?php echo $__env->make('documents._invoice-documents-list', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                        </div>
                    </div>

                    <div class="tab-pane fade <?php echo e($activeTab === 'purchase' ? 'show active' : ''); ?>" id="purchaseDocumentsPane" role="tabpanel">
                        <form method="GET" id="purchaseDocumentsSearchForm" action="<?php echo e(route('documents.index')); ?>" class="documents-page-search">
                            <input type="hidden" name="tab" value="purchase">
                            <div class="documents-page-search__input-group">
                                <i class="mdi mdi-magnify"></i>
                                <input type="text" id="purchase-documents-search" name="purchase_search" class="form-control" value="<?php echo e($purchaseSearch); ?>" placeholder="Search by device model, IMEI, supplier, or document number">
                            </div>
                        </form>

                        <div id="purchaseDocumentsList">
                            <?php echo $__env->make('documents._purchase-documents-list', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        (function () {
            function wireTab(options) {
                var $searchInput = $(options.searchInputSelector);
                var $list = $(options.listSelector);
                var searchDebounce = null;
                var activeRequest = null;

                function loadResults(query) {
                    if (activeRequest) {
                        activeRequest.abort();
                    }

                    activeRequest = $.ajax({
                        url: options.ajaxUrl,
                        method: 'GET',
                        data: query,
                        success: function (response) {
                            $list.html(response);
                        },
                        complete: function () {
                            activeRequest = null;
                        }
                    });
                }

                if ($searchInput.length) {
                    $searchInput.on('input', function () {
                        clearTimeout(searchDebounce);
                        var value = $(this).val();

                        searchDebounce = setTimeout(function () {
                            loadResults(options.paramName + '=' + encodeURIComponent(value));
                        }, 400);
                    });
                }

                $(document).on('click', options.listSelector + ' .pagination a', function (event) {
                    event.preventDefault();
                    var url = new URL($(this).attr('href'), window.location.origin);
                    var params = new URLSearchParams(url.search);
                    params.set(options.paramName, $searchInput.val());
                    loadResults(params.toString());
                });
            }

            wireTab({
                searchInputSelector: '#invoice-documents-search',
                listSelector: '#invoiceDocumentsList',
                ajaxUrl: '<?php echo e(route('documents.invoice')); ?>',
                paramName: 'invoice_search'
            });

            wireTab({
                searchInputSelector: '#purchase-documents-search',
                listSelector: '#purchaseDocumentsList',
                ajaxUrl: '<?php echo e(route('documents.purchase')); ?>',
                paramName: 'purchase_search'
            });

            $('#documentsTabs a[data-toggle="tab"]').on('shown.bs.tab', function (event) {
                var tab = $(event.target).attr('id') === 'purchase-tab' ? 'purchase' : 'invoice';

                if (window.history && window.history.replaceState) {
                    var url = new URL(window.location.href);
                    url.searchParams.set('tab', tab);
                    window.history.replaceState(null, '', url.toString());
                }
            });
        })();
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/html/resources/views/documents/index.blade.php ENDPATH**/ ?>