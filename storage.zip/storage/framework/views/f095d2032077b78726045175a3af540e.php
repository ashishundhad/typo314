<?php $__env->startSection('title'); ?>
    Stock Detail: #<?php echo e($purchase->id); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <div class="page-title-box">
                    <h4 class="page-title">Stock Detail ID : #<?php echo e($purchase->id); ?></h4>
                </div>
            </div>
        </div>

        <?php echo $__env->make('purchase._detail_content', ['purchase' => $purchase], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/html/resources/views/purchase/purchasedetail.blade.php ENDPATH**/ ?>