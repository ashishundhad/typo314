<?php $__env->startSection('title'); ?>
    Dashboard
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid dashboard-shell">
        <div class="dashboard-hero">
            <div class="row align-items-center">
                <div class="col-lg-8">
                    <h1 class="dashboard-hero__title">
                        <span id="greeting">Welcome</span>, <?php echo e(Auth()->user()->name); ?>

                    </h1>
                </div>
                <div class="col-lg-4">
                    <div class="dashboard-clock float-lg-right">
                        <div class="dashboard-clock__time" id="currentTime">--:--:--</div>
                        <p class="dashboard-clock__date mb-0">
                            <i class="mdi mdi-calendar-month-outline mr-1"></i><?php echo e(now()->format('d M Y')); ?>

                        </p>
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-6 col-lg-4 col-xl mb-3">
                <a href="<?php echo e(route('allpurchases')); ?>" class="d-block text-decoration-none">
                    <div class="card dashboard-stat dashboard-stat--teal">
                        <div class="card-body">
                            <div class="dashboard-stat__top">
                                <div class="dashboard-stat__icon">
                                    <i class="fe-layers"></i>
                                </div>
                                <div class="dashboard-stat__label">Stocks in Hand</div>
                            </div>
                            <div class="dashboard-stat__value">
                                <span data-plugin="counterup"><?php echo e($stocksInHand); ?></span>
                            </div>
                        </div>
                    </div>
                </a>
            </div>

            <div class="col-md-6 col-lg-4 col-xl mb-3">
                <a href="<?php echo e(route('allpurchases')); ?>" class="d-block text-decoration-none">
                    <div class="card dashboard-stat dashboard-stat--purple">
                        <div class="card-body">
                            <div class="dashboard-stat__top">
                                <div class="dashboard-stat__icon">
                                    <i class="fe-archive"></i>
                                </div>
                                <div class="dashboard-stat__label">Total Stock Value</div>
                            </div>
                            <div class="dashboard-stat__value">
                                ₹<span data-plugin="counterup"><?php echo e($totalStockValue); ?></span>
                            </div>
                        </div>
                    </div>
                </a>
            </div>

            <div class="col-md-6 col-lg-4 col-xl mb-3">
                <div class="card dashboard-stat dashboard-stat--indigo">
                    <div class="card-body">
                        <div class="dashboard-stat__top">
                            <div class="dashboard-stat__icon">
                                <i class="fe-calendar"></i>
                            </div>
                            <div class="dashboard-stat__label"><?php echo e($currentMonth); ?> Sales</div>
                        </div>
                        <div class="dashboard-stat__value">
                            ₹<span data-plugin="counterup"><?php echo e($currentMonthSales); ?></span>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-md-6 col-lg-4 col-xl mb-3">
                <div class="card dashboard-stat dashboard-stat--cyan">
                    <div class="card-body">
                        <div class="dashboard-stat__top">
                            <div class="dashboard-stat__icon">
                                <i class="fe-shopping-bag"></i>
                            </div>
                            <div class="dashboard-stat__label">Items Sold in <?php echo e($currentMonth); ?></div>
                        </div>
                        <div class="dashboard-stat__value">
                            <span data-plugin="counterup"><?php echo e($numberOfProductsSoldInMonth); ?></span>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-md-6 col-lg-4 col-xl mb-3">
                <div class="card dashboard-stat dashboard-stat--amber">
                    <div class="card-body">
                        <div class="dashboard-stat__top">
                            <div class="dashboard-stat__icon">
                                <i class="fe-dollar-sign"></i>
                            </div>
                            <div class="dashboard-stat__label">Today's Sales</div>
                        </div>
                        <div class="dashboard-stat__value">
                            <span data-plugin="counterup"><?php echo e($totalSales); ?></span>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
        <div class="col-lg-8 mb-3 mb-lg-0">
        <div class="card dashboard-section h-100">
            <div class="card-body">
                <div class="dashboard-section__top dashboard-section__top--sales">
                    <div>
                        <h2 class="dashboard-section__title">Recent Sales [<?php echo e($totalRecords); ?>]</h2>
                    </div>

                    <form action="<?php echo e(route('dashboard')); ?>" method="GET" id="dashboardfilter" class="dashboard-filter dashboard-filter--inline">
                        <select name="filtertime" id="findbystatus" class="form-control">
                            <option value="">Select time period</option>
                            <option value="today" <?php if($filtertime == 'today'): echo 'selected'; endif; ?>>Today</option>
                            <option value="yesterday" <?php if($filtertime == 'yesterday'): echo 'selected'; endif; ?>>Yesterday</option>
                            <option value="lastweek" <?php if($filtertime == 'lastweek'): echo 'selected'; endif; ?>>Last Week</option>
                            <option value="month" <?php if($filtertime == 'month'): echo 'selected'; endif; ?>>This Month</option>
                            <option value="custom" <?php if($filtertime == 'custom'): echo 'selected'; endif; ?>>Custom Range</option>
                        </select>

                        <div class="dashboard-filter__date-group <?php if($filtertime != 'custom'): ?> is-hidden <?php endif; ?>" id="fromdate-group">
                            <label class="dashboard-filter__label" for="fromdate">From Date</label>
                            <input type="date" id="fromdate" name="fromdate"
                                class="form-control <?php if($filtertime == 'custom'): ?> showdefault <?php endif; ?>"
                                value="<?php echo e($fromdate); ?>" style="display:none;">
                        </div>

                        <div class="dashboard-filter__date-group <?php if($filtertime != 'custom'): ?> is-hidden <?php endif; ?>" id="todate-group">
                            <label class="dashboard-filter__label" for="todate">To Date</label>
                            <input type="date" id="todate" name="todate"
                                class="form-control <?php if($filtertime == 'custom'): ?> showdefault <?php endif; ?>"
                                value="<?php echo e($todate); ?>" style="display:none;">
                        </div>

                        <button type="submit" class="btn btn-primary dashboard-btn">Apply Filter</button>
                    </form>
                </div>

                <div class="table-responsive" id="sales-table-container">
                    <?php if(count($todaysSales)): ?>
                        <table class="table sales-table">
                            <thead>
                                <tr>
                                    <th>Sr. No</th>
                                    <th>Item Detail</th>
                                    <th>Customer</th>
                                    <th>Payment</th>
                                    <th>Date</th>
                                    <th class="text-right">Amount</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $todaysSales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $sale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td>
                                            <a href="<?php echo e(route('saledetail', $sale->id)); ?>" class="sales-index">
                                                #<?php echo e(($todaysSales->currentPage() - 1) * $todaysSales->perPage() + $key + 1); ?>

                                            </a>
                                        </td>
                                        <td>
                                            <?php if($sale->items->isEmpty()): ?>
                                                <div class="sales-product">
                                                    <div class="sales-product__title">No items</div>
                                                    <div class="sales-product__meta">
                                                        <span class="sales-chip">Sale record without attached item rows</span>
                                                    </div>
                                                </div>
                                            <?php else: ?>
                                                <?php $__currentLoopData = $sale->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php
                                                        $p = $item->purchase;
                                                    ?>
                                                    <div class="sales-product">
                                                        <div class="sales-product__title"><?php echo e($p->model ?? 'Unknown Model'); ?></div>
                                                        <!-- <div class="sales-product__meta">
                                                            <span class="sales-chip">Color: <?php echo e($p->color ?? '-'); ?></span>
                                                            <span class="sales-chip">Storage: <?php echo e($p->storage ?? '-'); ?></span>
                                                            <span class="sales-chip">IMEI: <?php echo e($p->imei ?? '-'); ?></span>
                                                            <span class="sales-chip">Qty: <?php echo e($item->qty ?? 1); ?></span>
                                                        </div> -->
                                                    </div>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <div class="sales-customer__name"><?php echo e($sale->customer_name ?: 'Walk-in Customer'); ?></div>
                                            <?php if($sale->customer_no): ?>
                                                <div class="sales-customer__contact">
                                                    <a href="tel:<?php echo e($sale->customer_no); ?>"><?php echo e($sale->customer_no); ?></a>
                                                </div>
                                            <?php else: ?>
                                                <div class="text-muted">No contact number</div>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php if($sale->payment_type == 'Cash'): ?>
                                                <span class="badge badge-soft-primary text-primary px-3 py-2"><?php echo e($sale->payment_type); ?></span>
                                            <?php elseif($sale->payment_type == 'Online'): ?>
                                                <span class="badge badge-soft-info text-info px-3 py-2"><?php echo e($sale->payment_type); ?></span>
                                            <?php elseif($sale->payment_type == 'Credit Card'): ?>
                                                <span class="badge badge-soft-warning text-warning px-3 py-2"><?php echo e($sale->payment_type); ?></span>
                                            <?php else: ?>
                                                <span class="badge badge-light px-3 py-2"><?php echo e($sale->payment_type); ?></span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <div class="sales-date"><?php echo e(Carbon\Carbon::parse($sale->invoice_date)->format('d M Y')); ?></div>
                                        </td>
                                        <td class="sales-amount">
                                            <span class="sales-amount__value">₹<?php echo e($sale->net_amount); ?></span>
                                            <!-- <span class="sales-amount__label">Net amount</span> -->
                                        </td>
                                        <td class="sales-actions">
                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('sales.view')): ?>
                                                <a href="<?php echo e(route('saledetail', $sale->id)); ?>" class="btn btn-light btn-sm mr-2" title="View">
                                                    <i class="mdi mdi-eye-outline"></i>
                                                </a>
                                            <?php endif; ?>
                                            <form method="post" action="<?php echo e(route('delete-sale', $sale->id)); ?>"
                                                class="dashboard-delete-sale-form"
                                                style="display:inline;">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="btn btn-sm btn-danger" title="Delete">
                                                    <i class="mdi mdi-trash-can-outline"></i>
                                                </button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>

                        <div class="pagination-links">
                            <?php echo e($todaysSales->appends(request()->query())->links('vendor.pagination.bootstrap-5')); ?>

                        </div>
                    <?php else: ?>
                        <div class="sales-empty">
                            <div class="sales-empty__icon">
                                <i class="mdi mdi-chart-timeline-variant"></i>
                            </div>
                            <h4>No sales found for this selection</h4>
                            <p>Try another date range, add stock, or create a new invoice to start recording activity.</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        </div>

        <div class="col-lg-4">
        <div class="card dashboard-section h-100">
            <div class="card-body">
                <div class="dashboard-section__top dashboard-section__top--stacked">
                    <div class="dashboard-section__top-row">
                        <h2 class="dashboard-section__title" id="paymentBreakdownTitle">How customers paid today</h2>
                        <select id="paymentPeriod" class="form-control dashboard-period-select">
                            <option value="today" selected>Today</option>
                            <option value="yesterday">Yesterday</option>
                            <option value="week">This Week</option>
                            <option value="month">This Month</option>
                        </select>
                    </div>

                </div>

                <div id="paymentBreakdownEmpty" class="sales-empty" <?php if(! $todaysPaymentBreakdown->isEmpty()): ?> style="display:none;" <?php endif; ?>>
                    <div class="sales-empty__icon">
                        <i class="mdi mdi-chart-donut"></i>
                    </div>
                    <h4>No payments yet today</h4>
                    <p>The breakdown will appear here once today's invoices start coming in.</p>
                </div>

                <div id="paymentBreakdownWrap" <?php if($todaysPaymentBreakdown->isEmpty()): ?> style="display:none;" <?php endif; ?>>
                    <div id="paymentBreakdownChart"></div>
                    <div class="payment-breakdown-legend" id="paymentBreakdownLegend">
                        <?php $__currentLoopData = $todaysPaymentBreakdown; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="payment-breakdown-legend__item">
                                <span class="payment-breakdown-legend__label"><?php echo e($row['label']); ?></span>
                                <span class="payment-breakdown-legend__value"><?php echo e($row['percent']); ?>%</span>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
        </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script src="<?php echo e(asset('assets/libs/apexcharts/apexcharts.min.js')); ?>"></script>
    <script>
        const paymentBreakdownChart = new ApexCharts(document.getElementById('paymentBreakdownChart'), {
            chart: {
                type: 'donut',
                height: 260,
            },
            labels: <?php echo json_encode($todaysPaymentBreakdown->pluck('label'), 15, 512) ?>,
            series: <?php echo json_encode($todaysPaymentBreakdown->pluck('amount'), 15, 512) ?>,
            colors: ['#2f5bff', '#1abc9c', '#ffbc00', '#ef4444', '#8695a1'],
            legend: {
                show: false,
            },
            dataLabels: {
                formatter: function (val) {
                    return val.toFixed(1) + '%';
                },
            },
            tooltip: {
                y: {
                    formatter: function (val) {
                        return '₹' + Number(val).toLocaleString('en-IN');
                    },
                },
            },
        });
        paymentBreakdownChart.render();

        const paymentPeriodLabels = {
            today: 'Paid by customers today',
            yesterday: 'Paid by customers yesterday',
            week: 'Paid by customers this week',
            month: 'Paid by customers this month',
        };
        const paymentBreakdownUrl = <?php echo json_encode(route('dashboard.payment-breakdown'), 15, 512) ?>;

        function loadPaymentBreakdown(period) {
            const $title = $('#paymentBreakdownTitle');
            const $empty = $('#paymentBreakdownEmpty');
            const $wrap = $('#paymentBreakdownWrap');
            const $legend = $('#paymentBreakdownLegend');

            $title.text(paymentPeriodLabels[period] || paymentPeriodLabels.today);

            $.ajax({
                url: paymentBreakdownUrl,
                type: 'GET',
                data: { period: period },
                success: function (response) {
                    const breakdown = response.breakdown || [];

                    if (!breakdown.length) {
                        $wrap.hide();
                        $empty.show();
                        return;
                    }

                    $empty.hide();
                    $wrap.show();

                    paymentBreakdownChart.updateOptions({
                        labels: breakdown.map(function (row) { return row.label; }),
                    });
                    paymentBreakdownChart.updateSeries(breakdown.map(function (row) { return row.amount; }));

                    $legend.empty();
                    breakdown.forEach(function (row) {
                        $legend.append(
                            '<div class="payment-breakdown-legend__item">' +
                                '<span class="payment-breakdown-legend__label"></span>' +
                                '<span class="payment-breakdown-legend__value"></span>' +
                            '</div>'
                        );
                        const $item = $legend.children().last();
                        $item.find('.payment-breakdown-legend__label').text(row.label);
                        $item.find('.payment-breakdown-legend__value').text(row.percent + '%');
                    });
                },
            });
        }

        $('#paymentPeriod').on('change', function () {
            loadPaymentBreakdown($(this).val());
        });

        function updateTime() {
            const now = new Date();
            const rawHours = now.getHours();
            const period = rawHours >= 12 ? 'PM' : 'AM';
            const hours = String(((rawHours + 11) % 12) + 1).padStart(2, '0');
            const minutes = String(now.getMinutes()).padStart(2, '0');
            const seconds = String(now.getSeconds()).padStart(2, '0');

            const currentTime = hours + ":" + minutes + ":" + seconds + " " + period;
            document.getElementById('currentTime').innerText = currentTime;
        }

        updateTime();
        setInterval(updateTime, 1000);

        const filterTimeSelect = document.getElementById('findbystatus');
        const fromDateInput = document.getElementById('fromdate');
        const toDateInput = document.getElementById('todate');
        const fromDateGroup = document.getElementById('fromdate-group');
        const toDateGroup = document.getElementById('todate-group');

        function toggleCustomDateFields() {
            const isCustomRange = filterTimeSelect && filterTimeSelect.value === 'custom';

            [fromDateInput, toDateInput].forEach((field) => {
                if (!field) {
                    return;
                }

                field.style.display = isCustomRange ? 'block' : 'none';
                field.classList.toggle('showdefault', isCustomRange);
            });

            [fromDateGroup, toDateGroup].forEach((group) => {
                if (!group) {
                    return;
                }

                group.classList.toggle('is-hidden', !isCustomRange);
            });
        }

        if (filterTimeSelect) {
            toggleCustomDateFields();
        }

        function refreshSalesTable(url) {
            const $container = $('#sales-table-container');

            if (!$container.length) {
                return;
            }

            $container.css('opacity', 0.5);

            $.ajax({
                url: url,
                type: 'GET',
                success: function (html) {
                    const $newContainer = $('<div>').html(html).find('#sales-table-container');

                    if ($newContainer.length) {
                        $container.html($newContainer.html());
                        window.history.pushState({}, '', url);
                    } else {
                        window.location.href = url;
                    }
                },
                error: function () {
                    window.location.href = url;
                },
                complete: function () {
                    $container.css('opacity', '');
                }
            });
        }

        $('#findbystatus').on('change', function () {
            toggleCustomDateFields();

            // Custom range still needs both dates picked, so wait for Apply Filter.
            if ($(this).val() !== 'custom') {
                refreshSalesTable($('#dashboardfilter').attr('action') + '?' + $('#dashboardfilter').serialize());
            }
        });

        $('#dashboardfilter').on('submit', function (event) {
            event.preventDefault();
            refreshSalesTable($(this).attr('action') + '?' + $(this).serialize());
        });

        // Pagination links are re-rendered on every AJAX swap, so listen on the
        // container itself rather than binding to links that no longer exist.
        $(document).on('click', '#sales-table-container .pagination-links a', function (event) {
            event.preventDefault();
            refreshSalesTable($(this).attr('href'));
        });

        // Delete-sale forms are also re-rendered on every AJAX swap, so this needs
        // event delegation instead of binding to the original forms directly.
        $(document).on('submit', '.dashboard-delete-sale-form', function (event) {
            event.preventDefault();
            const $form = $(this);

            Swal.fire({
                title: 'Delete this sale?',
                text: "This action can't be undone.",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#ef4444',
                cancelButtonColor: '#64748b',
                confirmButtonText: 'Yes, delete it',
                cancelButtonText: 'Cancel'
            }).then((result) => {
                if (result.isConfirmed) {
                    $.ajax({
                        url: $form.attr('action'),
                        type: 'POST',
                        data: $form.serialize(),
                        success: function () {
                            refreshSalesTable(window.location.href);
                        },
                        error: function () {
                            $form[0].submit();
                        }
                    });
                }
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/html/resources/views/dashboard.blade.php ENDPATH**/ ?>