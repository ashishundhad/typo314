<?php $__env->startSection('title'); ?>
    Purchase Report
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="container-fluid purchase-report-shell">
        <div class="purchase-report-hero">
            <div class="row align-items-center">
                <div class="col-lg-8">
                    <h1 class="purchase-report-hero__title">Purchase Items Report</h1>
                    <p class="purchase-report-hero__subtitle">
                        Review purchased inventory with date, supplier, device and cost details, then export the same filtered view as CSV or PDF.
                    </p>
                </div>
                <div class="col-lg-4">
                    <div class="purchase-report-actions">
                        <a href="<?php echo e(route('buy-export', request()->query())); ?>" class="btn btn-light purchase-report-btn">
                            <i class="mdi mdi-file-delimited mr-1"></i>CSV
                        </a>
                        <a href="<?php echo e(route('purchase-report-pdf', request()->query())); ?>" class="btn btn-outline-light purchase-report-btn">
                            <i class="mdi mdi-file-pdf-box mr-1"></i>PDF
                        </a>
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-6 col-xl-4 mb-3">
                <div class="card purchase-report-summary purchase-report-summary--cost">
                    <div class="card-body">
                        <div class="purchase-report-summary__label">Purchase Cost - <?php echo e($timePeriod); ?></div>
                        <div class="purchase-report-summary__value"><?php echo e(config('constant.currency')); ?><?php echo e(number_format($totalPurchaseAmount, 2)); ?></div>
                    </div>
                </div>
            </div>
            <!-- <div class="col-md-6 col-xl-3 mb-3">
                <div class="card purchase-report-summary purchase-report-summary--repair">
                    <div class="card-body">
                        <div class="purchase-report-summary__label">Repairing - <?php echo e($timePeriod); ?></div>
                        <div class="purchase-report-summary__value"><?php echo e(config('constant.currency')); ?><?php echo e(number_format($totalRepairingAmount, 2)); ?></div>
                    </div>
                </div>
            </div> -->
            <div class="col-md-6 col-xl-4 mb-3">
                <div class="card purchase-report-summary purchase-report-summary--value">
                    <div class="card-body">
                        <div class="purchase-report-summary__label">Stock Value - <?php echo e($timePeriod); ?></div>
                        <div class="purchase-report-summary__value"><?php echo e(config('constant.currency')); ?><?php echo e(number_format($totalStockValue, 2)); ?></div>
                    </div>
                </div>
            </div>
            <div class="col-md-6 col-xl-4 mb-3">
                <div class="card purchase-report-summary purchase-report-summary--sold">
                    <div class="card-body">
                        <div class="purchase-report-summary__label">Sold vs Available</div>
                        <div class="purchase-report-summary__value"><?php echo e($soldItems); ?> / <?php echo e($availableItems); ?></div>
                    </div>
                </div>
            </div>
        </div>

        <div class="card purchase-report-card">
            <div class="card-body">
                <h2 class="purchase-report-card__title">Purchased Items [<?php echo e($totalItems); ?>]</h2>
                <p class="purchase-report-card__subtitle">Apply filters to narrow the report, then export exactly what you see.</p>

                <div class="purchase-report-filter">
                    <form method="GET" id="purchase-report-form">
                        <div class="form-row align-items-end">
                            <div class="col-12 col-md-3 mb-3 mb-md-0">
                                <label class="purchase-report-label" for="purchase-period">Report Period</label>
                                <select name="period" class="form-control" id="purchase-period">
                                    <option value="alls" <?php if($period == 'alls'): echo 'selected'; endif; ?>>All Purchases</option>
                                    <option value="thismonth" <?php if($period == 'thismonth'): echo 'selected'; endif; ?>>This Month</option>
                                    <option value="lastmonth" <?php if($period == 'lastmonth'): echo 'selected'; endif; ?>>Last Month</option>
                                    <option value="thisyear" <?php if($period == 'thisyear'): echo 'selected'; endif; ?>>This Year</option>
                                    <option value="lastyear" <?php if($period == 'lastyear'): echo 'selected'; endif; ?>>Last Year</option>
                                    <option value="custom" <?php if($period == 'custom'): echo 'selected'; endif; ?>>Custom Range</option>
                                </select>
                            </div>
                            <div class="col-md-2 mb-3 mb-md-0 purchase-report-date-group <?php if($period == 'custom'): ?> showdefault <?php endif; ?>">
                                <label class="purchase-report-label" for="purchase-fromdate">From Date</label>
                                <input type="date" id="purchase-fromdate" name="fromdate" class="form-control" value="<?php echo e($fromdate); ?>">
                            </div>
                            <div class="col-md-2 mb-3 mb-md-0 purchase-report-date-group <?php if($period == 'custom'): ?> showdefault <?php endif; ?>">
                                <label class="purchase-report-label" for="purchase-todate">To Date</label>
                                <input type="date" id="purchase-todate" name="todate" class="form-control" value="<?php echo e($todate); ?>">
                            </div>
                            <div class="col-12 col-md-2 mb-3 mb-md-0">
                                <label class="purchase-report-label" for="purchase-status">Item Status</label>
                                <select name="status" class="form-control" id="purchase-status">
                                    <option value="" <?php if($status === ''): echo 'selected'; endif; ?>>All</option>
                                    <option value="available" <?php if($status === 'available'): echo 'selected'; endif; ?>>Available</option>
                                    <option value="sold" <?php if($status === 'sold'): echo 'selected'; endif; ?>>Sold</option>
                                </select>
                            </div>
                            <!-- <div class="col-12 col-md-3 mb-3 mb-md-0">
                                <label class="purchase-report-label" for="purchase-search">Search</label>
                                <input type="text" id="purchase-search" name="search" class="form-control" value="<?php echo e($search); ?>" placeholder="IMEI, model, supplier, phone">
                            </div> -->
                            <div class="col-12 col-md-2 mb-3 mb-md-0">
                                <label class="purchase-report-label d-none d-md-block">&nbsp;</label>
                                <div class="purchase-report-filter-actions">
                                    <button type="submit" class="btn btn-primary purchase-report-btn">
                                    Filter Report
                                    </button>
                                    <a href="<?php echo e(route('purchase-report')); ?>" class="btn btn-outline-danger purchase-report-btn">
                                    Clear
                                    </a>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>

                <div class="table-responsive">
                    <?php if($allPurchased->count()): ?>
                        <table class="table purchase-report-table">
                            <thead>
                                <tr>
                                    <th>Purchase Date</th>
                                    <th>Device</th>
                                    <th>Supplier</th>
                                    <th>Costing</th>
                                    <th>Status</th>
                                    <!-- <th>Notes</th> -->
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $allPurchased; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $purchase): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td>
                                            <span class="purchase-report-date"><?php echo e(\Carbon\Carbon::parse($purchase->purchase_date)->format('d/m/Y')); ?></span>
                                            <?php if($purchase->sell_date): ?>
                                                <div class="purchase-report-device__meta mt-2">Sold: <?php echo e(\Carbon\Carbon::parse($purchase->sell_date)->format('d/m/Y')); ?></div>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <div class="purchase-report-device__name"><?php echo e($purchase->model ?: 'Unnamed Device'); ?></div>
                                            <div class="purchase-report-device__meta">IMEI: <?php echo e($purchase->imei ?: 'N/A'); ?></div>
                                            <div class="purchase-report-device__meta">Storage: <?php echo e($purchase->storage ?: 'N/A'); ?> | Color: <?php echo e($purchase->color ?: 'N/A'); ?></div>
                                        </td>
                                        <td>
                                            <div class="purchase-report-source__name"><?php echo e($purchase->purchase_from ?: 'Unknown Supplier'); ?></div>
                                            <div class="purchase-report-source__meta">Phone: <?php echo e($purchase->contactno ?: 'N/A'); ?></div>
                                        </td>
                                        <td>
                                            <div class="purchase-report-money__label">Buy Cost</div>
                                            <div class="purchase-report-money__value"><?php echo e(config('constant.currency')); ?><?php echo e(number_format((float) $purchase->purchase_cost, 2)); ?></div>
                                            <!-- <div class="purchase-report-money__label">Repairing</div> -->
                                            <!-- <div class="purchase-report-money__value"><?php echo e(config('constant.currency')); ?><?php echo e(number_format((float) ($purchase->repairing_charge ?: 0), 2)); ?></div> -->
                                            <!-- <div class="purchase-report-money__label">Stock Value</div>
                                            <div class="purchase-report-money__value purchase-report-money__value--main"><?php echo e(config('constant.currency')); ?><?php echo e(number_format((float) $purchase->purchase_price, 2)); ?></div> -->
                                        </td>
                                        <td>
                                            <span class="purchase-report-status purchase-report-status--<?php echo e($purchase->is_sold ? 'sold' : 'available'); ?>">
                                                <?php echo e($purchase->is_sold ? 'Sold' : 'Available'); ?>

                                            </span>
                                        </td>
                                        <!-- <td>
                                            <div class="purchase-report-note"><?php echo e($purchase->remark ?: 'No notes recorded'); ?></div>
                                        </td> -->
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <div class="mt-3">
                            <?php echo e($allPurchased->appends(request()->query())->links('vendor.pagination.bootstrap-5')); ?>

                        </div>
                    <?php else: ?>
                        <div class="purchase-report-empty">
                            <div class="purchase-report-empty__icon">
                                <i class="mdi mdi-package-variant-closed"></i>
                            </div>
                            <h4>No purchases found</h4>
                            <p>Try another date range, status, or search term to view purchase activity.</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <script>
        (function () {
            const periodSelect = document.getElementById('purchase-period');
            const dateGroups = document.querySelectorAll('.purchase-report-date-group');

            function toggleCustomDateFields() {
                const showDates = periodSelect && periodSelect.value === 'custom';

                dateGroups.forEach(function (group) {
                    group.style.display = showDates ? 'block' : 'none';
                });
            }

            if (periodSelect) {
                periodSelect.addEventListener('change', toggleCustomDateFields);
                toggleCustomDateFields();
            }
        })();
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/html/resources/views/reports/purchase.blade.php ENDPATH**/ ?>