<?php
    $isModal = request()->ajax() || request()->boolean('modal');
    $documentRows = $purchase->document ? array_filter(explode(',', $purchase->document)) : [];
?>

<div class="purchase-detail-view">
    <div class="container-fluid">
        <div class="purchase-detail-hero">
            <div class="row align-items-center">
                <div class="col-lg-8">
                    <!-- <div class="purchase-detail-hero__eyebrow">Stock Overview</div> -->
                    <h3 class="purchase-detail-hero__title mb-0"><?php echo e($purchase->model); ?> 
                        <span class="purchase-detail-status <?php echo e($purchase->status_label === 'Sold' ? 'purchase-detail-status--sold' : 'purchase-detail-status--available'); ?>">
                            <?php echo e($purchase->status_label); ?>

                        </span>
                    </h3>
                </div>
                <div class="col-lg-4 text-lg-right mt-3 mt-lg-0">
                    <?php if (! ($isModal)): ?>
                        <a href="javascript:history.back()" class="btn btn-light btn-sm">
                            <i class="mdi mdi-keyboard-backspace mr-1"></i>Back
                        </a>
                    <?php endif; ?>
                    <!-- <div class="purchase-detail-hero__meta <?php echo e($isModal ? '' : 'justify-content-lg-end'); ?>">
                        <span class="purchase-detail-pill">
                            <i class="mdi mdi-pound-box-outline"></i>ID #<?php echo e($purchase->id); ?>

                        </span>
                        <span class="purchase-detail-status <?php echo e($purchase->status_label === 'Sold' ? 'purchase-detail-status--sold' : 'purchase-detail-status--available'); ?>">
                            <?php echo e($purchase->status_label); ?>

                        </span>
                    </div> -->
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-xl-6 col-lg-6 mb-3">
                <div class="card purchase-detail-card">
                    <div class="card-body">
                        <h4 class="purchase-detail-card__title">Device Information</h4>
                        <div class="table-responsive">
                            <table class="table purchase-detail-table">
                                <tbody>
                                    <?php if($purchase->device_type): ?>
                                        <tr>
                                            <th>Device Type</th>
                                            <td>
                                                <?php if($purchase->device_type == 'Phone'): ?>
                                                    <i class="ti-mobile mr-1"></i>
                                                <?php endif; ?>
                                                <?php if($purchase->device_type == 'Tablet'): ?>
                                                    <i class="ti-tablet mr-1"></i>
                                                <?php endif; ?>
                                                <?php if($purchase->device_type == 'Laptop'): ?>
                                                    <i class="mdi mdi-laptop-mac mr-1"></i>
                                                <?php endif; ?>
                                                <?php if($purchase->device_type == 'Accessories'): ?>
                                                    <i class="mdi mdi-ipod mr-1"></i>
                                                <?php endif; ?>
                                                <?php echo e($purchase->device_type); ?>

                                            </td>
                                        </tr>
                                    <?php endif; ?>
                                    <?php if($purchase->imei): ?>
                                        <tr>
                                            <th>IMEI</th>
                                            <td><?php echo e($purchase->imei); ?></td>
                                        </tr>
                                    <?php endif; ?>
                                    <?php if($purchase->sku): ?>
                                        <tr>
                                            <th>SKU</th>
                                            <td><?php echo e($purchase->sku); ?></td>
                                        </tr>
                                    <?php endif; ?>
                                    <?php if($purchase->isBulkTracked()): ?>
                                        <tr>
                                            <th>Total Quantity</th>
                                            <td><?php echo e($purchase->total_units); ?></td>
                                        </tr>
                                        <tr>
                                            <th>Available Quantity</th>
                                            <td><?php echo e($purchase->available_units); ?></td>
                                        </tr>
                                    <?php endif; ?>
                                    <?php if($purchase->storage): ?>
                                        <tr>
                                            <th>Storage</th>
                                            <td><?php echo e($purchase->storage); ?> GB</td>
                                        </tr>
                                    <?php endif; ?>
                                    <?php if($purchase->color): ?>
                                        <tr>
                                            <th>Color</th>
                                            <td><?php echo e(ucfirst($purchase->color)); ?></td>
                                        </tr>
                                    <?php endif; ?>
                                    <?php if($purchase->purchase_from): ?>
                                        <tr>
                                            <th>Purchase From</th>
                                            <td><?php echo e(ucfirst($purchase->purchase_from)); ?></td>
                                        </tr>
                                    <?php endif; ?>
                                    <?php if($purchase->contactno): ?>
                                        <tr>
                                            <th>Mobile No</th>
                                            <td><?php echo e($purchase->contactno); ?></td>
                                        </tr>
                                    <?php endif; ?>
                                    <?php if($purchase->condition): ?>
                                        <tr>
                                            <th>Condition</th>
                                            <td><?php echo e($purchase->condition); ?></td>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-xl-6 col-lg-6 mb-3">
                <div class="card purchase-detail-card">
                    <div class="card-body">
                        <h4 class="purchase-detail-card__title">Pricing & Purchase Info</h4>
                        <div class="table-responsive">
                            <table class="table purchase-detail-table">
                                <tbody>
                                    <tr>
                                        <th>Purchase Cost</th>
                                        <td><span class="purchase-detail-value"><?php echo e('₹' . number_format($purchase->purchase_cost)); ?></span></td>
                                    </tr>
                                    <?php if($purchase->repairing_charge > 0): ?>
                                    <tr>
                                        <th>Repairing Charge</th>
                                        <td><span class="purchase-detail-value"><?php echo e('₹' . number_format($purchase->repairing_charge)); ?></span></td>
                                    </tr>
                                    <?php endif; ?>
                                    <tr>
                                        <th><?php echo e($purchase->isBulkTracked() ? 'Unit Cost' : 'Total Cost'); ?></th>
                                        <td><span class="purchase-detail-value"><?php echo e('₹' . number_format($purchase->purchase_price)); ?></span></td>
                                    </tr>
                                    <?php if($purchase->isBulkTracked()): ?>
                                    <tr>
                                        <th>Total Stock Value</th>
                                        <td><span class="purchase-detail-value"><?php echo e('₹' . number_format($purchase->total_stock_value)); ?></span></td>
                                    </tr>
                                    <?php endif; ?>
                                    <?php if($purchase->remark): ?>
                                        <tr>
                                            <th>Remark</th>
                                            <td><?php echo e($purchase->remark); ?></td>
                                        </tr>
                                    <?php endif; ?>
                                    <tr>
                                        <th>Purchase Date</th>
                                        <td><?php echo e(\Carbon\Carbon::parse($purchase->purchase_date)->format('d/m/Y')); ?></td>
                                    </tr>
                                    <tr>
                                        <th>Purchased By</th>
                                        <td><?php echo e($purchase->user && $purchase->user->name ? ucfirst($purchase->user->name) : 'Guest'); ?></td>
                                    </tr>
                                    <tr>
                                        <th>Brand Warrenty</th>
                                        <td>
                                            <?php if($purchase->warrentydate): ?>
                                                <?php echo e(\Carbon\Carbon::parse($purchase->warrentydate)->format('d-m-Y')); ?>

                                            <?php else: ?>
                                                Non Warrenty
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <?php if(!empty($documentRows)): ?>
            <div class="card purchase-detail-card purchase-detail-docs">
                <div class="card-body">
                    <h4 class="purchase-detail-card__title">Documents</h4>
                    <div class="row">
                        <?php $__currentLoopData = $documentRows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-sm-6 col-lg-3 mb-3">
                                <a href="<?php echo e(asset('documents/purchases/' . $row)); ?>" class="purchase-detail-doc" title="<?php echo e($purchase->model); ?>" target="_blank">
                                    <div class="purchase-detail-doc__media">
                                        <?php if(pathinfo($row, PATHINFO_EXTENSION) == 'pdf'): ?>
                                            <img src="<?php echo e(asset('assets/images/pdf-file.svg')); ?>" alt="<?php echo e($row); ?>">
                                        <?php else: ?>
                                            <img src="<?php echo e(asset('documents/purchases/' . $row)); ?>" alt="<?php echo e($row); ?>">
                                        <?php endif; ?>
                                    </div>
                                    <div class="purchase-detail-doc__label"><?php echo e(\Illuminate\Support\Str::limit($row, 24)); ?></div>
                                </a>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        <?php endif; ?>

        <?php if($purchase->documents->isNotEmpty()): ?>
            <div class="card purchase-detail-card">
                <div class="card-body">
                    <h4 class="purchase-detail-card__title">Supporting Documents</h4>
                    <div class="invoice-preview__documents-grid">
                        <?php $__currentLoopData = $purchase->documents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $document): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="invoice-preview__document-card">
                                <a href="<?php echo e($document->image_url); ?>" target="_blank">
                                    <img src="<?php echo e($document->image_url); ?>" alt="<?php echo e($document->document_type_label); ?>">
                                </a>
                                <div class="invoice-preview__document-meta">
                                    <span class="invoice-preview__document-type"><?php echo e($document->document_type_label); ?></span>
                                    <?php if($document->document_number): ?>
                                        <span class="invoice-preview__document-number" data-full="<?php echo e($document->document_number); ?>" data-masked="<?php echo e($document->masked_number); ?>"><?php echo e($document->masked_number); ?></span>
                                        <button type="button" class="invoice-preview__document-reveal" title="Show / hide full number">
                                            <i class="mdi mdi-eye-outline"></i>
                                        </button>
                                    <?php endif; ?>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </div>
</div>
<?php /**PATH /var/www/html/resources/views/purchase/_detail_content.blade.php ENDPATH**/ ?>