<?php $__env->startSection('title'); ?>
    Expenses List
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php
    $expenseCount = $expenses->count();
    $averageExpense = $expenseCount ? $expenses->avg('amount') : 0;
    $todayExpense = $expenses->filter(function ($expense) {
        return \Carbon\Carbon::parse($expense->entrydate)->isToday();
    })->sum('amount');

    $years = range(now()->year, now()->year - 3);
    $months = [
        'All',
        'January', 'February', 'March', 'April', 'May', 'June',
        'July', 'August', 'September', 'October', 'November', 'December',
    ];

    $oldExpenseId = old('expense_id');
    $oldEditExpense = $oldExpenseId ? $expenses->firstWhere('id', (int) $oldExpenseId) : null;

    $breakdown = $expenses
        ->groupBy(fn ($expense) => $expense->category?->name ?? 'Uncategorized')
        ->map(fn ($group) => $group->sum('amount'))
        ->sortDesc();
    $breakdownMax = $breakdown->max() ?: 1;
?>

<div class="container-fluid expenses-page">
    <div class="expenses-topbar">
        <div>
            <h1 class="expenses-topbar__title">Expenses</h1>
            <p class="expenses-topbar__subtitle">Track and record what the business spends.</p>
        </div>
        <div class="expenses-topbar__actions">
            <div class="expenses-mini-stats mr-3">
                <div class="expenses-mini-stat">
                    <div class="expenses-mini-stat__label">Total</div>
                    <div class="expenses-mini-stat__value">₹<?php echo e(number_format((float) $totalExpenseAmount, 2)); ?></div>
                </div>
                <div class="expenses-mini-stat">
                    <div class="expenses-mini-stat__label">Entries</div>
                    <div class="expenses-mini-stat__value"><?php echo e($expenseCount); ?></div>
                </div>
            </div>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('expense-categories.view')): ?>
                <a href="<?php echo e(route('expense-categories.index')); ?>" class="expenses-link-btn">
                    <i class="mdi mdi-shape-outline"></i> Manage Categories
                </a>
            <?php endif; ?>
        </div>
    </div>

    <?php if(session('status')): ?>
        <div class="alert alert-success expenses-alert" id="statusMessage">
            <?php echo e(session('status')); ?>

        </div>
    <?php endif; ?>

    <div class="row">
        <div class="col-lg-8 mb-4">
            <div class="expenses-card">
                <div class="expenses-card__header">
                    <div>
                        <h4 class="expenses-card__title">Recent expenses</h4>
                        <p class="expenses-card__subtitle">Newest first</p>
                    </div>
                    <form action="<?php echo e(route('expenses')); ?>" method="GET" id="filterexpense" class="expenses-card__filters">
                        <select name="year" class="form-control" id="selectyear">
                            <?php $__currentLoopData = $years; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $selectableYear): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($selectableYear); ?>" <?php if((int) $year === (int) $selectableYear): echo 'selected'; endif; ?>><?php echo e($selectableYear); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <select name="month" class="form-control" id="selectmonth">
                            <?php $__currentLoopData = $months; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $selectableMonth): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($selectableMonth); ?>" <?php if($month === $selectableMonth): echo 'selected'; endif; ?>><?php echo e($selectableMonth); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </form>
                </div>

                <?php if(count($expenses) > 0): ?>
                    <div class="table-responsive expenses-table-wrap">
                        <table class="table expenses-table table-hover m-0 table-centered dt-responsive nowrap w-100" id="tickets-table">
                            <thead>
                                <tr>
                                    <th>Date</th>
                                    <th>What for</th>
                                    <th>Amount</th>
                                    <th class="text-right">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $expenses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $expense): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td class="expense-date"><?php echo e(\Carbon\Carbon::parse($expense->entrydate)->format('d M')); ?></td>
                                        <td>
                                            <div class="expense-what">
                                                <?php echo e($expense->category?->name ?? 'Uncategorized'); ?>

                                                <?php if($expense->description): ?>
                                                    <small><?php echo e(\Illuminate\Support\Str::limit($expense->description, 60)); ?></small>
                                                <?php endif; ?>
                                            </div>
                                        </td>
                                        <td class="expense-amount">₹<?php echo e(number_format($expense->amount, 2)); ?></td>
                                        <td class="text-right">
                                            <div class="expense-actions">
                                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('expenses.edit')): ?>
                                                    <button
                                                        type="button"
                                                        class="btn expense-edit-link js-edit-expense"
                                                        title="Update"
                                                        data-toggle="modal"
                                                        data-target="#editExpenseModal"
                                                        data-id="<?php echo e($expense->id); ?>"
                                                        data-category="<?php echo e($expense->expense_category_id); ?>"
                                                        data-amount="<?php echo e($expense->amount); ?>"
                                                        data-entrydate="<?php echo e(\Carbon\Carbon::parse($expense->entrydate)->format('Y-m-d\TH:i')); ?>"
                                                        data-description="<?php echo e($expense->description); ?>">
                                                        <i class="mdi mdi-square-edit-outline"></i>
                                                    </button>
                                                <?php endif; ?>
                                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('expenses.delete')): ?>
                                                    <form method="post" action="<?php echo e(route('delete-expense', $expense->id)); ?>" style="display:inline;">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('DELETE'); ?>
                                                        <button type="submit" class="btn btn-danger btn-sm" onclick="sureToDelete(event)" title="Delete">
                                                            <i class="fas fa-trash"></i>
                                                        </button>
                                                    </form>
                                                <?php endif; ?>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <div class="expense-empty">
                        <h5 class="mb-2">No expenses found</h5>
                        <p class="mb-0">Try a different filter or add a new expense record to get started.</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <div class="col-lg-4 mb-4">
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('expenses.create')): ?>
                <div class="expenses-card">
                    <div class="expenses-card__header">
                        <div>
                            <h4 class="expenses-card__title">Add an expense</h4>
                        </div>
                    </div>
                    <form method="post" action="<?php echo e(route('save-expense')); ?>" id="addExpenseForm" class="add-expense-form">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label for="category">Category</label>
                            <select id="category" class="form-control" name="expense_category_id" required>
                                <option value="">-- Select Category --</option>
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($category->id); ?>" <?php if((int) old('expense_category_id') === $category->id): echo 'selected'; endif; ?>><?php echo e($category->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="description">Description</label>
                            <input
                                type="text"
                                id="description"
                                class="form-control"
                                name="description"
                                placeholder="For example: Courier for restock"
                                value="<?php echo e(old('description')); ?>">
                        </div>
                        <div class="form-group">
                            <label for="amount">Amount</label>
                            <input
                                type="number"
                                id="amount"
                                class="form-control <?php $__errorArgs = ['amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> parsley-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                name="amount"
                                placeholder="0.00"
                                value="<?php echo e(old('amount')); ?>"
                                required
                                min="0"
                                step="0.01">
                            <?php $__errorArgs = ['amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <ul class="parsley-errors-list filled mt-2 mb-0" aria-hidden="false">
                                    <li class="parsley-required"><?php echo e($message); ?></li>
                                </ul>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group">
                            <label for="expensedate">Date</label>
                            <input
                                type="datetime-local"
                                id="expensedate"
                                class="form-control <?php $__errorArgs = ['entrydate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> parsley-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                name="entrydate"
                                value="<?php echo e(old('entrydate', now()->format('Y-m-d\TH:i'))); ?>"
                                required>
                            <?php $__errorArgs = ['entrydate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <ul class="parsley-errors-list filled mt-2 mb-0" aria-hidden="false">
                                    <li class="parsley-required"><?php echo e($message); ?></li>
                                </ul>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <button type="submit" class="btn btn-save-expense">Save expense</button>
                    </form>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <div class="row">
        <div class="col-12 mb-4">
            <div class="expenses-card">
                <div class="expenses-card__header">
                    <div>
                        <h4 class="expenses-card__title">Where the money goes</h4>
                        <p class="expenses-card__subtitle"><?php echo e($periodLabel); ?> <?php echo e($year); ?> by category</p>
                    </div>
                </div>
                <div class="add-expense-form">
                    <?php $__empty_1 = true; $__currentLoopData = $breakdown; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoryName => $categoryTotal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="breakdown-row">
                            <div class="breakdown-row__label"><?php echo e($categoryName); ?></div>
                            <div class="breakdown-row__track">
                                <div class="breakdown-row__fill" style="width: <?php echo e(max(4, round($categoryTotal / $breakdownMax * 100))); ?>%"></div>
                            </div>
                            <div class="breakdown-row__value">₹<?php echo e(number_format($categoryTotal, 2)); ?></div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <p class="text-muted mb-0">No expenses in this period yet.</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('expenses.edit')): ?>
    <div class="modal fade expense-modal" id="editExpenseModal" tabindex="-1" role="dialog" aria-labelledby="editExpenseModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <div>
                        <h4 class="modal-title" id="editExpenseModalLabel">Edit Expense</h4>
                        <!-- <div class="modal-subtitle">Update an existing expense entry without leaving this page.</div> -->
                    </div>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form method="post" action="<?php echo e($oldEditExpense ? route('expenseedit', $oldEditExpense->id) : '#'); ?>" id="editExpenseForm">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="expense_id" id="edit_expense_id" value="<?php echo e(old('expense_id')); ?>">
                    <div class="modal-body">
                        <div class="form-row">
                            <div class="form-group col-md-6">
                                <label for="edit_category">Expense Category</label>
                                <select id="edit_category" class="form-control" name="expense_category_id" required>
                                    <option value="">-- Select Category --</option>
                                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($category->id); ?>" <?php if((int) old('expense_category_id', $oldEditExpense->expense_category_id ?? 0) === $category->id): echo 'selected'; endif; ?>><?php echo e($category->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="form-group col-md-6">
                                <label for="edit_amount">Amount</label>
                                <input
                                    type="number"
                                    id="edit_amount"
                                    class="form-control <?php $__errorArgs = ['amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> parsley-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    name="amount"
                                    placeholder="Enter amount"
                                    value="<?php echo e(old('amount', $oldEditExpense->amount ?? '')); ?>"
                                    required
                                    min="0"
                                    step="0.01">
                                <?php if($errors->any() && old('expense_id')): ?>
                                    <?php $__errorArgs = ['amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <ul class="parsley-errors-list filled mt-2 mb-0" aria-hidden="false">
                                            <li class="parsley-required"><?php echo e($message); ?></li>
                                        </ul>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <?php endif; ?>
                            </div>
                            <div class="form-group col-md-6">
                                <label for="edit_expensedate">Expense Date</label>
                                <input
                                    type="datetime-local"
                                    id="edit_expensedate"
                                    class="form-control <?php if($errors->any() && old('expense_id')): ?> <?php $__errorArgs = ['entrydate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> parsley-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> <?php endif; ?>"
                                    name="entrydate"
                                    value="<?php echo e(old('entrydate', $oldEditExpense ? \Carbon\Carbon::parse($oldEditExpense->entrydate)->format('Y-m-d\TH:i') : '')); ?>"
                                    required>
                                <?php if($errors->any() && old('expense_id')): ?>
                                    <?php $__errorArgs = ['entrydate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <ul class="parsley-errors-list filled mt-2 mb-0" aria-hidden="false">
                                            <li class="parsley-required"><?php echo e($message); ?></li>
                                        </ul>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <?php endif; ?>
                            </div>
                            <div class="form-group col-md-6">
                                <label for="edit_description">Note</label>
                                <textarea class="form-control" id="edit_description" rows="4" name="description" placeholder="Add a short note"><?php echo e(old('description', $oldEditExpense->description ?? '')); ?></textarea>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-light" data-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-success">Update Expense</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    setTimeout(function() {
        document.getElementById('statusMessage')?.remove();
    }, 5000);

    document.getElementById('selectyear')?.addEventListener('change', function () {
        document.getElementById('filterexpense').submit();
    });

    document.getElementById('selectmonth')?.addEventListener('change', function () {
        document.getElementById('filterexpense').submit();
    });

    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('expenses.create')): ?>
        $(function () {
            const addExpenseForm = document.getElementById('addExpenseForm');
            if (addExpenseForm) {
                addExpenseForm.addEventListener('submit', function (event) {
                    if (!this.checkValidity()) {
                        event.preventDefault();
                        event.stopPropagation();
                        this.reportValidity();
                    }
                });
            }
        });
    <?php endif; ?>

    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('expenses.edit')): ?>
        $(function () {
            const editExpenseForm = document.getElementById('editExpenseForm');
            const editExpenseId = document.getElementById('edit_expense_id');
            const editCategory = document.getElementById('edit_category');
            const editAmount = document.getElementById('edit_amount');
            const editEntrydate = document.getElementById('edit_expensedate');
            const editDescription = document.getElementById('edit_description');

            $('#editExpenseModal').on('show.bs.modal', function (event) {
                const trigger = event.relatedTarget;
                if (!trigger || !editExpenseForm) {
                    return;
                }

                const expenseId = trigger.getAttribute('data-id');
                editExpenseForm.action = "<?php echo e(url('/admin/expenses/update')); ?>/" + expenseId;
                editExpenseId.value = expenseId || '';
                editCategory.value = trigger.getAttribute('data-category') || '';
                editAmount.value = trigger.getAttribute('data-amount') || '';
                editEntrydate.value = trigger.getAttribute('data-entrydate') || '';
                editDescription.value = trigger.getAttribute('data-description') || '';
            });

            if (editExpenseForm) {
                editExpenseForm.addEventListener('submit', function (event) {
                    if (!this.checkValidity()) {
                        event.preventDefault();
                        event.stopPropagation();
                        $('#editExpenseModal').modal('show');
                        this.reportValidity();
                    }
                });
            }

            const shouldOpenEditModal = <?php echo e($errors->any() && $oldExpenseId ? 'true' : 'false'); ?>;
            if (shouldOpenEditModal) {
                $('#editExpenseModal').modal('show');
            }
        });
    <?php endif; ?>
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/html/resources/views/expenses/index.blade.php ENDPATH**/ ?>