<?php $__env->startSection('title'); ?>
    Company Settings
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="settings-shell">
    <div class="container-fluid">

        <?php if(session('message')): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <?php echo e(session('message')); ?>

                <button type="button" class="close" data-dismiss="alert">&times;</button>
            </div>
        <?php endif; ?>

        <?php
            // gst_number/gst_percentage errors render inline under their own fields below,
            // so they're excluded here to avoid showing the same message twice.
            $topLevelErrors = collect($errors->getMessages())->except(['gst_number', 'gst_percentage'])->flatten();
        ?>
        <?php if($topLevelErrors->isNotEmpty()): ?>
            <div class="alert alert-danger">
                <ul class="mb-0">
                    <?php $__currentLoopData = $topLevelErrors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <div class="row">
            <div class="col-lg-9">
                <div class="card settings-card">
                    <div class="card-body">
                        <form method="POST" action="<?php echo e(route('admin.settings.update')); ?>" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>

                            <div class="settings-section">
                                <!-- <div class="settings-section__eyebrow">Company</div> -->
                                <h2 class="settings-section__title">Store Information</h2>
                                <p class="settings-section__subtitle">Shown on invoices, receipts, and printed reports across the app.</p>

                                <div class="settings-panel">
                                    <div class="row">
                                        <div class="col-md-6 mb-3">
                                            <label class="settings-label">Store Name</label>
                                            <input type="text" class="form-control settings-input" name="company_name"
                                                value="<?php echo e(old('company_name', $setting->company_name)); ?>" required>
                                        </div>
                                        <div class="col-md-6 mb-3">
                                            <label class="settings-label">Phone</label>
                                            <input type="text" class="form-control settings-input" name="phone"
                                                value="<?php echo e(old('phone', $setting->phone)); ?>">
                                        </div>

                                        <div class="col-md-6 mb-3">
                                            <label class="settings-label">Email</label>
                                            <input type="email" class="form-control settings-input" name="email"
                                                value="<?php echo e(old('email', $setting->email)); ?>">
                                        </div>
                                        <div class="col-md-6 mb-3">
                                            <label class="settings-label">Logo</label>
                                            <input type="file" class="form-control settings-input" name="logo" accept="image/*">
                                            <?php if($setting->logo): ?>
                                                <img src="<?php echo e(asset($setting->logo)); ?>" alt="Current logo" class="settings-logo-preview" height="50">
                                            <?php endif; ?>
                                        </div>

                                        <div class="col-md-12">
                                            <label class="settings-label">Address</label>
                                            <textarea class="form-control settings-input" name="address" rows="2"><?php echo e(old('address', $setting->address)); ?></textarea>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="settings-section">
                                <!-- <div class="settings-section__eyebrow">Tax</div> -->
                                <h2 class="settings-section__title">GST Settings</h2>
                                <p class="settings-section__subtitle">Enable GST to show tax fields on invoices and reports.</p>

                                <div class="settings-panel">
                                    <div class="form-group custom-control custom-switch mb-3">
                                        <input type="hidden" name="gst_enabled" value="0">
                                        <input type="checkbox" class="custom-control-input" id="gstEnabled" name="gst_enabled" value="1"
                                            <?php echo e(old('gst_enabled', $setting->gst_enabled) ? 'checked' : ''); ?>>
                                        <label class="custom-control-label" for="gstEnabled">Enable GST</label>
                                    </div>

                                    <div id="gstNumberGroup" class="row" style="<?php echo e(old('gst_enabled', $setting->gst_enabled) ? '' : 'display:none;'); ?>">
                                        <div class="col-md-6 mb-3">
                                            <label class="settings-label">GST Number (GSTIN)</label>
                                            <input type="text" class="form-control settings-input <?php $__errorArgs = ['gst_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                name="gst_number" value="<?php echo e(old('gst_number', $setting->gst_number)); ?>"
                                                placeholder="e.g. 24ABCDE1234F1Z5">
                                            <?php $__errorArgs = ['gst_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback d-block"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>

                                        <div class="col-md-3 mb-3">
                                            <label class="settings-label">GST Percentage (%)</label>
                                            <input type="number" step="0.01" min="0" max="100"
                                                class="form-control settings-input <?php $__errorArgs = ['gst_percentage'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                name="gst_percentage" value="<?php echo e(old('gst_percentage', $setting->gst_percentage)); ?>"
                                                placeholder="e.g. 18">
                                            <?php $__errorArgs = ['gst_percentage'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback d-block"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>

                                        <div class="col-md-3 mb-3">
                                            <label class="settings-label">Prices Entered As</label>
                                            <?php $currentGstMode = old('default_gst_mode', $setting->default_gst_mode ?? 'exclude'); ?>
                                            <select class="form-control settings-input" name="default_gst_mode">
                                                <option value="exclude" <?php if($currentGstMode === 'exclude'): echo 'selected'; endif; ?>>Excluding GST</option>
                                                <option value="include" <?php if($currentGstMode === 'include'): echo 'selected'; endif; ?>>Including GST</option>
                                                <option value="none" <?php if($currentGstMode === 'none'): echo 'selected'; endif; ?>>None (don't count GST by default)</option>
                                            </select>
                                            <small class="form-text text-muted">"None" still shows your GSTIN on invoices — it just won't apply tax by default when creating one.</small>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="settings-actions">
                                <button type="submit" class="btn settings-btn btn-primary">Save Settings</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    document.getElementById('gstEnabled').addEventListener('change', function () {
        document.getElementById('gstNumberGroup').style.display = this.checked ? '' : 'none';
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/html/resources/views/admin/settings.blade.php ENDPATH**/ ?>