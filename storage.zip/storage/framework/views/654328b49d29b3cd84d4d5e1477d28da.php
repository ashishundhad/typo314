<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Stock Report</title>
    <style>
        @page {
            margin: 12px 18px;
        }

        body {
            font-family: DejaVu Sans, sans-serif;
            color: #1f2937;
            font-size: 12px;
            margin: 0;
            padding: 0;
        }

        .report-shell {
            padding: 0;
        }

        .report-hero {
            background-color: #17324d;
            border-radius: 18px;
            padding: 18px 24px;
            color: #fff;
            margin-bottom: 18px;
        }

        .report-hero__logo {
            max-height: 44px;
            margin-bottom: 10px;
            text-align: right;
        }

        .report-hero__eyebrow {
            font-size: 10px;
            letter-spacing: 0.14em;
            text-transform: uppercase;
            opacity: 0.82;
            margin-bottom: 8px;
        }

        .report-hero__title {
            font-size: 28px;
            font-weight: 700;
            margin: 0 0 6px;
        }

        .report-hero__subtitle {
            font-size: 12px;
            opacity: 0.84;
            margin: 0;
        }

        .report-meta {
            margin-top: 14px;
            font-size: 11px;
            opacity: 0.9;
        }

        .summary-grid {
            width: 100%;
            border-collapse: separate;
            border-spacing: 12px 0;
            margin: 0 0 18px;
        }

        .summary-card {
            background: #f8fbfd;
            border: 1px solid #e5edf5;
            border-radius: 16px;
            padding: 16px;
            vertical-align: top;
        }

        .summary-card__label {
            font-size: 10px;
            letter-spacing: 0.12em;
            text-transform: uppercase;
            color: #6b7b8f;
            margin-bottom: 8px;
        }

        .summary-card__value {
            font-size: 22px;
            font-weight: 700;
            color: #17324d;
            margin-bottom: 4px;
        }

        .summary-card__meta {
            font-size: 11px;
            color: #7b8798;
        }

        .stock-table {
            width: 100%;
            border-collapse: collapse;
        }

        .stock-table thead th {
            background: #17324d;
            color: #edf7ff;
            padding: 11px 10px;
            font-size: 10px;
            text-transform: uppercase;
            letter-spacing: 0.08em;
            text-align: left;
            white-space: nowrap;
        }

        .stock-table tbody td {
            padding: 11px 10px;
            border-bottom: 1px solid #e8eef5;
            vertical-align: top;
            color: #425466;
        }

        .stock-index {
            color: #4f46e5;
            font-weight: 700;
        }

        .stock-model {
            color: #17324d;
            font-weight: 700;
            margin-bottom: 4px;
        }

        .stock-meta {
            color: #7b8798;
            font-size: 10px;
        }

        .stock-chip {
            display: inline-block;
            padding: 4px 9px;
            border-radius: 999px;
            background: #f7fafc;
            border: 1px solid #dde7f0;
            color: #607086;
            font-size: 10px;
            font-weight: 700;
        }

        .stock-status {
            display: inline-block;
            padding: 4px 9px;
            border-radius: 999px;
            font-size: 10px;
            font-weight: 700;
        }

        .stock-status--available {
            background: #e9f8f4;
            color: #169c82;
        }

        .stock-status--sold {
            background: #fdeeee;
            color: #d63c49;
        }

        .stock-amount {
            text-align: right;
            font-size: 13px;
            font-weight: 700;
            color: #17324d;
            white-space: nowrap;
        }

        .stock-date {
            white-space: nowrap;
            color: #5f7188;
            font-weight: 600;
        }

        .align-right {
            text-align: right;
        }
    </style>
</head>
<body>
    <div class="report-shell">
        <div class="report-hero">
            <?php
                $companySetting = \App\Models\CompanySetting::current();
                // Base64 encode image for dompdf to resolve accurately
                $logoPath = $companySetting->logo ? public_path($companySetting->logo) : null;
                if ($logoPath && file_exists($logoPath)) {
                    $logoType = pathinfo($logoPath, PATHINFO_EXTENSION);
                    $logoData = file_get_contents($logoPath);
                    $logoBase64 = 'data:image/' . $logoType . ';base64,' . base64_encode($logoData);
                    echo '<img src="' . $logoBase64 . '" alt="Logo" class="report-hero__logo">';
                }
            ?>
            <!-- <div class="report-hero__eyebrow">Inventory Export</div> -->
            <div class="report-hero__title">Stock Report</div>
            <div class="report-meta">
                Filter: <?php echo e($summaryLabel); ?><br>
                Generated: <?php echo e(now()->format('d M Y, h:i A')); ?>

            </div>
        </div>

        <table class="summary-grid">
            <tr>
                <td width="25%">
                    <div class="summary-card">
                        <div class="summary-card__label">Records</div>
                        <div class="summary-card__value"><?php echo e($allPurchases->count()); ?></div>
                        <div class="summary-card__meta">Matching stock entries</div>
                    </div>
                </td>
                <td width="25%">
                    <div class="summary-card">
                        <div class="summary-card__label">Buying Cost</div>
                        <div class="summary-card__value">₹<?php echo e(number_format($totalPurchaseCost, 2)); ?></div>
                        <div class="summary-card__meta">Base purchase total</div>
                    </div>
                </td>
                <td width="25%">
                    <div class="summary-card">
                        <div class="summary-card__label">Repairing</div>
                        <div class="summary-card__value">₹<?php echo e(number_format($totalRepairingCost, 2)); ?></div>
                        <div class="summary-card__meta">Added refurbishment</div>
                    </div>
                </td>
                <td width="25%">
                    <div class="summary-card">
                        <div class="summary-card__label">Stock Value</div>
                        <div class="summary-card__value">₹<?php echo e(number_format($totalStockValue, 2)); ?></div>
                        <div class="summary-card__meta">Purchase price total</div>
                    </div>
                </td>
            </tr>
        </table>

        <table class="stock-table">
            <thead>
                <tr>
                    <th>Sr No</th>
                    <th>Model</th>
                    <th>IMEI</th>
                    <th>Storage</th>
                    <th>Color</th>
                    <th class="align-right">Buying Cost</th>
                    <th>Buy Date</th>
                    <th>Sale Date</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $allPurchases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $purchase): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="stock-index">#<?php echo e($purchase->id); ?></td>
                        <td>
                            <div class="stock-model"><?php echo e($purchase->model ?: '-'); ?></div>
                            <div class="stock-meta">
                                <?php echo e($purchase->purchase_from ?: 'Unknown vendor'); ?>

                                <?php if($purchase->contactno): ?>
                                    | <?php echo e($purchase->contactno); ?>

                                <?php endif; ?>
                            </div>
                        </td>
                        <td><?php echo e($purchase->imei ?: '-'); ?></td>
                        <td><span class="stock-chip"><?php echo e($purchase->storage ?: '-'); ?></span></td>
                        <td><?php echo e($purchase->color ?: '-'); ?></td>
                        <td class="stock-amount">₹<?php echo e(number_format((float) $purchase->purchase_cost, 2)); ?></td>
                        <td class="stock-date"><?php echo e($purchase->purchase_date ? \Carbon\Carbon::parse($purchase->purchase_date)->format('d-m-Y') : '-'); ?></td>
                        <td class="stock-date"><?php echo e($purchase->sell_date ? \Carbon\Carbon::parse($purchase->sell_date)->format('d-m-Y') : '--'); ?></td>
                        <td>
                            <span class="stock-status <?php echo e((int) $purchase->is_sold === 1 ? 'stock-status--sold' : 'stock-status--available'); ?>">
                                <?php echo e((int) $purchase->is_sold === 1 ? 'Sold' : 'Available'); ?>

                            </span>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</body>
</html>
<?php /**PATH /var/www/html/resources/views/purchase/stock-pdf.blade.php ENDPATH**/ ?>