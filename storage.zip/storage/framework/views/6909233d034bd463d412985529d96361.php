<div class="supplier-ledger-detail-view">
    <div class="supplier-ledger-detail-hero">
        <div class="row align-items-center">
            <div class="col-lg-8">
                <!-- <div class="supplier-ledger-detail-hero__eyebrow">Supplier Ledger</div> -->
                <h1 class="supplier-ledger-detail-hero__title"><?php echo e($supplierName); ?></h1>
                <p class="supplier-ledger-detail-hero__meta">
                    <?php echo e($timePeriod); ?>

                    <?php if($contactno): ?>
                        | Contact: <?php echo e($contactno); ?>

                    <?php endif; ?>
                    <?php if($latestPurchaseDate): ?>
                        | Last purchase: <?php echo e(\Carbon\Carbon::parse($latestPurchaseDate)->format('d M Y')); ?>

                    <?php endif; ?>
                </p>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-md-6 col-xl-3 mb-3">
            <div class="card supplier-ledger-detail-metric">
                <div class="card-body">
                    <div class="supplier-ledger-detail-metric__label">Purchased Items</div>
                    <div class="supplier-ledger-detail-metric__value"><?php echo e(number_format($totalItems)); ?></div>
                </div>
            </div>
        </div>
        <div class="col-md-6 col-xl-3 mb-3">
            <div class="card supplier-ledger-detail-metric">
                <div class="card-body">
                    <div class="supplier-ledger-detail-metric__label">Purchase Cost</div>
                    <div class="supplier-ledger-detail-metric__value"><?php echo e(config('constant.currency')); ?><?php echo e(number_format($totalPurchaseAmount, 2)); ?></div>
                </div>
            </div>
        </div>
        <div class="col-md-6 col-xl-3 mb-3">
            <div class="card supplier-ledger-detail-metric">
                <div class="card-body">
                    <div class="supplier-ledger-detail-metric__label">Repairing</div>
                    <div class="supplier-ledger-detail-metric__value"><?php echo e(config('constant.currency')); ?><?php echo e(number_format($totalRepairingAmount, 2)); ?></div>
                </div>
            </div>
        </div>
        <div class="col-md-6 col-xl-3 mb-3">
            <div class="card supplier-ledger-detail-metric">
                <div class="card-body">
                    <div class="supplier-ledger-detail-metric__label">Sold / Available</div>
                    <div class="supplier-ledger-detail-metric__value"><?php echo e($soldItems); ?> / <?php echo e($availableItems); ?></div>
                </div>
            </div>
        </div>
    </div>

    <div class="card supplier-ledger-detail-card">
        <div class="card-body">
            <h2 class="supplier-ledger-detail-card__title">Purchase List</h2>
            <p class="supplier-ledger-detail-card__subtitle"></p>

            <div class="supplier-ledger-detail-filter">
                <form method="GET" class="js-supplier-ledger-modal-form" action="<?php echo e(route('supplier-ledger-detail')); ?>">
                    <input type="hidden" name="supplier" value="<?php echo e($supplierFilter); ?>">
                    <input type="hidden" name="modal" value="1">
                    <div class="form-row align-items-end">
                        <div class="col-12 col-md-3 mb-3">
                            <label class="supplier-ledger-detail-label" for="detail-period">Report Period</label>
                            <select name="period" class="form-control" id="detail-period">
                                <option value="alls" <?php if($period === 'alls'): echo 'selected'; endif; ?>>All Time</option>
                                <option value="thismonth" <?php if($period === 'thismonth'): echo 'selected'; endif; ?>>This Month</option>
                                <option value="lastmonth" <?php if($period === 'lastmonth'): echo 'selected'; endif; ?>>Last Month</option>
                                <option value="thisyear" <?php if($period === 'thisyear'): echo 'selected'; endif; ?>>This Year</option>
                                <option value="lastyear" <?php if($period === 'lastyear'): echo 'selected'; endif; ?>>Last Year</option>
                                <option value="custom" <?php if($period === 'custom'): echo 'selected'; endif; ?>>Custom Range</option>
                            </select>
                        </div>
                        <div class="col-md-2 mb-3 supplier-ledger-detail-date-group <?php if($period === 'custom'): ?> d-block <?php endif; ?>">
                            <label class="supplier-ledger-detail-label" for="detail-fromdate">From Date</label>
                            <input type="date" id="detail-fromdate" name="fromdate" class="form-control" value="<?php echo e($fromdate); ?>">
                        </div>
                        <div class="col-md-2 mb-3 supplier-ledger-detail-date-group <?php if($period === 'custom'): ?> d-block <?php endif; ?>">
                            <label class="supplier-ledger-detail-label" for="detail-todate">To Date</label>
                            <input type="date" id="detail-todate" name="todate" class="form-control" value="<?php echo e($todate); ?>">
                        </div>
                        <div class="col-12 col-md-2 mb-3">
                            <label class="supplier-ledger-detail-label" for="detail-status">Stock Status</label>
                            <select name="status" class="form-control" id="detail-status">
                                <option value="" <?php if($status === ''): echo 'selected'; endif; ?>>All</option>
                                <option value="available" <?php if($status === 'available'): echo 'selected'; endif; ?>>Available</option>
                                <option value="sold" <?php if($status === 'sold'): echo 'selected'; endif; ?>>Sold</option>
                            </select>
                        </div>
                        <div class="col-12 col-md-3 mb-3">
                            <label class="supplier-ledger-detail-label" for="detail-search">Search</label>
                            <input type="text" id="detail-search" name="search" class="form-control" value="<?php echo e($search); ?>" placeholder="IMEI, model, color, remark">
                        </div>
                        <div class="col-12 col-md-2 mb-3">
                            <button type="submit" class="btn btn-primary supplier-ledger-detail-btn">Filter List</button>
                        </div>
                        <div class="col-12 col-md-2 mb-3">
                            <a href="<?php echo e(route('supplier-ledger-detail', ['supplier' => $supplierFilter, 'modal' => 1])); ?>" class="btn btn-outline-danger supplier-ledger-detail-btn js-supplier-ledger-modal-link">Clear</a>
                        </div>
                    </div>
                </form>
            </div>

            <div class="table-responsive">
                <?php if($purchases->count()): ?>
                    <table class="table supplier-ledger-detail-table">
                        <thead>
                            <tr>
                                <th>Purchase Date</th>
                                <th>Device</th>
                                <th>IMEI / Variant</th>
                                <th>Costing</th>
                                <th>Status</th>
                                <th class="text-right">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $purchases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $purchase): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>
                                        <div class="supplier-ledger-detail-money"><?php echo e(\Carbon\Carbon::parse($purchase->purchase_date)->format('d M Y')); ?></div>
                                        <?php if($purchase->sell_date): ?>
                                            <div class="supplier-ledger-detail-device__meta mt-1">Sold on <?php echo e(\Carbon\Carbon::parse($purchase->sell_date)->format('d M Y')); ?></div>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <div class="supplier-ledger-detail-device__name"><?php echo e($purchase->model ?: 'Unnamed Device'); ?></div>
                                        <div class="supplier-ledger-detail-device__meta">Source: <?php echo e($purchase->purchase_from ?: 'Unknown Supplier'); ?></div>
                                        <?php if($purchase->remark): ?>
                                            <div class="supplier-ledger-detail-note mt-1"><?php echo e($purchase->remark); ?></div>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <div class="supplier-ledger-detail-money"><?php echo e($purchase->imei ?: 'N/A'); ?></div>
                                        <div class="supplier-ledger-detail-device__meta">Storage: <?php echo e($purchase->storage ?: 'N/A'); ?></div>
                                        <div class="supplier-ledger-detail-device__meta">Color: <?php echo e($purchase->color ?: 'N/A'); ?></div>
                                    </td>
                                    <td>
                                        <div class="supplier-ledger-detail-money">Buy: <?php echo e(config('constant.currency')); ?><?php echo e(number_format((float) $purchase->purchase_cost, 2)); ?></div>
                                        <div class="supplier-ledger-detail-device__meta">Repairing: <?php echo e(config('constant.currency')); ?><?php echo e(number_format((float) ($purchase->repairing_charge ?: 0), 2)); ?></div>
                                        <div class="supplier-ledger-detail-device__meta">Stock value: <?php echo e(config('constant.currency')); ?><?php echo e(number_format((float) $purchase->purchase_price, 2)); ?></div>
                                    </td>
                                    <td>
                                        <span class="supplier-ledger-detail-status supplier-ledger-detail-status--<?php echo e($purchase->is_sold ? 'sold' : 'available'); ?>">
                                            <?php echo e($purchase->is_sold ? 'Sold' : 'Available'); ?>

                                        </span>
                                    </td>
                                    <td class="text-right">
                                        <a href="<?php echo e(route('purchase-detail', $purchase->id)); ?>" class="btn btn-outline-primary supplier-ledger-detail-btn">
                                            Open Stock
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>

                    <div class="mt-3">
                        <?php echo e($purchases->appends(request()->query())->links('vendor.pagination.bootstrap-5')); ?>

                    </div>
                <?php else: ?>
                    <div class="supplier-ledger-detail-empty">
                        <div class="supplier-ledger-detail-empty__icon">
                            <i class="mdi mdi-package-variant-closed"></i>
                        </div>
                        <h4 class="mb-2">No purchases found</h4>
                        <p class="text-muted mb-0">This supplier has no purchases for the current filters.</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<?php /**PATH /var/www/html/resources/views/reports/_supplier-ledger-detail-content.blade.php ENDPATH**/ ?>