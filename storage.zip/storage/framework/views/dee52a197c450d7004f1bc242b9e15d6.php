<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Access Denied • 403</title>
    <meta name="robots" content="noindex">
    <link href="<?php echo e(asset('assets/css/tenant.css')); ?>" rel="stylesheet" type="text/css" />
</head>

<body class="error-403-page">
    <div class="container">
        <div class="card">
            <div class="glow" aria-hidden="true"></div>
            <div class="content">
                <div class="error-badge">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"
                        aria-hidden="true">
                        <path d="M12 8v4" stroke="currentColor" stroke-width="2" stroke-linecap="round" />
                        <circle cx="12" cy="16" r="1.5" fill="currentColor" />
                        <path
                            d="M10.29 3.86 1.82 18.14A2 2 0 0 0 3.54 21h16.92a2 2 0 0 0 1.72-2.86L13.71 3.86a2 2 0 0 0-3.42 0z"
                            stroke="currentColor" stroke-width="2" fill="none" />
                    </svg>
                    Access denied
                </div>

                <div class="icon-wrap" role="img" aria-label="Warning">
                    <div class="pulse" aria-hidden="true"></div>
                    <svg width="34" height="34" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M12 8v5" stroke="#fca5a5" stroke-width="2.5" stroke-linecap="round" />
                        <circle cx="12" cy="17" r="1.6" fill="#fca5a5" />
                    </svg>
                </div>

                <h1>403 • You don’t have permission to access this page</h1>
                <p class="lead">Please contact your administrator to request access. If you believe this is a mistake,
                    try returning to the dashboard or signing in with the correct account.</p>

                <div class="hint">
                    Pro tip: share this code with your admin <span class="code">ERR-403</span> so they can quickly grant
                    the required role or permission.
                </div>

                <div class="actions">
                    <a class="btn" href="<?php echo e(url('/')); ?>">
                        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"
                            aria-hidden="true">
                            <path d="M3 12l9-9 9 9" stroke="currentColor" stroke-width="2" stroke-linecap="round"
                                stroke-linejoin="round" />
                            <path d="M9 21V9h6v12" stroke="currentColor" stroke-width="2" stroke-linecap="round"
                                stroke-linejoin="round" />
                        </svg>
                        Go to Dashboard
                    </a>
                    <a class="btn secondary"
                        href="mailto:ashish.undhad26@gmail.com?subject=Access%20Request%20(403)&body=Hello%2C%0D%0A%0DI%20encountered%20a%20403%20(Access%20Denied)%20error%20on%20the%20application.%20Could%20you%20please%20grant%20me%20the%20required%20permissions%3F%0D%0A%0D%0AThanks.">
                        Contact Administrator
                    </a>
                </div>

                <div class="footer">HTTP 403 • Authorization required</div>
            </div>
        </div>
    </div>
</body>

</html><?php /**PATH /var/www/html/resources/views/errors/403.blade.php ENDPATH**/ ?>