<?php $__env->startSection('title'); ?>
    Transaction List
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-fluid transactions-shell">
        <div class="transactions-hero">
            <div class="row align-items-center">
                <div class="col-lg-8">
                    <!-- <div class="transactions-hero__eyebrow">Finance Overview</div> -->
                    <h1 class="transactions-hero__title">Transaction Management</h1>
                    <p class="transactions-hero__subtitle">
                    </p>
                </div>
                <div class="col-lg-4">
                    <div class="transactions-actions mt-3 mt-lg-0">
                        <a href="<?php echo e(route('transactions.resync')); ?>" class="btn transactions-btn btn-info">
                            <i class="fas fa-sync-alt mr-1"></i>Resync Balances
                        </a>
                        <button type="button" class="btn transactions-btn btn-success" data-toggle="modal" data-target="#transactionModal">
                            <i class="fas fa-plus-circle mr-1"></i>Add Transaction
                        </button>
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-6 col-md-4 col-xl mb-3">
                <div class="transactions-card">
                    <div class="transactions-stat transactions-stat--balance">
                        <div class="transactions-stat__label">Total Balance</div>
                        <h5 class="transactions-stat__value"><?php echo e(config('constant.currency')); ?> <span id="openingBalance">0</span></h5>
                    </div>
                </div>
            </div>
            <div class="col-6 col-md-4 col-xl mb-3">
                <div class="transactions-card">
                    <div class="transactions-stat transactions-stat--cash">
                        <div class="transactions-stat__label">Cash Balance</div>
                        <h5 class="transactions-stat__value"><?php echo e(config('constant.currency')); ?> <span id="cashBalance">0</span></h5>
                    </div>
                </div>
            </div>
            <div class="col-6 col-md-4 col-xl mb-3">
                <div class="transactions-card">
                    <div class="transactions-stat transactions-stat--bank">
                        <div class="transactions-stat__label">Bank Balance</div>
                        <h5 class="transactions-stat__value"><?php echo e(config('constant.currency')); ?> <span id="bankBalance">0</span></h5>
                    </div>
                </div>
            </div>
            <div class="col-6 col-md-4 col-xl mb-3">
                <div class="transactions-card">
                    <div class="transactions-stat transactions-stat--in">
                        <div class="transactions-stat__label">Total In</div>
                        <h5 class="transactions-stat__value"><?php echo e(config('constant.currency')); ?> <span id="totalIn">0</span></h5>
                    </div>
                </div>
            </div>
            <div class="col-6 col-md-4 col-xl mb-3">
                <div class="transactions-card">
                    <div class="transactions-stat transactions-stat--out">
                        <div class="transactions-stat__label">Total Out</div>
                        <h5 class="transactions-stat__value"><?php echo e(config('constant.currency')); ?> <span id="totalOut">0</span></h5>
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-12">
                <?php if(session('status')): ?>
                <div class="alert alert-success" id="statusMessage">
                    <?php echo e(session('status')); ?>

                </div>
                <?php endif; ?>
                <?php if(session('error')): ?>
                <div class="alert alert-danger" id="errorMessage">
                    <?php echo e(session('error')); ?>

                </div>
                <?php endif; ?>
                <div class="transactions-panel">
                    <div class="transactions-panel__body">
                        <div class="transactions-panel__header">
                            <div>
                                <!-- <div class="transactions-panel__eyebrow">Recent Activity</div> -->
                                <h2 class="transactions-panel__title">All Transactions</h2>
                            </div>
                        </div>

                        <form id="filterForm" class="transactions-filter">
                            <div class="transactions-filter__row">
                                <div class="transactions-filter__item transactions-filter__item--date">
                                    <div class="form-group">
                                        <label for="date_from">Date From</label>
                                        <input type="date" class="form-control" id="date_from" name="date_from">
                                    </div>
                                </div>
                                <div class="transactions-filter__item transactions-filter__item--date">
                                    <div class="form-group">
                                        <label for="date_to">Date To</label>
                                        <input type="date" class="form-control" id="date_to" name="date_to">
                                    </div>
                                </div>
                                <div class="transactions-filter__item transactions-filter__item--type">
                                    <div class="form-group">
                                        <label for="filter_transaction_type">Transaction Type</label>
                                        <select class="form-control" id="filter_transaction_type" name="transaction_type">
                                            <option value="">All</option>
                                            <option value="credit">IN</option>
                                            <option value="debit">OUT</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="transactions-filter__item transactions-filter__item--source">
                                    <div class="form-group">
                                        <label for="filter_source">Source</label>
                                        <select class="form-control" id="filter_source" name="source">
                                            <option value="all">All</option>
                                            <option value="manual">Manual</option>
                                            <option value="sale">Sale</option>
                                            <option value="purchase">Purchase</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="transactions-filter__item transactions-filter__item--payment">
                                    <div class="form-group">
                                        <label for="filter_payment_method">Payment Method</label>
                                        <select class="form-control" id="filter_payment_method" name="payment_method">
                                            <option value="">All</option>
                                            <?php $__currentLoopData = $paymentMethods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $method): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($method->id); ?>"><?php echo e($method->method_name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="transactions-filter__item transactions-filter__item--actions">
                                    <div class="transactions-filter__actions">
                                        <button type="button" id="applyFilter" class="btn btn-primary transactions-btn">Apply Filter</button>
                                        <button type="button" id="resetFilter" class="btn btn-light transactions-btn">Reset</button>
                                    </div>
                                </div>
                            </div>
                        </form>

                        <div class="transactions-table-wrap">
                            <div class="transactions-table-toolbar">
                                <div>
                                    <div class="transactions-table-toolbar__title">Transaction Register</div>
                                    <p class="transactions-table-toolbar__hint">A cleaner, compact ledger view with quick actions and easier scanning.</p>
                                </div>
                                <div class="transactions-table-toolbar__chip">
                                    <i class="fas fa-arrows-alt-h"></i>
                                    <span>Scroll for more columns on smaller screens</span>
                                </div>
                            </div>
                            <table id="transactionTable" class="table table-bordered">
                                <thead>
                                    <tr>
                                        <th>No</th>
                                        <th>Payment Date</th>
                                        <th>Type</th>
                                        <th>Source</th>
                                        <th>Payment Method</th>
                                        <th>Amount</th>
                                        <th>Note</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody></tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Transaction Modal -->
    <div class="modal fade" id="transactionModal" tabindex="-1" role="dialog" aria-labelledby="transactionModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="transactionModalLabel">Add Transaction</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form id="transactionForm" action="<?php echo e(route('transactions.store')); ?>" method="POST">
                    <input type="hidden" name="id" id="transactionId">
                    <?php echo csrf_field(); ?>
                    <div class="modal-body">
                        <div class="row">
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label for="party_id">Party <span class="text-danger">*</span></label>
                                    <select class="form-control <?php $__errorArgs = ['party_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="party_id" name="party_id">
                                        <option value="">Select Party</option>
                                        <?php $__currentLoopData = $parties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $party): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($party->id); ?>" <?php echo e(old('party_id') == $party->id ? 'selected' : ''); ?>><?php echo e($party->party_name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <?php $__errorArgs = ['party_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>  
                                        <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label for="payment_date">Payment Date <span class="text-danger">*</span></label>
                                    <input type="date" class="form-control" id="payment_date" name="payment_date" required>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="transaction_type">Transaction Type <span class="text-danger">*</span></label>
                                    <select class="form-control" id="transaction_type" name="transaction_type" required>
                                        <option value="">Select Type</option>
                                        <option value="credit">IN</option>
                                        <option value="debit">OUT</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="payment_method">Payment Method <span class="text-danger">*</span></label>
                                    <select class="form-control" id="payment_method" name="payment_method" required>
                                        <option value="">Select Method</option>
                                        <?php $__currentLoopData = $paymentMethods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $method): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($method->id); ?>"><?php echo e($method->method_name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="amount">Amount <span class="text-danger">*</span></label>
                                    <div class="input-group">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text"><?php echo e(config('constant.currency')); ?></span>
                                        </div>
                                        <input type="number" class="form-control" id="amount" name="amount" step="0.01" min="0" required>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label for="note">Note</label>
                                    <textarea class="form-control" id="note" name="note" rows="3"></textarea>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary">Save Transaction</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script type="text/javascript">
        $(function () {
            const currency = '<?php echo e(config('constant.currency')); ?>';
            let table; // Declare table variable in higher scope

            // Initialize Bootstrap modal
            $('#transactionModal').modal({
                show: false,
                backdrop: 'static',
                keyboard: false
            });

            // Function to get filter parameters
            function getFilterParams() {
                return {
                    date_from: $('#date_from').val(),
                    date_to: $('#date_to').val(),
                    transaction_type: $('#filter_transaction_type').val(),
                    payment_method: $('#filter_payment_method').val(),
                    source: $('#filter_source').val() || 'all'
                };
            }

            table = $('#transactionTable').DataTable({
                processing: true,
                serverSide: true,
                scrollX: true,
                autoWidth: false,
                scrollCollapse: true,
                pageLength: 10,
                order: [[1, 'desc']],
                language: {
                    search: '',
                    searchPlaceholder: 'Search date, method, amount, note...',
                    lengthMenu: 'Show _MENU_ rows',
                    info: 'Showing _START_ to _END_ of _TOTAL_ transactions',
                    infoEmpty: 'No transactions available',
                    zeroRecords: 'No matching transactions found',
                    paginate: {
                        previous: 'Prev',
                        next: 'Next'
                    }
                },
                ajax: {
                    url: "<?php echo e(route('transactions.index')); ?>",
                    data: function(d) {
                        return $.extend({}, d, getFilterParams());
                    }
                },
                columns: [
                    {data: 'DT_RowIndex', name: 'DT_RowIndex', className: 'text-center transactions-col-index'},
                    {data: 'payment_date', name: 'payment_date', className: 'text-center transactions-col-date', render: function(data) {
                        return moment(data).format('DD/MM/YYYY');
                    }},
                    {data: 'transaction_type', name: 'transaction_type', className: 'text-center transactions-col-type', render: function(data, type, row) {
                        const label = row.transaction_type === 'debit' ? 'OUT' : 'IN';
                        const badgeClass = row.transaction_type === 'debit'
                            ? 'transactions-type-badge transactions-type-badge--debit'
                            : 'transactions-type-badge transactions-type-badge--credit';
                        return '<span class="' + badgeClass + '">' + label + '</span>';
                    }},
                    {data: 'source', name: 'source', className: 'text-center transactions-col-source', render: function(data) {
                        return '<span class="transactions-source-badge">' + (data ? data : 'Manual') + '</span>';
                    }},
                    {data: 'payment_method', name: 'payment_method', className: 'text-center transactions-col-payment', render: function(data, type, row) {
                        if (row.paymentMethod && row.paymentMethod.method_name) {
                            return '<span class="transactions-payment-method">' + row.paymentMethod.method_name + '</span>';
                        }
                        if (row.source === 'Sale') {
                            return '<span class="transactions-payment-method">Invoice</span>';
                        }
                        if (row.source === 'Purchase') {
                            return '<span class="transactions-payment-method">Purchase</span>';
                        }
                        return '<span class="transactions-payment-method">-</span>';
                    }},
                    {data: 'amount', name: 'amount', className: 'text-center transactions-col-amount', render: function(data, type, row) {
                        const amountClass = row.transaction_type === 'debit'
                            ? 'transactions-amount transactions-amount--debit'
                            : 'transactions-amount transactions-amount--credit';
                        return '<span class="' + amountClass + '">' + (row.transaction_type === 'debit' ? '- ' : '+ ') + currency + ' ' + data + '</span>';
                    }},
                    {data: 'note', name: 'note', className: 'text-left transactions-col-note', render: function(data) {
                        if (data && data.length > 50) {
                            return '<span class="transactions-note note-tooltip" data-toggle="tooltip" data-placement="top" title="' + data + '">' + data + '</span>';
                        }
                        if (data) {
                            return '<span class="transactions-note">' + data + '</span>';
                        }
                        return '<span class="transactions-empty-note">No note</span>';
                    }},
                    // {
                    //     data: 'created_at',
                    //     name: 'created_at',
                    //     className: 'text-center',
                    //     render: function(data) {
                    //         return moment(data).format('DD/MM/YYYY HH:mm:ss');
                    //     }
                    // },
                    {data: 'action', name: 'action', className: 'text-center transactions-actions-cell transactions-col-actions', orderable: false, searchable: false, render: function(data, type, row) {
                        if (row.source === 'Manual') {
                            return '<div class="transactions-actions-group">' +
                                '<button class="btn btn-primary btn-sm edit-transaction" data-id="' + row.id + '" title="Edit transaction"><i class="fas fa-edit"></i></button>' +
                                '<button class="btn btn-danger btn-sm delete-transaction" data-id="' + row.id + '" title="Delete transaction"><i class="fas fa-trash"></i></button>' +
                            '</div>';
                        }
                        return '<span class="transactions-actions-empty" title="Locked"><i class="fas fa-lock"></i></span>';
                    }},
                ],
                initComplete: function(settings, json) {
                    if (json) {
                        if (json.openingBalance !== undefined) {
                            $('#openingBalance').text(json.openingBalance);
                        }
                        if (json.cashBalance !== undefined) {
                            $('#cashBalance').text(json.cashBalance);
                        }
                        if (json.bankBalance !== undefined) {
                            $('#bankBalance').text(json.bankBalance);
                        }
                        if (json.totalIn !== undefined) {
                            $('#totalIn').text(json.totalIn);
                        }
                        if (json.totalOut !== undefined) {
                            $('#totalOut').text(json.totalOut);
                        }
                    }

                    $('#transactionTable').closest('.dataTables_wrapper').find('.dataTables_filter input').attr('autocomplete', 'off');
                },
                drawCallback: function() {
                    this.api().columns.adjust();
                }
            });

            setTimeout(function() {
                table.columns.adjust().draw(false);
            }, 0);

            $(window).on('resize', function() {
                table.columns.adjust();
            });

            // Apply filter button click handler
            $('#applyFilter').on('click', function() {
                table.ajax.reload(function(json) {
                    if (json) {
                        if (json.openingBalance !== undefined) {
                            $('#openingBalance').text(json.openingBalance);
                        }
                        if (json.cashBalance !== undefined) {
                            $('#cashBalance').text(json.cashBalance);
                        }
                        if (json.bankBalance !== undefined) {
                            $('#bankBalance').text(json.bankBalance);
                        }
                        if (json.totalIn !== undefined) {
                            $('#totalIn').text(json.totalIn);
                        }
                        if (json.totalOut !== undefined) {
                            $('#totalOut').text(json.totalOut);
                        }
                    }
                });
            });

            $('#resetFilter').on('click', function() {
                $('#filterForm')[0].reset();
                table.order([1, 'desc']).ajax.reload();
            });

            // Delete transaction handler
            $(document).on('click', '.delete-transaction', function() {
                const transactionId = $(this).data('id');

                Swal.fire({
                    title: 'Are you sure?',
                    text: "You won't be able to revert this!",
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: 'Yes, delete it!'
                }).then((result) => {
                    if (result.isConfirmed) {
                        $.ajax({
                            url: "/admin/transactions/delete/" + transactionId,
                            type: 'DELETE',
                            data: {
                                _token: '<?php echo e(csrf_token()); ?>'
                            },
                            success: function(response) {
                                table.ajax.reload(function(json) {
                                    if (json) {
                                        if (json.openingBalance !== undefined) {
                                            $('#openingBalance').text(json.openingBalance);
                                        }
                                        if (json.cashBalance !== undefined) {
                                            $('#cashBalance').text(json.cashBalance);
                                        }
                                        if (json.bankBalance !== undefined) {
                                            $('#bankBalance').text(json.bankBalance);
                                        }
                                        if (json.totalIn !== undefined) {
                                            $('#totalIn').text(json.totalIn);
                                        }
                                        if (json.totalOut !== undefined) {
                                            $('#totalOut').text(json.totalOut);
                                        }
                                    }
                                });
                                $('#openingBalance').text(response.data.openingBalance);
                                $('#totalIn').text(response.data.totalIn);
                                $('#totalOut').text(response.data.totalOut);
                                Swal.fire(
                                    'Deleted!',
                                    'Transaction has been deleted.',
                                    'success'
                                );
                            },
                            error: function(xhr) {
                                Swal.fire(
                                    'Error!',
                                    'Something went wrong while deleting the transaction.',
                                    'error'
                                );
                            }
                        });
                    }
                });
            });

            // Edit transaction handler
            $(document).on('click', '.edit-transaction', function() {
                const transactionId = $(this).data('id');

                // Reset form and clear validation errors
                $('#transactionForm')[0].reset();
                $('#transactionForm').validate().resetForm();

                // Set transaction ID in hidden field
                $('#transactionId').val(transactionId);

                // Fetch transaction data
                $.ajax({
                    url: "/admin/transactions/edit/" + transactionId,
                    type: 'GET',
                    success: function(response) {
                        response = response.data;

                        // Pre-fill form fields
                        $('#transactionForm #party_id').val(response.party_id).trigger('change');
                        $('#transactionForm #payment_date').val(response.payment_date);
                        $('#transactionForm #transaction_type').val(response.transaction_type).trigger('change');
                        $('#transactionForm #payment_method').val(response.payment_method).trigger('change');
                        $('#transactionForm #amount').val(response.amount);
                        $('#transactionForm #note').val(response.note);
                        $('#transactionForm #transactionId').val(response.id);

                        // Show modal
                        $('#transactionModal').modal('show');
                    },
                    error: function(xhr) {
                        toastr.error('Error fetching transaction details');
                    }
                });
            });

            // Form validation
            $("#transactionForm").validate({
                rules: {
                    party_id: "required",
                    payment_date: "required",
                    transaction_type: "required",
                    payment_method: "required",
                    amount: {
                        required: true,
                        min: 0.01
                    }
                },
                messages: {
                    party_id: "Please select Party",
                    payment_date: "Please select payment date",
                    transaction_type: "Please select transaction type",
                    payment_method: "Please select payment method",
                    amount: {
                        required: "Please enter amount",
                        min: "Amount must be greater than 0"
                    }
                },
                submitHandler: function(form) {
                    var formData = $(form).serialize();
                    $.ajax({
                        url: $(form).attr('action'),
                        type: 'POST',
                        data: formData,
                        success: function(response) {
                            toastr.success(response.message);

                            // Try normal hide
                            $('#transactionModal').modal('hide');

                            // Force hide backup
                            setTimeout(() => {
                                $('#transactionModal').removeClass('show').hide();
                                $('body').removeClass('modal-open');
                                $('.modal-backdrop').remove();
                            }, 300);

                            // Reset form and select2 fields
                            $('#transactionForm')[0].reset();

                            // Update UI
                            table.ajax.reload(function(json) {
                                if (json) {
                                    if (json.openingBalance !== undefined) {
                                        $('#openingBalance').text(json.openingBalance);
                                    }
                                    if (json.totalIn !== undefined) {
                                        $('#totalIn').text(json.totalIn);
                                    }
                                    if (json.cashBalance !== undefined) {
                                        $('#cashBalance').text(json.cashBalance);
                                    }
                                    if (json.bankBalance !== undefined) {
                                        $('#bankBalance').text(json.bankBalance);
                                    }
                                    if (json.totalOut !== undefined) {
                                        $('#totalOut').text(json.totalOut);
                                    }
                                }
                            });
                        },
                        error: function(xhr) {
                            toastr.error('Error storing transaction');
                        }
                    });
                    return false;
                }
            });

            // Set default date to today
            $('#payment_date').val(new Date().toISOString().split('T')[0]);
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/html/resources/views/finance/index.blade.php ENDPATH**/ ?>