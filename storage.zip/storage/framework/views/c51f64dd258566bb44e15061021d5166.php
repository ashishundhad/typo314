<?php $__env->startSection('title'); ?>
    Daily Closing Summary
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

    <div class="container-fluid daily-closing-shell">
        <div class="daily-closing-hero">
            <div class="row align-items-center">
                <div class="col-lg-7 mb-3 mb-lg-0">
                    <!-- <div class="daily-closing-hero__eyebrow">Reports</div> -->
                    <h1 class="daily-closing-hero__title">Daily Closing Summary</h1>
                    <p class="daily-closing-hero__subtitle">
                        Review opening balance, payment-wise sales, expenses, and net profit for a single day in one clear closing view.
                    </p>
                </div>
                <div class="col-lg-5">
                    <form method="GET" action="<?php echo e(route('daily-closing')); ?>" class="daily-closing-toolbar daily-closing-no-print">
                        <div class="daily-closing-filter">
                            <label for="closingDate">Closing Date</label>
                            <input type="date" name="date" id="closingDate" class="form-control" value="<?php echo e($selectedDate); ?>">
                        </div>
                        <button type="submit" class="btn btn-light">Apply</button>
                        <a href="<?php echo e(route('daily-closing', ['date' => now()->toDateString()])); ?>" class="btn btn-outline-light">Today</a>
                        <button type="button" class="btn btn-outline-light" onclick="window.print()">Print</button>
                    </form>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-6 col-xl-3 mb-3">
                <div class="card daily-closing-summary">
                    <div class="card-body">
                        <div class="daily-closing-summary__label">Opening Balance</div>
                        <div class="daily-closing-summary__value">₹<?php echo e(number_format($openingBalance, 2)); ?></div>
                        <p class="daily-closing-summary__meta">Cash ₹<?php echo e(number_format($openingCash, 2)); ?> | Bank ₹<?php echo e(number_format($openingBank, 2)); ?></p>
                    </div>
                </div>
            </div>
            <div class="col-md-6 col-xl-3 mb-3">
                <div class="card daily-closing-summary">
                    <div class="card-body">
                        <div class="daily-closing-summary__label">Total Sales</div>
                        <div class="daily-closing-summary__value">₹<?php echo e(number_format($totalSales, 2)); ?></div>
                        <p class="daily-closing-summary__meta"><?php echo e($invoiceCount); ?> invoice(s) | <?php echo e($itemsSold); ?> item(s) sold</p>
                    </div>
                </div>
            </div>
            <div class="col-md-6 col-xl-3 mb-3">
                <div class="card daily-closing-summary daily-closing-summary--good">
                    <div class="card-body">
                        <div class="daily-closing-summary__label">Net Profit</div>
                        <div class="daily-closing-summary__value">₹<?php echo e(number_format($netProfit, 2)); ?></div>
                        <p class="daily-closing-summary__meta">Gross ₹<?php echo e(number_format($grossProfit, 2)); ?> | Expense ₹<?php echo e(number_format($totalExpense, 2)); ?></p>
                    </div>
                </div>
            </div>
            <div class="col-md-6 col-xl-3 mb-3">
                <div class="card daily-closing-summary daily-closing-summary--warn">
                    <div class="card-body">
                        <div class="daily-closing-summary__label">Closing Balance</div>
                        <div class="daily-closing-summary__value">₹<?php echo e(number_format($closingBalance, 2)); ?></div>
                        <p class="daily-closing-summary__meta">Cash ₹<?php echo e(number_format($closingCash, 2)); ?> | Bank ₹<?php echo e(number_format($closingBank, 2)); ?></p>
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-12 mb-4">
                <div class="card daily-closing-card">
                    <div class="card-body">
                        <!-- <div class="daily-closing-card__eyebrow">Trend</div> -->
                        <h2 class="daily-closing-card__title">Purchase vs Sales for Last 12 Months</h2>
                        <p class="daily-closing-card__subtitle">Compare monthly purchase cost against billed sales value from <?php echo e(collect($monthlyComparisonLabels)->first()); ?> to <?php echo e(collect($monthlyComparisonLabels)->last()); ?>.</p>

                        <div class="daily-closing-mini-stats">
                            <div class="daily-closing-mini-stat">
                                <div class="daily-closing-mini-stat__label">12 Month Purchases</div>
                                <div class="daily-closing-mini-stat__value">₹<?php echo e(number_format($lastTwelveMonthPurchaseTotal, 2)); ?></div>
                            </div>
                            <div class="daily-closing-mini-stat">
                                <div class="daily-closing-mini-stat__label">12 Month Sales</div>
                                <div class="daily-closing-mini-stat__value">₹<?php echo e(number_format($lastTwelveMonthSalesTotal, 2)); ?></div>
                            </div>
                        </div>

                        <div class="daily-closing-chart-wrap daily-closing-no-print">
                            <canvas id="purchaseSalesComparisonChart"></canvas>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-lg-5 mb-4">
                <div class="card daily-closing-card">
                    <div class="card-body">
                        <!-- <div class="daily-closing-card__eyebrow">Cash Flow</div> -->
                        <h2 class="daily-closing-card__title">Closing Breakdown</h2>
                        <p class="daily-closing-card__subtitle">A quick view of how today moved cash, bank balance, and profit.</p>

                        <div class="daily-closing-stat">
                            <div class="daily-closing-stat__label">Cash Sales</div>
                            <div class="daily-closing-stat__value">₹<?php echo e(number_format($cashSales, 2)); ?></div>
                        </div>
                        <div class="daily-closing-stat">
                            <div class="daily-closing-stat__label">Online / UPI Sales</div>
                            <div class="daily-closing-stat__value">₹<?php echo e(number_format($onlineSales, 2)); ?></div>
                        </div>
                        <div class="daily-closing-stat">
                            <div class="daily-closing-stat__label">Card Sales</div>
                            <div class="daily-closing-stat__value">₹<?php echo e(number_format($cardSales, 2)); ?></div>
                        </div>
                        <div class="daily-closing-stat">
                            <div class="daily-closing-stat__label">Expenses</div>
                            <div class="daily-closing-stat__value is-negative">₹<?php echo e(number_format($totalExpense, 2)); ?></div>
                        </div>
                        <div class="daily-closing-stat">
                            <div class="daily-closing-stat__label">Gross Profit</div>
                            <div class="daily-closing-stat__value is-positive">₹<?php echo e(number_format($grossProfit, 2)); ?></div>
                        </div>
                        <div class="daily-closing-stat">
                            <div class="daily-closing-stat__label">Net Profit</div>
                            <div class="daily-closing-stat__value <?php echo e($netProfit >= 0 ? 'is-positive' : 'is-negative'); ?>">₹<?php echo e(number_format($netProfit, 2)); ?></div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-lg-7 mb-4">
                <div class="card daily-closing-card">
                    <div class="card-body">
                        <!-- <div class="daily-closing-card__eyebrow">Register</div> -->
                        <h2 class="daily-closing-card__title">Daily Position</h2>
                        <p class="daily-closing-card__subtitle">Use this as a simple end-of-day reconciliation snapshot.</p>

                        <div class="row">
                            <div class="col-md-6">
                                <div class="daily-closing-stat">
                                    <div class="daily-closing-stat__label">Opening Cash</div>
                                    <div class="daily-closing-stat__value">₹<?php echo e(number_format($openingCash, 2)); ?></div>
                                </div>
                                <div class="daily-closing-stat">
                                    <div class="daily-closing-stat__label">Cash Inflow</div>
                                    <div class="daily-closing-stat__value">₹<?php echo e(number_format($cashSales, 2)); ?></div>
                                </div>
                                <div class="daily-closing-stat">
                                    <div class="daily-closing-stat__label">Cash Outflow</div>
                                    <div class="daily-closing-stat__value is-negative">₹<?php echo e(number_format($totalExpense, 2)); ?></div>
                                </div>
                                <div class="daily-closing-stat">
                                    <div class="daily-closing-stat__label">Closing Cash</div>
                                    <div class="daily-closing-stat__value">₹<?php echo e(number_format($closingCash, 2)); ?></div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="daily-closing-stat">
                                    <div class="daily-closing-stat__label">Opening Bank</div>
                                    <div class="daily-closing-stat__value">₹<?php echo e(number_format($openingBank, 2)); ?></div>
                                </div>
                                <div class="daily-closing-stat">
                                    <div class="daily-closing-stat__label">Bank / UPI Inflow</div>
                                    <div class="daily-closing-stat__value">₹<?php echo e(number_format($onlineSales + $cardSales, 2)); ?></div>
                                </div>
                                <div class="daily-closing-stat">
                                    <div class="daily-closing-stat__label">Closing Bank</div>
                                    <div class="daily-closing-stat__value">₹<?php echo e(number_format($closingBank, 2)); ?></div>
                                </div>
                                <div class="daily-closing-stat">
                                    <div class="daily-closing-stat__label">Total Closing</div>
                                    <div class="daily-closing-stat__value">₹<?php echo e(number_format($closingBalance, 2)); ?></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-lg-8 mb-4">
                <div class="card daily-closing-card">
                    <div class="card-body">
                        <!-- <div class="daily-closing-card__eyebrow">Sales</div> -->
                        <h2 class="daily-closing-card__title">Invoices on <?php echo e(\Carbon\Carbon::parse($selectedDate)->format('d M Y')); ?></h2>
                        <p class="daily-closing-card__subtitle">Review today’s invoice activity and payment mix.</p>

                        <?php if($invoices->isEmpty()): ?>
                            <div class="daily-closing-empty">No invoices found for this date.</div>
                        <?php else: ?>
                            <div class="table-responsive">
                                <table class="table daily-closing-table">
                                    <thead>
                                        <tr>
                                            <th>Invoice</th>
                                            <th>Customer</th>
                                            <th>Payment</th>
                                            <th class="text-right">Amount</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $invoices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $invoice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td>
                                                    <strong>#<?php echo e($invoice->invoice_no); ?></strong><br>
                                                    <small class="text-muted"><?php echo e(\Carbon\Carbon::parse($invoice->invoice_date)->format('d-m-Y')); ?></small>
                                                </td>
                                                <td>
                                                    <strong><?php echo e($invoice->customer_name ?: 'Walk-in Customer'); ?></strong><br>
                                                    <small class="text-muted"><?php echo e($invoice->customer_no ?: '-'); ?></small>
                                                </td>
                                                <td>
                                                    <span class="daily-closing-payment"><?php echo e($invoice->payment_type ?: 'Unknown'); ?></span>
                                                </td>
                                                <td class="daily-closing-amount">₹<?php echo e(number_format((float) $invoice->net_amount, 2)); ?></td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <div class="col-lg-4 mb-4">
                <div class="card daily-closing-card">
                    <div class="card-body">
                        <!-- <div class="daily-closing-card__eyebrow">Expenses</div> -->
                        <h2 class="daily-closing-card__title">Expense Register</h2>
                        <p class="daily-closing-card__subtitle">Expenses are deducted from cash while calculating today’s closing.</p>

                        <?php if($expenses->isEmpty()): ?>
                            <div class="daily-closing-empty">No expenses recorded for this date.</div>
                        <?php else: ?>
                            <?php $__currentLoopData = $expenses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $expense): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="daily-closing-stat">
                                    <div>
                                        <div class="daily-closing-stat__label text-dark"><?php echo e($expense->expense_name ?: ($expense->title ?? 'Expense')); ?></div>
                                        <small class="text-muted"><?php echo e($expense->remark ?: ($expense->note ?? 'No note added')); ?></small>
                                    </div>
                                    <div class="daily-closing-stat__value is-negative">₹<?php echo e(number_format((float) $expense->amount, 2)); ?></div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        const monthlyComparisonLabels = <?php echo json_encode($monthlyComparisonLabels, 15, 512) ?>;
        const monthlyPurchaseSeries = <?php echo json_encode($monthlyPurchaseSeries, 15, 512) ?>;
        const monthlySalesSeries = <?php echo json_encode($monthlySalesSeries, 15, 512) ?>;

        const closingAxisLabelColor = '#607086';
        const closingGridColor = 'rgba(148, 163, 184, 0.18)';
        const closingCurrencyTooltip = (value) => '₹' + Number(value).toLocaleString('en-IN', {
            minimumFractionDigits: 2,
            maximumFractionDigits: 2
        });

        new Chart(document.getElementById('purchaseSalesComparisonChart'), {
            type: 'bar',
            data: {
                labels: monthlyComparisonLabels,
                datasets: [{
                    label: 'Purchase',
                    data: monthlyPurchaseSeries,
                    backgroundColor: '#17324d',
                    borderRadius: 8,
                    maxBarThickness: 24
                }, {
                    label: 'Sales',
                    data: monthlySalesSeries,
                    backgroundColor: '#1abc9c',
                    borderRadius: 8,
                    maxBarThickness: 24
                }]
            },
            options: {
                maintainAspectRatio: false,
                interaction: {
                    mode: 'index',
                    intersect: false
                },
                plugins: {
                    legend: {
                        position: 'bottom',
                        labels: {
                            color: closingAxisLabelColor,
                            boxWidth: 14,
                            padding: 18
                        }
                    },
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                return ' ' + context.dataset.label + ': ' + closingCurrencyTooltip(context.parsed.y);
                            }
                        }
                    }
                },
                scales: {
                    x: {
                        ticks: {
                            color: closingAxisLabelColor
                        },
                        grid: {
                            display: false
                        }
                    },
                    y: {
                        beginAtZero: true,
                        ticks: {
                            color: closingAxisLabelColor,
                            callback: function(value) {
                                return '₹' + Number(value).toLocaleString('en-IN');
                            }
                        },
                        grid: {
                            color: closingGridColor
                        }
                    }
                }
            }
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/html/resources/views/reports/daily-closing.blade.php ENDPATH**/ ?>