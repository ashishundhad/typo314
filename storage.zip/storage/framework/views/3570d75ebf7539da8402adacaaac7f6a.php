<?php $__env->startSection('title', 'Sale Returns'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row align-items-center">
            <div class="col-12 mt-2 mb-2">
                <h4 class="page-title">Sale Returns</h4>
            </div>
        </div>

        <div class="card-box">
            <table id="saleReturnsTable" class="table table-bordered">
                <thead>
                    <tr>
                        <th style="width: 5%;">#</th>
                        <th>Invoice</th>
                        <th>Item</th>
                        <th>Qty</th>
                        <th>Refund Amount</th>
                        <th>Condition</th>
                        <th>Reason</th>
                        <th>Return Date</th>
                        <th>Processed By</th>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('returns.delete')): ?>
                            <th style="width: 10%;">Action</th>
                        <?php endif; ?>
                    </tr>
                </thead>
                <tbody></tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        $(function () {
            $('#saleReturnsTable').DataTable({
                processing: true,
                serverSide: true,
                scrollX: true,
                ajax: "<?php echo e(route('sale-returns.index')); ?>",
                columns: [
                    { data: 'DT_RowIndex', name: 'DT_RowIndex', className: 'text-center' },
                    { data: 'invoice_no', name: 'invoice_no' },
                    { data: 'item', name: 'item' },
                    { data: 'quantity', name: 'quantity', className: 'text-center' },
                    {
                        data: 'refund_amount',
                        name: 'refund_amount',
                        render: function (data) {
                            return '₹' + data;
                        }
                    },
                    {
                        data: 'condition',
                        name: 'condition',
                        render: function (data) {
                            const cls = data === 'damaged' ? 'badge-danger' : 'badge-success';
                            return `<span class="badge ${cls}">${data}</span>`;
                        }
                    },
                    { data: 'reason', name: 'reason' },
                    { data: 'return_date', name: 'return_date' },
                    { data: 'processed_by', name: 'processed_by' },
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('returns.delete')): ?>
                    {
                        data: 'id',
                        name: 'action',
                        className: 'text-center',
                        orderable: false,
                        searchable: false,
                        render: function (data) {
                            return '<button class="btn btn-danger btn-sm void-return" data-id="' + data + '">Void</button>';
                        }
                    },
                    <?php endif; ?>
                ]
            });
        });

        $(document).on('click', '.void-return', function () {
            const id = $(this).data('id');
            Swal.fire({
                title: 'Void this return?',
                text: "This will re-mark the returned unit(s) as sold and remove the refund ledger entry.",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Yes, void it'
            }).then((result) => {
                if (result.isConfirmed) {
                    const form = document.createElement('form');
                    form.method = 'POST';
                    form.action = '<?php echo e(url("admin/sale-returns")); ?>/' + id + '/void';
                    form.innerHTML = '<?php echo csrf_field(); ?>';
                    document.body.appendChild(form);
                    form.submit();
                }
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/html/resources/views/sale-returns/index.blade.php ENDPATH**/ ?>