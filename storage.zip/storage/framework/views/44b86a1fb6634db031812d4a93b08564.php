<?php $__env->startSection('title'); ?>
    Sales Report
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="container-fluid sales-report-shell">
        <div class="sales-report-hero">
            <div class="row align-items-center">
                <div class="col-lg-8">
                    <!-- <div class="sales-report-hero__eyebrow">Reports</div> -->
                    <h1 class="sales-report-hero__title">Sales Report</h1>
                    <p class="sales-report-hero__subtitle">
                    </p>
                </div>
                <div class="col-lg-4">
                    <div class="sales-report-actions">
                        <a href="<?php echo e(route('sale-export', request()->query())); ?>" class="btn btn-light sales-report-btn">
                            <i class="mdi mdi-microsoft-excel mr-1"></i>Spreadsheet
                        </a>
                        <a href="<?php echo e(route('sale-export-pdf', request()->query())); ?>" class="btn btn-outline-light sales-report-btn">
                            <i class="mdi mdi-file-pdf-box mr-1"></i>PDF
                        </a>
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-6 col-xl-3 mb-3">
                <div class="card sales-report-summary sales-report-summary--sales">
                    <div class="card-body">
                        <div class="sales-report-summary__label">Total Sales - <?php echo e($timePeriod); ?></div>
                        <div class="sales-report-summary__value">₹<?php echo e(number_format($totalSalesAmount, 2)); ?></div>
                    </div>
                </div>
            </div>
            <div class="col-md-6 col-xl-3 mb-3">
                <div class="card sales-report-summary sales-report-summary--profit">
                    <div class="card-body">
                        <div class="sales-report-summary__label">Total Profit - <?php echo e($timePeriod); ?></div>
                        <div class="sales-report-summary__value">₹<?php echo e(number_format($totalProfitAmount, 2)); ?></div>
                    </div>
                </div>
            </div>
            <div class="col-md-6 col-xl-3 mb-3">
                <div class="card sales-report-summary sales-report-summary--expense">
                    <div class="card-body">
                        <div class="sales-report-summary__label">Total Expense - <?php echo e($timePeriod); ?></div>
                        <div class="sales-report-summary__value">₹<?php echo e(number_format($totalExpenseAmount, 2)); ?></div>
                    </div>
                </div>
            </div>
            <div class="col-md-6 col-xl-3 mb-3">
                <div class="card sales-report-summary sales-report-summary--net">
                    <div class="card-body">
                        <div class="sales-report-summary__label">Net Profit - <?php echo e($timePeriod); ?></div>
                        <div class="sales-report-summary__value">₹<?php echo e(number_format($totalProfitAmount - $totalExpenseAmount, 2)); ?></div>
                    </div>
                </div>
            </div>
        </div>

        <div class="card sales-report-card">
            <div class="card-body">
                <h2 class="sales-report-card__title">Transactions Report [<?php echo e($totalItems); ?>]</h2>
                <p class="sales-report-card__subtitle"></p>

                <div class="sales-report-filter">
                    <form method="GET" id="salesreport">
                        <div class="form-row align-items-end">
                            <div class="col-12 col-md-4 mb-3 mb-md-0">
                                <label class="sales-report-label" for="selectsalesperiod">Report Period</label>
                                <select name="period" class="form-control" id="selectsalesperiod">
                                    <option value="alls" <?php if($period == 'alls'): echo 'selected'; endif; ?>>All Sales</option>
                                    <option value="thismonth" <?php if($period == 'thismonth'): echo 'selected'; endif; ?>>This Month</option>
                                    <option value="lastmonth" <?php if($period == 'lastmonth'): echo 'selected'; endif; ?>>Last Month</option>
                                    <option value="thisyear" <?php if($period == 'thisyear'): echo 'selected'; endif; ?>>This Year</option>
                                    <option value="lastyear" <?php if($period == 'lastyear'): echo 'selected'; endif; ?>>Last Year</option>
                                    <option value="custom" <?php if($period == 'custom'): echo 'selected'; endif; ?>>Custom Range</option>
                                </select>
                            </div>

                            <div class="col-md-2 mb-3 mb-md-0 sales-report-date-group <?php if($period == 'custom'): ?> showdefault <?php endif; ?>">
                                <label class="sales-report-label" for="salefromdate">From Date</label>
                                <input type="date" id="salefromdate" name="fromdate" class="form-control"
                                    value="<?php echo e($fromdate); ?>">
                            </div>
                            <div class="col-md-2 mb-3 mb-md-0 sales-report-date-group <?php if($period == 'custom'): ?> showdefault <?php endif; ?>">
                                <label class="sales-report-label" for="saletodate">To Date</label>
                                <input type="date" id="saletodate" name="todate" class="form-control"
                                    value="<?php echo e($todate); ?>">
                            </div>

                            <div class="col-12 col-md-4 d-flex">
                                <button type="submit" formaction="<?php echo e(route('sale-report')); ?>" class="btn btn-primary sales-report-btn flex-fill mr-2">
                                    Filter
                                </button>
                                <a href="<?php echo e(route('sale-report')); ?>" class="btn btn-outline-danger sales-report-btn flex-fill">
                                    Clear
                                </a>
                            </div>
                        </div>
                    </form>
                </div>

                <div class="table-responsive">
                    <?php if(count($allSales)): ?>
                        <table class="table sales-report-table" id="invoice-tables">
                            <thead>
                                <tr>
                                    <th>Date</th>
                                    <th>Invoice No.</th>
                                    <th>Party Name</th>
                                    <th class="text-right">Billing Info</th>
                                    <th>Payment Type</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $allSales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $invoice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td>
                                            <span class="sales-report-date"><?php echo e(date('d/m/Y', strtotime($invoice->invoice_date))); ?></span>
                                        </td>
                                        <td>
                                            <a href="<?php echo e(route('invoice-detail', $invoice->id)); ?>" class="sales-report-invoice">
                                                #<?php echo e($invoice->invoice_no); ?>

                                            </a>
                                        </td>
                                        <td>
                                            <div class="sales-report-party__name"><?php echo e(ucwords($invoice->customer_name)); ?></div>
                                            <div class="sales-report-party__meta">
                                                <?php if($invoice->customer_no): ?>
                                                    Contact: <?php echo e(ucfirst($invoice->customer_no)); ?>

                                                <?php else: ?>
                                                    Contact: N/A
                                                <?php endif; ?>
                                            </div>
                                        </td>
                                        <td class="sales-report-billing">
                                            <?php if($invoice->total_amount): ?>
                                                <div class="sales-report-billing__item">
                                                    <span class="sales-report-billing__label">Total Amount</span>
                                                    <span class="sales-report-billing__value">₹<?php echo e(number_format($invoice->total_amount, 2)); ?></span>
                                                </div>
                                            <?php endif; ?>
                                            <?php if($invoice->tax_amount): ?>
                                                <div class="sales-report-billing__item">
                                                    <span class="sales-report-billing__label">Tax</span>
                                                    <span class="sales-report-billing__value">₹<?php echo e(number_format($invoice->tax_amount, 2)); ?></span>
                                                </div>
                                            <?php endif; ?>
                                            <?php if($invoice->discount): ?>
                                                <div class="sales-report-billing__item">
                                                    <span class="sales-report-billing__label">Discount</span>
                                                    <span class="sales-report-billing__value">₹<?php echo e(number_format($invoice->discount, 2)); ?></span>
                                                </div>
                                            <?php endif; ?>
                                            <?php if($invoice->net_amount): ?>
                                                <div class="sales-report-billing__item">
                                                    <span class="sales-report-billing__label">Net Amount</span>
                                                    <span class="sales-report-billing__value sales-report-billing__value--net">₹<?php echo e(number_format($invoice->net_amount, 2)); ?></span>
                                                </div>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <span class="sales-report-payment"><?php echo e(ucfirst($invoice->payment_type)); ?></span>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <div class="mt-3">
                            <?php echo e($allSales->appends(request()->query())->links('vendor.pagination.bootstrap-5')); ?>

                        </div>
                    <?php else: ?>
                        <div class="sales-report-empty">
                            <div class="sales-report-empty__icon">
                                <i class="mdi mdi-chart-bar-stacked"></i>
                            </div>
                            <h4>No transactions to show</h4>
                            <p>Try another period or date range to view sales activity.</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <script>
        (function () {
            const periodSelect = document.getElementById('selectsalesperiod');
            const dateGroups = document.querySelectorAll('.sales-report-date-group');

            function toggleCustomDateFields() {
                const showDates = periodSelect && periodSelect.value === 'custom';

                dateGroups.forEach(function (group) {
                    group.style.display = showDates ? 'block' : 'none';
                });
            }

            if (periodSelect) {
                periodSelect.addEventListener('change', toggleCustomDateFields);
                toggleCustomDateFields();
            }
        })();
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/html/resources/views/reports/sales.blade.php ENDPATH**/ ?>