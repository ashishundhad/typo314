<?php $__env->startSection('title', 'Sale Details'); ?>

<?php
    use Carbon\Carbon;

    $expirydate = $sale->warranty_expiry_date ? Carbon::parse($sale->warranty_expiry_date) : null;
    $currentDate = Carbon::now();

    // See identical note in invoice/_document.blade.php for why "include" mode needs
    // total_amount - tax_amount here instead of total_amount directly.
    $saleSubtotal = $sale->gst_mode === 'include'
        ? $sale->total_amount - ($sale->tax_amount ?? 0)
        : $sale->total_amount;
?>

<?php $__env->startSection('content'); ?>

    <div class="container-fluid sale-detail-shell">
        <div class="sale-detail-wrap">
            <div class="sale-detail-hero">
                <div class="row align-items-center">
                    <div class="col-lg-8">
                        <!-- <div class="sale-detail-hero__eyebrow">Sales Overview</div> -->
                        <h1 class="sale-detail-hero__title">Sale #<?php echo e($sale->invoice_no); ?></h1>
                        <!-- <p class="sale-detail-hero__subtitle">
                            Review invoice details, sold items, payment information, and sale profitability from one organized screen.
                        </p> -->
                    </div>
                    <div class="col-lg-4">
                        <div class="sale-detail-hero__meta">
                            <!-- <span class="sale-detail-pill">
                                <i class="mdi mdi-calendar-month-outline"></i>
                                <?php echo e($sale->invoice_date ? Carbon::parse($sale->invoice_date)->format('d M Y') : '-'); ?>

                            </span> -->
                            <a href="javascript:history.back();" class="btn sale-detail-back">
                                <i class="mdi mdi-arrow-left mr-1"></i>Back
                            </a>
                        </div>
                    </div>
                </div>
            </div>

            <div class="sale-detail-grid">
                <div class="card sale-detail-card">
                    <div class="card-body">
                        <!-- <div class="sale-detail-card__eyebrow">Invoice Information</div> -->
                        <h2 class="sale-detail-card__title">Customer & Billing</h2>
                        <!-- <p class="sale-detail-card__subtitle">The key transaction and customer details for this completed sale.</p> -->

                        <div class="sale-detail-info-grid">
                            <div class="sale-detail-info">
                                <div class="sale-detail-info__label">Invoice No</div>
                                <div class="sale-detail-info__value">#<?php echo e($sale->invoice_no); ?></div>
                            </div>
                            <div class="sale-detail-info">
                                <div class="sale-detail-info__label">Sale Date</div>
                                <div class="sale-detail-info__value">
                                    <?php echo e($sale->invoice_date ? Carbon::parse($sale->invoice_date)->format('d-m-Y') : '-'); ?>

                                </div>
                            </div>
                            <div class="sale-detail-info">
                                <div class="sale-detail-info__label">Customer Name</div>
                                <div class="sale-detail-info__value"><?php echo e($sale->customer_name ?? '-'); ?></div>
                            </div>
                            <div class="sale-detail-info">
                                <div class="sale-detail-info__label">Customer No</div>
                                <div class="sale-detail-info__value"><?php echo e($sale->customer_no ?? '-'); ?></div>
                            </div>
                            <div class="sale-detail-info">
                                <div class="sale-detail-info__label">Payment Type</div>
                                <div class="sale-detail-info__value">
                                    <span class="sale-detail-badge sale-detail-badge--info">
                                        <?php echo e(strtoupper($sale->payment_type ?? '-')); ?>

                                    </span>
                                </div>
                            </div>
                            <div class="sale-detail-info">
                                <div class="sale-detail-info__label">Sold By</div>
                                <div class="sale-detail-info__value"><?php echo e($soldBy->name ?? '-'); ?></div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="card sale-detail-card">
                    <div class="card-body">
                        <!-- <div class="sale-detail-card__eyebrow">Summary</div> -->
                        <h2 class="sale-detail-card__title">Financial Snapshot</h2>
                        <!-- <p class="sale-detail-card__subtitle">Quick view of totals, warranty status, and profitability.</p> -->

                        <div class="sale-detail-summary-list">
                            <div class="sale-detail-summary-item">
                                <div class="sale-detail-summary-item__label">Warranty Expiry</div>
                                <div class="sale-detail-summary-item__value">
                                    <?php if($sale->warranty_expiry_date): ?>
                                        <?php if($expirydate && $expirydate->lt($currentDate)): ?>
                                            <span class="sale-detail-badge sale-detail-badge--danger">
                                                <?php echo e(Carbon::parse($sale->warranty_expiry_date)->format('d-m-Y')); ?> Expired
                                            </span>
                                        <?php else: ?>
                                            <span class="sale-detail-badge sale-detail-badge--success">
                                                <?php echo e(Carbon::parse($sale->warranty_expiry_date)->format('d-m-Y')); ?>

                                            </span>
                                        <?php endif; ?>
                                    <?php else: ?>
                                        <span class="sale-detail-badge sale-detail-badge--warning">Not Available</span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <?php if($sale->gst_mode && $sale->gst_mode !== 'none'): ?>
                                <div class="sale-detail-summary-item">
                                    <div class="sale-detail-summary-item__label"><?php echo e($sale->invoice_type === 'tax' ? 'Taxable Amount' : 'Subtotal'); ?></div>
                                    <div class="sale-detail-summary-item__value">₹<?php echo e(number_format($saleSubtotal, 2)); ?></div>
                                </div>

                                <?php if($sale->cgst_amount): ?>
                                    <div class="sale-detail-summary-item">
                                        <div class="sale-detail-summary-item__label">CGST (<?php echo e(rtrim(rtrim(number_format($sale->cgst_rate, 2), '0'), '.')); ?>%)</div>
                                        <div class="sale-detail-summary-item__value">₹<?php echo e(number_format($sale->cgst_amount, 2)); ?></div>
                                    </div>
                                <?php endif; ?>

                                <?php if($sale->sgst_amount): ?>
                                    <div class="sale-detail-summary-item">
                                        <div class="sale-detail-summary-item__label">SGST (<?php echo e(rtrim(rtrim(number_format($sale->sgst_rate, 2), '0'), '.')); ?>%)</div>
                                        <div class="sale-detail-summary-item__value">₹<?php echo e(number_format($sale->sgst_amount, 2)); ?></div>
                                    </div>
                                <?php endif; ?>

                                <?php if($sale->igst_amount): ?>
                                    <div class="sale-detail-summary-item">
                                        <div class="sale-detail-summary-item__label">IGST (<?php echo e(rtrim(rtrim(number_format($sale->igst_rate, 2), '0'), '.')); ?>%)</div>
                                        <div class="sale-detail-summary-item__value">₹<?php echo e(number_format($sale->igst_amount, 2)); ?></div>
                                    </div>
                                <?php endif; ?>
                            <?php endif; ?>

                            <?php if(($sale->discount ?? 0) > 0): ?>
                                <div class="sale-detail-summary-item">
                                    <div class="sale-detail-summary-item__label">Discount</div>
                                    <div class="sale-detail-summary-item__value">
                                        ₹<?php echo e(number_format($sale->discount, 2)); ?>

                                        <?php if($sale->discount_rate): ?>
                                            <span class="text-muted">(<?php echo e(rtrim(rtrim(number_format($sale->discount_rate, 2), '0'), '.')); ?>%)</span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            <?php endif; ?>

                            <div class="sale-detail-summary-item">
                                <div class="sale-detail-summary-item__label">Net Amount</div>
                                <div class="sale-detail-summary-item__value">₹<?php echo e(number_format($sale->net_amount ?? 0, 2)); ?></div>
                            </div>

                            <?php if(in_array('super-admin', Auth::user()->roles->pluck('name')->toArray())): ?>
                                <div class="sale-detail-summary-item">
                                    <div class="sale-detail-summary-item__label">Total Profit</div>
                                    <div class="sale-detail-summary-item__value" style="color:#169c82;">
                                        ₹<?php echo e(number_format($totalProfit ?? 0, 2)); ?>

                                    </div>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>

            <div class="card sale-detail-table-card">
                <div class="card-body">
                    <!-- <div class="sale-detail-card__eyebrow">Sold Products</div> -->
                    <h2 class="sale-detail-card__title">Product Details</h2>
                    <!-- <p class="sale-detail-card__subtitle">Line-item breakdown of the devices included in this sale.</p> -->

                    <div class="table-responsive">
                        <table class="table sale-detail-table">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Product</th>
                                    <th>IMEI</th>
                                    <th>Color</th>
                                    <th>Storage</th>
                                    <th class="sale-detail-text-right">Purchase Price</th>
                                    <th class="sale-detail-text-right">Sell Price</th>
                                    <th class="sale-detail-text-right">Profit</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $sale->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td><span class="sale-detail-index">#<?php echo e($index + 1); ?></span></td>
                                        <td>
                                            <div class="sale-detail-product"><?php echo e($item->purchase->model ?? '-'); ?></div>
                                            <div class="sale-detail-submeta">Invoice item <?php echo e($index + 1); ?></div>
                                        </td>
                                        <td><?php echo e($item->purchase->imei ?? '-'); ?></td>
                                        <td><?php echo e($item->purchase->color ?? '-'); ?></td>
                                        <td><?php echo e($item->purchase->storage ?? '-'); ?> GB</td>
                                        <td class="sale-detail-text-right">
                                            <span class="sale-detail-amount">₹<?php echo e(number_format($item->purchase->purchase_price ?? 0, 2)); ?></span>
                                        </td>
                                        <td class="sale-detail-text-right">
                                            <span class="sale-detail-amount">₹<?php echo e(number_format($item->unit_price ?? 0, 2)); ?></span>
                                        </td>
                                        <td class="sale-detail-text-right">
                                            <span class="sale-detail-amount" style="color:#169c82;">
                                                ₹<?php echo e(number_format($item->profit ?? 0, 2)); ?>

                                            </span>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="8" class="sale-detail-empty">No items found for this sale.</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/html/resources/views/sales/saledetail.blade.php ENDPATH**/ ?>