<?php $__env->startSection('title'); ?>
    Manage Sales
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid sales-page">
    <div class="sales-topbar">
        <div>
            <h1 class="sales-topbar__title">Sales</h1>
            <p class="sales-topbar__subtitle">Browse, search, and manage every recorded sale.</p>
        </div>
        <div class="sales-topbar__actions">
            <div class="sales-mini-stat">
                <div class="sales-mini-stat__label">Total</div>
                <div class="sales-mini-stat__value"><?php echo e($totalItems); ?></div>
            </div>
        </div>
    </div>

    <div class="sales-card">
        <!-- <div class="sales-card__header">
            <div>
                <h4 class="sales-card__title">Sales Register</h4>
                <p class="sales-card__subtitle">Search by ID, customer, or item, then filter by year and payment type.</p>
            </div>
        </div> -->

        <form action="<?php echo e(route('allsales')); ?>" method="GET" id="filtersales" class="sales-filter-form">
            <div class="form-row align-items-end">
                <div class="form-group col-md-5 mb-2 mb-md-0">
                    <!-- <label class="sales-filter-label" for="searchsales">Search</label> -->
                    <div class="sales-search-group">
                        <input type="text" class="form-control" placeholder="Search by ID, customer, item.." name="search"
                            value="<?php echo e(request()->input('search')); ?>" id="searchsales">
                        <button class="btn btn-primary" type="submit">
                            <i class="mdi mdi-magnify"></i> Search
                        </button>
                    </div>
                </div>

                <div class="form-group col-md-3 mb-2 mb-md-0">
                    <!-- <label class="sales-filter-label" for="selectyear">Year</label> -->
                    <select name="year" class="form-control" id="selectyear">
                        <option value="">All Years</option>
                        <?php for($filterYear = now()->year; $filterYear >= 2024; $filterYear--): ?>
                            <option value="<?php echo e($filterYear); ?>" <?php if((int) $year === $filterYear): echo 'selected'; endif; ?>>
                                <?php echo e($filterYear); ?>

                            </option>
                        <?php endfor; ?>
                    </select>
                </div>
                <div class="form-group col-md-4 mb-0">
                    <!-- <label class="sales-filter-label" for="payments">Payment Type</label> -->
                    <select name="paymentType" class="form-control" id="payments">
                        <option value="">All Payment Types</option>
                        <option value="Online" <?php if($paymentType == 'Online'): echo 'selected'; endif; ?>>Online</option>
                        <option value="Credit Card" <?php if($paymentType == 'Credit Card'): echo 'selected'; endif; ?>>Credit Card</option>
                        <option value="Cash" <?php if($paymentType == 'Cash'): echo 'selected'; endif; ?>>Cash</option>
                    </select>
                </div>
            </div>
        </form>

        <?php if(count($allSales)): ?>
            <div class="table-responsive sales-table-wrap">
                <table class="table sales-table table-hover m-0 table-centered dt-responsive nowrap w-100" id="tickets-table">
                    <thead>
                        <tr>
                            <th>
                                <a class="sales-sort-link" href="<?php echo e(route('allsales', ['direction' => $sortDirection == 'asc' ? 'desc' : 'asc'])); ?>">
                                    Sr.No
                                    <?php if($sortDirection == 'asc'): ?>
                                        <i class="mdi mdi-arrow-up"></i>
                                    <?php else: ?>
                                        <i class="mdi mdi-arrow-down"></i>
                                    <?php endif; ?>
                                </a>
                            </th>
                            <th>Item Detail</th>
                            <th>Customer</th>
                            <th>Payment</th>
                            <th>Date</th>
                            <th class="text-right">Amount</th>
                            <th class="text-right">Action</th>
                        </tr>
                    </thead>

                    <tbody>
                        <?php $__currentLoopData = $allSales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><a href="<?php echo e(route('saledetail', $sale->id)); ?>" class="sales-index">#<?php echo e($sale->id); ?></a></td>
                                <td>
                                    <?php if($sale->items->isEmpty()): ?>
                                        <div class="sales-product">
                                            <div class="sales-product__title">No items</div>
                                        </div>
                                    <?php else: ?>
                                        <?php $__currentLoopData = $sale->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php
                                                $p = $item->purchase; // can be null if the record was detached later
                                            ?>
                                            <div class="sales-product">
                                                <div class="sales-product__title"><?php echo e($p->model ?? 'Unknown Model'); ?></div>
                                                <div class="sales-product__meta">
                                                    <span class="sales-chip">Color: <?php echo e($p->color ?? '-'); ?></span>
                                                    <span class="sales-chip">Storage: <?php echo e($p->storage ?? '-'); ?></span>
                                                    <span class="sales-chip">IMEI: <?php echo e($p->imei ?? '-'); ?></span>
                                                    <span class="sales-chip">Qty: <?php echo e($item->qty ?? 1); ?></span>
                                                </div>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <div class="sales-customer__name"><?php echo e($sale->customer_name ?: 'Walk-in Customer'); ?></div>
                                    <?php if($sale->customer_no): ?>
                                        <div class="sales-customer__contact">
                                            <a href="tel:<?php echo e($sale->customer_no); ?>"><?php echo e($sale->customer_no); ?></a>
                                        </div>
                                    <?php else: ?>
                                        <div class="text-muted">No contact number</div>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if($sale->payment_type == 'Cash'): ?>
                                        <span class="badge badge-soft-primary text-primary px-3 py-2"><?php echo e($sale->payment_type); ?></span>
                                    <?php elseif($sale->payment_type == 'Online'): ?>
                                        <span class="badge badge-soft-info text-info px-3 py-2"><?php echo e($sale->payment_type); ?></span>
                                    <?php elseif($sale->payment_type == 'Credit Card'): ?>
                                        <span class="badge badge-soft-warning text-warning px-3 py-2"><?php echo e($sale->payment_type); ?></span>
                                    <?php else: ?>
                                        <span class="badge badge-light px-3 py-2"><?php echo e($sale->payment_type); ?></span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <div class="sales-date"><?php echo e(Carbon\Carbon::parse($sale->created_at)->format('d M Y')); ?></div>
                                </td>
                                <td class="sales-amount">
                                    <span class="sales-amount__value">₹<?php echo e($sale->net_amount); ?></span>
                                </td>
                                <td class="sales-actions">
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('sales.view')): ?>
                                        <a href="<?php echo e(route('saledetail', $sale->id)); ?>" class="btn btn-light btn-sm mr-2" title="View">
                                            <i class="mdi mdi-eye-outline"></i>
                                        </a>
                                    <?php endif; ?>
                                    <form method="post" action="<?php echo e(route('delete-sale', $sale->id)); ?>" style="display:inline;">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-danger btn-sm" onclick="sureToDelete(event)" title="Delete">
                                            <i class="mdi mdi-trash-can-outline"></i>
                                        </button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>

            <div class="pagination-links px-3 pb-3">
                <?php echo e($allSales->appends(request()->query())->links('vendor.pagination.bootstrap-5')); ?>

            </div>
        <?php else: ?>
            <div class="sales-empty">
                <div class="sales-empty__icon">
                    <i class="mdi mdi-chart-timeline-variant"></i>
                </div>
                <h4>No sales found</h4>
                <p>Try a different search or filter.</p>
            </div>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/html/resources/views/sales/index.blade.php ENDPATH**/ ?>