<?php $companySetting = \App\Models\CompanySetting::current(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <title>Log In | <?php echo e($companySetting->company_name); ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta content="We deal with BUY Sale Exchanges of Old Phones" name="description" />
    <meta content="<?php echo e($companySetting->company_name); ?>" name="author" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <link rel="shortcut icon" href="<?php echo e($companySetting->logo ? asset($companySetting->logo) : asset('assets/images/new_logo/favicon.ico')); ?>">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('assets/css/icons.min.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('assets/css/tenant.css')); ?>" rel="stylesheet" type="text/css" />

</head>

<body>
    <main class="login-shell">
        <div class="w-100" style="max-width: 416px;">
            <div class="login-card">
                <div class="login-logo"><span></span><span></span><span></span></div>
                <h1 class="login-brandname">Invoxa</h1>
                <p class="login-tagline">Simple GST Billing, Inventory &amp; POS for Retail, Restaurant &amp; Salon</p>

                <h2 class="login-heading">Welcome Back</h2>
                <p class="login-subheading">Sign in to your account to continue</p>

                <?php echo $__env->make('include.alert', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

                <?php if($tenantSuspended ?? false): ?>
                    <?php
                        $renewPlan = $subscription?->plan;
                        $renewPrice = $subscription?->planPrice;
                        $renewMessage = "Hi, I'd like to renew my Invoxa subscription (" . request()->getHost() . ').';
                        $renewLink = 'https://wa.me/917600384075?text=' . rawurlencode($renewMessage);
                    ?>
                    <div class="alert alert-danger" role="alert">
                        <strong><?php echo e($subscription?->isOnTrial() ? 'Your free trial has ended.' : 'This account is suspended.'); ?></strong>
                        <p class="mb-0">Renew to get back into your dashboard — nothing has been deleted.</p>
                    </div>

                    <?php if($renewPlan): ?>
                        <div class="form-group" style="background:#f8f8fb;border:1px solid #eef0f3;border-radius:12px;padding:14px 16px;margin-bottom:18px;">
                            <div style="display:flex;justify-content:space-between;font-size:0.9rem;">
                                <span style="color:#6b7280;">Plan</span>
                                <strong><?php echo e($renewPlan->name); ?></strong>
                            </div>
                            <?php if($renewPrice): ?>
                                <div style="display:flex;justify-content:space-between;font-size:0.9rem;margin-top:6px;">
                                    <span style="color:#6b7280;">Billing</span>
                                    <strong><?php echo e(ucfirst($renewPrice->billing_cycle)); ?> — <?php echo e($renewPrice->currency); ?> <?php echo e(number_format((float) $renewPrice->amount, 0)); ?></strong>
                                </div>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>

                    <a href="<?php echo e($renewLink); ?>" class="signin-btn" target="_blank" rel="noopener noreferrer" style="background:#25d366;">
                        Renew via WhatsApp
                    </a>
                <?php else: ?>
                <form class="login-form" method="POST" action="<?php echo e(route('login')); ?>">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="remember" value="1">

                    <div class="form-group">
                        <label class="form-label" for="email">Email</label>
                        <div class="field-shell">
                            <input
                                class="form-control"
                                type="email"
                                id="email"
                                name="email"
                                value="<?php echo e(old('email')); ?>"
                                placeholder="you@fonico.com"
                                required
                                autofocus
                                autocomplete="username">
                        </div>
                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <ul class="parsley-errors-list filled" aria-hidden="false">
                                <li class="parsley-required"><?php echo e($message); ?></li>
                            </ul>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="form-group">
                        <label class="form-label" for="password">Password</label>
                        <div class="field-shell">
                            <input
                                type="password"
                                id="password"
                                name="password"
                                required
                                autocomplete="current-password"
                                class="form-control"
                                placeholder="Enter your password">
                            <button type="button" class="password-toggle" id="passwordToggle" aria-label="Show password">
                                <i class="fe-eye"></i>
                            </button>
                        </div>
                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <ul class="parsley-errors-list filled" aria-hidden="false">
                                <li class="parsley-required"><?php echo e($message); ?></li>
                            </ul>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <button class="signin-btn" type="submit">
                        <i class="fe-log-in"></i> <?php echo e(__('Login to Dashboard')); ?>

                    </button>
                </form>
                <?php endif; ?>
            </div>

            <div class="page-footer">
                <script>document.write(new Date().getFullYear())</script> &copy;
                <a href="https://www.ascentwebservices.com" target="_blank" rel="noopener noreferrer">Ascent Web Services</a>.
                Built for <?php echo e($companySetting->company_name); ?>.
            </div>
        </div>
    </main>

    <script src="<?php echo e(asset('assets/js/vendor.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/app.min.js')); ?>"></script>
    <script>
        const passwordInput = document.getElementById('password');
        const passwordToggle = document.getElementById('passwordToggle');

        if (passwordInput && passwordToggle) {
            passwordToggle.addEventListener('click', function () {
                const nextType = passwordInput.type === 'password' ? 'text' : 'password';
                passwordInput.type = nextType;
                this.setAttribute('aria-label', nextType === 'password' ? 'Show password' : 'Hide password');
                this.innerHTML = nextType === 'password' ? '<i class="fe-eye"></i>' : '<i class="fe-eye-off"></i>';
            });
        }
    </script>
</body>
</html>
<?php /**PATH /var/www/html/resources/views/auth/login.blade.php ENDPATH**/ ?>