<?php $__env->startSection('title', 'Finance Report'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid py-3">
    <div class="card shadow-sm border-0 rounded-4">
        <div class="card-body">
            <div class="d-flex flex-column flex-lg-row justify-content-between align-items-lg-center gap-3">
                <div>
                    <h4 class="mb-1">Finance Report</h4>
                    <p class="text-muted mb-0">Sales, profit, and item count for the selected period.</p>
                </div>
                <div class="d-flex flex-wrap gap-2">
                    <a href="<?php echo e(route('finance-report-export-csv', request()->query())); ?>" class="btn btn-outline-success btn-sm">Export CSV</a>
                    <a href="<?php echo e(route('finance-report-export-pdf', request()->query())); ?>" class="btn btn-outline-danger btn-sm">Export PDF</a>
                </div>
            </div>

            <form method="GET" action="<?php echo e(route('finance-report')); ?>" class="row g-3 mt-2 align-items-end">
                <div class="col-md-3">
                    <label class="form-label">Period</label>
                    <select name="period" class="form-control">
                        <option value="thismonth" <?php echo e(($period ?? 'thismonth') === 'thismonth' ? 'selected' : ''); ?>>This Month</option>
                        <option value="lastmonth" <?php echo e(($period ?? '') === 'lastmonth' ? 'selected' : ''); ?>>Last Month</option>
                        <option value="thisyear" <?php echo e(($period ?? '') === 'thisyear' ? 'selected' : ''); ?>>This Year</option>
                        <option value="custom" <?php echo e(($period ?? '') === 'custom' ? 'selected' : ''); ?>>Custom Range</option>
                    </select>
                </div>
                <div class="col-md-3">
                    <label class="form-label">From Date</label>
                    <input type="date" name="fromdate" class="form-control" value="<?php echo e($fromdate ?? ''); ?>">
                </div>
                <div class="col-md-3">
                    <label class="form-label">To Date</label>
                    <input type="date" name="todate" class="form-control" value="<?php echo e($todate ?? ''); ?>">
                </div>
                <div class="col-md-3">
                    <button type="submit" class="btn btn-primary w-100">Generate</button>
                </div>
            </form>

            <div class="row mt-4 g-3">
                <div class="col-md-3">
                    <div class="border rounded-3 p-3 bg-light h-100">
                        <div class="text-muted small">Sales</div>
                        <div class="fw-bold fs-4"><?php echo e(number_format($summary['totalSales'], 2)); ?></div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="border rounded-3 p-3 bg-light h-100">
                        <div class="text-muted small">Purchase Cost</div>
                        <div class="fw-bold fs-4"><?php echo e(number_format($summary['totalPurchaseCost'], 2)); ?></div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="border rounded-3 p-3 bg-light h-100">
                        <div class="text-muted small">Profit</div>
                        <div class="fw-bold fs-4"><?php echo e(number_format($summary['totalProfit'], 2)); ?></div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="border rounded-3 p-3 bg-light h-100">
                        <div class="text-muted small">Items Sold</div>
                        <div class="fw-bold fs-4"><?php echo e($summary['itemsSold']); ?></div>
                    </div>
                </div>
            </div>

            <div class="row mt-4 g-3">
                <?php $__currentLoopData = $summary['paymentTypeBreakdown']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $paymentType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-3">
                        <div class="border rounded-3 p-3 bg-white h-100">
                            <div class="text-muted small"><?php echo e($paymentType['label']); ?></div>
                            <div class="fw-bold fs-5"><?php echo e($paymentType['count']); ?> invoice(s)</div>
                            <div class="small text-muted mt-2">Sales: <?php echo e(number_format($paymentType['sales'], 2)); ?></div>
                            <div class="small text-muted">Profit: <?php echo e(number_format($paymentType['profit'], 2)); ?></div>
                            <div class="small text-muted">Items: <?php echo e($paymentType['itemsSold']); ?></div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <div class="table-responsive mt-4">
                <table class="table table-bordered table-hover align-middle">
                    <thead class="table-dark">
                        <tr>
                            <th>Date</th>
                            <th>Invoice No</th>
                            <th>Customer</th>
                            <th>Sales</th>
                            <th>Purchase Cost</th>
                            <th>Profit</th>
                            <th>Items</th>
                            <th>Payment</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $invoices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $invoice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($invoice->invoice_date); ?></td>
                                <td><?php echo e($invoice->invoice_no); ?></td>
                                <td><?php echo e($invoice->customer_name); ?></td>
                                <td><?php echo e(number_format((float) $invoice->net_amount, 2)); ?></td>
                                <td><?php echo e(number_format((float) ($invoice->items ?? collect())->sum(function ($item) {
                                    return (float) (
                                        $item->purchase->purchase_cost ??
                                        $item->purchase->purchase_price ??
                                        $item->purchase_cost ??
                                        0
                                    );
                                }), 2)); ?></td>
                                <td><?php echo e(number_format((float) ($invoice->items ?? collect())->sum('profit'), 2)); ?></td>
                                <td><?php echo e((int) ($invoice->items ?? collect())->sum('quantity')); ?></td>
                                <td><?php echo e($invoice->payment_type); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="7" class="text-center text-muted">No records found for this period.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/html/resources/views/reports/finance-report.blade.php ENDPATH**/ ?>