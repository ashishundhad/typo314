<?php $__env->startSection('title'); ?>
    Supplier Ledger
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="container-fluid supplier-ledger-shell">
        <div class="supplier-ledger-hero">
            <div class="row align-items-center">
                <div class="col-lg-8">
                    <h1 class="supplier-ledger-hero__title mb-0">Supplier Purchase Ledger</h1>
                </div>
                <div class="col-lg-4 text-lg-right">
                    <div class="supplier-ledger-hero__badge mt-3 mt-lg-0">
                        <i class="mdi mdi-calendar-range"></i>
                        <span><?php echo e($timePeriod); ?></span>
                    </div>
                </div>
            </div>
        </div>

        <div id="supplierLedgerMetrics">
            <?php echo $__env->make('reports._supplier-ledger-metrics', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        </div>

        <div class="card supplier-ledger-card">
            <div class="card-body">
                <h2 class="supplier-ledger-card__title">All Suppliers</h2>
                <!-- <p class="supplier-ledger-card__subtitle">Filter by time, stock status, or search text to narrow the ledger before opening a supplier.</p> -->

                <div class="supplier-ledger-filter">
                    <form method="GET" id="supplierLedgerFilterForm" action="<?php echo e(route('supplier-ledger')); ?>">
                        <div class="form-row align-items-end">
                            <div class="col-12 col-md-3 mb-3">
                                <label class="supplier-ledger-label" for="supplier-period">Report Period</label>
                                <select name="period" class="form-control" id="supplier-period">
                                    <option value="alls" <?php if($period === 'alls'): echo 'selected'; endif; ?>>All Time</option>
                                    <option value="thismonth" <?php if($period === 'thismonth'): echo 'selected'; endif; ?>>This Month</option>
                                    <option value="lastmonth" <?php if($period === 'lastmonth'): echo 'selected'; endif; ?>>Last Month</option>
                                    <option value="thisyear" <?php if($period === 'thisyear'): echo 'selected'; endif; ?>>This Year</option>
                                    <option value="lastyear" <?php if($period === 'lastyear'): echo 'selected'; endif; ?>>Last Year</option>
                                    <option value="custom" <?php if($period === 'custom'): echo 'selected'; endif; ?>>Custom Range</option>
                                </select>
                            </div>
                            <div class="col-md-2 mb-3 supplier-ledger-date-group <?php if($period === 'custom'): ?> d-block <?php endif; ?>">
                                <label class="supplier-ledger-label" for="supplier-fromdate">From Date</label>
                                <input type="date" id="supplier-fromdate" name="fromdate" class="form-control" value="<?php echo e($fromdate); ?>">
                            </div>
                            <div class="col-md-2 mb-3 supplier-ledger-date-group <?php if($period === 'custom'): ?> d-block <?php endif; ?>">
                                <label class="supplier-ledger-label" for="supplier-todate">To Date</label>
                                <input type="date" id="supplier-todate" name="todate" class="form-control" value="<?php echo e($todate); ?>">
                            </div>
                            <div class="col-12 col-md-2 mb-3">
                                <label class="supplier-ledger-label" for="supplier-status">Stock Status</label>
                                <select name="status" class="form-control" id="supplier-status">
                                    <option value="" <?php if($status === ''): echo 'selected'; endif; ?>>All</option>
                                    <option value="available" <?php if($status === 'available'): echo 'selected'; endif; ?>>Available</option>
                                    <option value="sold" <?php if($status === 'sold'): echo 'selected'; endif; ?>>Sold</option>
                                </select>
                            </div>
                            <div class="col-12 col-md-3 mb-3">
                                <label class="supplier-ledger-label" for="supplier-search">Search</label>
                                <input type="text" id="supplier-search" name="search" class="form-control" value="<?php echo e($search); ?>" placeholder="Supplier, phone, IMEI, model">
                            </div>
                            <div class="col-12 col-md-2 mb-3">
                                <button type="submit" class="btn btn-primary supplier-ledger-btn">Filter Ledger</button>
                            </div>
                            <div class="col-12 col-md-2 mb-3">
                                <a href="<?php echo e(route('supplier-ledger')); ?>" class="btn btn-outline-danger supplier-ledger-btn">Clear</a>
                            </div>
                        </div>
                    </form>
                </div>

                <div id="supplierLedgerTable">
                    <?php echo $__env->make('reports._supplier-ledger-table', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                </div>
            </div>
        </div>
    </div>

    <script>
        (function () {
            const periodSelect = document.getElementById('supplier-period');
            const dateGroups = document.querySelectorAll('.supplier-ledger-date-group');

            function toggleDateGroups() {
                const showDates = periodSelect && periodSelect.value === 'custom';

                dateGroups.forEach(function (group) {
                    group.style.display = showDates ? 'block' : 'none';
                });
            }

            if (periodSelect) {
                periodSelect.addEventListener('change', toggleDateGroups);
                toggleDateGroups();
            }
        })();
    </script>

    <script>
        (function () {
            const $form = $('#supplierLedgerFilterForm');
            const $searchInput = $('#supplier-search');
            const $metrics = $('#supplierLedgerMetrics');
            const $table = $('#supplierLedgerTable');
            let searchDebounce = null;
            let activeRequest = null;

            function loadResults(query) {
                if (activeRequest) {
                    activeRequest.abort();
                }

                activeRequest = $.ajax({
                    url: $form.attr('action'),
                    method: 'GET',
                    data: query,
                    success: function (response) {
                        $metrics.html(response.metrics);
                        $table.html(response.table);

                        if (window.history && window.history.replaceState) {
                            const newUrl = $form.attr('action') + (query ? '?' + query : '');
                            window.history.replaceState(null, '', newUrl);
                        }
                    },
                    complete: function () {
                        activeRequest = null;
                    }
                });
            }

            if ($searchInput.length && $form.length) {
                $searchInput.on('input', function () {
                    clearTimeout(searchDebounce);

                    searchDebounce = setTimeout(function () {
                        loadResults($form.serialize());
                    }, 400);
                });

                $searchInput.on('keydown', function (event) {
                    if (event.key === 'Enter') {
                        event.preventDefault();
                        clearTimeout(searchDebounce);
                        loadResults($form.serialize());
                    }
                });
            }

            $(document).on('click', '#supplierLedgerTable .pagination a', function (event) {
                event.preventDefault();
                const url = new URL($(this).attr('href'), window.location.origin);
                loadResults(url.search.replace(/^\?/, ''));
            });
        })();
    </script>

    <div class="modal fade supplier-ledger-modal" id="supplierPurchasesModal" tabindex="-1" role="dialog"
        aria-labelledby="supplierPurchasesModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-xl" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="supplierPurchasesModalLabel">Supplier Purchases</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div id="supplierPurchasesModalContent" class="supplier-ledger-modal__content">
                        <div class="supplier-ledger-modal__state">
                            <i class="mdi mdi-package-variant-closed"></i>Select a supplier to view purchases.
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        (function () {
            const $modal = $('#supplierPurchasesModal');
            const $content = $('#supplierPurchasesModalContent');
            const $title = $('#supplierPurchasesModalLabel');

            function loadingState(message) {
                return '<div class="supplier-ledger-modal__state"><i class="mdi mdi-loading mdi-spin"></i>' + message + '</div>';
            }

            function errorState(message) {
                return '<div class="supplier-ledger-modal__state"><i class="mdi mdi-alert-circle-outline"></i>' + message + '</div>';
            }

            function toggleDetailDateGroups(container) {
                const periodSelect = container.querySelector('#detail-period');
                const dateGroups = container.querySelectorAll('.supplier-ledger-detail-date-group');

                if (!periodSelect) {
                    return;
                }

                function sync() {
                    const showDates = periodSelect.value === 'custom';
                    dateGroups.forEach(function (group) {
                        group.style.display = showDates ? 'block' : 'none';
                    });
                }

                periodSelect.addEventListener('change', sync);
                sync();
            }

            function loadSupplierPurchases(url, titleText) {
                if (titleText) {
                    $title.text(titleText);
                }

                $modal.modal('show');
                $content.html(loadingState('Loading supplier purchases...'));

                $.ajax({
                    url: url,
                    method: 'GET',
                    data: {
                        modal: 1
                    },
                    success: function (response) {
                        $content.html(response);
                        toggleDetailDateGroups($content.get(0));
                    },
                    error: function () {
                        $content.html(errorState('Unable to load supplier purchases right now.'));
                    }
                });
            }

            $(document).on('click', '.js-supplier-purchases-modal, .js-supplier-ledger-modal-link', function (event) {
                event.preventDefault();
                loadSupplierPurchases($(this).attr('href'), $(this).data('title') || 'Supplier Purchases');
            });

            $(document).on('submit', '.js-supplier-ledger-modal-form', function (event) {
                event.preventDefault();
                const action = $(this).attr('action');
                const query = $(this).serialize();
                loadSupplierPurchases(action + '?' + query, $title.text());
            });

            $(document).on('click', '#supplierPurchasesModal .pagination a', function (event) {
                event.preventDefault();
                loadSupplierPurchases($(this).attr('href'), $title.text());
            });

            $modal.on('hidden.bs.modal', function () {
                $content.html(
                    '<div class="supplier-ledger-modal__state"><i class="mdi mdi-package-variant-closed"></i>Select a supplier to view purchases.</div>'
                );
            });
        })();
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/html/resources/views/reports/supplier-ledger.blade.php ENDPATH**/ ?>