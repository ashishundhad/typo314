<?php $__env->startSection('title'); ?>
    Manage Invoices
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="invoice-workspace">
        <div class="invoice-workspace__header">
            <div>
                <h1 class="invoice-workspace__title">Manage Invoices</h1>
                <!-- <p class="invoice-workspace__subtitle">Browse invoices on the left and review the full receipt preview on the right.</p> -->
            </div>

            <a href="<?php echo e(route('newinvoice')); ?>" class="invoice-workspace__new">
                <i class="mdi mdi-plus-circle-outline"></i>
                <span>New Invoice</span>
            </a>
        </div>

        <div class="invoice-workspace__body">
            <aside class="invoice-sidebar">
                <div class="invoice-sidebar__top">
                    <div class="invoice-sidebar__count">
                        <i class="mdi mdi-receipt-text-outline"></i>
                        <span><?php echo e(number_format($invoices->total())); ?> Invoices</span>
                    </div>

                    <form method="GET" action="<?php echo e(route('allinvoices')); ?>" class="invoice-sidebar__filters">
                        <input
                            type="text"
                            name="search"
                            class="invoice-sidebar__search"
                            value="<?php echo e(request('search')); ?>"
                            placeholder="Search by invoice, customer, phone, IMEI"
                        >

                        <select name="payment_type" class="invoice-sidebar__select">
                            <option value="">All Payment Types</option>
                            <?php $__currentLoopData = $paymentTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($type); ?>" <?php echo e(request('payment_type') === $type ? 'selected' : ''); ?>>
                                    <?php echo e($type); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>

                        <div class="invoice-sidebar__filter-actions">
                            <button type="submit" class="invoice-sidebar__filter-btn invoice-sidebar__filter-btn--primary">
                                <i class="mdi mdi-magnify"></i>
                                <span>Search</span>
                            </button>
                            <a href="<?php echo e(route('allinvoices')); ?>" class="invoice-sidebar__filter-btn">
                                <i class="mdi mdi-refresh"></i>
                                <span>Reset</span>
                            </a>
                        </div>
                    </form>
                </div>

                <div class="invoice-sidebar__list">
                    <?php $__empty_1 = true; $__currentLoopData = $invoices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $invoice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <?php
                            $isActive = $selectedInvoice && $selectedInvoice->id === $invoice->id;
                        ?>
                        <a href="<?php echo e(route('allinvoices', array_merge(request()->except('page'), ['invoice' => $invoice->id]))); ?>" class="invoice-row <?php echo e($isActive ? 'invoice-row--active' : ''); ?>">
                            <div class="invoice-row__top">
                                <div>
                                    <div class="invoice-row__name"><?php echo e(ucfirst($invoice->customer_name ?: 'Walk-in customer')); ?></div>
                                    <div class="invoice-row__number"><?php echo e($invoice->invoice_no); ?></div>
                                </div>
                                <div class="invoice-row__amount">₹<?php echo e(number_format($invoice->net_amount, 2)); ?></div>
                            </div>

                            <div class="invoice-row__bottom">
                                <div class="invoice-row__meta">
                                    <?php echo e(date('d M Y', strtotime($invoice->invoice_date))); ?> · <?php echo e($invoice->created_at?->format('h:i A')); ?>

                                    <?php if($invoice->customer_no): ?>
                                        <br><?php echo e($invoice->customer_no); ?>

                                    <?php endif; ?>
                                </div>
                                <div class="invoice-row__payment">
                                    <i class="mdi mdi-wallet-outline"></i>
                                    <span><?php echo e($invoice->payment_type ?: 'N/A'); ?></span>
                                </div>
                            </div>
                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <div class="invoice-preview__empty" style="min-height: 240px;">
                            <div>
                                <i class="mdi mdi-receipt-text-remove-outline"></i>
                                <h3>No invoices found</h3>
                                <p>No billing records are available yet.</p>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>

                <?php if($invoices->hasPages()): ?>
                    <div class="invoice-sidebar__pagination">
                        <?php echo e($invoices->links('vendor.pagination.simple-bootstrap-4')); ?>

                    </div>
                <?php endif; ?>
            </aside>

            <section class="invoice-preview">
                <?php if($selectedInvoice): ?>
                    <div class="invoice-preview__toolbar">
                        <div class="invoice-preview__identity">
                            <h3><?php echo e($selectedInvoice->invoice_no); ?></h3>
                            <p><?php echo e(ucfirst($selectedInvoice->customer_name ?: 'Walk-in customer')); ?> · <?php echo e(date('d M Y', strtotime($selectedInvoice->invoice_date))); ?> · <?php echo e($selectedInvoice->created_at?->format('h:i A')); ?></p>
                            <div class="invoice-preview__stats">
                                <div class="invoice-preview__status">
                                    <i class="mdi mdi-check-decagram"></i>
                                    <span><?php echo e((int) ($selectedInvoice->is_paid ?? 0) === 1 ? 'Paid' : 'Pending'); ?></span>
                                </div>
                                <div class="invoice-preview__stat">
                                    <!-- <span class="invoice-preview__stat-label">Payment</span> -->
                                    <span class="invoice-preview__stat-value"><?php echo e($selectedInvoice->payment_type ?: 'N/A'); ?></span>
                                </div>
                                <!-- <div class="invoice-preview__stat">
                                    <span class="invoice-preview__stat-label">Total</span>
                                    <span class="invoice-preview__stat-value">₹<?php echo e(number_format($selectedInvoice->total_amount, 2)); ?></span>
                                </div>
                                <div class="invoice-preview__stat">
                                    <span class="invoice-preview__stat-label">Net</span>
                                    <span class="invoice-preview__stat-value invoice-preview__stat-value--accent">₹<?php echo e(number_format($selectedInvoice->net_amount, 2)); ?></span>
                                </div> -->
                            </div>
                        </div>

                        <div class="invoice-preview__actions">
                            <a href="<?php echo e(route('invoice-edit', $selectedInvoice->id)); ?>" class="invoice-preview__btn">
                                <i class="mdi mdi-pencil-outline"></i>
                                <!-- <span>Edit</span> -->
                            </a>
                            <a href="<?php echo e(route('print-invoice', $selectedInvoice->id)); ?>" class="invoice-preview__btn invoice-preview__btn--primary">
                                <i class="mdi mdi-printer"></i>
                                <!-- <span>Print</span> -->
                            </a>
                            <a href="<?php echo e(route('download-pdf', $selectedInvoice->id)); ?>" class="invoice-preview__btn">
                                <i class="mdi mdi-file-pdf-box"></i>
                                <!-- <span>PDF</span> -->
                            </a>
                            <?php if($selectedInvoice->customer_no): ?>
                                <a href="<?php echo e(route('send-whatsapp', ['id' => $selectedInvoice->id])); ?>" target="_blank" class="invoice-preview__btn invoice-preview__btn--wa">
                                    <i class="mdi mdi-whatsapp"></i>
                                    <!-- <span>WhatsApp</span> -->
                                </a>
                            <?php endif; ?>
                            <button type="button" class="invoice-preview__btn delete-invoice" data-id="<?php echo e($selectedInvoice->id); ?>">
                                <i class="mdi mdi-delete-outline"></i>
                                <!-- <span>Delete</span> -->
                            </button>
                        </div>
                    </div>

                    <div class="invoice-preview__stage">
                        <?php echo $__env->make('invoice._document', ['invoice' => $selectedInvoice, 'amountInWords' => $amountInWords], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    </div>

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('returns.create')): ?>
                        <div class="invoice-preview__documents">
                            <h4 class="invoice-preview__documents-title">
                                <i class="mdi mdi-undo-variant"></i> Items — Return
                            </h4>
                            <div class="table-responsive">
                                <table class="table table-bordered mb-0">
                                    <thead>
                                        <tr>
                                            <th>Item</th>
                                            <th>Qty</th>
                                            <th>Returned</th>
                                            <th style="width: 140px;">Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $selectedInvoice->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php
                                                $returned = (int) ($returnedQuantities[$item->id] ?? 0);
                                                $returnable = max(0, (int) $item->quantity - $returned);
                                            ?>
                                            <tr>
                                                <td><?php echo nl2br(e($item->item_description)); ?></td>
                                                <td><?php echo e($item->quantity); ?></td>
                                                <td><?php echo e($returned); ?></td>
                                                <td>
                                                    <?php if($returnable > 0 && $item->purchase): ?>
                                                        <button type="button" class="btn btn-sm btn-outline-danger open-return-modal"
                                                            data-item-id="<?php echo e($item->id); ?>"
                                                            data-item-label="<?php echo e($item->item_description); ?>"
                                                            data-returnable="<?php echo e($returnable); ?>">
                                                            Return
                                                        </button>
                                                    <?php else: ?>
                                                        <span class="text-muted">—</span>
                                                    <?php endif; ?>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    <?php endif; ?>

                    <?php if($selectedInvoice->documents->isNotEmpty()): ?>
                        <div class="invoice-preview__documents">
                            <h4 class="invoice-preview__documents-title">
                                <i class="mdi mdi-card-account-details-outline"></i> Customer Identity Documents
                            </h4>
                            <div class="invoice-preview__documents-grid">
                                <?php $__currentLoopData = $selectedInvoice->documents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $document): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="invoice-preview__document-card">
                                        <a href="<?php echo e($document->image_url); ?>" target="_blank">
                                            <img src="<?php echo e($document->image_url); ?>" alt="<?php echo e($document->document_type_label); ?>">
                                        </a>
                                        <div class="invoice-preview__document-meta">
                                            <span class="invoice-preview__document-type"><?php echo e($document->document_type_label); ?></span>
                                            <span class="invoice-preview__document-number" data-full="<?php echo e($document->document_number); ?>" data-masked="<?php echo e($document->masked_number); ?>"><?php echo e($document->masked_number); ?></span>
                                            <button type="button" class="invoice-preview__document-reveal" title="Show / hide full number">
                                                <i class="mdi mdi-eye-outline"></i>
                                            </button>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    <?php endif; ?>

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('returns.create')): ?>
                        <div class="modal fade" id="returnItemModal" tabindex="-1" role="dialog" aria-hidden="true">
                            <div class="modal-dialog" role="document">
                                <div class="modal-content p-3">
                                    <div class="modal-header">
                                        <h5 class="modal-title">Return Item</h5>
                                        <button type="button" class="close" data-dismiss="modal"><span>&times;</span></button>
                                    </div>
                                    <form action="<?php echo e(route('sale-returns.store')); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" name="invoice_item_id" id="returnInvoiceItemId">
                                        <div class="modal-body">
                                            <p class="mb-3" id="returnItemLabel"></p>
                                            <div class="form-group">
                                                <label>Quantity to Return</label>
                                                <input type="number" name="quantity" id="returnQuantity" class="form-control" min="1" required>
                                            </div>
                                            <div class="form-group">
                                                <label>Condition</label>
                                                <select name="condition" class="form-control" required>
                                                    <option value="resellable">Resellable (restock)</option>
                                                    <option value="damaged">Damaged (do not restock)</option>
                                                </select>
                                            </div>
                                            <div class="form-group">
                                                <label>Reason</label>
                                                <input type="text" name="reason" class="form-control" placeholder="e.g. Customer changed mind, defective unit">
                                            </div>
                                            <div class="form-group">
                                                <label>Notes (optional)</label>
                                                <textarea name="notes" class="form-control" rows="2"></textarea>
                                            </div>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                                            <button type="submit" class="btn btn-danger">Process Return</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>
                <?php else: ?>
                    <div class="invoice-preview__empty">
                        <div>
                            <i class="mdi mdi-file-document-outline"></i>
                            <h3>Select an invoice</h3>
                            <p>Choose any invoice from the left panel to load its printable layout here.</p>
                        </div>
                    </div>
                <?php endif; ?>
            </section>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        $(document).ready(function () {
            $('.delete-invoice').on('click', function () {
                var invoiceId = $(this).data('id');
                var deleteUrl = '/admin/invoice/delete/' + invoiceId;

                Swal.fire({
                    title: 'Delete this invoice?',
                    text: "This will remove the invoice and mark its sold items available again.",
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#d33',
                    cancelButtonColor: '#64748b',
                    confirmButtonText: 'Delete Invoice',
                    cancelButtonText: 'Cancel'
                }).then((result) => {
                    if (result.isConfirmed) {
                        var form = $('<form method="POST" action="' + deleteUrl + '"></form>');
                        form.append('<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">');
                        $('body').append(form);
                        form.submit();
                    }
                });
            });

            // Document reveal-toggle handler lives globally in assets/js/custom.js
            // (also used on the Customers page's documents modal).

            $(document).on('click', '.open-return-modal', function () {
                var itemId = $(this).data('item-id');
                var label = $(this).data('item-label');
                var returnable = $(this).data('returnable');

                $('#returnInvoiceItemId').val(itemId);
                $('#returnItemLabel').text(label + ' — up to ' + returnable + ' unit(s) can be returned.');
                $('#returnQuantity').attr('max', returnable).val(1);

                $('#returnItemModal').modal('show');
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/html/resources/views/invoice/index.blade.php ENDPATH**/ ?>