<?php $__env->startSection('title', 'Role Management'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <!-- start page title -->
        <div class="row align-items-center">

            <!-- Title & Buttons for Mobile -->
            <div class="col-12 d-flex justify-content-between align-items-center mb-2 d-md-none">
                <h4 class="page-title mb-0">Role Management</h4>
                <div class="d-flex align-items-center mt-2">
                    <button type="button" class="btn btn-success btn-sm" data-toggle="modal" data-target="#roleModal">
                        Add
                    </button>
                </div>
            </div>

            <!-- Title for Desktop -->
            <div class="col-md-6 mt-2 mb-2 d-none d-md-block">
                <h4 class="page-title">Role Management</h4>
            </div>

            <!-- Buttons for Desktop -->
            <div class="col-md-6 d-none d-md-flex justify-content-end">
                <button type="button" class="btn btn-success" data-toggle="modal" data-target="#roleModal">
                    Add Role
                </button>
            </div>
        </div>

        <div class="card-box">
            <table id="roleTable" class="table table-bordered">
                <thead>
                    <tr>
                        <th style="width: 5%;">#</th>
                        <th style="width: 25%;">Role Name</th>
                        <th>Permissions</th>
                        <th style="width: 10%;">Action</th>
                    </tr>
                </thead>
                <tbody></tbody>
            </table>
        </div>

        <!-- Add Role Modal -->
        <div class="modal fade" id="roleModal" tabindex="-1" role="dialog" aria-labelledby="roleModalLabel"
            aria-hidden="true">
            <div class="modal-dialog modal-lg" role="document">
                <div class="modal-content p-3">
                    <div class="modal-header">
                        <h5 class="modal-title">Add Role</h5>
                        <button type="button" class="close" data-dismiss="modal">
                            <span>&times;</span>
                        </button>
                    </div>
                    <form action="<?php echo e(route('roles.store')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="id" value="<?php echo e(old('id')); ?>">
                        <div class="modal-body">
                            <div class="form-group">
                                <label>Role Name</label>
                                <input value="<?php echo e(old('name')); ?>" type="text" name="name" class="form-control" required>
                            </div>

                            <!-- Permissions Checkboxes -->
                            <div class="form-group">
                                <label>Permissions</label>
                                <div class="permissions-checkbox-wrapper">
                                    <?php $__currentLoopData = $permissions->groupBy(fn ($permission) => explode('.', $permission->name)[0]); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group => $groupPermissions): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="permission-group">
                                            <label class="permission-group__title">
                                                <input type="checkbox" class="permission-group-toggle" data-group="<?php echo e($group); ?>">
                                                <span><?php echo e(ucwords(str_replace('.', ' ', $group))); ?></span>
                                            </label>
                                            <div class="permission-group__items">
                                                <?php $__currentLoopData = $groupPermissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <label class="permission-item">
                                                        <input type="checkbox" name="permissions[]" value="<?php echo e($permission->name); ?>" class="permission-checkbox" data-group="<?php echo e($group); ?>" <?php echo e(in_array($permission->name, $selectedPermissions ?? []) ? 'checked' : ''); ?>>
                                                        <span><?php echo e($permission->name); ?></span>
                                                    </label>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>

                            
                        </div>
                        <div class="modal-footer">
                            <button class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                            <button type="submit" class="btn btn-primary modal-button">Create Role</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

    <script>
        let editRoleRequestInFlight = false;

        $(function () {
            $('#roleTable').DataTable({
                processing: true,
                serverSide: true,
                scrollX: true,
                ajax: "<?php echo e(route('roles.index')); ?>",
                columns: [
                    { data: 'DT_RowIndex', name: 'DT_RowIndex', className: 'text-center' },
                    { data: 'name', name: 'name' },
                    {
                        data: 'permissions',
                        name: 'permissions',
                        className: 'text-left',
                        render: function (data) {
                            if (!data || data.length === 0) {
                                return '<span class="text-muted">No permissions</span>';
                            }

                            return data.map(p => `<span class="badge badge-primary mr-1">${p}</span>`).join('');
                        }
                    },
                    {
                        data: 'action',
                        name: 'action',
                        className: 'text-center',
                        render: function (data, type, row) {
                            return  '<button class="btn btn-primary btn-sm edit-role mr-2" data-id="' + row.id + '"><i class="fas fa-edit"></i></button>' +
                                    '<button class="btn btn-danger btn-sm delete-role" data-id="' + row.id + '"><i class="fas fa-trash"></i></button>';
                        }
                    }
                ]
            });
        });

        // Group "select all" checkbox toggles its permission checkboxes
        $(document).on('change', '.permission-group-toggle', function () {
            const group = $(this).data('group');
            $('.permission-checkbox[data-group="' + group + '"]').prop('checked', this.checked);
        });

        // Keep group toggle in sync when individual permissions change
        $(document).on('change', '.permission-checkbox', function () {
            const group = $(this).data('group');
            const groupBoxes = $('.permission-checkbox[data-group="' + group + '"]');
            const allChecked = groupBoxes.length === groupBoxes.filter(':checked').length;
            $('.permission-group-toggle[data-group="' + group + '"]').prop('checked', allChecked);
        });

        $('#roleModal form').on('submit', function (e) {
            e.preventDefault();
            const form = $(this);
            const url = form.attr('action');
            const formData = form.serialize();

            $.ajax({
                url: url,
                type: 'POST',
                data: formData,
                success: function (response) {
                    if (response.status) {
                        toastr.success(response.message);

                        // Hide modal and remove backdrop properly
                        $('#roleModal').modal('hide');
                        $('body').removeClass('modal-open');
                        $('.modal-backdrop').remove();

                        // Reset and reload
                        form[0].reset();
                        form.find('.permission-checkbox, .permission-group-toggle').prop('checked', false);
                        form.find('input[name="id"]').remove();
                        form.attr('action', "<?php echo e(route('roles.store')); ?>");
                        $('#roleModal .modal-title').text('Add Role');

                        // Reload table
                        $('#roleTable').DataTable().ajax.reload();
                    } else {
                        toastr.error(response.message || 'Failed to save role.');
                    }
                },
                error: function (xhr) {
                    const msg = xhr.responseJSON?.message || 'Something went wrong.';
                    toastr.error(msg);
                }
            });
        });

        $(document).on('click', '.edit-role', function () {
            if (editRoleRequestInFlight) {
                return;
            }
            editRoleRequestInFlight = true;

            const id = $(this).data('id');
            $.ajax({
                url: '<?php echo e(url('roles')); ?>/' + id + '/edit',
                type: 'GET',
                success: function (res) {
                    const role = res.data;
                    const form = $('#roleModal form');

                    form[0].reset();
                    form.find('input[name="id"]').remove(); // Remove previous hidden input
                    form.find('input[name="name"]').val(role.name);

                    form.find('.permission-checkbox').each(function () {
                        $(this).prop('checked', role.permissions.includes(this.value));
                    });
                    form.find('.permission-group-toggle').each(function () {
                        const group = $(this).data('group');
                        const groupBoxes = form.find('.permission-checkbox[data-group="' + group + '"]');
                        $(this).prop('checked', groupBoxes.length === groupBoxes.filter(':checked').length);
                    });

                    form.attr('action', "<?php echo e(route('roles.store')); ?>"); // Always post to store
                    form.append('<input type="hidden" name="id" value="' + id + '">');

                    $('#roleModal .modal-title').text('Edit Role');
                    $('#roleModal .modal-button').text('Update Role');
                    $('#roleModal').modal('show');
                },
                error: function () {
                    toastr.error('Failed to fetch role data');
                },
                complete: function () {
                    editRoleRequestInFlight = false;
                }
            });
        });

        $(document).on('click', '.delete-role', function () {
            const id = $(this).data('id');
            Swal.fire({
                title: 'Are you sure?',
                text: "You won't be able to revert this!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Yes, delete it!'
            }).then((result) => {
                if (result.isConfirmed) {
                    $.ajax({
                        url: '<?php echo e(route("roles.destroy", ":id")); ?>'.replace(':id', id),
                        type: 'DELETE',
                        data: { _token: '<?php echo e(csrf_token()); ?>' },
                        success: function () {
                            toastr.success('Role deleted successfully');
                            // Reload table
                            $('#roleTable').DataTable().ajax.reload();
                        },
                        error: function () {
                            toastr.error('Failed to delete role');
                            // Reload table
                            $('#roleTable').DataTable().ajax.reload();
                        }
                    });
                }
            });
        });

        // Backdrop cleanup + re-parenting to <body> on show is handled globally
        // for every modal in assets/js/custom.js, so it isn't repeated per view.

        $('#roleModal').on('hidden.bs.modal', function () {
            const form = $('#roleModal form');
            form[0].reset();
            form.attr('action', '<?php echo e(route('roles.store')); ?>');
            form.find('input[name="_method"]').remove();
            form.find('.permission-checkbox, .permission-group-toggle').prop('checked', false);
            $('#roleModal .modal-title').text('Add Role');
            $('#roleModal .modal-button').text('Create Role');
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/html/resources/views/roles/index.blade.php ENDPATH**/ ?>