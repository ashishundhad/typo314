<?php if($documents->isNotEmpty()): ?>
    <div class="invoice-preview__documents-grid">
        <?php $__currentLoopData = $documents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $document): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="invoice-preview__document-card">
                <a href="<?php echo e($document->image_url); ?>" target="_blank">
                    <img src="<?php echo e($document->image_url); ?>" alt="<?php echo e($document->document_type_label); ?>">
                </a>
                <div class="invoice-preview__document-meta">
                    <span class="invoice-preview__document-type"><?php echo e($document->document_type_label); ?></span>
                    <span class="invoice-preview__document-number" data-full="<?php echo e($document->document_number); ?>" data-masked="<?php echo e($document->masked_number); ?>"><?php echo e($document->masked_number); ?></span>
                    <button type="button" class="invoice-preview__document-reveal" title="Show / hide full number">
                        <i class="mdi mdi-eye-outline"></i>
                    </button>
                    <?php if($document->invoice): ?>
                        <a href="<?php echo e(route('invoice-detail', $document->invoice_id)); ?>" class="d-block small mt-1" target="_blank">
                            From invoice #<?php echo e($document->invoice->invoice_no); ?>

                        </a>
                    <?php endif; ?>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php else: ?>
    <div class="supplier-ledger-modal__state">
        <i class="mdi mdi-card-account-details-outline"></i>No identity documents on file for <?php echo e($customer->name); ?>.
    </div>
<?php endif; ?>
<?php /**PATH /var/www/html/resources/views/reports/_customer-documents-content.blade.php ENDPATH**/ ?>